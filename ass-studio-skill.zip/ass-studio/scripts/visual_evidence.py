#!/usr/bin/env python3
"""Build timestamped raw/composite sheets or compare RGBA renders. Requires Pillow."""
import argparse
import csv
from decimal import Decimal, InvalidOperation, ROUND_FLOOR
import hashlib
import json
from pathlib import Path
import sys


def imaging():
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError as exc:
        raise ValueError('Evidence images need Pillow in this Python interpreter') from exc
    return Image, ImageDraw, ImageFont


def path_from(value, parent):
    path = Path(value)
    return path.resolve() if path.is_absolute() else (parent / path).resolve()


def preflight(outputs, inputs, force):
    protected = {Path(p).resolve() for p in inputs}
    for output in outputs:
        if output.resolve() in protected:
            raise ValueError(f'Output would overwrite input: {output}')
        if output.exists() and not force:
            raise ValueError(f'Output already exists: {output}')


def checked_roi(roi, size):
    box = tuple(roi) if roi else (0, 0, *size)
    left, top, right, bottom = box
    if not (0 <= left < right <= size[0] and 0 <= top < bottom <= size[1]):
        raise ValueError('ROI must be a nonempty native-pixel box inside the frame')
    return box


def frame_time(record, ass_offset_ms=0):
    if 'pts_time_text' in record:
        value, method = Decimal(str(record['pts_time_text']))*1000, 'actual_pts_text_floor_ms'
    elif 'pts_time_s' in record:
        value, method = Decimal(str(record['pts_time_s']))*1000, 'actual_pts_seconds_floor_ms'
    else:
        value, method = Decimal(str(record['pts_ms_rounded'])), 'rounded_pts_fallback'
    if not value.is_finite():
        raise ValueError('PTS must be finite')
    # ASS event boundaries are integer milliseconds; round-up can cross a boundary.
    sample = int((value+ass_offset_ms).to_integral_value(rounding=ROUND_FLOOR))
    if sample < 0:
        raise ValueError('Mapped ASS sample is negative; verify the source time origin/offset')
    return value, sample, method


def render_times(manifest, ass_offset_ms=0):
    records=json.loads(Path(manifest).read_text(encoding='utf-8'))['frames']
    frames=[]
    for row in records:
        pts,sample,method=frame_time(row,ass_offset_ms)
        frames.append({'frame_index_0based':int(row['frame_index_0based']),
                       'pts_ms_text':str(pts),'ass_render_time_ms':sample,'method':method})
    if not frames:
        raise ValueError('Frame manifest is empty')
    return {'frames':frames,'unique_ass_times_ms':list(dict.fromkeys(row['ass_render_time_ms'] for row in frames))}


def make_sheet(manifest, output, roi=None, columns=3, width=480, render_report=None,
               ass_offset_ms=0, points_csv=None, force=False):
    Image, ImageDraw, ImageFont = imaging()
    if not 1 <= columns <= 12 or not 32 <= width <= 4096:
        raise ValueError('Choose 1..12 columns and a cell width of 32..4096 pixels')
    source, folder = Path(manifest).resolve(), Path(output).resolve()
    records = json.loads(source.read_text(encoding='utf-8'))['frames']
    if not records:
        raise ValueError('Frame manifest is empty')
    overlays, input_paths = {}, [source]
    if render_report:
        render_path = Path(render_report).resolve()
        input_paths.append(render_path)
        for sample in json.loads(render_path.read_text(encoding='utf-8'))['samples']:
            if 'png' not in sample:
                raise ValueError('Render report sample has no PNG; render with --png-dir')
            stamp = int(sample['time_ms'])
            if stamp in overlays:
                raise ValueError('Duplicate timestamps in render report')
            overlays[stamp] = path_from(sample['png'], render_path.parent)
    landmarks = {}
    if points_csv:
        points_path = Path(points_csv).resolve()
        input_paths.append(points_path)
        with points_path.open(encoding='utf-8-sig', newline='') as handle:
            for point in csv.DictReader(handle):
                if (point.get('status', '').strip() or 'measured') != 'measured':
                    continue
                landmarks.setdefault(int(point['frame_index_0based']), []).append(
                    (point['point_id'], float(point['x']), float(point['y'])))
    prepared, native_size = [], None
    for record in records:
        raw_path = path_from(record['file'], source.parent)
        frame = int(record['frame_index_0based'])
        if frame < 0:
            raise ValueError('Frame index must be nonnegative')
        stamp, ass_stamp, time_method = frame_time(record, ass_offset_ms)
        overlay_path = overlays.get(ass_stamp)
        if render_report and overlay_path is None:
            raise ValueError(f'No exact ASS render timestamp {ass_stamp} ms for frame {frame}; supply the correct offset/render')
        if record.get('overlay'):
            if render_report:
                raise ValueError('Use either frame.overlay or --render-report, not both')
            overlay_path = path_from(record['overlay'], source.parent)
        input_paths.append(raw_path)
        with Image.open(raw_path) as raw:
            if native_size is None: native_size = raw.size
            if raw.size != native_size:
                raise ValueError('Mixed frame dimensions; normalize explicitly before comparing')
        if overlay_path:
            input_paths.append(overlay_path)
            with Image.open(overlay_path) as overlay:
                if overlay.size != native_size:
                    raise ValueError('Overlay and raw dimensions differ; refusing to resize silently')
        prepared.append({'record': record, 'frame': frame, 'stamp': stamp, 'ass_stamp': ass_stamp,'time_method':time_method,
                         'raw': raw_path, 'overlay': overlay_path})
    if len({row['frame'] for row in prepared}) != len(prepared):
        raise ValueError('Duplicate frame indices in manifest')
    crop = checked_roi(roi, native_size)
    outputs = [folder/'sheet.png', folder/'evidence.json']
    outputs += [folder/f"composite_{i:04d}_{row['frame']:06d}.png" for i,row in enumerate(prepared) if row['overlay']]
    preflight(outputs, input_paths, force)
    crop_width, crop_height = crop[2]-crop[0], crop[3]-crop[1]
    height = max(1, round(crop_height * width/crop_width))
    panels = 2 if any(row['overlay'] for row in prepared) else 1
    columns = min(columns, len(prepared))
    rows = (len(prepared)+columns-1)//columns
    tile_height, tile_width = 28 + panels*(height+20), width
    if columns*tile_width*rows*tile_height > 80_000_000:
        raise ValueError('Evidence sheet too large; use a tighter ROI or fewer frames per sheet')
    sheet = Image.new('RGB', (columns*tile_width, rows*tile_height), '#171b22')
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()
    mapping = []
    folder.mkdir(parents=True, exist_ok=True)
    for i, row in enumerate(prepared):
        left, top = i % columns * tile_width, i // columns * tile_height
        draw.text((left+4, top+4), f"f{row['frame']} | PTS {row['stamp']} ms | ASS {row['ass_stamp']} ms", fill='white', font=font)
        with Image.open(row['raw']) as image:
            raw = image.convert('RGBA')
        views = [('raw', raw)]
        if row['overlay']:
            with Image.open(row['overlay']) as image:
                overlay = image.convert('RGBA')
            composite = Image.alpha_composite(raw, overlay)
            composite.save(folder/f"composite_{i:04d}_{row['frame']:06d}.png")
            views.append(('candidate composite', composite))
        elif panels == 2:
            views.append(('no overlay', raw))
        for panel, (label, image) in enumerate(views):
            y = top+28+panel*(height+20)
            thumb = image.crop(crop).resize((width, height), getattr(Image, 'Resampling', Image).LANCZOS).convert('RGB')
            marker = ImageDraw.Draw(thumb)
            for name, x, py in landmarks.get(row['frame'], []):
                if not (crop[0] <= x < crop[2] and crop[1] <= py < crop[3]): continue
                tx = (x-crop[0]+.5)*width/crop_width-.5
                ty = (py-crop[1]+.5)*height/crop_height-.5
                marker.line((tx-5,ty,tx+5,ty),fill='#00ffb4',width=1)
                marker.line((tx,ty-5,tx,ty+5),fill='#00ffb4',width=1)
                marker.text((tx+5,ty+2),name,fill='#00ffb4',font=font)
            sheet.paste(thumb, (left, y))
            draw.text((left+4,y+height+2),label,fill='white',font=font)
            mapping.append({'frame_index_0based':row['frame'],'pts_ms_text':str(row['stamp']),
                            'ass_render_time_ms':row['ass_stamp'],'timestamp_method':row['time_method'],'panel':label,
                            'sheet_content_box':[left,y,left+width,y+height],
                            'native_crop_box':list(crop),'scale_native_to_sheet':[width/crop_width,height/crop_height],
                            'raw_file':str(row['raw']),'overlay_file':str(row['overlay']) if row['overlay'] else None})
    sheet.save(folder/'sheet.png')
    report = {'schema':'ass-studio.evidence.v1','manifest':str(source),
              'manifest_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
              'native_size':list(native_size),'ass_offset_ms':ass_offset_ms,
              'sheet':str(folder/'sheet.png'),'panels':mapping,
              'coordinate_convention':'zero-based pixel centers; panel boxes are pixel-edge bounds',
              'coordinate_inverse':'native_x = crop_left + (sheet_x - panel_left + 0.5) / scale_x - 0.5; same for y',
              'limits':'PNG-space alpha composite. Not a proof of player YCbCr pipeline or visual accuracy. Thumbnail coordinates require the saved crop/scale mapping.'}
    (folder/'evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return report


def compare_images(before, after, output, roi=None, force=False):
    Image, _, _ = imaging()
    try:
        import numpy as np
    except ImportError as exc:
        raise ValueError('RGBA comparison needs NumPy') from exc
    source_a, source_b, folder = Path(before).resolve(), Path(after).resolve(), Path(output).resolve()
    outputs = [folder/'difference.png',folder/'blend.png',folder/'compare.json']
    preflight(outputs,[source_a,source_b],force)
    with Image.open(source_a) as a, Image.open(source_b) as b:
        if a.size != b.size:
            raise ValueError('Image dimensions differ; no implicit resizing is allowed')
        crop = checked_roi(roi,a.size)
        left, right = a.convert('RGBA').crop(crop), b.convert('RGBA').crop(crop)
    def premultiplied(image):
        data=np.asarray(image,dtype=float)/255
        data[:,:,:3]*=data[:,:,3:4]
        return data
    delta=np.abs(premultiplied(left)-premultiplied(right))
    per_pixel=delta.max(axis=2)
    changed=per_pixel > (0.5/255)
    heat=np.rint(np.clip(per_pixel*8,0,1)*255).astype('uint8')
    folder.mkdir(parents=True,exist_ok=True)
    Image.fromarray(heat).save(folder/'difference.png')
    Image.blend(left,right,.5).save(folder/'blend.png')
    report={'schema':'ass-studio.compare.v1','before':str(source_a),'after':str(source_b),
            'native_crop_box':list(crop),'changed_pixels':int(changed.sum()),'roi_pixels':int(changed.size),
            'max_premultiplied_rgba_error_255':float(delta.max()*255),
            'rmse_premultiplied_rgba_255':float(np.sqrt((delta**2).mean())*255),
            'limits':'Premultiplied RGBA difference, ignoring invisible RGB. Heatmap is amplified 8x; metrics measure this ROI only, not semantic correctness.'}
    (folder/'compare.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest='command',required=True)
    times=commands.add_parser('times');times.add_argument('manifest');times.add_argument('--ass-offset-ms',type=int,default=0)
    sheet=commands.add_parser('sheet')
    sheet.add_argument('manifest');sheet.add_argument('--render-report');sheet.add_argument('--points-csv')
    sheet.add_argument('--ass-offset-ms',type=int,default=0)
    sheet.add_argument('--columns',type=int,default=3);sheet.add_argument('--width',type=int,default=480)
    compare=commands.add_parser('compare');compare.add_argument('before');compare.add_argument('after')
    for command in [sheet,compare]:
        command.add_argument('--roi',type=int,nargs=4,metavar=('LEFT','TOP','RIGHT','BOTTOM'))
        command.add_argument('--output',required=True);command.add_argument('--force',action='store_true')
    args=parser.parse_args()
    try:
        if args.command=='times':
            print(json.dumps(render_times(args.manifest,args.ass_offset_ms)))
        elif args.command=='sheet':
            report=make_sheet(args.manifest,args.output,args.roi,args.columns,args.width,
                              args.render_report,args.ass_offset_ms,args.points_csv,args.force)
            print(json.dumps({'sheet':report['sheet'],'panels':len(report['panels'])}))
        else:
            print(json.dumps(compare_images(args.before,args.after,args.output,args.roi,args.force)))
        return 0
    except (ValueError,OSError,KeyError,TypeError,InvalidOperation) as exc:
        print(f'ERROR: {exc}',file=sys.stderr);return 2


if __name__=='__main__':
    sys.exit(main())
