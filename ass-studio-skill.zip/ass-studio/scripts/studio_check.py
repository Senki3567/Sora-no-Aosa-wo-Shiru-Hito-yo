#!/usr/bin/env python3
"""Report local ASS Studio prerequisites without installing or changing settings."""
import argparse
import ctypes.util
import importlib.metadata
import importlib.util
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys


def inspect_environment(probe=False):
    modules = {}
    for module, package in [('PIL', 'Pillow'), ('numpy', 'numpy'), ('scipy', 'scipy'),
                            ('cv2', 'opencv-python'), ('fontTools', 'fonttools')]:
        available = importlib.util.find_spec(module) is not None
        try:
            version = importlib.metadata.version(package) if available else None
        except importlib.metadata.PackageNotFoundError:
            version = None
        modules[module] = {'available': available, 'version': version}
    commands = {name: {'path': shutil.which(name)} for name in
                ['ffmpeg', 'ffprobe', 'blender', 'aegisub-cli', 'claude', 'opencode', 'agy']}
    if probe:
        # Probe only documented version switches, never initialize a harness/session.
        for name, switch in [('ffmpeg', '-version'), ('ffprobe', '-version'), ('blender', '--version')]:
            if not commands[name]['path']:
                continue
            try:
                p = subprocess.run([commands[name]['path'], switch], capture_output=True,
                                   text=True, timeout=15)
                lines = (p.stdout + p.stderr).splitlines()
                commands[name].update(exit_code=p.returncode, version_line=lines[0] if lines else '')
            except (OSError, subprocess.TimeoutExpired) as exc:
                commands[name]['probe_error'] = str(exc)
    libass = ctypes.util.find_library('ass')
    return {
        'schema': 'ass-studio.environment.v1',
        'skill_root': str(Path(__file__).resolve().parent.parent),
        'python': {'executable': sys.executable, 'version': platform.python_version()},
        'platform': platform.system(), 'commands': commands, 'modules': modules,
        'libass_library': libass,
        'capabilities': {
            'field_edits': True,
            'frame_extraction': all(commands[n]['path'] for n in ['ffmpeg', 'ffprobe']),
            'evidence_images': modules['PIL']['available'],
            'landmark_fitting': modules['numpy']['available'],
            'motion_reverse_and_compile': bool(modules['PIL']['available'] and modules['numpy']['available']),
            'layout_overflow_scan': bool(libass),
            'rgba_render_prerequisites': bool(libass and modules['PIL']['available'] and modules['numpy']['available']),
            'image_perception': 'unknown: verify the current model and image-view tool',
            'automation_macros': 'unknown: binary, include paths, script dependencies and display need a real macro trial',
        },
        'limits': 'Availability is not an end-to-end test. No credentials or harness configuration were read.'
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--probe', action='store_true', help='Also run bounded ffmpeg/ffprobe/Blender version probes')
    args = parser.parse_args()
    print(json.dumps(inspect_environment(args.probe), ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
