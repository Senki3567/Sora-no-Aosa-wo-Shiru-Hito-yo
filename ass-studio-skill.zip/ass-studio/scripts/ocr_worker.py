#!/usr/bin/env python3
"""Hardsub Mega-Batch Tiler, OCR coverage validator, and ASS exporter.

The script performs mechanical I/O only. Agents own all linguistic OCR review,
semantic alignment, copyediting, classification, and line-break decisions.
"""
import os
import sys
import re
import json
import subprocess
import concurrent.futures
import glob
import tempfile
import time
import shutil
import math
import base64
import urllib.error
import urllib.request
import urllib.parse
from PIL import Image, ImageDraw, ImageStat


class TechnicalPipelineError(RuntimeError):
    """A deterministic I/O failure that must be fixed before asking an agent."""


class GeminiQuotaExhausted(TechnicalPipelineError):
    """Every permitted key/model pair returned quota exhaustion for a batch."""


class SourceStaleError(TechnicalPipelineError):
    """An artifact references a source identity that no longer matches disk."""


class OcrSchemaError(TechnicalPipelineError):
    """Gemini returned a response that violates the OCR contract."""


class CapturePipelineError(TechnicalPipelineError):
    """ffmpeg/JPEG capture failed after the permitted retry."""


EXIT_INPUT = 64
EXIT_CAPTURE = 65
EXIT_SCHEMA = 66
EXIT_QUOTA = 75
EXIT_STALE = 76
EXIT_REVIEW = 77


def _file_identity(path):
    """Cheap, deterministic source identity; avoids hashing multi-GB video files."""
    stat = os.stat(path)
    return {
        "path": os.path.abspath(path),
        "size": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
    }


def _identity_matches(expected):
    """Return false rather than guessing when a source was replaced or moved."""
    try:
        actual = _file_identity(expected["path"])
    except (KeyError, OSError):
        return False
    return actual == {key: expected.get(key) for key in ("path", "size", "mtime_ns")}


def _compact_process_error(stderr, limit=600):
    """Keep actionable process diagnostics without dumping noisy ffmpeg logs."""
    text = (stderr or "").strip().replace("\x00", " ")
    return text[-limit:] if text else "ffmpeg không trả về chẩn đoán"


def _probe_video(video_path):
    """Validate the input has one decodable video stream before fan-out extraction."""
    if not os.path.isfile(video_path):
        raise TechnicalPipelineError(f"Không tìm thấy video: {video_path}")
    try:
        result = subprocess.run(
            [
                "ffprobe", "-v", "error", "-select_streams", "v:0",
                "-show_entries", "stream=codec_name,width,height,duration",
                "-show_entries", "format=duration", "-of", "json", video_path,
            ],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    except FileNotFoundError as exc:
        raise TechnicalPipelineError("Không tìm thấy ffprobe trong PATH.") from exc
    except subprocess.TimeoutExpired as exc:
        raise TechnicalPipelineError(f"ffprobe timeout khi đọc video: {video_path}") from exc

    if result.returncode != 0:
        raise TechnicalPipelineError(
            f"ffprobe không đọc được video {video_path}: {_compact_process_error(result.stderr)}"
        )
    try:
        payload = json.loads(result.stdout)
        stream = payload.get("streams", [])[0]
        duration = float(stream.get("duration") or payload.get("format", {}).get("duration"))
        width = int(stream["width"])
        height = int(stream["height"])
    except (IndexError, KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise TechnicalPipelineError(f"Video không có stream hình hợp lệ: {video_path}") from exc
    if not math.isfinite(duration) or duration <= 0 or width <= 0 or height <= 0:
        raise TechnicalPipelineError(f"Metadata video không hợp lệ: {video_path}")
    return {"duration": duration, "width": width, "height": height, "codec": stream.get("codec_name", "")}


def _prepare_items_for_video(video_path, items):
    """Validate timestamps once and attach the physical end of the source video."""
    if not items:
        raise TechnicalPipelineError("Không có cue nào được chọn; kiểm tra file ASS hoặc --styles.")
    meta = _probe_video(video_path)
    malformed = []
    for item in items:
        start, end = item["start_sec"], item["end_sec"]
        if not (math.isfinite(start) and math.isfinite(end) and 0 <= start < end):
            malformed.append(str(item["id"]))
        item["video_duration"] = meta["duration"]
    if malformed:
        raise TechnicalPipelineError(
            "Timestamp subtitle không hợp lệ ở cue: " + ", ".join(malformed[:20])
        )
    return meta


def _capture_frame(video_path, timestamp, video_filter, output_path):
    """Capture one verified frame atomically, retrying transient decoder failures once."""
    tmp_path = f"{output_path}.part-{os.getpid()}.jpg"
    last_error = ""
    for attempt in range(1, 3):
        try:
            result = subprocess.run(
                [
                    "ffmpeg", "-nostdin", "-threads", "1", "-ss", f"{timestamp:.3f}",
                    "-i", video_path, "-vf", video_filter, "-frames:v", "1", "-q:v", "2",
                    "-y", tmp_path,
                ],
                capture_output=True,
                text=True,
                timeout=90,
                check=False,
            )
            if result.returncode == 0 and os.path.exists(tmp_path):
                with Image.open(tmp_path) as image:
                    image.verify()
                os.replace(tmp_path, output_path)
                return None
            last_error = _compact_process_error(result.stderr)
        except FileNotFoundError:
            last_error = "Không tìm thấy ffmpeg trong PATH."
        except subprocess.TimeoutExpired:
            last_error = "ffmpeg timeout sau 90 giây."
        except (OSError, Image.UnidentifiedImageError) as exc:
            last_error = str(exc)
        finally:
            if os.path.exists(tmp_path):
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
        if attempt == 1:
            time.sleep(0.25)
    return last_error or "Không trích được frame."

# ==================== PHẦN 1: SUBTITLE PARSER (ASS / SRT) ====================

def tc_to_sec(tc):
    """Chuyển timestamp H:MM:SS.CS hoặc HH:MM:SS,MS sang giây."""
    tc = str(tc or "").strip().replace(",", ".")
    parts = tc.split(":")
    if len(parts) == 3:
        try:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
        except ValueError:
            return 0.0
    return 0.0

def sec_to_ass_tc(sec):
    """Chuyển giây sang format ASS H:MM:SS.CS."""
    sec = max(0.0, float(sec))
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = sec % 60
    return f"{h}:{m:02d}:{s:05.2f}"

def sec_to_srt_tc(sec):
    """Chuyển giây sang format SRT HH:MM:SS,MS."""
    sec = max(0.0, float(sec))
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = int(sec % 60)
    ms = int(round((sec - int(sec)) * 1000))
    if ms >= 1000:
        s += 1
        ms -= 1000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def strip_ass_tags(t):
    """Loại bỏ thẻ ASS và ký tự xuống dòng đặc biệt để lấy plain text."""
    if not t:
        return ""
    t = re.sub(r"\{[^}]*\}", "", str(t))
    t = t.replace("\\N", " ").replace("\\n", " ").replace("\\h", " ")
    t = re.sub(r"\s+", " ", t).strip()
    return t

def ass_leading_tags(t):
    """Trích xuất khối thẻ override ở đầu dòng ASS (chỉ các thẻ bắt đầu bằng {\\)."""
    m = re.match(r"^((?:\{\\[^}]*\})+)", str(t or ""))
    return m.group(1) if m else ""

def parse_sub_file(sub_path, styles=None):
    """
    Parse file .ass hoặc .srt.
    styles: set of style names to keep (None = keep all).
    Trả về: (items, raw_lines, is_ass, ass_header)
    """
    with open(sub_path, "r", encoding="utf-8-sig", errors="ignore") as f:
        content = f.read()

    items = []
    is_ass = sub_path.lower().endswith(".ass") or ".ass." in sub_path.lower() or "[Script Info]" in content

    raw_lines = content.splitlines(keepends=True)
    ass_header = ""

    if is_ass:
        header_match = re.search(r"(?is)^(.*?\[Events\][^\S\r\n]*\r?\n\s*Format:[^\r\n]*\r?\n)", content)
        if header_match:
            ass_header = header_match.group(1)

        for idx, line in enumerate(raw_lines):
            s = line.strip()
            if not s or s.startswith(";"):
                continue
            m = re.match(r"(?i)^Dialogue\s*:\s*", line)
            if not m:
                continue

            payload = line[m.end():].rstrip("\r\n")
            parts = payload.split(",", 9)
            if len(parts) == 10:
                layer, start_raw, end_raw, style, name, ml, mr, mv, effect = [p.strip() for p in parts[:9]]
                # Style filter
                if styles is not None and style not in styles:
                    continue
                text_raw = parts[9]
                # Check if there is an existing inline comment (non-backslash)
                comment_match = re.search(r"\{([^\}\\]+)\}", text_raw)
                if comment_match:
                    clean_text = comment_match.group(1).strip()
                else:
                    clean_text = strip_ass_tags(text_raw)
                    clean_text = re.sub(r"^\[(?:NEED_FIX:)?[A-Z_]+\]\s*", "", clean_text).strip()
                leading_tags = ass_leading_tags(text_raw)
                items.append({
                    "id": len(items) + 1,
                    "line_idx": idx,
                    "start_sec": tc_to_sec(start_raw),
                    "end_sec": tc_to_sec(end_raw),
                    "start_raw": start_raw,
                    "end_raw": end_raw,
                    "en_ref": clean_text,
                    "leading_tags": leading_tags,
                    "text_raw": text_raw,
                    "ass_fields": {
                        "layer": layer,
                        "style": style,
                        "name": name,
                        "ml": ml,
                        "mr": mr,
                        "mv": mv,
                        "effect": effect
                    },
                    "raw_line": line
                })
    else:
        # SRT Parser
        def flush_block(b):
            if len(b) >= 2:
                tc_line_idx = 1 if re.match(r"^\d+$", b[0].strip()) else 0
                if tc_line_idx < len(b):
                    m = re.match(r"(\d{2}:\d{2}:\d{2}[,\.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,\.]\d{3})", b[tc_line_idx].strip())
                    if m:
                        text_lines = b[tc_line_idx + 1:]
                        clean_text = "\n".join(tl.strip() for tl in text_lines if tl.strip())
                        items.append({
                            "id": len(items) + 1,
                            "start_sec": tc_to_sec(m.group(1)),
                            "end_sec": tc_to_sec(m.group(2)),
                            "start_raw": m.group(1).strip(),
                            "end_raw": m.group(2).strip(),
                            "en_ref": clean_text,
                            "leading_tags": "",
                            "ass_fields": {},
                            "raw_line": "".join(b)
                        })

        block = []
        for line in raw_lines:
            if line.strip():
                block.append(line)
            else:
                flush_block(block)
                block = []
        flush_block(block)

    return items, raw_lines, is_ass, ass_header

# ==================== PHẦN 2: MEGA-BATCH TILER & FRAME EXTRACTOR ====================

def _tag_sort_key(item):
    tag = item[0]
    return _label_sort_key(tag)


def _label_sort_key(tag):
    m = re.match(r"^(\d+)([A-Za-z]*)$", tag)
    if m:
        return (int(m.group(1)), m.group(2))
    return (999999, tag)

def _crop_filter(crop_mode):
    """Return a deterministic visual transform; never infer subtitle semantics."""
    filters = {
        "bottom": "crop=in_w:in_h*0.24:0:in_h*0.74,scale=560:-2:flags=lanczos",
        "top": "crop=in_w:in_h*0.24:0:in_h*0.02,scale=560:-2:flags=lanczos",
        "full": "scale=560:-2:flags=lanczos",
    }
    if crop_mode not in filters:
        raise ValueError(f"crop_mode phải là một trong: {', '.join(filters)}")
    return filters[crop_mode]


def _safe_interval_detail(item):
    """Return the usable physical interval and a machine-readable failure when absent."""
    start = item["start_sec"]
    end = item["end_sec"]
    c_start = max(float(item.get("clamp_prev_end", 0.0)) + 0.05, start)
    c_end = min(float(item.get("clamp_next_start", end + 2.0)) - 0.05, end)
    video_duration = item.get("video_duration")
    if video_duration is not None:
        c_end = min(c_end, max(0.0, float(video_duration) - 0.02))
    if c_start < c_end:
        return (c_start, c_end), None
    if video_duration is not None and start >= float(video_duration) - 0.02:
        return None, "OUT_OF_VIDEO_RANGE"
    return None, "UNSAFE_OVERLAP"


def _safe_interval(item):
    """Compatibility helper for callers that only need the physical interval."""
    interval, _ = _safe_interval_detail(item)
    return interval


def _atomic_json_dump(path, data, *, indent=None, separators=None):
    """Write only complete JSON files so interrupted jobs never look successful."""
    parent = os.path.dirname(os.path.abspath(path))
    os.makedirs(parent, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".hardsub-", suffix=".json", dir=parent, text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=indent, separators=separators)
            f.write("\n")
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass
        raise


def _atomic_text_write(path, content, *, encoding="utf-8-sig"):
    parent = os.path.dirname(os.path.abspath(path))
    os.makedirs(parent, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".hardsub-", suffix=".tmp", dir=parent, text=True)
    try:
        with os.fdopen(fd, "w", encoding=encoding) as f:
            f.write(content)
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass
        raise


def _is_uniform_strip(image):
    """Only prefill a visually uniform tile; darkness by itself is never evidence."""
    stat = ImageStat.Stat(image)
    return max(stat.stddev) < 1.0


def _save_contact_sheet(tiles, output_path, columns=3):
    """Write labelled 3-column contact sheets without changing source pixels."""
    if not tiles:
        return None
    cols = min(columns, len(tiles))
    tile_w = max(image.width for _, image in tiles)
    tile_h = max(image.height for _, image in tiles)
    rows = math.ceil(len(tiles) / cols)
    canvas = Image.new("RGB", (tile_w * cols, tile_h * rows), (0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    for index, (tag, image) in enumerate(tiles):
        x = (index % cols) * tile_w
        y = (index // cols) * tile_h
        canvas.paste(image, (x, y))
        draw.rectangle([x + 8, y + 2, x + 118, y + 28], fill=(0, 0, 0))
        draw.text((x + 12, y + 5), f"#{tag}", fill=(255, 255, 0))
        draw.rectangle([x, y, x + tile_w - 1, y + tile_h - 1], outline=(255, 0, 0), width=2)
    canvas.save(output_path, quality=95, optimize=True)
    return {"columns": cols, "rows": rows, "tile_width": tile_w, "tile_height": tile_h}


def build_mega_batches(video_path, items, out_dir="/tmp/sub_ocr", batch_size=20, crop_mode="bottom", source_info=None):
    """Extract one safe midpoint per cue and build validated, 3-column OCR sheets."""
    if not isinstance(batch_size, int) or batch_size < 1:
        raise TechnicalPipelineError("batch_size phải là số nguyên dương.")
    video_meta = _prepare_items_for_video(video_path, items)
    os.makedirs(f"{out_dir}/frames", exist_ok=True)
    os.makedirs(f"{out_dir}/batches", exist_ok=True)

    vf = _crop_filter(crop_mode)
    manifest = {
        "version": 2,
        "run_id": f"{int(time.time())}-{os.getpid()}",
        "source": {"video": _file_identity(video_path), "video_meta": video_meta, **(source_info or {})},
        "render": {"crop_mode": crop_mode, "filter": vf, "batch_size": batch_size, "columns": 3},
        "cues": {},
        "labels": {},
        "prefilled": {},
        "unsafe": {},
        "batches": {},
    }

    def extract_item_frame(item):
        tag = f"{item['id']:03d}"
        interval, unsafe_status = _safe_interval_detail(item)
        if interval is None:
            return tag, None, {"status": unsafe_status, "start": item["start_sec"], "end": item["end_sec"]}
        c_start, c_end = interval
        timestamp = c_start + (c_end - c_start) * 0.50
        path = f"{out_dir}/frames/f_{tag}.jpg"
        error = _capture_frame(video_path, timestamp, vf, path)
        meta = {"timestamp": round(timestamp, 3), "safe_start": round(c_start, 3), "safe_end": round(c_end, 3)}
        if error:
            meta.update({"status": "EXTRACT_FAILED", "error": error})
            return tag, None, meta
        meta["status"] = "READY"
        return tag, path, meta

    all_extracted = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, os.cpu_count() or 4)) as executor:
        futures = [executor.submit(extract_item_frame, item) for item in items]
        for future in concurrent.futures.as_completed(futures):
            tag, path, meta = future.result()
            manifest["cues"][tag] = meta
            if path:
                all_extracted.append((tag, path))
                manifest["labels"][tag] = meta
            else:
                manifest["unsafe"][tag] = meta
    all_extracted.sort(key=_tag_sort_key)

    visual = []
    for tag, path in all_extracted:
        try:
            with Image.open(path) as source_image:
                image = source_image.convert("RGB")
            if _is_uniform_strip(image):
                manifest["prefilled"][tag] = "[EMPTY]"
                manifest["labels"].pop(tag, None)
            else:
                visual.append((tag, image))
        except (OSError, Image.UnidentifiedImageError) as exc:
            manifest["labels"].pop(tag, None)
            manifest["unsafe"][tag] = {"status": "TILER_FAILED", "error": str(exc)}

    batches = []
    for index in range(0, len(visual), batch_size):
        tiles = visual[index:index + batch_size]
        batch_name = f"batch_{index // batch_size + 1:02d}.jpg"
        batch_path = os.path.join(out_dir, "batches", batch_name)
        layout = _save_contact_sheet(tiles, batch_path)
        manifest["batches"][batch_name] = {"labels": [tag for tag, _ in tiles], "layout": layout}
        batches.append(batch_path)

    manifest["summary"] = {
        "visual_labels": len(manifest["labels"]),
        "prefilled_empty": len(manifest["prefilled"]),
        "technical_failures": sum(1 for value in manifest["unsafe"].values() if value.get("status") == "EXTRACT_FAILED"),
    }
    _atomic_json_dump(f"{out_dir}/batch_manifest.json", manifest, indent=2)
    if manifest["prefilled"]:
        _atomic_json_dump(f"{out_dir}/pre_empty.json", manifest["prefilled"], indent=2)
    print(f"✅ Tạo {len(batches)} contact sheet 3 cột tại {out_dir}/batches/ | OCR: {len(manifest['labels'])} | prefill uniform: {len(manifest['prefilled'])}")
    return batches

# ==================== PHẦN 3: OCR HANDOFF & STRUCTURAL VALIDATION ====================

VALID_METHODS = {
    "DIRECT", "MERGE_N1", "MERGED_INTO", "COPY_M", "DUP_CASCADE",
    "MISSING_ROLLOVER", "RESCUE_CAND", "TOP_RESCUE", "RESCUE", "SEQ_SPLIT",
    "NEED_SEQ_PROBE", "NEED_SEMANTIC_REVIEW", "MISSING",
}


def _ocr_text(value):
    """Read the literal OCR payload only; never merge, correct, or classify language."""
    if isinstance(value, dict):
        value = value.get("text", "")
    return str(value or "").strip()


def _normalise_ocr_label(label):
    """Normalize only the mechanical label form (#001 == 1), never its text."""
    clean = str(label).lstrip("#")
    return str(int(clean)) if clean.isdigit() else clean


def _normalise_ocr_dict(ocr_data):
    """Normalize OCR keys and reject ambiguous duplicate labels."""
    normalized = {}
    for key, value in ocr_data.items():
        normalized_key = _normalise_ocr_label(key)
        if normalized_key in normalized and normalized[normalized_key] != value:
            raise ValueError(f"OCR có hai giá trị khác nhau cho label {normalized_key!r}.")
        normalized[normalized_key] = value
    return normalized


def _load_run_manifest(batches_dir):
    """Load the one manifest that owns an OCR run, never infer labels from pixels."""
    root = os.path.dirname(os.path.abspath(batches_dir.rstrip(os.sep)))
    batch_manifest = os.path.join(root, "batch_manifest.json")
    if os.path.exists(batch_manifest):
        with open(batch_manifest, "r", encoding="utf-8") as f:
            return json.load(f), batch_manifest
    rescue_manifest = os.path.join(root, "rescue_manifest.json")
    if os.path.exists(rescue_manifest):
        with open(rescue_manifest, "r", encoding="utf-8") as f:
            return json.load(f), rescue_manifest
    return None, None


def _load_expected_labels(batches_dir):
    """Load extraction labels so missing OCR can never be silently classified as MISSING."""
    data, manifest_path = _load_run_manifest(batches_dir)
    if data is None:
        return None, {}, None
    if "labels" in data:
        labels = set(data.get("labels", {})) | set(data.get("prefilled", {}))
        unsafe = data.get("unsafe", {})
    else:  # Compatibility with an existing rescue manifest.
        labels = {key for key, meta in data.items() if meta.get("type") != "UNSAFE_OVERLAP"}
        unsafe = {}
    return (
        {_normalise_ocr_label(key) for key in labels},
        {_normalise_ocr_label(key): value for key, value in unsafe.items()},
        manifest_path,
    )


def _expected_batch_labels(batches_dir, batch_path):
    """Return exactly the keys Gemini must emit for this one contact sheet."""
    data, manifest_path = _load_run_manifest(batches_dir)
    if not data or "batches" not in data:
        raise TechnicalPipelineError(f"Manifest batch v2 không tồn tại cho {batch_path}.")
    entry = data["batches"].get(os.path.basename(batch_path))
    if not entry:
        raise TechnicalPipelineError(f"Không có label manifest cho batch: {batch_path}")
    return {_normalise_ocr_label(label) for label in entry.get("labels", [])}, manifest_path


def _validate_exact_labels(ocr_data, expected, scope):
    actual = {_normalise_ocr_label(key) for key in ocr_data}
    missing = sorted(expected - actual)
    unexpected = sorted(actual - expected)
    if missing or unexpected:
        parts = [scope]
        if missing:
            parts.append("thiếu label: " + ", ".join(missing[:20]))
        if unexpected:
            parts.append("label ngoài manifest: " + ", ".join(unexpected[:20]))
        raise ValueError("OCR không khớp manifest; " + " | ".join(parts))


def _validate_ocr_coverage(ocr_data, batches_dir):
    expected, unsafe, manifest_path = _load_expected_labels(batches_dir)
    if expected is None:
        return
    _validate_exact_labels(ocr_data, expected, f"manifest={manifest_path}")
    if unsafe:
        print(f"⚠️ {len(unsafe)} cue không có vùng lấy mẫu an toàn; agent phải xử lý như UNSAFE_OVERLAP, không tự gán MISSING.")


def _require_fresh_ocr(ocr_file, batches_dir):
    """Reject OCR that belongs to another run or whose source has changed."""
    manifest, manifest_path = _load_run_manifest(batches_dir)
    if not manifest_path or not manifest:
        return
    meta_path = ocr_file + ".meta.json"
    if not os.path.exists(meta_path):
        raise ValueError("Thiếu provenance OCR; chạy lại ocr-vlm cho run hiện tại.")
    try:
        with open(meta_path, "r", encoding="utf-8") as file:
            ocr_meta = json.load(file)
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("Provenance OCR không đọc được; chạy lại ocr-vlm.") from exc
    if ocr_meta.get("run_id") != manifest.get("run_id"):
        raise ValueError("OCR thuộc run khác; không tái dùng kết quả cũ.")
    for name, identity in manifest.get("source", {}).items():
        if isinstance(identity, dict) and {"path", "size", "mtime_ns"} <= set(identity):
            if not _identity_matches(identity):
                raise ValueError(f"Nguồn {name} đã thay đổi hoặc không còn tồn tại; trích xuất run mới.")


def _direct_ocr_map(items, ocr_dict):
    """Compatibility handoff for `align`: maps only the same cue ID, no semantic inference."""
    aligned = {}
    stats = {"DIRECT": 0, "MISSING": 0}
    for item in items:
        cue_id = item["id"]
        value = ocr_dict.get(cue_id, ocr_dict.get(str(cue_id), ""))
        text = _ocr_text(value)
        method = "MISSING" if text in ("", "[EMPTY]", "[MISSING]") else "DIRECT"
        aligned[cue_id] = {"vi": "" if method == "MISSING" else text, "method": method, "sources": [cue_id]}
        stats[method] += 1
    return aligned, stats


# ==================== PHẦN 3B: GEMINI OCR WORKER ====================

def _model_allowlist(env_name):
    models = [value.strip() for value in os.environ.get(env_name, "").split(",") if value.strip()]
    if not models:
        raise TechnicalPipelineError(f"Thiếu {env_name}; đặt danh sách model Gemini được phép dùng.")
    return models


def _gemini_api_keys():
    """Load private key-file and environment configuration without reading distributable instructions."""
    keys = []
    key_file = os.environ.get("HARDSUB_GEMINI_API_KEYS_FILE", "").strip()
    if not key_file:
        default_file = os.path.expanduser("~/.config/hardsub-ocr/api_keys")
        if os.path.isfile(default_file):
            key_file = default_file
    if key_file:
        try:
            mode = os.stat(key_file).st_mode
            if mode & 0o077:
                raise TechnicalPipelineError("File Gemini API keys phải chỉ chủ sở hữu được đọc (chmod 600).")
            with open(key_file, "r", encoding="utf-8") as file:
                keys.extend(line.strip() for line in file if line.strip() and not line.lstrip().startswith("#"))
        except OSError as exc:
            raise TechnicalPipelineError("Không đọc được file Gemini API keys.") from exc
    keys.extend(value.strip() for value in os.environ.get("HARDSUB_GEMINI_API_KEYS", "").replace("\n", ",").split(",") if value.strip())
    single = os.environ.get("GEMINI_API_KEY", "").strip()
    if single:
        keys.insert(0, single)
    unique = list(dict.fromkeys(keys))
    if not unique:
        raise TechnicalPipelineError("Thiếu Gemini API key: đặt GEMINI_API_KEY hoặc cấu hình file HARDSUB_GEMINI_API_KEYS_FILE.")
    if any(any(char.isspace() for char in key) or "\\" in key for key in unique):
        raise TechnicalPipelineError("File Gemini API keys có key chứa khoảng trắng hoặc dấu escape không hợp lệ.")
    return unique


class GeminiKeyPool:
    """Round-robin keys; retire a key/model pair for this run after HTTP 429."""

    def __init__(self, keys):
        self.keys = tuple(keys)
        self.cursor = 0
        self.quota_exhausted = set()
        self.supported = {index: None for index in range(len(self.keys))}

    def available_indices(self, model):
        order = [(self.cursor + offset) % len(self.keys) for offset in range(len(self.keys))]
        return [index for index in order if (index, model) not in self.quota_exhausted
                and (self.supported[index] is None or model in self.supported[index])]

    def advance(self, index):
        self.cursor = (index + 1) % len(self.keys)


def _gemini_request(url, payload=None, timeout=90, *, method="POST", api_key=None):
    """Small REST helper. API keys stay in headers and are never written to artifacts."""
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["x-goog-api-key"] = api_key
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read().decode("utf-8")
            return json.loads(body) if body.strip() else {}
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        if api_key:
            body = body.replace(api_key, "[REDACTED_KEY]")
        retry_after = exc.headers.get("Retry-After") if exc.headers else None
        error = TechnicalPipelineError(f"Gemini HTTP {exc.code}: {_compact_process_error(body)}")
        error.status_code = exc.code
        error.retry_after = retry_after
        raise error from exc
    except urllib.error.URLError as exc:
        raise TechnicalPipelineError(f"Không kết nối được Gemini API: {exc.reason}") from exc
    except json.JSONDecodeError as exc:
        raise OcrSchemaError("Gemini trả response HTTP không phải JSON hợp lệ.") from exc


def _gemini_models(api_key):
    """List every visible model with GET, following pagination."""
    models = {}
    page_token = None
    while True:
        url = "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000"
        if page_token:
            url += "&pageToken=" + urllib.parse.quote(page_token, safe="")
        payload = _gemini_request(url, None, timeout=30, method="GET", api_key=api_key)
        for entry in payload.get("models", []):
            name = str(entry.get("name", "")).removeprefix("models/")
            methods = set(entry.get("supportedGenerationMethods", entry.get("supportedActions", [])))
            if name:
                models[name] = methods
        page_token = payload.get("nextPageToken")
        if not page_token:
            break
    return models


def _validate_gemini_models(api_key, allowlists):
    available = _gemini_models(api_key)
    missing = []
    for name, models in allowlists.items():
        for model in models:
            methods = available.get(model, set())
            if not methods or "generateContent" not in methods:
                missing.append(f"{name}:{model}")
    if missing:
        raise TechnicalPipelineError("Model Gemini không khả dụng cho generateContent: " + ", ".join(missing))
    return available


def _validate_gemini_key_pool(pool, allowlists):
    """Validate each key without exposing key material or requiring identical projects."""
    configured = {model for models in allowlists.values() for model in models}
    rejected = []
    visible = set()
    for index, key in enumerate(pool.keys):
        try:
            available = _gemini_models(key)
        except TechnicalPipelineError as exc:
            rejected.append({"slot": index + 1, "status": getattr(exc, "status_code", None)})
            pool.supported[index] = set()
            continue
        visible.update(available)
        pool.supported[index] = {model for model in configured
                                 if "generateContent" in available.get(model, set())}
    missing = [f"{name}:{model}" for name, models in allowlists.items()
               for model in models
               if not any(model in supported for supported in pool.supported.values())]
    if missing:
        if rejected and len(rejected) == len(pool.keys) and all(item["status"] == 429 for item in rejected):
            raise GeminiQuotaExhausted("Gemini model listing trả 429 trên mọi key; thử lại khi quota hồi phục.")
        raise TechnicalPipelineError("Model Gemini không khả dụng qua các key đã cấu hình: " + ", ".join(missing))
    return {"visible_models": len(visible), "rejected_slots": rejected}


def _gemini_schema(expected_labels):
    return {
        "type": "OBJECT",
        "properties": {label: {"type": "STRING"} for label in sorted(expected_labels, key=_label_sort_key)},
        "required": sorted(expected_labels, key=_label_sort_key),
    }


def _gemini_ocr_prompt(expected_labels, rescue=False):
    keys = ", ".join(sorted(expected_labels, key=_label_sort_key))
    if rescue:
        task = "Mỗi cue có ba frame A/B/C; chọn duy nhất chữ Việt xuất hiện ổn định ở các frame."
    else:
        task = "Đọc nguyên văn chữ Việt của từng tile."
    return (
        f"OCR phụ đề anime, chỉ trả JSON đúng schema. Keys bắt buộc: {keys}. "
        f"{task} Không dịch, không giải thích, không thêm \\N. "
        "Không có chữ: [EMPTY]. Không chắc hoặc không đọc được tile: [UNCERTAIN]. "
        "Không bao giờ trả giá trị rỗng; mọi key bắt buộc phải có text hoặc một sentinel hợp lệ."
    )


def _validate_ocr_values(values, expected_labels, scope):
    _validate_exact_labels(values, expected_labels, scope)
    for label, value in values.items():
        text = _ocr_text(value)
        if not text:
            raise OcrSchemaError(f"{scope}: label {label} trả chuỗi rỗng; phải dùng [EMPTY] hoặc [UNCERTAIN].")
        if "\\N" in text or "\\n" in text or "\n" in text or "\r" in text:
            raise OcrSchemaError(f"{scope}: label {label} chứa line break; OCR phải là text phẳng.")
        if text.startswith("[") and text.endswith("]") and text not in ("[EMPTY]", "[UNCERTAIN]"):
            raise OcrSchemaError(f"{scope}: label {label} dùng sentinel không hợp lệ: {text}")


def _gemini_ocr_once(api_key, model, image_path, expected_labels, rescue=False):
    with open(image_path, "rb") as image_file:
        encoded = base64.b64encode(image_file.read()).decode("ascii")
    schema = _gemini_schema(expected_labels)
    if model.startswith("gemini-2.0"):
        schema["propertyOrdering"] = sorted(expected_labels, key=_label_sort_key)
    payload = {
        "contents": [{"parts": [
            {"text": _gemini_ocr_prompt(expected_labels, rescue=rescue)},
            {"inline_data": {"mime_type": "image/jpeg", "data": encoded}},
        ]}],
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseSchema": schema,
            "temperature": 0,
        },
    }
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    response = _gemini_request(url, payload, api_key=api_key)
    try:
        text = response["candidates"][0]["content"]["parts"][0]["text"]
        values = _normalise_ocr_dict(json.loads(text))
        _validate_ocr_values(values, expected_labels, f"batch={os.path.basename(image_path)} model={model}")
    except (KeyError, IndexError, TypeError, json.JSONDecodeError, ValueError, OcrSchemaError) as exc:
        if isinstance(exc, OcrSchemaError):
            raise
        raise OcrSchemaError(f"Gemini trả OCR không hợp lệ: {exc}") from exc
    return values


def _sleep_retry(exc, attempt):
    retry_after = getattr(exc, "retry_after", None)
    if retry_after:
        try:
            time.sleep(min(30.0, max(0.0, float(retry_after))))
            return
        except (TypeError, ValueError):
            pass
    time.sleep(min(5.0, float(attempt)))


def _gemini_ocr_with_fallback(pool, models, image_path, expected_labels, rescue=False):
    """Rotate keys by batch; retire 429 key/model pairs for this run."""
    errors = []
    failure_types = []
    for model_index, model in enumerate(models):
        for index in pool.available_indices(model):
            for attempt in range(1, 4):
                try:
                    result = _gemini_ocr_once(pool.keys[index], model, image_path, expected_labels, rescue=rescue)
                    pool.advance(index)
                    return result, model
                except TechnicalPipelineError as exc:
                    status = getattr(exc, "status_code", None)
                    errors.append(f"{model} slot {index + 1} attempt {attempt}: {exc}")
                    failure_types.append("schema" if isinstance(exc, OcrSchemaError) else "other")
                    if status == 429:
                        pool.quota_exhausted.add((index, model))
                        break
                    if status == 503 and model_index + 1 < len(models):
                        break
                    if status is not None and 400 <= status < 500:
                        break
                    if attempt < 3:
                        _sleep_retry(exc, attempt)
    eligible = sum(1 for model in models for supported in pool.supported.values()
                   if supported is None or model in supported)
    if eligible and all((index, model) in pool.quota_exhausted
                        for model in models for index in range(len(pool.keys))
                        if pool.supported[index] is None or model in pool.supported[index]):
        raise GeminiQuotaExhausted("Gemini 429 trên mọi cặp key/model khả dụng; resume khi quota hồi phục.")
    if failure_types and all(kind == "schema" for kind in failure_types):
        raise OcrSchemaError("Gemini OCR sai JSON/schema sau khi retry: " + " | ".join(errors[-8:]))
    raise TechnicalPipelineError("Gemini OCR thất bại: " + " | ".join(errors[-8:]))


def _checkpoint_path(run_root, batch_name, phase="primary"):
    safe_name = os.path.splitext(os.path.basename(batch_name))[0]
    return os.path.join(run_root, "ocr_checkpoints", phase, f"{safe_name}.json")


def _load_checkpoint(run_root, batch_name, run_id, expected_labels, phase="primary"):
    path = _checkpoint_path(run_root, batch_name, phase)
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as file:
            data = json.load(file)
        values = _normalise_ocr_dict(data.get("values", {}))
        if data.get("run_id") != run_id:
            return None
        _validate_exact_labels(values, expected_labels, f"checkpoint={path}")
        return values
    except (OSError, json.JSONDecodeError, ValueError):
        return None


def _save_checkpoint(run_root, batch_name, run_id, values, model, phase="primary"):
    _atomic_json_dump(
        _checkpoint_path(run_root, batch_name, phase),
        {"run_id": run_id, "model": model, "values": values},
        separators=(",", ":"),
    )


def _save_uncertain_sheet(groups, output_path):
    """One row per cue, three raw temporal probes (A=35%, B=50%, C=65%)."""
    if not groups:
        return None
    all_images = [image for _, images in groups for image in images]
    tile_w = max(image.width for image in all_images)
    tile_h = max(image.height for image in all_images)
    canvas = Image.new("RGB", (tile_w * 3, tile_h * len(groups)), (0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    for row, (tag, images) in enumerate(groups):
        for col, image in enumerate(images):
            x, y = col * tile_w, row * tile_h
            canvas.paste(image, (x, y))
            suffix = "ABC"[col]
            draw.rectangle([x + 8, y + 2, x + 130, y + 28], fill=(0, 0, 0))
            draw.text((x + 12, y + 5), f"#{tag}{suffix}", fill=(255, 255, 0))
            draw.rectangle([x, y, x + tile_w - 1, y + tile_h - 1], outline=(255, 0, 0), width=2)
    canvas.save(output_path, quality=95, optimize=True)
    return {"columns": 3, "rows": len(groups), "tile_width": tile_w, "tile_height": tile_h}


def _write_review_report(run_root, manifest, unresolved, *, state="REVIEW_REQUIRED"):
    target_meta = manifest.get("rescue_targets", {})
    cues = []
    for label in sorted(unresolved, key=_label_sort_key):
        meta = target_meta.get(label, {})
        images = list(meta.get("images", []))
        if not images:
            cue_meta = manifest.get("cues", {}).get(label, {})
            frame = cue_meta.get("frame")
            if frame:
                images = [frame]
        cues.append({"id": label, "images": images, "meta": meta})
    _atomic_json_dump(os.path.join(run_root, "review_report.json"), {
        "run_id": manifest.get("run_id"),
        "state": state,
        "cues": cues,
    }, indent=2)


def _resolve_uncertain_ocr(run_root, batches_dir, values, pool, rescue_models):
    """Primary ASS run only: 35/50/65 raw probes, then Gemini rescue allowlist."""
    manifest, _ = _load_run_manifest(batches_dir)
    if not manifest:
        raise TechnicalPipelineError("Không tìm thấy manifest cho uncertain rescue.")
    uncertain = sorted(
        [label for label, text in values.items() if _ocr_text(text) == "[UNCERTAIN]"],
        key=_label_sort_key,
    )
    if not uncertain:
        return values, []
    source_video = manifest.get("source", {}).get("video", {})
    if not _identity_matches(source_video):
        raise SourceStaleError("Video nguồn đã đổi trước uncertain rescue; không thể lấy frame mới.")
    run_id = manifest.get("run_id")
    rescue_root = os.path.join(run_root, "uncertain")
    os.makedirs(os.path.join(rescue_root, "frames"), exist_ok=True)
    os.makedirs(os.path.join(rescue_root, "batches"), exist_ok=True)
    labels_by_normalized = {_normalise_ocr_label(label): label for label in manifest.get("labels", {})}
    video_filter = manifest.get("render", {}).get("filter") or _crop_filter("bottom")
    groups = []
    review_paths = {}
    for normalized in uncertain:
        tag = labels_by_normalized.get(normalized)
        if not tag:
            raise OcrSchemaError(f"UNCERTAIN label ngoài manifest: {normalized}")
        cue = manifest.get("cues", {}).get(tag, {})
        start, end = cue.get("safe_start"), cue.get("safe_end")
        if start is None or end is None or end <= start:
            raise TechnicalPipelineError(f"Không có interval an toàn cho UNCERTAIN cue {normalized}")
        timestamps = [start + (end - start) * portion for portion in (0.35, 0.50, 0.65)]
        paths = []
        for suffix, timestamp in zip(("A", "B", "C"), timestamps):
            path = os.path.join(rescue_root, "frames", f"f_{tag}_{suffix}.jpg")
            if suffix == "B":
                path = os.path.join(run_root, "frames", f"f_{tag}.jpg")
            elif not os.path.exists(path):
                error = _capture_frame(source_video["path"], timestamp, video_filter, path)
                if error:
                    raise TechnicalPipelineError(f"Uncertain rescue {normalized}{suffix} lỗi: {error}")
            try:
                with Image.open(path) as source_image:
                    paths.append((path, source_image.convert("RGB")))
            except (OSError, Image.UnidentifiedImageError) as exc:
                raise TechnicalPipelineError(f"Uncertain rescue {normalized}{suffix} hỏng: {exc}") from exc
        groups.append((normalized, [image for _, image in paths]))
        review_paths[normalized] = [path for path, _ in paths]

    uncertain_manifest = {"version": 2, "purpose": "uncertain", "run_id": run_id, "cues": review_paths, "batches": {}}
    for offset in range(0, len(groups), 5):
        chunk = groups[offset:offset + 5]
        batch_name = f"uncertain_{offset // 5 + 1:02d}.jpg"
        batch_path = os.path.join(rescue_root, "batches", batch_name)
        layout = _save_uncertain_sheet(chunk, batch_path)
        expected = {tag for tag, _ in chunk}
        uncertain_manifest["batches"][batch_name] = {"labels": sorted(expected, key=_label_sort_key), "layout": layout}
        checkpoint = _load_checkpoint(run_root, batch_name, run_id, expected, phase="uncertain")
        if checkpoint is None:
            result, model = _gemini_ocr_with_fallback(pool, rescue_models, batch_path, expected, rescue=True)
            _save_checkpoint(run_root, batch_name, run_id, result, model, phase="uncertain")
        else:
            result = checkpoint
        values.update(result)
    _atomic_json_dump(os.path.join(rescue_root, "uncertain_manifest.json"), uncertain_manifest, indent=2)
    unresolved = sorted([label for label, text in values.items() if _ocr_text(text) == "[UNCERTAIN]"], key=_label_sort_key)
    if unresolved:
        _atomic_json_dump(os.path.join(run_root, "review_report.json"), {
            "run_id": run_id,
            "state": "REVIEW_REQUIRED",
            "cues": [{"id": label, "images": review_paths.get(label, [])} for label in unresolved],
        }, indent=2)
    else:
        try:
            os.unlink(os.path.join(run_root, "review_report.json"))
        except FileNotFoundError:
            pass
    return values, unresolved

# ==================== PHẦN 4: SUBTITLE EXPORTER & TAG PRESERVATION ====================

def _normalize_al_info(info):
    if isinstance(info, str):
        return {"vi": info, "method": "DIRECT"}
    if isinstance(info, (list, tuple)):
        vi = info[0] if len(info) > 0 else ""
        meth = info[1] if len(info) > 1 else "DIRECT"
        return {"vi": vi, "method": meth}
    if isinstance(info, dict):
        return info
    return {}


def _validate_alignment_map(items, aligned_map):
    """Validate agent decisions structurally without judging their language or meaning."""
    missing = []
    for item in items:
        cue_id = item["id"]
        raw = aligned_map.get(cue_id, aligned_map.get(str(cue_id)))
        if raw is None:
            missing.append(str(cue_id))
            continue
        info = _normalize_al_info(raw)
        method = str(info.get("method", ""))
        if method not in VALID_METHODS:
            raise ValueError(f"Cue #{cue_id} có method không hợp lệ: {method!r}")
        if not isinstance(info.get("vi", ""), str):
            raise ValueError(f"Cue #{cue_id} phải có vi là chuỗi.")
    if missing:
        raise ValueError("Thiếu quyết định của agent cho cue: " + ", ".join(missing[:30]))

def export_sub(input_sub_path, output_sub_path, items, aligned_map, raw_lines=None, ass_header="", report_path=None):
    """
    Xuất file phụ đề ASS hoặc SRT với 100% bảo tồn thẻ style và timing.
    Hỗ trợ format: dict {"vi": ..., "method": ...}, compact list [vi, method], hoặc string vi.
    Nếu raw_lines được cung cấp, giữ nguyên 100% các dòng không thuộc target items.
    """
    is_ass = output_sub_path.lower().endswith(".ass") or input_sub_path.lower().endswith(".ass")
    _validate_alignment_map(items, aligned_map)
    matched_count = 0
    missing_count = 0
    cues_report = []

    nl = "\r\n" if raw_lines and raw_lines[0].endswith("\r\n") else "\n"

    # Canonicalize the ASS newline token only.  The agent owns every textual decision.
    for it in items:
        s_id = it["id"]
        al_info = _normalize_al_info(aligned_map.get(s_id) or aligned_map.get(str(s_id)))
        vi = str(al_info.get("vi", "") or "").strip()
        # Chuẩn hóa cơ học \n, newline thực tế sang \N.
        vi = vi.replace(r"\n", r"\N").replace("\n", r"\N").replace("\r", "")
        vi = re.sub(r"\s*\\N\s*", r"\\N", vi)

        al_info["vi"] = vi
        aligned_map[s_id] = al_info
        aligned_map[str(s_id)] = al_info

    # ==================== NHÁNH 1: ASS FILE VỚI RAW LINES ====================
    if is_ass and raw_lines:
        out_raw_lines = list(raw_lines)
        for it in items:
            s_id = it["id"]
            line_idx = it["line_idx"]
            al_info = _normalize_al_info(aligned_map.get(s_id) or aligned_map.get(str(s_id)))
            vi_text = str(al_info.get("vi", "") or "").strip()
            method = al_info.get("method", "MISSING")

            flds = it.get("ass_fields", {})
            leading_tags = it.get("leading_tags", "")
            clean_en = it.get("en_ref", "").strip().replace("{", "(").replace("}", ")")

            en_inline = f"{{{clean_en}}}" if clean_en else ""
            if not vi_text or vi_text in ("[MISSING]", "[EMPTY]"):
                effect = "" if method == "DIRECT" else method
                final_text = f"{leading_tags}{en_inline}".strip()
                missing_count += 1
            else:
                if method == "DIRECT":
                    orig_eff = flds.get("effect", "")
                    known_methods = {"NEED_FIX", "xxx", "DIRECT", "MERGE_N1", "COPY_M", "DUP_CASCADE", "MISSING_ROLLOVER", "RESCUE_CAND", "TOP_RESCUE", "RESCUE", "SEQ_SPLIT", "NEED_SEQ_PROBE", "NEED_SEMANTIC_REVIEW", "MISSING", "MERGED_INTO"}
                    effect = "" if (orig_eff in known_methods or orig_eff.startswith("NEED_FIX")) else orig_eff
                else:
                    effect = method

                clean_vi = re.sub(r"^\{[^\}\\]+\}\s*", "", vi_text).strip()
                final_text = f"{leading_tags}{en_inline}{clean_vi}".strip()
                matched_count += 1

            dialogue_line = (
                f"Dialogue: {flds.get('layer', '0')},{it.get('start_raw', sec_to_ass_tc(it['start_sec']))},"
                f"{it.get('end_raw', sec_to_ass_tc(it['end_sec']))},{flds.get('style', 'Default')},"
                f"{flds.get('name', '')},{flds.get('ml', '0')},{flds.get('mr', '0')},"
                f"{flds.get('mv', '0')},{effect},{final_text}{nl}"
            )
            out_raw_lines[line_idx] = dialogue_line

            cues_report.append({
                "id": s_id,
                "style": flds.get("style", ""),
                "en_ref": clean_en,
                "vi_aligned": vi_text,
                "method": method,
                "effect": effect,
                "sources": al_info.get("sources", [s_id])
            })

        _atomic_text_write(output_sub_path, "".join(out_raw_lines))

    # ==================== NHÁNH 2: ASS FILE MỚI HOẶC KHÔNG CÓ RAW LINES ====================
    elif is_ass:
        if not ass_header:
            ass_header = (
                "[Script Info]\nScriptType: v4.00+\nPlayResX: 1280\nPlayResY: 720\n\n"
                "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
                "Style: Default,Arial,48,&H00FFFFFF,&H000019FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,2,2,10,10,10,1\n\n"
                "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
            )
        if not ass_header.endswith("\n"):
            ass_header += "\n"

        out_lines = [ass_header.rstrip("\r\n")]
        for it in items:
            s_id = it["id"]
            al_info = _normalize_al_info(aligned_map.get(s_id) or aligned_map.get(str(s_id)))
            vi_text = str(al_info.get("vi", "") or "").strip()
            method = al_info.get("method", "MISSING")

            flds = it.get("ass_fields", {})
            leading_tags = it.get("leading_tags", "")
            clean_en = it.get("en_ref", "").strip().replace("{", "(").replace("}", ")")

            en_inline = f"{{{clean_en}}}" if clean_en else ""
            if not vi_text or vi_text in ("[MISSING]", "[EMPTY]"):
                effect = "" if method == "DIRECT" else method
                final_text = f"{leading_tags}{en_inline}".strip()
                missing_count += 1
            else:
                if method == "DIRECT":
                    orig_eff = flds.get("effect", "")
                    known_methods = {"NEED_FIX", "xxx", "DIRECT", "MERGE_N1", "COPY_M", "DUP_CASCADE", "MISSING_ROLLOVER", "RESCUE_CAND", "TOP_RESCUE", "RESCUE", "SEQ_SPLIT", "NEED_SEQ_PROBE", "NEED_SEMANTIC_REVIEW", "MISSING", "MERGED_INTO"}
                    effect = "" if (orig_eff in known_methods or orig_eff.startswith("NEED_FIX")) else orig_eff
                else:
                    effect = method

                clean_vi = re.sub(r"^\{[^\}\\]+\}\s*", "", vi_text).strip()
                final_text = f"{leading_tags}{en_inline}{clean_vi}".strip()
                matched_count += 1

            dialogue_line = (
                f"Dialogue: {flds.get('layer', '0')},{it.get('start_raw', sec_to_ass_tc(it['start_sec']))},"
                f"{it.get('end_raw', sec_to_ass_tc(it['end_sec']))},{flds.get('style', 'Default')},"
                f"{flds.get('name', '')},{flds.get('ml', '0')},{flds.get('mr', '0')},"
                f"{flds.get('mv', '0')},{effect},{final_text}"
            )
            out_lines.append(dialogue_line)

            cues_report.append({
                "id": s_id,
                "en_ref": clean_en,
                "vi_aligned": vi_text,
                "method": method,
                "effect": effect,
                "sources": al_info.get("sources", [s_id])
            })

        _atomic_text_write(output_sub_path, "\n".join(out_lines) + "\n")
    else:
        # SRT Export
        srt_blocks = []
        for it in items:
            s_id = it["id"]
            al_info = _normalize_al_info(aligned_map.get(s_id) or aligned_map.get(str(s_id)))
            vi_text = str(al_info.get("vi", "") or "").strip()
            method = al_info.get("method", "MISSING")
            clean_en = it.get("en_ref", "").strip().replace("{", "(").replace("}", ")")

            en_inline = f"{{{clean_en}}}" if clean_en else ""
            if not vi_text or vi_text in ("[MISSING]", "[EMPTY]"):
                body = en_inline
                missing_count += 1
            else:
                clean_vi = re.sub(r"^\{[^\}\\]+\}\s*", "", vi_text).strip()
                body = f"{en_inline}{clean_vi}".strip()
                matched_count += 1

            s_tc = sec_to_srt_tc(it["start_sec"]) if "start_sec" in it else it.get("start_raw", "00:00:00,000")
            e_tc = sec_to_srt_tc(it["end_sec"]) if "end_sec" in it else it.get("end_raw", "00:00:00,000")
            srt_blocks.append(f"{s_id}\n{s_tc} --> {e_tc}\n{body}\n")

            cues_report.append({
                "id": s_id,
                "en_ref": clean_en,
                "vi_aligned": vi_text,
                "method": method,
                "sources": al_info.get("sources", [s_id])
            })

        _atomic_text_write(output_sub_path, "\n".join(srt_blocks))

    total = len(items)
    cov = (matched_count / max(1, total)) * 100
    print(f"📁 Xuất phụ đề thành công: {output_sub_path}")
    print(f"📊 Thống kê: Khớp {matched_count}/{total} ({cov:.1f}%) | Missing: {missing_count}")

    if report_path:
        rep = {
            "total": total,
            "matched": matched_count,
            "missing": missing_count,
            "coverage_pct": round(cov, 2),
            "cues": cues_report
        }
        _atomic_json_dump(report_path, rep, indent=2)
        print(f"📄 Báo cáo chi tiết: {report_path}")

# ==================== PHẦN 5: CLI ENTRYPOINT ====================

def _require_ass(path, *, role="ASS"):
    if not path or not str(path).lower().endswith(".ass"):
        raise TechnicalPipelineError(f"{role} phải là file .ass trong workflow ASS-native: {path}")
    if not os.path.isfile(path):
        raise TechnicalPipelineError(f"Không tìm thấy {role}: {path}")


def _parse_flag_values(args):
    values = {}
    flags = set()
    i = 0
    while i < len(args):
        token = args[i]
        if token.startswith("--"):
            if i + 1 < len(args) and not args[i + 1].startswith("--"):
                values[token] = args[i + 1]
                i += 2
            else:
                flags.add(token)
                i += 1
        else:
            i += 1
    return values, flags


def _styles_from_arg(value):
    return set(part.strip() for part in str(value or "").split(",") if part.strip()) or None


def _read_json(path):
    with open(path, "r", encoding="utf-8") as file:
        return json.load(file)


def _artifact_meta_path(path):
    return path + ".meta.json"


def _write_artifact_meta(path, *, run_id, source, kind, extra=None):
    payload = {"version": 1, "kind": kind, "run_id": run_id, "source": source}
    if extra:
        payload.update(extra)
    _atomic_json_dump(_artifact_meta_path(path), payload, indent=2)


def _validate_source_dict(source):
    for name, identity in (source or {}).items():
        if isinstance(identity, dict) and {"path", "size", "mtime_ns"} <= set(identity):
            if not _identity_matches(identity):
                raise SourceStaleError(f"Nguồn {name} đã thay đổi hoặc không còn tồn tại: {identity.get('path')}")


def _require_meta_for_source(artifact_path, source_path=None, *, expected_kind=None):
    meta_path = _artifact_meta_path(artifact_path)
    if not os.path.isfile(meta_path):
        raise SourceStaleError(f"Thiếu provenance cho artifact: {artifact_path}")
    meta = _read_json(meta_path)
    if expected_kind and meta.get("kind") != expected_kind:
        raise SourceStaleError(f"Artifact {artifact_path} có kind={meta.get('kind')!r}, cần {expected_kind!r}.")
    _validate_source_dict(meta.get("source", {}))
    if source_path:
        _require_ass(source_path)
        expected = meta.get("source", {}).get("subtitle") or meta.get("source", {}).get("sub")
        if not isinstance(expected, dict) or _file_identity(source_path) != expected:
            raise SourceStaleError("File ASS đầu vào không đúng source identity của artifact.")
    return meta


def _style_counts(ass_path):
    with open(ass_path, "r", encoding="utf-8-sig", errors="ignore") as file:
        content = file.read()
    counts = {}
    for match in re.finditer(r"^Style:\s*([^,]+)", content, re.MULTILINE):
        counts[match.group(1).strip()] = 0
    for match in re.finditer(r"^Dialogue\s*:\s*[^,]*,[^,]*,[^,]*,\s*([^,]*)", content, re.MULTILINE):
        style = match.group(1).strip()
        counts[style] = counts.get(style, 0) + 1
    return counts


def _validate_selected_styles(ass_path, styles):
    counts = _style_counts(ass_path)
    if styles:
        absent = sorted(set(styles) - set(counts))
        if absent:
            raise TechnicalPipelineError("Style không tồn tại trong ASS: " + ", ".join(absent))
    return counts


def _attach_boundaries(items):
    for index, item in enumerate(items):
        item["clamp_prev_end"] = items[index - 1]["end_sec"] if index > 0 else 0.0
        item["clamp_next_start"] = items[index + 1]["start_sec"] if index < len(items) - 1 else item["end_sec"] + 2.0


def _exact_pairs(video_dir, sub_dir, episodes=None):
    if not os.path.isdir(video_dir) or not os.path.isdir(sub_dir):
        raise TechnicalPipelineError("--video-dir và --sub-dir phải tồn tại.")
    videos = []
    for name in sorted(os.listdir(video_dir)):
        path = os.path.join(video_dir, name)
        if os.path.isfile(path) and os.path.splitext(name)[1].lower() in (".mp4", ".mkv", ".webm", ".mov"):
            videos.append(path)
    subs = [
        os.path.join(sub_dir, name)
        for name in sorted(os.listdir(sub_dir))
        if name.lower().endswith(".ass")
        and not name.lower().endswith("_vi.ass")
        and os.path.isfile(os.path.join(sub_dir, name))
    ]
    vmap = {os.path.splitext(os.path.basename(path))[0]: path for path in videos}
    smap = {os.path.splitext(os.path.basename(path))[0]: path for path in subs}
    selected = set(episodes or (set(vmap) | set(smap)))
    pairs = [(base, vmap[base], smap[base]) for base in sorted(selected & set(vmap) & set(smap))]
    missing_video = sorted(base for base in selected & set(smap) if base not in vmap)
    missing_sub = sorted(base for base in selected & set(vmap) if base not in smap)
    unknown = sorted(base for base in selected if base not in vmap and base not in smap)
    return pairs, missing_video, missing_sub, unknown, videos, subs


def _load_episode_manifest(ep_dir):
    path = os.path.join(ep_dir, "batch_manifest.json")
    if not os.path.isfile(path):
        raise SourceStaleError(f"Thiếu batch_manifest.json: {ep_dir}")
    manifest = _read_json(path)
    if manifest.get("version") != 2 or manifest.get("purpose", "primary") != "primary":
        raise SourceStaleError(f"Manifest primary không hợp lệ: {path}")
    _validate_source_dict(manifest.get("source", {}))
    return manifest, path


def _iter_episode_dirs(out_base):
    if not os.path.isdir(out_base):
        return []
    dirs = []
    for name in sorted(os.listdir(out_base)):
        path = os.path.join(out_base, name)
        if name.startswith("ep") and os.path.isdir(path):
            dirs.append(path)
    return dirs


def _rescue_task_selection(report, top_ids=None, full_ids=None, seq_ids=None):
    top_ids = set(top_ids or [])
    full_ids = set(full_ids or [])
    seq_ids = set(seq_ids or [])
    selected = []
    for cue in report.get("cues", []):
        cid = int(cue.get("id"))
        method = cue.get("method")
        if cid in seq_ids or method == "NEED_SEQ_PROBE":
            selected.append((cue, "SEQ_SPLIT"))
        elif cid in full_ids:
            selected.append((cue, "FULL_RESCUE"))
        elif cid in top_ids or method == "MISSING":
            selected.append((cue, "TOP_RESCUE"))
    return selected


def _parse_id_set(value):
    result = set()
    for part in str(value or "").split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            left, right = part.split("-", 1)
            if not (left.isdigit() and right.isdigit()):
                raise TechnicalPipelineError(f"Khoảng cue id không hợp lệ: {part}")
            result.update(range(int(left), int(right) + 1))
        elif part.isdigit():
            result.add(int(part))
        else:
            raise TechnicalPipelineError(f"Cue id không hợp lệ: {part}")
    return result


def _build_rescue_manifest(out_base, *, replace=False, top_ids=None, full_ids=None, seq_ids=None):
    rescue_root = os.path.join(out_base, "rescue")
    if os.path.exists(rescue_root):
        if not replace:
            raise TechnicalPipelineError(f"Rescue artifact đã tồn tại: {rescue_root}. Dùng --replace-rescue để tạo run rescue mới.")
        shutil.rmtree(rescue_root)
    os.makedirs(os.path.join(rescue_root, "frames"), exist_ok=True)
    os.makedirs(os.path.join(rescue_root, "batches"), exist_ok=True)

    run_id = f"rescue-{int(time.time())}-{os.getpid()}"
    manifest = {
        "version": 2,
        "purpose": "rescue",
        "run_id": run_id,
        "source": {},
        "render": {"batch_size": 20, "columns": 3},
        "cues": {},
        "labels": {},
        "prefilled": {},
        "unsafe": {},
        "batches": {},
        "rescue_targets": {},
    }
    visual = []
    target_count = 0
    for ep_dir in _iter_episode_dirs(out_base):
        ep_name = os.path.basename(ep_dir)[2:]
        primary, _ = _load_episode_manifest(ep_dir)
        report_path = os.path.join(ep_dir, "report.json")
        report_meta_path = _artifact_meta_path(report_path)
        if not os.path.isfile(report_path):
            continue
        if not os.path.isfile(report_meta_path):
            raise SourceStaleError(f"Report thiếu provenance, không rescue mơ hồ: {report_path}")
        report_meta = _read_json(report_meta_path)
        if report_meta.get("run_id") != primary.get("run_id"):
            raise SourceStaleError(f"Report thuộc run khác: {report_path}")
        _validate_source_dict(report_meta.get("source", {}))
        report = _read_json(report_path)
        selected = _rescue_task_selection(report, top_ids=top_ids, full_ids=full_ids, seq_ids=seq_ids)
        if not selected:
            continue
        video_identity = primary.get("source", {}).get("video")
        sub_identity = primary.get("source", {}).get("subtitle")
        if not _identity_matches(video_identity or {}):
            raise SourceStaleError(f"Video source stale ở ep {ep_name}.")
        if not _identity_matches(sub_identity or {}):
            raise SourceStaleError(f"ASS source stale ở ep {ep_name}.")
        manifest["source"][f"video:{ep_name}"] = video_identity
        manifest["source"][f"subtitle:{ep_name}"] = sub_identity
        styles = set(primary.get("source", {}).get("config", {}).get("styles", [])) or None
        items, _, _, _ = parse_sub_file(sub_identity["path"], styles=styles)
        _attach_boundaries(items)
        by_id = {int(item["id"]): item for item in items}
        for cue, request_type in selected:
            cid = int(cue["id"])
            item = by_id.get(cid)
            if not item:
                raise SourceStaleError(f"Cue #{cid} ep {ep_name} không còn tồn tại trong ASS source.")
            interval, failure = _safe_interval_detail({**item, "video_duration": primary.get("source", {}).get("video_meta", {}).get("duration")})
            if interval is None:
                label = f"E{ep_name}_{cid:03d}_{request_type}"
                manifest["unsafe"][label] = {"status": failure or "UNSAFE_OVERLAP", "ep": ep_name, "id": cid, "request": request_type}
                continue
            start, end = interval
            probes = []
            if request_type == "SEQ_SPLIT":
                probes = [("A", 0.25, "bottom"), ("B", 0.75, "bottom")]
            elif request_type == "FULL_RESCUE":
                probes = [("FULL", 0.50, "full")]
            else:
                probes = [("TOP", 0.50, "top")]
            for suffix, portion, crop_mode in probes:
                label = f"E{ep_name}_{cid:03d}_{suffix}"
                timestamp = start + (end - start) * portion
                frame = os.path.join(rescue_root, "frames", f"f_{label}.jpg")
                error = _capture_frame(video_identity["path"], timestamp, _crop_filter(crop_mode), frame)
                meta = {
                    "status": "READY" if not error else "EXTRACT_FAILED",
                    "timestamp": round(timestamp, 3), "safe_start": round(start, 3), "safe_end": round(end, 3),
                    "frame": frame, "ep": ep_name, "id": cid, "request": request_type, "part": suffix,
                }
                manifest["cues"][label] = meta
                manifest["rescue_targets"][label] = {
                    "ep": ep_name, "id": cid, "request": request_type, "part": suffix,
                    "en": cue.get("en_ref", item.get("en_ref", "")),
                    "report": report_path,
                    "report_meta": report_meta_path,
                    "aligned_json": report_meta.get("aligned_json"),
                    "output_sub": report_meta.get("output_sub"),
                    "source_run_id": primary.get("run_id"),
                    "images": [frame],
                }
                target_count += 1
                if error:
                    manifest["unsafe"][label] = {**meta, "error": error}
                    continue
                try:
                    with Image.open(frame) as image_file:
                        image = image_file.convert("RGB")
                except (OSError, Image.UnidentifiedImageError) as exc:
                    manifest["unsafe"][label] = {**meta, "status": "TILER_FAILED", "error": str(exc)}
                    continue
                if _is_uniform_strip(image):
                    manifest["prefilled"][label] = "[EMPTY]"
                else:
                    manifest["labels"][label] = meta
                    visual.append((label, image))

    if not target_count:
        raise TechnicalPipelineError("Không có cue nào được agent/report yêu cầu rescue.")
    failures = [label for label, meta in manifest["unsafe"].items() if meta.get("status") in ("EXTRACT_FAILED", "TILER_FAILED")]
    if failures:
        _atomic_json_dump(os.path.join(rescue_root, "batch_manifest.json"), manifest, indent=2)
        raise CapturePipelineError("Rescue capture lỗi: " + ", ".join(failures[:20]))

    for offset in range(0, len(visual), 20):
        chunk = visual[offset:offset + 20]
        name = f"batch_{offset // 20 + 1:02d}.jpg"
        path = os.path.join(rescue_root, "batches", name)
        layout = _save_contact_sheet(chunk, path, columns=3)
        manifest["batches"][name] = {"labels": [label for label, _ in chunk], "layout": layout}
    manifest["summary"] = {"targets": target_count, "visual_labels": len(manifest["labels"]), "prefilled_empty": len(manifest["prefilled"])}
    _atomic_json_dump(os.path.join(rescue_root, "batch_manifest.json"), manifest, indent=2)
    return rescue_root, manifest


def _prepare_rescue_tasks(rescue_raw, manifest):
    normalized = _normalise_ocr_dict(rescue_raw)
    groups = {}
    for label, meta in manifest.get("rescue_targets", {}).items():
        key = f"{meta['ep']}:{meta['id']}"
        group = groups.setdefault(key, {
            "id": key,
            "episode": meta["ep"],
            "cue_id": str(meta["id"]),
            "en": meta.get("en", ""),
            "request": meta.get("request", ""),
            "ocr": {},
            "source_state": "OCR",
        })
        value = _ocr_text(normalized.get(_normalise_ocr_label(label), ""))
        group["ocr"][meta.get("part", label)] = value
        if value == "[UNCERTAIN]":
            group["source_state"] = "REVIEW_REQUIRED"
    return [groups[key] for key in sorted(groups)]


def _cli_help():
    print("Hardsub OCR ASS-native (Gemini external OCR worker + text-only semantic agent)")
    print("  ocr-doctor --video <video> --sub <file.ass> [--styles S1,S2]")
    print("  preflight --video-dir <dir> --sub-dir <dir> [--episodes E01,E02]")
    print("  batch-extract --video-dir <dir> --sub-dir <dir> --styles <S1,S2> [--out-base /tmp/sub_ocr] [--replace-run]")
    print("  ocr-vlm <batches_dir> <ocr_raw.json>")
    print("  prepare-pr <sub.ass> <ocr_raw.json> <pr_tasks.json> [--styles S1,S2]")
    print("  pr-view <pr_tasks.json> [--start ID] [--count N]")
    print("  merge-pr <pr_tasks_locked.json> <pr_done.json> <pr_merged.json>")
    print("  export <sub.ass> <pr_merged.json> <name_vi.ass> [--styles S1,S2] [--report report.json]")
    print("  batch-rescue --out-base /tmp/sub_ocr [--top-ids ...] [--full-ids ...] [--seq-ids ...] [--replace-rescue]")
    print("  prepare-rescue-pr <rescue_raw.json> <rescue_tasks.json>")
    print("  batch-rescue-apply <rescue_done.json> --out-base /tmp/sub_ocr")
    print("Legacy SRT parser/export helpers remain untouched but are outside this ASS-native workflow.")


def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help", "help"):
        _cli_help()
        return 0
    cmd = sys.argv[1].lower()
    try:
        if cmd == "ocr-doctor":
            values, _ = _parse_flag_values(sys.argv[2:])
            video_path = values.get("--video")
            sub_path = values.get("--sub")
            styles = _styles_from_arg(values.get("--styles"))
            if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
                raise TechnicalPipelineError("Thiếu ffmpeg hoặc ffprobe trong PATH.")
            pool = GeminiKeyPool(_gemini_api_keys())
            ocr_models = _model_allowlist("HARDSUB_GEMINI_OCR_MODELS")
            rescue_models = _model_allowlist("HARDSUB_GEMINI_RESCUE_MODELS")
            key_check = _validate_gemini_key_pool(pool, {"ocr": ocr_models, "rescue": rescue_models})
            report = {
                "ok": True,
                "ffmpeg": shutil.which("ffmpeg"), "ffprobe": shutil.which("ffprobe"), "pillow": Image.__version__,
                "gemini": {"ocr_models": ocr_models, "rescue_models": rescue_models,
                           "key_slots": len(pool.keys), **key_check},
            }
            if video_path:
                report["video"] = _probe_video(video_path)
            if sub_path:
                _require_ass(sub_path)
                counts = _validate_selected_styles(sub_path, styles)
                items, _, _, _ = parse_sub_file(sub_path, styles=styles)
                if not items:
                    raise TechnicalPipelineError("ASS không có cue nào khớp style đã chọn.")
                malformed = [item["id"] for item in items if not (0 <= item["start_sec"] < item["end_sec"])]
                empty = [item["id"] for item in items if not item.get("en_ref", "").strip()]
                if malformed:
                    raise TechnicalPipelineError("Timestamp ASS lỗi ở cue: " + ", ".join(map(str, malformed[:20])))
                report["ass"] = {"source": _file_identity(sub_path), "selected_cues": len(items), "styles": counts, "empty_cues": empty}
            print(json.dumps(report, ensure_ascii=False, indent=2))
            return 0

        if cmd == "preflight":
            values, _ = _parse_flag_values(sys.argv[2:])
            video_dir, sub_dir = values.get("--video-dir"), values.get("--sub-dir")
            if not video_dir or not sub_dir:
                raise TechnicalPipelineError("preflight cần --video-dir và --sub-dir.")
            episodes = _styles_from_arg(values.get("--episodes"))
            pairs, missing_video, missing_sub, unknown, videos, subs = _exact_pairs(video_dir, sub_dir, episodes)
            print(f"Videos: {len(videos)} | ASS: {len(subs)} | exact pairs: {len(pairs)}")
            preflight_bad = []
            for base, video, sub in pairs:
                counts = _style_counts(sub)
                try:
                    video_meta = _probe_video(video)
                    items, _, _, _ = parse_sub_file(sub)
                    malformed = [item["id"] for item in items if not (0 <= item["start_sec"] < item["end_sec"])]
                    empty = [item["id"] for item in items if not item.get("en_ref", "").strip()]
                    outside = [item["id"] for item in items if item["start_sec"] >= video_meta["duration"]]
                    if malformed:
                        preflight_bad.append(f"{base}: malformed timestamps {malformed[:10]}")
                except TechnicalPipelineError as exc:
                    preflight_bad.append(f"{base}: {exc}")
                    video_meta = {}
                    empty, outside = [], []
                print(f"- {base}: {os.path.basename(video)} <-> {os.path.basename(sub)} | duration={video_meta.get('duration', '?')}s")
                for style, count in sorted(counts.items(), key=lambda item: (-item[1], item[0])):
                    print(f"    {style}: {count}")
                if empty:
                    print(f"    empty cues: {empty[:20]}")
                if outside:
                    print(f"    out-of-video cues: {outside[:20]}")
            if missing_video or missing_sub or unknown:
                if missing_video: print("Missing video:", ", ".join(missing_video))
                if missing_sub: print("Missing ASS:", ", ".join(missing_sub))
                if unknown: print("Unknown episodes:", ", ".join(unknown))
                return EXIT_INPUT
            if preflight_bad:
                print("Preflight errors:")
                for problem in preflight_bad:
                    print("  -", problem)
                return EXIT_INPUT
            return 0

        if cmd == "batch-extract":
            values, flags = _parse_flag_values(sys.argv[2:])
            video_dir, sub_dir = values.get("--video-dir"), values.get("--sub-dir")
            if not video_dir or not sub_dir:
                raise TechnicalPipelineError("batch-extract cần --video-dir và --sub-dir.")
            styles = _styles_from_arg(values.get("--styles"))
            if not styles:
                raise TechnicalPipelineError("ASS-native yêu cầu --styles rõ ràng để không OCR nhầm Signs/OP/ED.")
            batch_size = int(values.get("--batch-size", "20"))
            out_base = values.get("--out-base", "/tmp/sub_ocr")
            episodes = _styles_from_arg(values.get("--episodes"))
            pairs, missing_video, missing_sub, unknown, _, _ = _exact_pairs(video_dir, sub_dir, episodes)
            if missing_video or missing_sub or unknown or not pairs:
                raise TechnicalPipelineError("Không có tập hợp cặp video–ASS exact hoàn chỉnh; chạy preflight để xem chi tiết.")
            for ep_name, video, sub in pairs:
                _require_ass(sub)
                _validate_selected_styles(sub, styles)
                ep_out = os.path.join(out_base, f"ep{ep_name}")
                config = {"styles": sorted(styles), "crop_mode": "bottom", "batch_size": batch_size}
                source_info = {"subtitle": _file_identity(sub), "config": config}
                manifest_path = os.path.join(ep_out, "batch_manifest.json")
                if os.path.isfile(manifest_path):
                    old = _read_json(manifest_path)
                    old_source = old.get("source", {})
                    same = _identity_matches(old_source.get("video", {})) and _identity_matches(old_source.get("subtitle", {})) and old_source.get("config") == config
                    if same and "--replace-run" not in flags:
                        print(f"↩️ {ep_name}: giữ run hiện tại để resume; --replace-run để tạo run mới.")
                        continue
                    if "--replace-run" not in flags:
                        raise SourceStaleError(f"Run cũ {ep_out} khác source/config; không xóa artifact âm thầm.")
                    shutil.rmtree(ep_out)
                os.makedirs(ep_out, exist_ok=True)
                items, _, _, _ = parse_sub_file(sub, styles=styles)
                if not items:
                    raise TechnicalPipelineError(f"{ep_name}: không có cue cho styles {sorted(styles)}")
                _attach_boundaries(items)
                _atomic_json_dump(os.path.join(ep_out, "session_info.json"), {
                    "ep": ep_name, "video": _file_identity(video), "sub": _file_identity(sub), "config": config,
                }, indent=2)
                build_mega_batches(video, items, out_dir=ep_out, batch_size=batch_size, crop_mode="bottom", source_info=source_info)
                manifest = _read_json(manifest_path)
                manifest["purpose"] = "primary"
                _atomic_json_dump(manifest_path, manifest, indent=2)
                failed = [key for key, meta in manifest.get("unsafe", {}).items() if meta.get("status") in ("EXTRACT_FAILED", "TILER_FAILED")]
                if failed:
                    raise CapturePipelineError(f"{ep_name}: capture lỗi: " + ", ".join(failed[:20]))
            return 0

        if cmd == "ocr-vlm":
            if len(sys.argv) != 4:
                raise TechnicalPipelineError("Usage: ocr-vlm <batches_dir> <out_raw.json>")
            batches_dir, out_raw = sys.argv[2], sys.argv[3]
            manifest, manifest_path = _load_run_manifest(batches_dir)
            if not manifest or manifest.get("version") != 2:
                raise TechnicalPipelineError("ocr-vlm cần batch_manifest v2.")
            _validate_source_dict(manifest.get("source", {}))
            capture_failures = [key for key, meta in manifest.get("unsafe", {}).items() if meta.get("status") in ("EXTRACT_FAILED", "TILER_FAILED")]
            if capture_failures:
                print("Capture failure: " + ", ".join(capture_failures[:20]))
                return EXIT_CAPTURE
            pool = GeminiKeyPool(_gemini_api_keys())
            purpose = manifest.get("purpose", "primary")
            env_name = "HARDSUB_GEMINI_RESCUE_MODELS" if purpose == "rescue" else "HARDSUB_GEMINI_OCR_MODELS"
            models = _model_allowlist(env_name)
            _validate_gemini_key_pool(pool, {purpose: models})
            root = os.path.dirname(os.path.abspath(batches_dir.rstrip(os.sep)))
            run_id = manifest.get("run_id")
            results = _normalise_ocr_dict(manifest.get("prefilled", {}))
            batch_files = [os.path.join(batches_dir, name) for name in sorted(manifest.get("batches", {}))]
            for index, batch_path in enumerate(batch_files, 1):
                expected, _ = _expected_batch_labels(batches_dir, batch_path)
                checkpoint = _load_checkpoint(root, batch_path, run_id, expected, phase="primary" if purpose == "primary" else "rescue")
                if checkpoint is None:
                    try:
                        values_batch, model = _gemini_ocr_with_fallback(pool, models, batch_path, expected, rescue=(purpose == "rescue"))
                    except GeminiQuotaExhausted as exc:
                        _atomic_json_dump(os.path.join(root, "ocr_status.json"), {"run_id": run_id, "state": "QUOTA_EXHAUSTED", "batch": os.path.basename(batch_path), "error": str(exc)}, indent=2)
                        return EXIT_QUOTA
                    _save_checkpoint(root, batch_path, run_id, values_batch, model, phase="primary" if purpose == "primary" else "rescue")
                    checkpoint = values_batch
                    print(f"[{index}/{len(batch_files)}] {os.path.basename(batch_path)} -> {model}")
                else:
                    print(f"[{index}/{len(batch_files)}] resume {os.path.basename(batch_path)}")
                results.update(checkpoint)
            _validate_ocr_coverage(results, batches_dir)
            unresolved = []
            if purpose == "primary":
                if any(_ocr_text(value) == "[UNCERTAIN]" for value in results.values()):
                    rescue_models = _model_allowlist("HARDSUB_GEMINI_RESCUE_MODELS")
                    _validate_gemini_key_pool(pool, {"rescue": rescue_models})
                    try:
                        results, unresolved = _resolve_uncertain_ocr(root, batches_dir, results, pool, rescue_models)
                    except GeminiQuotaExhausted as exc:
                        _atomic_json_dump(os.path.join(root, "ocr_status.json"), {"run_id": run_id, "state": "QUOTA_EXHAUSTED", "phase": "uncertain", "error": str(exc)}, indent=2)
                        return EXIT_QUOTA
            else:
                unresolved = sorted([key for key, value in results.items() if _ocr_text(value) == "[UNCERTAIN]"], key=_label_sort_key)
                if unresolved:
                    _write_review_report(root, manifest, unresolved)
            _atomic_json_dump(out_raw, results, indent=2)
            _write_artifact_meta(out_raw, run_id=run_id, source=manifest.get("source", {}), kind="ocr", extra={"manifest": os.path.abspath(manifest_path), "purpose": purpose})
            state = "REVIEW_REQUIRED" if unresolved else "COMPLETE"
            _atomic_json_dump(os.path.join(root, "ocr_status.json"), {"run_id": run_id, "state": state, "unresolved": unresolved}, indent=2)
            return EXIT_REVIEW if unresolved else 0

        if cmd == "prepare-pr":
            if len(sys.argv) < 5:
                raise TechnicalPipelineError("Usage: prepare-pr <sub.ass> <ocr_raw.json> <pr_tasks.json> [--styles S1,S2]")
            sub, ocr_file, tasks_out = sys.argv[2:5]
            values, _ = _parse_flag_values(sys.argv[5:])
            styles = _styles_from_arg(values.get("--styles"))
            _require_ass(sub)
            meta = _require_meta_for_source(ocr_file, sub, expected_kind="ocr")
            if meta.get("purpose") != "primary":
                raise SourceStaleError("prepare-pr chỉ nhận OCR primary; rescue dùng prepare-rescue-pr.")
            ocr = _normalise_ocr_dict(_read_json(ocr_file))
            manifest_path = meta.get("manifest")
            if not manifest_path or not os.path.isfile(manifest_path):
                raise SourceStaleError("OCR meta không còn trỏ tới manifest hợp lệ.")
            batches_dir = os.path.join(os.path.dirname(os.path.abspath(manifest_path)), "batches")
            _validate_ocr_coverage(ocr, batches_dir)
            manifest, _ = _load_run_manifest(batches_dir)
            items, _, _, _ = parse_sub_file(sub, styles=styles)
            prefilled = {_normalise_ocr_label(key) for key in manifest.get("prefilled", {})}
            unsafe = {_normalise_ocr_label(key): value for key, value in manifest.get("unsafe", {}).items()}
            cues = []
            for item in items:
                cid = _normalise_ocr_label(item["id"])
                text = _ocr_text(ocr.get(cid, ""))
                state = unsafe.get(cid, {}).get("status", "OCR")
                if cid in prefilled: state = "PRE_EMPTY_UNIFORM"
                if text == "[UNCERTAIN]": state = "REVIEW_REQUIRED"
                cues.append({"id": str(item["id"]), "en": item.get("en_ref", ""), "ocr": text, "source_state": state})
            contract = {
                "input": "text-only except image paths explicitly listed in review_report.json",
                "output": "JSON {run_id: <same run_id>, decisions: {id: {vi, method}}}",
                "methods": sorted(VALID_METHODS),
                "invariants": [
                    "Agent aligns existing Vietnamese OCR spans to English cue boundaries and owns only evidence-based OCR correction, punctuation and line breaks.",
                    "English is a reference for alignment only: never retranslate, paraphrase, replace wording or add Vietnamese content from English.",
                    "Preserve Vietnamese fansub words, pronouns, meaning and order when splitting or merging cues; missing text requires rescue or a missing method.",
                    "DIRECT requires semantic review of every cue and adjacent context; matching cue IDs or timestamps alone is not evidence of alignment.",
                    "Accept natural nonliteral translation differences when core meaning and dialogue function agree; flag clear contradictions, polarity/action/entity changes, major clause omissions, or unrelated Vietnamese. English and Vietnamese may both be translations from Japanese, so do not demand literal equivalence.",
                    "For a suspected mismatch, inspect neighboring OCR spans and move only evidenced Vietnamese text; never compose a replacement from English.",
                    "Use NEED_SEMANTIC_REVIEW when a possible EN/VI meaning or alignment mismatch cannot be resolved from existing OCR/rescue text and translation variation is plausible; preserve the existing VI text and do not mark it MISSING or invent a correction.",
                    "Before MISSING, review adjacent EN/VI cues for rollover or shifted alignment; unresolved gaps require a rescue probe before final absence.",
                    "Script must not infer language, merge/copy/missing or punctuation.",
                ],
            }
            _atomic_json_dump(tasks_out, {"contract": contract, "run_id": meta.get("run_id"), "cues": cues}, indent=2)
            locked = values.get("--locked-out", os.path.splitext(tasks_out)[0] + "_locked.json")
            _atomic_json_dump(locked, {}, indent=2)
            source = meta.get("source", {})
            for artifact, kind in ((tasks_out, "pr_tasks"), (locked, "pr_locked")):
                _write_artifact_meta(artifact, run_id=meta.get("run_id"), source=source, kind=kind, extra={"tasks": os.path.abspath(tasks_out), "sub": os.path.abspath(sub)})
            return 0

        if cmd == "pr-view":
            if len(sys.argv) < 3:
                raise TechnicalPipelineError("Usage: pr-view <pr_tasks.json> [--start ID] [--count N]")
            tasks_file = sys.argv[2]
            values, flags = _parse_flag_values(sys.argv[3:])
            if flags or set(values) - {"--start", "--count"}:
                raise TechnicalPipelineError("pr-view chỉ nhận --start ID và --count N.")
            meta = _require_meta_for_source(tasks_file, expected_kind="pr_tasks")
            tasks = _read_json(tasks_file)
            if tasks.get("run_id") != meta.get("run_id") or not isinstance(tasks.get("cues"), list):
                raise SourceStaleError("pr_tasks.json không khớp provenance của run hiện tại.")
            try:
                start = int(values.get("--start", "1"))
                count = int(values["--count"]) if "--count" in values else None
            except ValueError as exc:
                raise TechnicalPipelineError("--start và --count phải là số nguyên dương.") from exc
            if start < 1 or (count is not None and count < 1):
                raise TechnicalPipelineError("--start và --count phải là số nguyên dương.")
            cues = [cue for cue in tasks["cues"] if int(cue["id"]) >= start]
            if count is not None:
                cues = cues[:count]
            print(f"run_id={tasks['run_id']} | id\tEN\tVI OCR\tstate nếu khác OCR")
            for cue in cues:
                fields = [str(cue["id"]), str(cue["en"]), str(cue["ocr"])]
                state = str(cue.get("source_state", "OCR"))
                if state != "OCR":
                    fields.append(state)
                print("\t".join(field.replace("\t", " ").replace("\n", "\\n") for field in fields))
            return 0

        if cmd == "merge-pr":
            if len(sys.argv) != 5:
                raise TechnicalPipelineError("Usage: merge-pr <locked.json> <done.json> <merged.json>")
            locked_file, done_file, merged_out = sys.argv[2:5]
            meta = _require_meta_for_source(locked_file, expected_kind="pr_locked")
            locked = _read_json(locked_file)
            done = _read_json(done_file)
            merged = {str(key): value for key, value in locked.items()}
            if not isinstance(done, dict) or done.get("run_id") != meta.get("run_id") or not isinstance(done.get("decisions"), dict):
                raise SourceStaleError("pr_done.json phải mang đúng run_id và trường decisions từ pr_tasks hiện tại.")
            for key, value in done["decisions"].items():
                merged[str(key)] = value
            tasks = _read_json(meta.get("tasks"))
            expected = {str(cue["id"]) for cue in tasks.get("cues", [])}
            actual = set(merged)
            if expected != actual:
                missing = sorted(expected - actual)
                extra = sorted(actual - expected)
                raise OcrSchemaError(f"PR coverage sai; missing={missing[:20]} extra={extra[:20]}")
            sorted_merged = {key: merged[key] for key in sorted(merged, key=lambda value: int(value) if value.isdigit() else 999999)}
            _atomic_json_dump(merged_out, sorted_merged, indent=2)
            _write_artifact_meta(merged_out, run_id=meta.get("run_id"), source=meta.get("source", {}), kind="pr_merged", extra={"tasks": meta.get("tasks"), "sub": meta.get("sub")})
            return 0

        if cmd == "export":
            if len(sys.argv) < 5:
                raise TechnicalPipelineError("Usage: export <sub.ass> <pr_merged.json> <name_vi.ass> [--styles S1,S2] [--report report.json]")
            sub, merged_file, output = sys.argv[2:5]
            values, _ = _parse_flag_values(sys.argv[5:])
            styles = _styles_from_arg(values.get("--styles"))
            report = values.get("--report", os.path.join(os.path.dirname(os.path.abspath(merged_file)), "report.json"))
            _require_ass(sub)
            if not output.lower().endswith("_vi.ass"):
                raise TechnicalPipelineError("Output ASS-native phải có hậu tố _vi.ass.")
            if os.path.abspath(output) == os.path.abspath(sub):
                raise TechnicalPipelineError("Không được ghi đè ASS source.")
            meta = _require_meta_for_source(merged_file, sub, expected_kind="pr_merged")
            items, raw_lines, _, header = parse_sub_file(sub, styles=styles)
            aligned = _read_json(merged_file)
            export_sub(sub, output, items, aligned, raw_lines=raw_lines, ass_header=header, report_path=report)
            extra = {"input_sub": os.path.abspath(sub), "output_sub": os.path.abspath(output), "aligned_json": os.path.abspath(merged_file)}
            _write_artifact_meta(report, run_id=meta.get("run_id"), source=meta.get("source", {}), kind="report", extra=extra)
            _write_artifact_meta(output, run_id=meta.get("run_id"), source=meta.get("source", {}), kind="ass_output", extra=extra)
            return 0

        if cmd == "batch-rescue":
            values, flags = _parse_flag_values(sys.argv[2:])
            out_base = values.get("--out-base", "/tmp/sub_ocr")
            rescue_root, manifest = _build_rescue_manifest(
                out_base,
                replace="--replace-rescue" in flags,
                top_ids=_parse_id_set(values.get("--top-ids")),
                full_ids=_parse_id_set(values.get("--full-ids")),
                seq_ids=_parse_id_set(values.get("--seq-ids")),
            )
            print(f"Rescue run: {manifest['run_id']} | labels={len(manifest['labels'])} | prefilled={len(manifest['prefilled'])}")
            print(f"Next: ocr-vlm {rescue_root}/batches {rescue_root}/rescue_raw.json")
            return 0

        if cmd == "prepare-rescue-pr":
            if len(sys.argv) != 4:
                raise TechnicalPipelineError("Usage: prepare-rescue-pr <rescue_raw.json> <rescue_tasks.json>")
            raw_file, tasks_out = sys.argv[2:4]
            meta = _require_meta_for_source(raw_file, expected_kind="ocr")
            if meta.get("purpose") != "rescue":
                raise SourceStaleError("prepare-rescue-pr cần rescue OCR artifact.")
            root = os.path.dirname(os.path.abspath(raw_file))
            manifest = _read_json(os.path.join(root, "batch_manifest.json"))
            tasks = _prepare_rescue_tasks(_read_json(raw_file), manifest)
            contract = {
                "output": "JSON {run_id: <same rescue run_id>, decisions: {episode:cue_id: {vi, method}}}",
                "allowed_final_methods": ["TOP_RESCUE", "RESCUE", "SEQ_SPLIT", "MISSING", "MISSING_ROLLOVER", "DUP_CASCADE"],
                "rule": "Use Vietnamese primary/rescue OCR as the only wording source; EN only aligns cue boundaries. Agent may split/merge existing Vietnamese spans and minimally correct proven OCR errors, but must never retranslate, paraphrase or add content from EN. Before MISSING, check adjacent EN/VI spans for rollover and probe unresolved gaps.",
            }
            _atomic_json_dump(tasks_out, {"contract": contract, "run_id": meta.get("run_id"), "cues": tasks}, indent=2)
            _write_artifact_meta(tasks_out, run_id=meta.get("run_id"), source=meta.get("source", {}), kind="rescue_tasks", extra={"manifest": os.path.join(root, "batch_manifest.json")})
            return 0

        if cmd == "batch-rescue-apply":
            if len(sys.argv) < 3:
                raise TechnicalPipelineError("Usage: batch-rescue-apply <rescue_done.json> --out-base /tmp/sub_ocr")
            done_file = sys.argv[2]
            values, _ = _parse_flag_values(sys.argv[3:])
            out_base = values.get("--out-base", "/tmp/sub_ocr")
            rescue_root = os.path.join(out_base, "rescue")
            manifest = _read_json(os.path.join(rescue_root, "batch_manifest.json"))
            _validate_source_dict(manifest.get("source", {}))
            done = _read_json(done_file)
            if not isinstance(done, dict) or done.get("run_id") != manifest.get("run_id") or not isinstance(done.get("decisions"), dict):
                raise SourceStaleError("rescue_done.json phải mang đúng rescue run_id và trường decisions.")
            grouped = {}
            for key, raw in done["decisions"].items():
                if ":" not in str(key):
                    raise OcrSchemaError(f"Rescue decision key phải là episode:cue_id: {key}")
                ep, cid = str(key).split(":", 1)
                info = _normalize_al_info(raw)
                method = info.get("method", "")
                if method not in ("TOP_RESCUE", "RESCUE", "SEQ_SPLIT", "MISSING", "MISSING_ROLLOVER", "DUP_CASCADE"):
                    raise OcrSchemaError(f"Rescue method không hợp lệ cho {key}: {method}")
                grouped.setdefault(ep, {})[str(int(cid))] = info
            for ep, decisions in grouped.items():
                ep_dir = os.path.join(out_base, f"ep{ep}")
                report_path = os.path.join(ep_dir, "report.json")
                report_meta = _require_meta_for_source(report_path, expected_kind="report")
                aligned_path = report_meta.get("aligned_json")
                sub = report_meta.get("input_sub")
                output = report_meta.get("output_sub")
                if not aligned_path or not sub or not output:
                    raise SourceStaleError(f"Report meta ep {ep} thiếu đường dẫn exact để apply rescue.")
                merged_meta = _require_meta_for_source(aligned_path, sub, expected_kind="pr_merged")
                aligned = _read_json(aligned_path)
                for cid, info in decisions.items():
                    if cid not in aligned:
                        raise OcrSchemaError(f"Cue {ep}:{cid} không tồn tại trong PR merged.")
                    aligned[cid] = info
                _atomic_json_dump(aligned_path, aligned, indent=2)
                _write_artifact_meta(aligned_path, run_id=merged_meta.get("run_id"), source=merged_meta.get("source", {}), kind="pr_merged", extra={"tasks": merged_meta.get("tasks"), "sub": merged_meta.get("sub")})
                styles = set(_load_episode_manifest(ep_dir)[0].get("source", {}).get("config", {}).get("styles", [])) or None
                items, raw_lines, _, header = parse_sub_file(sub, styles=styles)
                export_sub(sub, output, items, aligned, raw_lines=raw_lines, ass_header=header, report_path=report_path)
                _write_artifact_meta(report_path, run_id=report_meta.get("run_id"), source=report_meta.get("source", {}), kind="report", extra={"input_sub": sub, "output_sub": output, "aligned_json": aligned_path})
                _write_artifact_meta(output, run_id=report_meta.get("run_id"), source=report_meta.get("source", {}), kind="ass_output", extra={"input_sub": sub, "output_sub": output, "aligned_json": aligned_path})
            return 0

        # Keep narrow legacy commands available but outside the documented ASS-native flow.
        if cmd == "align":
            if len(sys.argv) < 5:
                raise TechnicalPipelineError("Usage: align <sub> <ocr.json> <out_sub>")
            sub, ocr_file, out_sub = sys.argv[2:5]
            items, raw_lines, _, header = parse_sub_file(sub)
            aligned, stats = _direct_ocr_map(items, _normalise_ocr_dict(_read_json(ocr_file)))
            print(f"Legacy mechanical align: {stats}")
            export_sub(sub, out_sub, items, aligned, raw_lines=raw_lines, ass_header=header)
            return 0

        raise TechnicalPipelineError(f"Lệnh không hỗ trợ: {cmd}. Dùng --help.")

    except SourceStaleError as exc:
        print(f"❌ SOURCE_STALE: {exc}")
        return EXIT_STALE
    except (OcrSchemaError, ValueError, json.JSONDecodeError) as exc:
        print(f"❌ SCHEMA_ERROR: {exc}")
        return EXIT_SCHEMA
    except GeminiQuotaExhausted as exc:
        print(f"⏸️ QUOTA_EXHAUSTED: {exc}")
        return EXIT_QUOTA
    except CapturePipelineError as exc:
        print(f"❌ CAPTURE_ERROR: {exc}")
        return EXIT_CAPTURE
    except TechnicalPipelineError as exc:
        print(f"❌ INPUT_OR_TECHNICAL_ERROR: {exc}")
        return EXIT_INPUT
    except (OSError, subprocess.SubprocessError) as exc:
        print(f"❌ CAPTURE_OR_IO_ERROR: {exc}")
        return EXIT_CAPTURE


if __name__ == "__main__":
    sys.exit(main())
