#!/usr/bin/env python3
"""
Inspect and scan ASS lines for layout margin overflow and smart wrapping candidates.
Calculates available pixel width per dialogue event based on:
  - Script PlayResX (fallback 1920)
  - Style MarginL / MarginR
  - Event-specific MarginL / MarginR override
  - Exact libass rendered bounding box width (WrapStyle: 2, unwrapped)
Outputs a structured JSON report or CLI summary with candidate split points.
"""

import argparse
import ctypes as C
import ctypes.util
import json
import os
import re
import sys
from pathlib import Path


class AssImage(C.Structure):
    pass


AssImage._fields_ = [
    ('w', C.c_int), ('h', C.c_int), ('stride', C.c_int),
    ('bitmap', C.POINTER(C.c_ubyte)), ('color', C.c_uint32),
    ('x', C.c_int), ('y', C.c_int), ('next', C.POINTER(AssImage))
]


class LibassScanner:
    def __init__(self, font_dir=None):
        lib_path = ctypes.util.find_library('ass')
        if not lib_path:
            raise RuntimeError('libass library not found on system')
        self.a = C.CDLL(lib_path)

        self.a.ass_library_init.restype = C.c_void_p
        self.a.ass_renderer_init.argtypes = [C.c_void_p]
        self.a.ass_renderer_init.restype = C.c_void_p
        self.a.ass_set_frame_size.argtypes = [C.c_void_p, C.c_int, C.c_int]
        self.a.ass_set_storage_size.argtypes = [C.c_void_p, C.c_int, C.c_int]
        self.a.ass_set_fonts.argtypes = [C.c_void_p, C.c_char_p, C.c_char_p, C.c_int, C.c_char_p, C.c_int]
        self.a.ass_read_memory.argtypes = [C.c_void_p, C.c_char_p, C.c_size_t, C.c_char_p]
        self.a.ass_read_memory.restype = C.c_void_p
        self.a.ass_render_frame.argtypes = [C.c_void_p, C.c_void_p, C.c_longlong, C.POINTER(C.c_int)]
        self.a.ass_render_frame.restype = C.POINTER(AssImage)
        self.a.ass_free_track.argtypes = [C.c_void_p]
        self.a.ass_renderer_done.argtypes = [C.c_void_p]
        self.a.ass_library_done.argtypes = [C.c_void_p]

        self.lib = self.a.ass_library_init()
        self.renderer = self.a.ass_renderer_init(self.lib)
        self.font_dir = font_dir.encode('utf-8') if font_dir else None

    def init_frame(self, play_res_x, play_res_y):
        self.play_res_x = play_res_x
        self.play_res_y = play_res_y
        self.a.ass_set_frame_size(self.renderer, play_res_x, play_res_y)
        self.a.ass_set_storage_size(self.renderer, play_res_x, play_res_y)
        self.a.ass_set_fonts(self.renderer, None, None, 1, self.font_dir, 1)

    def measure_unwrapped_width(self, style_line, text, style_name='Default'):
        """Render a single event with WrapStyle 2 (unwrapped) to measure exact pixel width."""
        test_script = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {self.play_res_x}
PlayResY: {self.play_res_y}
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
{style_line}

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:01.00,0:00:05.00,{style_name},,0,0,0,,{text}
"""
        data = test_script.encode('utf-8')
        track = self.a.ass_read_memory(self.lib, data, len(data), None)
        if not track:
            return 0
        dc = C.c_int()
        ptr = self.a.ass_render_frame(self.renderer, track, 2000, C.byref(dc))
        min_x, max_x = 999999, -999999
        c = ptr
        while c:
            img = c.contents
            if img.w > 0 and img.h > 0:
                min_x = min(min_x, img.x)
                max_x = max(max_x, img.x + img.w)
            c = img.next
        self.a.ass_free_track(track)
        return max_x - min_x if max_x >= min_x else 0

    def close(self):
        if getattr(self, 'renderer', None):
            self.a.ass_renderer_done(self.renderer)
            self.renderer = None
        if getattr(self, 'lib', None):
            self.a.ass_library_done(self.lib)
            self.lib = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


def parse_ass(file_path):
    with open(file_path, 'r', encoding='utf-8-sig') as f:
        lines = f.readlines()

    play_res_x = 1920
    play_res_y = 1080
    styles = {}
    events = []

    current_section = None
    style_format = []
    event_format = []

    for idx, raw_line in enumerate(lines):
        line = raw_line.strip()
        if line.startswith('[') and line.endswith(']'):
            current_section = line
            continue

        if current_section == '[Script Info]':
            if line.startswith('PlayResX:'):
                try:
                    play_res_x = int(line.split(':', 1)[1].strip())
                except ValueError:
                    pass
            elif line.startswith('PlayResY:'):
                try:
                    play_res_y = int(line.split(':', 1)[1].strip())
                except ValueError:
                    pass

        elif current_section in ('[V4+ Styles]', '[V4 Styles]'):
            if line.startswith('Format:'):
                style_format = [x.strip() for x in line.split(':', 1)[1].split(',')]
            elif line.startswith('Style:'):
                parts = [x.strip() for x in line.split(':', 1)[1].split(',', len(style_format) - 1)]
                s_dict = dict(zip(style_format, parts))
                name = s_dict.get('Name', '')
                styles[name] = {
                    'raw': line,
                    'dict': s_dict,
                    'margin_l': int(s_dict.get('MarginL', 0)),
                    'margin_r': int(s_dict.get('MarginR', 0)),
                    'margin_v': int(s_dict.get('MarginV', 0)),
                    'alignment': int(s_dict.get('Alignment', 2)),
                    'fontsize': float(s_dict.get('Fontsize', 95))
                }

        elif current_section == '[Events]':
            if line.startswith('Format:'):
                event_format = [x.strip() for x in line.split(':', 1)[1].split(',')]
            elif line.startswith('Dialogue:'):
                parts = line.split(':', 1)[1].split(',', len(event_format) - 1)
                e_dict = dict(zip(event_format, [p.strip() for p in parts]))
                events.append({
                    'line_num': idx + 1,
                    'raw': raw_line,
                    'dict': e_dict,
                    'style': e_dict.get('Style', ''),
                    'actor': e_dict.get('Name', e_dict.get('Actor', '')),
                    'start': e_dict.get('Start', ''),
                    'end': e_dict.get('End', ''),
                    'ml': int(e_dict.get('MarginL', 0)),
                    'mr': int(e_dict.get('MarginR', 0)),
                    'mv': int(e_dict.get('MarginV', 0)),
                    'effect': e_dict.get('Effect', ''),
                    'text': parts[-1] if parts else ''
                })

    return play_res_x, play_res_y, styles, events


def strip_leading_tags(text):
    m = re.match(r'^((?:\{[^}]*\})*)(.*)$', text)
    if m:
        return m.group(1), m.group(2)
    return '', text


def scan_overflows(file_path, font_dir=None, style_prefix='Dial'):
    play_res_x, play_res_y, styles, events = parse_ass(file_path)

    overflows = []
    with LibassScanner(font_dir) as scanner:
        scanner.init_frame(play_res_x, play_res_y)

        for ev in events:
            style_name = ev['style']
            if style_prefix and style_prefix != '*' and not style_name.startswith(style_prefix):
                continue

            style_info = styles.get(style_name)
            if not style_info:
                continue

            text = ev['text'].rstrip('\r\n')
            # Skip lines already manually positioned with \pos
            if r'\pos(' in text:
                continue

            eff_l = ev['ml'] if ev['ml'] > 0 else style_info['margin_l']
            eff_r = ev['mr'] if ev['mr'] > 0 else style_info['margin_r']
            avail_w = play_res_x - eff_l - eff_r

            # Center X calculation
            center_x = round((eff_l + (play_res_x - eff_r)) / 2)

            prefix_tags, plain_text = strip_leading_tags(text)
            if not plain_text.strip():
                continue

            # If already has explicit \N break, check both lines
            if r'\N' in plain_text:
                parts = plain_text.split(r'\N')
                w_max = max(scanner.measure_unwrapped_width(style_info['raw'], p, style_name=style_name) for p in parts)
                has_explicit_break = True
            else:
                w_max = scanner.measure_unwrapped_width(style_info['raw'], plain_text, style_name=style_name)
                has_explicit_break = False

            if w_max > avail_w:
                overflows.append({
                    'line_num': ev['line_num'],
                    'start': ev['start'],
                    'end': ev['end'],
                    'actor': ev['actor'],
                    'style': style_name,
                    'margin_l': ev['ml'],
                    'margin_r': ev['mr'],
                    'avail_w': avail_w,
                    'measured_w': w_max,
                    'overflow_px': w_max - avail_w,
                    'center_x': center_x,
                    'has_explicit_break': has_explicit_break,
                    'prefix_tags': prefix_tags,
                    'text': plain_text
                })

    return overflows, play_res_x, play_res_y


def main():
    parser = argparse.ArgumentParser(description='Scan ASS dialogue lines for layout margin overflow.')
    parser.add_argument('ass', help='Path to .ass file')
    parser.add_argument('--font-dir', help='Optional path to font directory for libass', default=None)
    parser.add_argument('--style-prefix', help='Style prefix to filter (default: Dial, use * for all)', default='Dial')
    parser.add_argument('--json', nargs='?', const='-', default=None,
                        help='Output results in JSON format (optionally provide file path)')
    args = parser.parse_args()

    overflows, prx, pry = scan_overflows(args.ass, args.font_dir, args.style_prefix)

    if args.json is not None:
        payload = json.dumps({
            'file': args.ass,
            'play_res_x': prx,
            'play_res_y': pry,
            'total_overflows': len(overflows),
            'items': overflows
        }, ensure_ascii=False, indent=2)
        if args.json != '-':
            out_path = Path(args.json).resolve()
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(payload + '\n', encoding='utf-8')
        print(payload)
    else:
        print(f"=== ASS Layout Margin Scanner: {args.ass} ===")
        print(f"Canvas: {prx}x{pry} | Total overflow lines: {len(overflows)}\n")
        for item in overflows:
            print(f"Line {item['line_num']:5d} [{item['start']}] Actor: {item['actor']:12s} | Avail: {item['avail_w']:4d}px, Need: {item['measured_w']:4d}px (+{item['overflow_px']:3d}px) | CenterX: {item['center_x']}")
            print(f"   Text: {item['text']}")
            print()


if __name__ == '__main__':
    main()
