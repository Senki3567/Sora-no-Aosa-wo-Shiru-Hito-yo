#!/usr/bin/env python3
"""
MCP Server for subs.typesetting.cc
Enables Antigravity / AI agents to search, inspect and download fansub subtitles across anime projects.
Uses the fixed password 'SlothStationAlpha' and native REST API.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

# Add script dir to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from typesetting_subs import TypesettingSubsClient

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("typesetting-subs")
client = TypesettingSubsClient()


@mcp.tool()
def search_anime(query: str) -> str:
    """
    Search for anime titles on subs.typesetting.cc.
    Returns list of matching anime records with anime ID (aid), title, episodes, and languages.
    
    Args:
        query: Anime title, romaji name, or keyword (e.g., 'Kaguya', 'Frieren', 'Panty').
    """
    try:
        results = client.search(query)
        if not results:
            return f"Không tìm thấy anime nào khớp với: '{query}'."
        return json.dumps(results, ensure_ascii=False, indent=2)
    except Exception as e:
        return f"Lỗi khi tìm kiếm: {e}"


@mcp.tool()
def get_anime_episodes(aid: int) -> str:
    """
    Get detailed episode list for an anime on subs.typesetting.cc.
    Returns list of episodes with episode ID (eid), episode number, title, and script counts.
    
    Args:
        aid: Anime ID from search_anime (e.g., 19701 for Chou Kaguya-hime).
    """
    try:
        data = client.get_anime_details(aid)
        return json.dumps(data, ensure_ascii=False, indent=2)
    except Exception as e:
        return f"Lỗi khi lấy danh sách tập: {e}"


@mcp.tool()
def get_episode_subtitles(eid: int) -> str:
    """
    List all subtitle files (.ass) available for a specific episode, including fansub group,
    language, typesetting line count (n_ts), and peak typesetting score (ts_peak).
    
    Args:
        eid: Episode ID from get_anime_episodes.
    """
    try:
        scripts = client.get_episode_scripts(eid)
        if not scripts:
            return f"Không có phụ đề nào cho episode {eid}."
        return json.dumps(scripts, ensure_ascii=False, indent=2)
    except Exception as e:
        return f"Lỗi khi lấy phụ đề tập: {e}"


@mcp.tool()
def download_subtitle_file(fid: int, output_dir: str = ".") -> str:
    """
    Download an ASS subtitle file from subs.typesetting.cc by its File ID (fid).
    
    Args:
        fid: Subtitle Script File ID from get_episode_subtitles.
        output_dir: Target directory to save the downloaded .ass file (default: current directory).
    """
    try:
        saved_path = client.download_script(fid, output_dir)
        return f"Tải phụ đề thành công: {saved_path.resolve()}"
    except Exception as e:
        return f"Lỗi khi tải file: {e}"


if __name__ == "__main__":
    mcp.run()
