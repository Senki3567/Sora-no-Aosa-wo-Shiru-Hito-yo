#!/usr/bin/env python3
"""Read-only inventory for ASS karaoke source, templates and generated KFX.

This reports structural evidence only. It does not execute Automation 4 Lua,
infer visual quality, or decide which templater dialect is semantically correct.
"""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import re
import sys

from ass_tools import Document, timestamp_ms


COMPONENT_KINDS = {'code', 'template', 'mixin'}
EXPLICIT_SOURCE = {'kara', 'karaoke'}
THE0X_MARKERS = {
    'mixin', 'anystyle', 'actor', 'noactor', 't_actor', 'no_t_actor',
    'prefix', 'nok0', 'keeptags', 'keepspace', 'nomerge', 'notext',
}
NYAA_MARKERS = {'fbf', 'recalculate', 'shape', 'allowempty', 'keepbrackets', 'hidesyl'}
STOCK_MARKERS = {'pre-line', 'furi', 'fxgroup'}
K_DURATION = re.compile(r'\\(k|K|kf|ko)(\d+)')
KT_OFFSET = re.compile(r'\\kt(\d+)')


def effect_tokens(effect):
    """Return lowercase space-delimited Effect tokens without punctuation."""
    return [token.casefold() for token in re.findall(r'[^\s,]+', effect.strip())]


def marker_hits(tokens, effect):
    token_set = set(tokens)
    result = defaultdict(list)
    for marker in sorted(THE0X_MARKERS & token_set):
        result['the0x'].append(marker)
    for marker in sorted(NYAA_MARKERS & token_set):
        result['nyaa'].append(marker)
    for marker in sorted(STOCK_MARKERS & token_set):
        result['stock'].append(marker)

    # Named/nested loops are a The0x extension; a bare numeric loop is shared.
    if re.search(r'(?:^|\s)!?loop\s+[A-Za-z_]\w*\s+\d+', effect, re.I):
        result['the0x'].append('named_loop')
    # These stock classes are meaningful only when used as Effect tokens.
    for marker in ('all', 'char'):
        if marker in token_set:
            result['stock'].append(marker)
    return result


def classify_event(row):
    effect = row.get('Effect', '').strip()
    tokens = effect_tokens(effect)
    first = tokens[0].lstrip('!') if tokens else ''
    text = row.get('Text', '')
    if first in COMPONENT_KINDS:
        return 'component', first, tokens
    if first in EXPLICIT_SOURCE and len(tokens) == 1:
        return 'explicit_source', None, tokens
    if first == 'fx' and len(tokens) == 1:
        return 'generated_fx', None, tokens
    if not effect and (K_DURATION.search(text) or KT_OFFSET.search(text)):
        return 'implicit_source_candidate', None, tokens
    return 'other', None, tokens


def inspect_document(document):
    counts = Counter()
    component_classes = Counter()
    component_styles = Counter()
    source_styles = Counter()
    dialect_evidence = defaultdict(list)
    clocks = []

    for event in document.events.values():
        row = event.data()
        category, component_kind, tokens = classify_event(row)
        counts[category] += 1
        if component_kind:
            component_classes[component_kind] += 1
            component_styles[row.get('Style', '').strip()] += 1
        if category in ('explicit_source', 'implicit_source_candidate'):
            source_styles[row.get('Style', '').strip()] += 1

        effect = row.get('Effect', '').strip()
        for family, markers in marker_hits(tokens, effect).items():
            if markers:
                dialect_evidence[family].append({
                    'line': event.line,
                    'effect': effect,
                    'markers': sorted(set(markers)),
                })

        durations = [(kind, int(value)) for kind, value in K_DURATION.findall(row.get('Text', ''))]
        offsets = [int(value) for value in KT_OFFSET.findall(row.get('Text', ''))]
        if durations or offsets:
            record = {
                'line': event.line,
                'event_kind': event.kind,
                'category': category,
                'style': row.get('Style', '').strip(),
                'k_tags': [{'tag': kind, 'centiseconds': value} for kind, value in durations],
                'k_total_ms': sum(value for _, value in durations) * 10,
                'kt_offsets_ms': [value * 10 for value in offsets],
            }
            try:
                duration = timestamp_ms(row['End']) - timestamp_ms(row['Start'])
                record['cue_duration_ms'] = duration
                record['k_minus_cue_ms'] = record['k_total_ms'] - duration
                if record['k_total_ms'] > duration:
                    record['warning'] = 'karaoke_duration_exceeds_cue'
            except (KeyError, ValueError) as exc:
                record['time_error'] = str(exc)
            clocks.append(record)

    families = sorted(family for family, evidence in dialect_evidence.items() if evidence)
    risks = []
    source_count = counts['explicit_source'] + counts['implicit_source_candidate']
    if sum(component_classes.values()) and not source_count:
        risks.append({'code': 'components_without_source_candidate',
                      'detail': 'No explicit kara/karaoke or empty-Effect karaoke source was found.'})
    if component_classes['mixin'] and not component_classes['template']:
        risks.append({'code': 'mixin_without_template',
                      'detail': 'Mixin lines do not emit output by themselves.'})
    if counts['generated_fx']:
        risks.append({'code': 'generated_fx_present',
                      'detail': 'Confirm regeneration ownership before deleting or replacing Effect: fx lines.'})
    if len(families) > 1:
        risks.append({'code': 'mixed_dialect_signals', 'families': families,
                      'detail': 'Verify the exact templater build; shared keywords can still make this a false positive.'})
    if 'nyaa' in families:
        risks.append({'code': 'nyaa_build_or_dependency_required',
                      'detail': 'fbf/recalculate/shape extensions depend on the exact local build and may need extra modules.'})
    if any(record.get('warning') for record in clocks):
        risks.append({'code': 'karaoke_clock_overrun',
                      'detail': 'At least one sum of duration-based karaoke tags exceeds its cue span.'})
    risks.append({'code': 'lua_not_executed',
                  'detail': 'Dynamic expressions, include files, output count and rendered appearance require the actual Automation runtime.'})

    return {
        'sha256': document.sha256,
        'bytes': len(document.raw),
        'encoding': document.encoding,
        'parse_warnings': document.warnings,
        'counts': dict(counts),
        'component_classes': dict(component_classes),
        'component_styles': dict(component_styles),
        'source_styles': dict(source_styles),
        'dialect': {
            'families_with_signals': families,
            'evidence': {family: rows for family, rows in sorted(dialect_evidence.items())},
            'note': 'Signals are lexical evidence, not proof of a compatible runtime.',
        },
        'karaoke_clocks': clocks,
        'risks': risks,
        'limitations': [
            'Does not execute templates, code, mixins, includes or export filters.',
            'Does not predict generated line count or validate visual composition.',
            'An empty-Effect karaoke row is only an implicit source candidate.',
            'A shorter duration-tag sum can be intentional; only overrun is flagged.',
        ],
    }


def inspect_path(path, encoding=None):
    return inspect_document(Document.read(path, encoding))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ass', help='ASS file to inspect; it is never modified')
    parser.add_argument('--encoding', help='Input encoding when BOM/UTF-8 detection is insufficient')
    parser.add_argument('--pretty', action='store_true', help='Indent JSON output')
    args = parser.parse_args(argv)
    try:
        result = inspect_path(Path(args.ass), args.encoding)
    except (OSError, ValueError) as exc:
        print(json.dumps({'error': str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None,
                     sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
