#!/usr/bin/env python3
"""Portable libass RGBA overlay rendering and explicitly bounded CPU profiling."""
import argparse
import ctypes as C
import ctypes.util
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import time
from ass_tools import Document


class AssImage(C.Structure):
    pass


AssImage._fields_ = [('w', C.c_int), ('h', C.c_int), ('stride', C.c_int),
                    ('bitmap', C.POINTER(C.c_ubyte)), ('color', C.c_uint32),
                    ('x', C.c_int), ('y', C.c_int), ('next', C.POINTER(AssImage))]


def dimensions(value):
    try:
        w, h = map(int, value.lower().split('x'))
    except ValueError as exc:
        raise argparse.ArgumentTypeError('Use WIDTHxHEIGHT') from exc
    if w < 1 or h < 1:
        raise argparse.ArgumentTypeError('Dimensions must be positive')
    return w, h


class Renderer:
    def __init__(self, size, storage, font_dirs, cache_mb=None, pixel_aspect=0):
        library = ctypes.util.find_library('ass')
        if not library:
            raise ValueError('libass is unavailable; preserve the ASS and use the target renderer instead')
        self.a = C.CDLL(library)
        self.size, self.storage, self.cache_mb = size, storage, cache_mb
        self.pixel_aspect = pixel_aspect
        signatures = [
            ('ass_library_init', [], C.c_void_p),
            ('ass_renderer_init', [C.c_void_p], C.c_void_p),
            ('ass_set_frame_size', [C.c_void_p, C.c_int, C.c_int], None),
            ('ass_set_storage_size', [C.c_void_p, C.c_int, C.c_int], None),
            ('ass_set_pixel_aspect', [C.c_void_p, C.c_double], None),
            ('ass_set_fonts', [C.c_void_p, C.c_char_p, C.c_char_p, C.c_int, C.c_char_p, C.c_int], None),
            ('ass_set_cache_limits', [C.c_void_p, C.c_int, C.c_int], None),
            ('ass_add_font', [C.c_void_p, C.c_char_p, C.c_char_p, C.c_int], None),
            ('ass_read_memory', [C.c_void_p, C.c_char_p, C.c_size_t, C.c_char_p], C.c_void_p),
            ('ass_render_frame', [C.c_void_p, C.c_void_p, C.c_longlong, C.POINTER(C.c_int)], C.POINTER(AssImage)),
            ('ass_free_track', [C.c_void_p], None),
            ('ass_renderer_done', [C.c_void_p], None),
            ('ass_library_done', [C.c_void_p], None),
            ('ass_library_version', [], C.c_uint),
        ]
        for name, arguments, result in signatures:
            fn = getattr(self.a, name); fn.argtypes = arguments; fn.restype = result
        self.lib = self.a.ass_library_init()
        if not self.lib:
            raise ValueError('Cannot initialize libass library')
        self.renderer, self.track = None, None
        self.fonts = []
        try:
            for directory in font_dirs:
                directory = Path(directory).resolve()
                if not directory.is_dir():
                    raise ValueError(f'Font directory absent: {directory}')
                for path in sorted(directory.rglob('*')):
                    if not path.is_file() or path.suffix.casefold() not in ('.ttf', '.otf', '.ttc'):
                        continue
                    if any(f['path'] == str(path) for f in self.fonts):
                        continue
                    data = path.read_bytes()
                    if data.startswith(b'version https://git-lfs.github.com/spec/v1'):
                        raise ValueError(f'Font is an LFS pointer: {path}')
                    self.a.ass_add_font(self.lib, path.name.encode('utf-8'), data, len(data))
                    self.fonts.append({'path': str(path), 'sha256': hashlib.sha256(data).hexdigest()})
            self.reset()
        except Exception:
            self.close(); raise

    def reset(self):
        if self.renderer:
            self.a.ass_renderer_done(self.renderer)
        self.renderer = self.a.ass_renderer_init(self.lib)
        if not self.renderer:
            raise ValueError('Cannot initialize libass renderer')
        self.a.ass_set_frame_size(self.renderer, *self.size)
        self.a.ass_set_storage_size(self.renderer, *self.storage)
        self.a.ass_set_pixel_aspect(self.renderer, self.pixel_aspect)
        self.a.ass_set_fonts(self.renderer, None, b'Arial', 1, None, 1)
        if self.cache_mb is not None:
            self.a.ass_set_cache_limits(self.renderer, 0, self.cache_mb)

    def load(self, data):
        self.track = self.a.ass_read_memory(self.lib, data, len(data), None)
        if not self.track:
            raise ValueError('libass could not load the track')

    def render(self, timestamp):
        changed = C.c_int()
        start = time.perf_counter()
        head = self.a.ass_render_frame(self.renderer, self.track, timestamp, C.byref(changed))
        elapsed = (time.perf_counter() - start) * 1000
        count, area, colored = 0, 0, 0
        cursor = head
        while cursor:
            z = cursor.contents
            if z.w > 0 and z.h > 0:
                count += 1; area += z.w * z.h
                if (z.color & 255) != 255:
                    colored += z.w * z.h
            cursor = z.next
        return head, {'time_ms': timestamp, 'libass_cpu_ms': elapsed,
                      'bitmap_count': count, 'bitmap_area_pixels': area,
                      'nontransparent_color_bitmap_area_pixels': colored,
                      'change_flag': changed.value}

    def png(self, head, output):
        try:
            import numpy as np
            from PIL import Image
        except ImportError as exc:
            raise ValueError('PNG output needs NumPy and Pillow; profiling does not') from exc
        width, height = self.size
        # Keep premultiplied RGB during compositing; convert once for PNG straight alpha.
        canvas = np.zeros((height, width, 4), dtype=np.float32)
        while head:
            z = head.contents
            left, top = max(z.x, 0), max(z.y, 0)
            right, bottom = min(z.x + z.w, width), min(z.y + z.h, height)
            if left < right and top < bottom and (z.color & 255) != 255:
                bitmap = np.ctypeslib.as_array(z.bitmap, shape=(z.h * z.stride,)).reshape(z.h, z.stride)
                alpha = bitmap[top-z.y:bottom-z.y, left-z.x:right-z.x].astype(np.float32) / 255
                alpha *= (255 - (z.color & 255)) / 255
                color = np.array([(z.color >> 24) & 255, (z.color >> 16) & 255,
                                  (z.color >> 8) & 255], dtype=np.float32) / 255
                region = canvas[top:bottom, left:right]
                region[:, :, :3] = color * alpha[:, :, None] + region[:, :, :3] * (1-alpha[:, :, None])
                region[:, :, 3] = alpha + region[:, :, 3] * (1-alpha)
            head = z.next
        alpha = canvas[:, :, 3:4]
        canvas[:, :, :3] = np.divide(canvas[:, :, :3], alpha,
                                    out=np.zeros_like(canvas[:, :, :3]), where=alpha > 0)
        Image.fromarray(np.rint(np.clip(canvas, 0, 1) * 255).astype(np.uint8)).save(output)

    def close(self):
        if getattr(self, 'track', None):
            self.a.ass_free_track(self.track); self.track = None
        if getattr(self, 'renderer', None):
            self.a.ass_renderer_done(self.renderer); self.renderer = None
        if getattr(self, 'lib', None):
            self.a.ass_library_done(self.lib); self.lib = None


def percentile(values, q):
    values = sorted(values); position = (len(values)-1) * q
    lo, hi = math.floor(position), math.ceil(position)
    return values[lo] + (values[hi] - values[lo]) * (position-lo)


def stats(values):
    return {'median_ms': round(statistics.median(values), 3),
            'p95_ms': round(percentile(values, .95), 3), 'max_ms': round(max(values), 3)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('ass'); p.add_argument('--font-dir', action='append', default=[])
    p.add_argument('--size', type=dimensions, default=(1920,1080))
    p.add_argument('--storage-size', type=dimensions)
    p.add_argument('--pixel-aspect', type=float, default=0, help='Video PAR correction; 0 uses libass automatic default')
    p.add_argument('--times-ms', type=int, nargs='+', required=True)
    p.add_argument('--cache-mb', type=int); p.add_argument('--fresh', action='store_true')
    p.add_argument('--png-dir'); p.add_argument('--report'); p.add_argument('--force', action='store_true')
    args = p.parse_args(); renderer = None
    try:
        if not math.isfinite(args.pixel_aspect) or args.pixel_aspect < 0:
            raise ValueError('Pixel aspect must be finite and nonnegative (0 = automatic)')
        if min(args.times_ms) < 0 or (args.cache_mb is not None and args.cache_mb < 1):
            raise ValueError('Timestamps must be nonnegative; cache limit must be positive')
        if args.report and Path(args.report).resolve() == Path(args.ass).resolve():
            raise ValueError('Report must not overwrite the source ASS')
        pngs = [Path(args.png_dir) / f'render_{i:04d}_{t}.png' for i,t in enumerate(args.times_ms)] if args.png_dir else []
        outputs = pngs + ([Path(args.report)] if args.report else [])
        if not args.force and any(path.exists() for path in outputs):
            raise ValueError('Generated output exists; use another path or --force intentionally')
        doc = Document.read(args.ass)
        content = ''.join(doc.lines).encode('utf-8')
        renderer = Renderer(args.size, args.storage_size or args.size, args.font_dir, args.cache_mb, args.pixel_aspect)
        begin = time.perf_counter(); renderer.load(content); load_ms = (time.perf_counter()-begin)*1000
        samples = []
        if pngs:
            Path(args.png_dir).mkdir(parents=True, exist_ok=True)
        for i, timestamp in enumerate(args.times_ms):
            head, sample = renderer.render(timestamp)
            if pngs:
                renderer.png(head, pngs[i]); sample['png'] = str(pngs[i].resolve())
            samples.append(sample)
        if args.fresh:
            for row in samples:
                renderer.reset()
                _, fresh = renderer.render(row['time_ms'])
                row['fresh_renderer_cpu_ms'] = fresh['libass_cpu_ms']
                row['fresh_bitmap_area_pixels'] = fresh['bitmap_area_pixels']
                row['fresh_matches_bitmap_area'] = fresh['bitmap_area_pixels'] == row['bitmap_area_pixels']
        report = {'ass': str(Path(args.ass).resolve()), 'ass_sha256': doc.sha256,
                  'bytes': len(doc.raw), 'libass_version_hex': hex(renderer.a.ass_library_version()),
                  'size': list(args.size), 'storage_size': list(args.storage_size or args.size),
                  'pixel_aspect_requested': args.pixel_aspect,
                  'fonts': renderer.fonts, 'cache_limit_mib': args.cache_mb,
                  'sample_count': len(samples), 'timestamps_in_given_order': args.times_ms,
                  'track_load_ms': round(load_ms,3),
                  'sequential': stats([r['libass_cpu_ms'] for r in samples]),
                  'fresh_renderer': stats([r['fresh_renderer_cpu_ms'] for r in samples]) if args.fresh else None,
                  'max_bitmap_area_pixels': max(r['bitmap_area_pixels'] for r in samples),
                  'samples': samples,
                  'method': 'CPU ass_render_frame only; excludes setup, PNG/compositor, decoder/player/display. Fresh renderer keeps library/fonts/track; not a full-process cold start.'}
        if args.report:
            dest = Path(args.report); dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        print(json.dumps({k:v for k,v in report.items() if k != 'samples'}, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, AttributeError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr); return 2
    finally:
        if renderer:
            renderer.close()


if __name__ == '__main__':
    sys.exit(main())
