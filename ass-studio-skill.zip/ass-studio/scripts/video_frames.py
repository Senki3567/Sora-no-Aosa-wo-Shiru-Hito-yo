#!/usr/bin/env python3
"""Probe a video and extract exact zero-based native frame indices in one pass."""
import argparse
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile


def probe(path):
    args = ['ffprobe', '-v', 'error', '-show_entries',
        'format=duration,start_time:stream=index,codec_type,codec_name,width,height,'
        'r_frame_rate,avg_frame_rate,start_time,sample_aspect_ratio,color_space,color_range,'
        'color_transfer,color_primaries,sample_rate,channels:stream_tags=language,title:'
        'stream_disposition=attached_pic', '-of', 'json', str(path)]
    result = subprocess.run(args, capture_output=True, text=True, check=True)
    return json.loads(result.stdout)


def extract(video, frames, output, force=False):
    video, output = Path(video).resolve(), Path(output).resolve()
    if not video.is_file():
        raise ValueError('Input video does not exist')
    frames = sorted(set(frames))
    if not frames or frames[0] < 0:
        raise ValueError('Choose at least one nonnegative native frame index')
    metadata = probe(video)
    streams = [s for s in metadata.get('streams', []) if s.get('codec_type') == 'video']
    if not streams or streams[0].get('disposition', {}).get('attached_pic'):
        raise ValueError('First video stream is absent or an attached picture; select the source explicitly')
    paths = [output / f'frame_{n:06d}.png' for n in frames]
    if not force and any(p.exists() for p in paths + [output / 'frames.json', output / 'contact_sheet.jpg']):
        raise ValueError('Output artifacts already exist; use another folder or --force intentionally')
    output.mkdir(parents=True, exist_ok=True)
    selector = '+'.join(f'eq(n\\,{n})' for n in frames)
    with tempfile.TemporaryDirectory(prefix='extract-', dir=output) as temp:
        pattern = str(Path(temp) / '%06d.png')
        args = ['ffmpeg', '-hide_banner', '-nostdin', '-loglevel', 'info', '-threads', '2',
                '-copyts', '-i', str(video), '-map', '0:v:0', '-an', '-sn', '-dn',
                '-vf', f'select={selector},showinfo', '-fps_mode', 'passthrough',
                '-frames:v', str(len(frames)), '-start_number', '0', '-y', pattern]
        proc = subprocess.run(args, capture_output=True, text=True)
        if proc.returncode:
            raise ValueError('ffmpeg extraction failed:\n' + proc.stderr[-4000:])
        pts = re.findall(r'\bn:\s*\d+\s+pts:\s*\S+\s+pts_time:([^\s]+)', proc.stderr)
        images = sorted(Path(temp).glob('*.png'))
        if len(images) != len(frames) or len(pts) != len(frames):
            raise ValueError(f'Requested {len(frames)} frames, decoded {len(images)} images / {len(pts)} timestamps')
        records = []
        for index, stamp, src, dest in zip(frames, pts, images, paths):
            shutil.move(str(src), dest)
            records.append({'frame_index_0based': index, 'pts_time_s': float(stamp),
                            'pts_time_text': stamp, 'pts_ms_rounded': round(float(stamp) * 1000),
                            'file': str(dest)})
    stat = video.stat()
    report = {'source': str(video), 'source_bytes': stat.st_size,
              'source_mtime_ns': stat.st_mtime_ns, 'probe': metadata,
              'method': 'Decoded from native frame zero; select before showinfo, no fps resampling, copyts enabled',
              'frames': records}
    try:
        from PIL import Image, ImageDraw
        width, thumb_height, columns = 480, 270, min(3, len(records))
        rows = (len(records) + columns - 1) // columns
        sheet = Image.new('RGB', (columns * width, rows * (thumb_height + 28)), '#161b22')
        draw = ImageDraw.Draw(sheet)
        for i, row in enumerate(records):
            x, y = i % columns * width, i // columns * (thumb_height + 28)
            with Image.open(row['file']) as image:
                image = image.convert('RGB'); image.thumbnail((width, thumb_height))
                sheet.paste(image, (x, y))
            draw.text((x + 8, y + thumb_height + 4),
                      f"frame {row['frame_index_0based']} | PTS {row['pts_time_text']} s", fill='white')
        sheet.save(output / 'contact_sheet.jpg', quality=92)
        report['contact_sheet'] = str(output / 'contact_sheet.jpg')
    except ImportError:
        report['contact_sheet'] = None
    (output / 'frames.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('video'); selection = p.add_mutually_exclusive_group(required=True)
    selection.add_argument('--frames', type=int, nargs='+')
    selection.add_argument('--range', type=int, nargs=2, metavar=('START', 'END'))
    p.add_argument('--step', type=int, default=1); p.add_argument('--output', required=True)
    p.add_argument('--force', action='store_true'); args = p.parse_args()
    try:
        if args.step < 1:
            raise ValueError('--step must be positive')
        if args.range and args.range[1] < args.range[0]:
            raise ValueError('Range end precedes start')
        frames = args.frames if args.frames is not None else list(range(args.range[0], args.range[1] + 1, args.step))
        result = extract(args.video, frames, args.output, args.force)
        print(json.dumps({'output': str(Path(args.output).resolve()), 'frames': result['frames'],
                          'contact_sheet': result.get('contact_sheet')}, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr); return 2


if __name__ == '__main__':
    sys.exit(main())
