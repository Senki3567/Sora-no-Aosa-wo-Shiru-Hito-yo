#!/usr/bin/env python3
"""Loss-preserving ASS inventory, guarded event-field patching, comparison, tag/timing/font/series auditing."""
import argparse
from collections import Counter, defaultdict
from dataclasses import dataclass
import hashlib
import io
import json
from pathlib import Path
import re
import sys

STANDARD = ('Layer Start End Style Name MarginL MarginR MarginV Effect Text '
            'Fontname Fontsize PrimaryColour SecondaryColour OutlineColour BackColour '
            'Bold Italic Underline StrikeOut ScaleX ScaleY Spacing Angle BorderStyle '
            'Outline Shadow Alignment Encoding').split()
NAMES = {x.casefold(): x for x in STANDARD}
NAMES['actor'] = 'Name'

SINGLETON_BLOCK_TAGS = ('pos', 'move', 'an', 'org', 'fad', 'fade', 'q')
HALLUCINATED_TAGS = ('opacity', 'scale', 'rotate', 'rotation', 'glow', 'color', 'x', 'y', 'z', 'size', 'align')
DRAWING_TOKEN_RE = re.compile(r'^[mnlbspc]|^-?\d+(?:\.\d+)?$')


def canonical(name):
    if not isinstance(name, str):
        raise ValueError('Field names must be strings')
    return NAMES.get(name.strip().casefold(), name.strip())


def normalized_mapping(value, label):
    if not isinstance(value, dict):
        raise ValueError(f'{label} must be a JSON object')
    result = {}
    for key, item in value.items():
        field = canonical(key)
        if field in result:
            raise ValueError(f'Duplicate field/alias in {label}: {field}')
        result[field] = item
    return result


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ending(line):
    m = re.search(r'(\r\n|\n|\r)$', line)
    return m.group(1) if m else ''


def physical_lines(text):
    parts = re.split(r'(\r\n|\n|\r)', text)
    return [parts[i] + (parts[i + 1] if i + 1 < len(parts) else '')
            for i in range(0, len(parts), 2) if parts[i] or i + 1 < len(parts)]


def timestamp_ms(value):
    m = re.fullmatch(r'(\d+):([0-5]\d):([0-5]\d)\.(\d{2})', value.strip())
    if not m:
        raise ValueError(f'Invalid ASS timestamp: {value!r}')
    h, minute, sec, cs = map(int, m.groups())
    return (h * 3600 + minute * 60 + sec) * 1000 + cs * 10


def decode_ass_uuencoded_section(lines):
    """Decode an ASS [Fonts] or [Graphics] uuencoded payload into raw bytes."""
    out = bytearray()
    for raw_line in lines:
        s = raw_line.strip()
        if not s or s.lower().startswith('fontname:') or s.lower().startswith('filename:'):
            continue
        vals = [ord(ch) - 33 for ch in s]
        if any(v < 0 or v > 63 for v in vals):
            raise ValueError(f'Invalid uuencode character in line: {s[:20]!r}')
        n = len(vals)
        for i in range(0, n, 4):
            chunk = vals[i:i + 4]
            if len(chunk) < 2:
                break
            b0 = (chunk[0] << 2) | (chunk[1] >> 4)
            out.append(b0 & 0xFF)
            if len(chunk) >= 3:
                b1 = ((chunk[1] & 0x0F) << 4) | (chunk[2] >> 2)
                out.append(b1 & 0xFF)
            if len(chunk) >= 4:
                b2 = ((chunk[2] & 0x03) << 6) | chunk[3]
                out.append(b2 & 0xFF)
    return bytes(out)


@dataclass
class Event:
    line: int
    kind: str
    prefix: str
    fields: tuple
    values: list
    newline: str

    def data(self):
        return dict(zip(self.fields, self.values))

    def render(self, values):
        return self.prefix + ','.join(values) + self.newline


class Document:
    def __init__(self, data, encoding=None):
        if data.startswith(b'version https://git-lfs.github.com/spec/v1'):
            raise ValueError('This is an LFS pointer; obtain the actual ASS object first')
        self.raw = data
        self.sha256 = digest(data)
        self.bom = b''
        for bom, codec in ((b'\xef\xbb\xbf', 'utf-8'),
                           (b'\xff\xfe', 'utf-16-le'), (b'\xfe\xff', 'utf-16-be')):
            if data.startswith(bom):
                self.bom, self.encoding = bom, codec
                data = data[len(bom):]
                break
        else:
            self.encoding = encoding or 'utf-8'
        try:
            text = data.decode(self.encoding)
        except UnicodeDecodeError as exc:
            raise ValueError('Cannot decode ASS; supply --encoding explicitly') from exc
        self.lines = physical_lines(text)
        self.events = {}
        self.styles = {}
        self.sections = []
        self.info = {}
        self.warnings = []
        self.extradata_ids = []
        self.embedded_fonts = []
        section, event_format, style_format = '', None, None
        current_font = None
        KNOWN_SECTIONS = {'script info', 'v4+ styles', 'v4 styles', 'events', 'fonts', 'graphics', 'aegisub project garbage', 'aegisub extradata'}
        for number, full in enumerate(self.lines, 1):
            body = full[:-len(ending(full))] if ending(full) else full
            stripped = body.strip()
            # In [Fonts] or [Graphics], a uuencoded 80-char line can start with '[' and even end with ']'.
            # Only treat [Header] as a true section header if it matches a valid ASS section header pattern.
            if stripped.startswith('[') and stripped.endswith(']'):
                candidate_sec = stripped[1:-1].strip().casefold()
                if section not in ('fonts', 'graphics') or candidate_sec in KNOWN_SECTIONS or len(stripped) < 40:
                    if current_font is not None:
                        self.embedded_fonts.append(current_font)
                        current_font = None
                    section = candidate_sec
                    self.sections.append({'name': stripped, 'line': number})
                    event_format, style_format = None, None
                    continue
            if section == 'fonts':
                if stripped.lower().startswith('fontname:'):
                    if current_font is not None:
                        self.embedded_fonts.append(current_font)
                    fname = stripped.split(':', 1)[1].strip()
                    current_font = {'fontname_header': fname, 'line': number, 'payload_lines': []}
                elif current_font is not None and stripped:
                    current_font['payload_lines'].append(stripped)
                continue
            if section == 'script info' and ':' in body and not stripped.startswith(';'):
                key, val = body.split(':', 1)
                self.info[key.strip()] = val.strip()
            if stripped.startswith('Format:'):
                fmt = tuple(canonical(f) for f in stripped.split(':', 1)[1].split(','))
                if section == 'events':
                    event_format = fmt
                elif section in ('v4+ styles', 'v4 styles'):
                    style_format = fmt
            match = re.match(r'^([ \t]*)(Dialogue|Comment):([ \t]*)(.*)$', body)
            if match:
                if section != 'events':
                    self.warnings.append({'line': number, 'issue': 'event_outside_Events'})
                    continue
                if (not event_format or event_format[-1] != 'Text'
                        or len(set(event_format)) != len(event_format)):
                    self.warnings.append({'line': number, 'issue': 'ambiguous_or_missing_Event_Format'})
                    continue
                vals = match.group(4).split(',', len(event_format) - 1)
                if len(vals) != len(event_format):
                    self.warnings.append({'line': number, 'issue': 'wrong_event_field_count'})
                    continue
                self.events[number] = Event(number, match.group(2),
                    match.group(1) + match.group(2) + ':' + match.group(3),
                    event_format, vals, ending(full))
            elif stripped.startswith('Style:') and section in ('v4+ styles', 'v4 styles'):
                if not style_format or len(set(style_format)) != len(style_format):
                    self.warnings.append({'line': number, 'issue': 'missing_or_duplicate_style_Format'})
                    continue
                vals = stripped.split(':', 1)[1].lstrip().split(',', len(style_format) - 1)
                if len(vals) != len(style_format):
                    self.warnings.append({'line': number, 'issue': 'wrong_style_field_count'})
                    continue
                style = dict(zip(style_format, vals))
                name = style.get('Name', '').strip()
                if name in self.styles:
                    self.warnings.append({'line': number, 'issue': 'duplicate_style_name', 'name': name})
                self.styles[name] = style
            elif section == 'aegisub extradata' and stripped.startswith('Data:'):
                ident = stripped.split(':', 1)[1].split(',', 1)[0].strip()
                if ident.isdigit():
                    self.extradata_ids.append(int(ident))
        if current_font is not None:
            self.embedded_fonts.append(current_font)

    @classmethod
    def read(cls, path, encoding=None):
        return cls(Path(path).read_bytes(), encoding)

    def serialize(self, lines=None):
        return self.bom + ''.join(self.lines if lines is None else lines).encode(self.encoding)

    def inventory(self):
        counts, styles, actors = Counter(), Counter(), Counter()
        fonts = {s.get('Fontname', '').strip() for s in self.styles.values()}
        refs, sweep, starts, ends, warnings = set(), [], [], [], list(self.warnings)
        features = Counter()
        for ev in self.events.values():
            row = ev.data()
            counts[ev.kind] += 1
            styles[row.get('Style', '').strip()] += 1
            actors[row.get('Name', '').strip()] += 1
            text = row['Text']
            for marker in re.findall(r'\{=([0-9=]+)\}', text):
                refs.update(int(i) for i in marker.split('=') if i)
            for block in re.findall(r'\{([^}]*)\}', text):
                fonts.update(f.strip() for f in re.findall(r'\\fn([^\\}]+)', block))
            if re.search(r'\\p[1-9]\d*\b', text):
                features['drawing_events'] += 1
            if re.search(r'\\(?:k[fo]?|K|kt)\d', text):
                features['karaoke_tag_events'] += 1
            if re.search(r'\\(?:move|t|fad|fade)\(', text):
                features['animated_events'] += 1
            try:
                a, b = timestamp_ms(row['Start']), timestamp_ms(row['End'])
                starts.append(a); ends.append(b)
                if b < a:
                    warnings.append({'line': ev.line, 'issue': 'End_before_Start'})
                if ev.kind == 'Dialogue' and b > a:
                    sweep.extend(((a, 1), (b, -1)))
            except (ValueError, KeyError) as exc:
                warnings.append({'line': ev.line, 'issue': str(exc)})
        live, peak = 0, 0
        for _, delta in sorted(sweep):
            live += delta; peak = max(peak, live)
        unknown = sorted(set(styles) - set(self.styles))
        return {'sha256': self.sha256, 'bytes': len(self.raw), 'encoding': self.encoding,
                'bom': self.bom.hex(), 'newline_counts': dict(Counter(ending(l) or 'none' for l in self.lines)),
                'sections': self.sections, 'script_info': self.info, 'event_counts': dict(counts),
                'event_formats': [list(f) for f in sorted({e.fields for e in self.events.values()})],
                'style_definitions': len(self.styles), 'style_usage': dict(styles),
                'actor_usage': dict(actors), 'fonts': sorted(f for f in fonts if f),
                'undefined_styles': unknown, 'features': dict(features),
                'time_span_ms': [min(starts), max(ends)] if starts else None,
                'peak_concurrent_dialogues': peak,
                'extradata': {'defined_count': len(self.extradata_ids),
                             'duplicate_ids': sorted(i for i,c in Counter(self.extradata_ids).items() if c > 1),
                             'undefined_referenced_ids': sorted(refs - set(self.extradata_ids))},
                'warnings': warnings}


def compare(before, after, allowed_fields=None):
    allowed = {canonical(f) for f in allowed_fields} if allowed_fields is not None else None
    structural, changes, violations = [], [], []
    if before.encoding != after.encoding or before.bom != after.bom:
        structural.append({'issue': 'encoding_or_BOM_changed'})
    if len(before.lines) != len(after.lines):
        structural.append({'issue': 'physical_line_count_changed', 'before': len(before.lines), 'after': len(after.lines)})
    for number, (a, b) in enumerate(zip(before.lines, after.lines), 1):
        if a == b:
            continue
        ea, eb = before.events.get(number), after.events.get(number)
        if not ea or not eb or ea.kind != eb.kind or ea.fields != eb.fields:
            structural.append({'line': number, 'issue': 'non_event_or_event_structure_changed'})
            continue
        if ea.prefix != eb.prefix or ea.newline != eb.newline:
            structural.append({'line': number, 'issue': 'event_prefix_or_newline_changed'})
        changed = [f for f,x,y in zip(ea.fields, ea.values, eb.values) if x != y]
        changes.append({'line': number, 'kind': ea.kind, 'fields': changed})
        if allowed is not None:
            violations.extend({'line': number, 'field': f} for f in changed if f not in allowed)
    return {'before_sha256': before.sha256, 'after_sha256': after.sha256,
            'identical_bytes': before.raw == after.raw, 'event_changes': changes,
            'structural_changes': structural, 'unauthorized_field_changes': violations,
            'scope_pass': None if allowed is None else not structural and not violations}


def patch(source, plan_path, output, encoding=None, force=False):
    source, output = Path(source), Path(output)
    if source.resolve() == output.resolve():
        raise ValueError('Use a distinct candidate output; install it after checking the baseline')
    if output.exists() and not force:
        raise ValueError('Candidate exists; choose another output or use --force intentionally')
    doc = Document.read(source, encoding)
    plan = json.loads(Path(plan_path).read_text(encoding='utf-8-sig'))
    if not isinstance(plan, dict) or not isinstance(plan.get('allowed_fields'), list) or not isinstance(plan.get('edits'), list):
        raise ValueError('Plan must be an object with allowed_fields and edits lists')
    if plan.get('baseline_sha256') != doc.sha256:
        raise ValueError('Baseline SHA256 differs: reread the current ASS and update the plan')
    allowed = {canonical(f) for f in plan.get('allowed_fields', [])}
    if not allowed:
        raise ValueError('Plan must declare allowed_fields')
    lines, touched = doc.lines.copy(), set()
    for edit in plan.get('edits', []):
        if not isinstance(edit, dict):
            raise ValueError('Each edit must be a JSON object')
        number = edit.get('line')
        if type(number) is not int or number not in doc.events or number in touched:
            raise ValueError(f'Invalid, unparsed or repeated event line {number!r}')
        touched.add(number)
        ev = doc.events[number]; old = ev.data()
        if edit.get('kind') != ev.kind:
            raise ValueError(f'Kind differs at line {number}')
        expected = normalized_mapping(edit.get('expect', {}), 'expect')
        required = {'Start', 'End', 'Style', 'Name', 'Text'} & set(ev.fields)
        if not required <= expected.keys():
            raise ValueError(f'expect must include {sorted(required)} at line {number}')
        for field, val in expected.items():
            if field not in old or old[field] != val:
                raise ValueError(f'Expected {field} differs at line {number}')
        updates = normalized_mapping(edit.get('set', {}), 'set')
        if not updates or not set(updates) <= allowed or not set(updates) <= set(ev.fields):
            raise ValueError(f'Unknown, empty or unapproved fields at line {number}')
        new = old.copy()
        for field, val in updates.items():
            if not isinstance(val, str) or '\r' in val or '\n' in val or '\x00' in val:
                raise ValueError(f'Values must be single-line strings at line {number}')
            if field != 'Text' and ',' in val:
                raise ValueError(f'Comma is invalid in {field} at line {number}')
            new[field] = val
        if {'Start', 'End'} & set(updates):
            if timestamp_ms(new['End']) < timestamp_ms(new['Start']):
                raise ValueError(f'End before Start at line {number}')
        lines[number - 1] = ev.render([new[f] for f in ev.fields])
    data = doc.serialize(lines)
    result = compare(doc, Document(data, doc.encoding), list(allowed))
    if not result['scope_pass']:
        raise ValueError('Internal invariant failure: candidate changes exceed allowed fields')
    if source.read_bytes() != doc.raw:
        raise ValueError('Source changed while preparing the candidate; reread baseline')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(data)
    result['output'] = str(output.resolve())
    return result


# ---------------------------------------------------------------------------
# NEW CAPABILITY 1: Structured Override Tag AST & Linter (lint-tags)
# ---------------------------------------------------------------------------

def lint_event_text(text):
    """Inspect a single ASS event Text string for brace/tag syntax issues and extract visible runs."""
    issues = []
    depth = 0
    in_brace = False
    buf = []
    blocks = []
    visible_runs = []

    for idx, ch in enumerate(text):
        if ch == '{':
            if in_brace:
                issues.append({'issue': 'nested_open_brace', 'offset': idx})
            else:
                if buf:
                    visible_runs.append(''.join(buf))
                    buf = []
                in_brace = True
            depth += 1
        elif ch == '}':
            if not in_brace or depth <= 0:
                issues.append({'issue': 'unmatched_close_brace', 'offset': idx})
                buf.append(ch)
            else:
                depth -= 1
                if depth == 0:
                    block_content = ''.join(buf)
                    blocks.append(block_content)
                    buf = []
                    in_brace = False
        else:
            buf.append(ch)

    if in_brace or depth > 0:
        issues.append({'issue': 'unclosed_brace_block', 'offset': len(text)})
    elif buf:
        visible_runs.append(''.join(buf))

    drawing_mode = 0
    for b_idx, blk in enumerate(blocks):
        if blk.endswith('\\'):
            issues.append({'issue': 'trailing_backslash_before_brace_close', 'block_index': b_idx, 'block': blk})
        if '\\' not in blk:
            continue
        # Check nested \t(...)
        for t_match in re.finditer(r'\\t\(([^()]*|\([^()]*\))*\)', blk):
            inner = t_match.group(0)[3:-1]
            if '\\t(' in inner:
                issues.append({'issue': 'nested_transform_tag', 'block_index': b_idx})
        # Check hallucinated tags (e.g. \opacity, \scale, \rotate, \glow)
        for htag in HALLUCINATED_TAGS:
            if re.search(rf'\\{htag}(?![a-zA-Z])', blk):
                issues.append({'issue': 'hallucinated_override_tag', 'tag': htag, 'block_index': b_idx})
        # Check duplicate singleton tags outside \t(...)
        stripped_no_t = re.sub(r'\\t\((?:[^()]*|\([^()]*\))*\)', '', blk)
        for stag in SINGLETON_BLOCK_TAGS:
            hits = re.findall(rf'\\{stag}(?![a-zA-Z])', stripped_no_t)
            if len(hits) > 1:
                issues.append({'issue': 'duplicate_singleton_tag_in_block', 'tag': stag, 'count': len(hits), 'block_index': b_idx})
        # Check drawing mode changes
        for p_hit in re.findall(r'\\p(\d+)', blk):
            drawing_mode = int(p_hit)

    joined_visible = ''.join(visible_runs)
    clean_visible = re.sub(r'\\[Nn]', '\n', joined_visible)
    clean_visible = re.sub(r'\\h', ' ', clean_visible)
    if drawing_mode > 0 and clean_visible.strip():
        tokens = clean_visible.strip().split()
        bad_tokens = [tok for tok in tokens if not DRAWING_TOKEN_RE.match(tok)]
        if bad_tokens:
            issues.append({'issue': 'non_drawing_text_while_p_mode_active', 'sample_tokens': bad_tokens[:5]})

    return {
        'issues': issues,
        'override_block_count': len(blocks),
        'drawing_mode_at_end': drawing_mode,
        'visible_text': clean_visible
    }


def lint_document_tags(doc):
    findings = []
    total_blocks = 0
    for ev in doc.events.values():
        if ev.kind != 'Dialogue':
            continue
        row = ev.data()
        res = lint_event_text(row.get('Text', ''))
        total_blocks += res['override_block_count']
        if res['issues']:
            findings.append({
                'line': ev.line,
                'style': row.get('Style', ''),
                'issues': res['issues']
            })
    return {
        'schema': 'ass-studio.tag-lint.v1',
        'sha256': doc.sha256,
        'dialogue_events_checked': sum(1 for e in doc.events.values() if e.kind == 'Dialogue'),
        'total_override_blocks': total_blocks,
        'events_with_issues_count': len(findings),
        'findings': findings
    }


# ---------------------------------------------------------------------------
# NEW CAPABILITY 2: Quantitative Dialogue Timing & Cut/Cluster QC (timing-qc)
# ---------------------------------------------------------------------------

def audit_timing(doc, styles=None, cuts_ms=None, max_cps=22.0, min_duration_ms=350, min_gap_ms=120, cut_bleed_ms=120):
    target_styles = {s.strip() for s in styles.split(',') if s.strip()} if styles else None
    cuts = sorted(int(c) for c in (cuts_ms or []))

    cues = []
    for ev in doc.events.values():
        if ev.kind != 'Dialogue':
            continue
        row = ev.data()
        style = row.get('Style', '').strip()
        if target_styles and style not in target_styles:
            continue
        text = row.get('Text', '')
        if re.search(r'\\p[1-9]\d*\b', text):
            continue
        lint_info = lint_event_text(text)
        vis = lint_info['visible_text'].strip()
        if not vis:
            continue
        try:
            start = timestamp_ms(row['Start'])
            end = timestamp_ms(row['End'])
        except ValueError:
            continue
        if end <= start:
            continue
        cues.append({
            'line': ev.line,
            'style': style,
            'actor': row.get('Name', '').strip(),
            'start_ms': start,
            'end_ms': end,
            'duration_ms': end - start,
            'visible_text': vis,
            'char_count': len(re.sub(r'\s+', '', vis))
        })

    cues.sort(key=lambda c: (c['start_ms'], c['end_ms'], c['line']))

    # Build 1:N continuation clusters (same style + same actor + gap <= min_gap_ms or trailing continuation punctuation)
    clusters = []
    for cue in cues:
        if clusters:
            prev = clusters[-1][-1]
            gap = cue['start_ms'] - prev['end_ms']
            same_speaker = (cue['style'] == prev['style']) and (cue['actor'] == prev['actor'])
            continues = prev['visible_text'].endswith(('...', '…', '—', '-', ','))
            if same_speaker and (0 <= gap <= min_gap_ms or (continues and 0 <= gap <= 400)):
                clusters[-1].append(cue)
                continue
        clusters.append([cue])

    cue_to_cluster = {}
    for c_idx, grp in enumerate(clusters):
        for member in grp:
            cue_to_cluster[member['line']] = (c_idx, len(grp))

    issues = []
    for i, cue in enumerate(cues):
        dur_s = cue['duration_ms'] / 1000.0
        cps = round(cue['char_count'] / dur_s, 2) if dur_s > 0 else 999.0
        c_idx, c_size = cue_to_cluster[cue['line']]

        if cue['duration_ms'] < min_duration_ms and c_size == 1:
            issues.append({
                'line': cue['line'],
                'type': 'flash_cue',
                'duration_ms': cue['duration_ms'],
                'detail': f'Duration {cue["duration_ms"]}ms is below {min_duration_ms}ms threshold'
            })
        if cps > max_cps:
            issues.append({
                'line': cue['line'],
                'type': 'high_cps',
                'cps': cps,
                'char_count': cue['char_count'],
                'duration_ms': cue['duration_ms'],
                'cluster_size': c_size
            })

        # Check gap to next cue in same style
        if i + 1 < len(cues) and cues[i + 1]['style'] == cue['style']:
            nxt = cues[i + 1]
            gap = nxt['start_ms'] - cue['end_ms']
            same_cluster = cue_to_cluster[nxt['line']][0] == c_idx
            if 0 < gap < min_gap_ms and not same_cluster:
                issues.append({
                    'line': cue['line'],
                    'next_line': nxt['line'],
                    'type': 'micro_gap',
                    'gap_ms': gap,
                    'detail': f'Gap of {gap}ms before line {nxt["line"]} causes visual blink; snap or widen'
                })
            elif gap < 0 and cue['actor'] == nxt['actor'] and cue['actor'] != '':
                issues.append({
                    'line': cue['line'],
                    'next_line': nxt['line'],
                    'type': 'same_speaker_overlap',
                    'overlap_ms': -gap
                })

        # Check scene-cut bleed
        for cut in cuts:
            if 0 < abs(cue['start_ms'] - cut) <= cut_bleed_ms:
                issues.append({
                    'line': cue['line'],
                    'type': 'cut_bleed_start',
                    'cut_ms': cut,
                    'delta_ms': cue['start_ms'] - cut
                })
            if 0 < abs(cue['end_ms'] - cut) <= cut_bleed_ms:
                issues.append({
                    'line': cue['line'],
                    'type': 'cut_bleed_end',
                    'cut_ms': cut,
                    'delta_ms': cue['end_ms'] - cut
                })

    return {
        'schema': 'ass-studio.timing-qc.v1',
        'sha256': doc.sha256,
        'dialogue_cues_evaluated': len(cues),
        'continuation_clusters_count': sum(1 for g in clusters if len(g) > 1),
        'issue_count': len(issues),
        'issues': issues
    }


# ---------------------------------------------------------------------------
# NEW CAPABILITY 3: Font, Vietnamese Diacritic Coverage & [Fonts] Audit
# ---------------------------------------------------------------------------

def audit_fonts(doc, font_dirs=None):
    try:
        from fontTools.ttLib import TTFont, TTCollection
        has_fonttools = True
    except ImportError:
        has_fonttools = False

    # 1. Collect characters used per font family across the ASS file
    chars_by_font = defaultdict(set)
    for style_name, st in doc.styles.items():
        fn = st.get('Fontname', '').strip().lstrip('@')
        if fn:
            chars_by_font[fn]  # initialize key

    for ev in doc.events.values():
        if ev.kind != 'Dialogue':
            continue
        row = ev.data()
        style_name = row.get('Style', '').strip()
        default_fn = doc.styles.get(style_name, {}).get('Fontname', 'Arial').strip().lstrip('@')
        text = row.get('Text', '')
        if re.search(r'\\p[1-9]\d*\b', text):
            continue
        current_fn = default_fn
        pos = 0
        for m in re.finditer(r'\{([^}]*)\}', text):
            seg = text[pos:m.start()]
            clean_seg = re.sub(r'\\[Nnh]', '', seg)
            for ch in clean_seg:
                if not ch.isspace():
                    chars_by_font[current_fn].add(ch)
            blk = m.group(1)
            fn_hits = re.findall(r'\\fn([^\\}]+)', blk)
            if fn_hits:
                current_fn = fn_hits[-1].strip().lstrip('@')
            if re.search(r'\\r(?![a-zA-Z])', blk):
                current_fn = default_fn
            pos = m.end()
        tail = re.sub(r'\\[Nnh]', '', text[pos:])
        for ch in tail:
            if not ch.isspace():
                chars_by_font[current_fn].add(ch)

    # 2. Index available fonts in font_dirs and embedded [Fonts]
    family_to_cmaps = defaultdict(list)
    embedded_report = []

    def register_ttfont(tt, source_label):
        names = set()
        if 'name' in tt:
            for rec in tt['name'].names:
                if rec.nameID in (1, 4, 16):
                    try:
                        names.add(rec.toUnicode().strip())
                    except Exception:
                        pass
        cmap = set()
        if 'cmap' in tt:
            for table in tt['cmap'].tables:
                if table.isUnicode():
                    cmap.update(table.cmap.keys())
        for n in names:
            family_to_cmaps[n.casefold()].append({'source': source_label, 'family': n, 'codepoints': cmap})

    if has_fonttools:
        for directory in (font_dirs or []):
            dpath = Path(directory).resolve()
            if not dpath.is_dir():
                continue
            for fpath in sorted(dpath.rglob('*')):
                if not fpath.is_file() or fpath.suffix.casefold() not in ('.ttf', '.otf', '.ttc'):
                    continue
                try:
                    if fpath.suffix.casefold() == '.ttc':
                        ttc = TTCollection(str(fpath))
                        for idx, font in enumerate(ttc.fonts):
                            register_ttfont(font, f'{fpath.name}#{idx}')
                    else:
                        register_ttfont(TTFont(str(fpath)), fpath.name)
                except Exception:
                    pass

    for emb in doc.embedded_fonts:
        try:
            raw_bytes = decode_ass_uuencoded_section(emb['payload_lines'])
            sha = hashlib.sha256(raw_bytes).hexdigest()
            valid_sfnt = raw_bytes[:4] in (b'\x00\x01\x00\x00', b'OTTO', b'ttcf', b'true')
            if has_fonttools and valid_sfnt:
                register_ttfont(TTFont(io.BytesIO(raw_bytes)), f'embedded:{emb["fontname_header"]}')
            embedded_report.append({
                'fontname_header': emb['fontname_header'],
                'line': emb['line'],
                'decoded_bytes': len(raw_bytes),
                'sha256': sha,
                'valid_sfnt_signature': valid_sfnt
            })
        except Exception as exc:
            embedded_report.append({
                'fontname_header': emb['fontname_header'],
                'line': emb['line'],
                'error': str(exc)
            })

    # 3. Verify coverage per requested font family
    font_checks = []
    for fn, used_chars in sorted(chars_by_font.items()):
        matches = family_to_cmaps.get(fn.casefold(), [])
        if not matches:
            font_checks.append({
                'requested_family': fn,
                'used_char_count': len(used_chars),
                'status': 'unverified_or_missing_in_font_dir',
                'missing_glyphs': []
            })
        else:
            union_cp = set().union(*(m['codepoints'] for m in matches))
            missing = sorted(ch for ch in used_chars if ord(ch) not in union_cp)
            font_checks.append({
                'requested_family': fn,
                'matched_sources': [m['source'] for m in matches],
                'used_char_count': len(used_chars),
                'status': 'ok' if not missing else 'missing_glyphs',
                'missing_glyphs': missing
            })

    return {
        'schema': 'ass-studio.font-audit.v1',
        'sha256': doc.sha256,
        'fonttools_available': has_fonttools,
        'embedded_fonts': embedded_report,
        'font_checks': font_checks
    }


# ---------------------------------------------------------------------------
# NEW CAPABILITY 4: Series-Wide Cross-Episode Consistency Audit (series-audit)
# ---------------------------------------------------------------------------

def audit_series(paths, encoding=None):
    episodes = []
    playres_Counter = Counter()
    matrix_Counter = Counter()
    style_signatures = defaultdict(lambda: defaultdict(list))
    all_actors = Counter()

    for p in paths:
        doc = Document.read(p, encoding)
        inv = doc.inventory()
        ep_name = Path(p).name
        pr = f"{doc.info.get('PlayResX', 'unset')}x{doc.info.get('PlayResY', 'unset')}"
        ym = doc.info.get('YCbCr Matrix', 'unset')
        playres_Counter[pr] += 1
        matrix_Counter[ym] += 1

        for sname, sdict in doc.styles.items():
            sig = json.dumps(sdict, sort_keys=True, ensure_ascii=False)
            style_signatures[sname][sig].append(ep_name)

        for act, cnt in inv['actor_usage'].items():
            if act:
                all_actors[act] += cnt

        episodes.append({
            'file': ep_name,
            'sha256': doc.sha256,
            'play_res': pr,
            'ycbcr_matrix': ym,
            'dialogue_count': inv['event_counts'].get('Dialogue', 0),
            'undefined_styles': inv['undefined_styles'],
            'warnings_count': len(inv['warnings'])
        })

    style_divergences = {}
    for sname, sig_map in sorted(style_signatures.items()):
        if len(sig_map) > 1:
            style_divergences[sname] = [
                {'episodes': eps, 'definition': json.loads(sig)}
                for sig, eps in sig_map.items()
            ]

    return {
        'schema': 'ass-studio.series-audit.v1',
        'episode_count': len(episodes),
        'play_res_distribution': dict(playres_Counter),
        'ycbcr_matrix_distribution': dict(matrix_Counter),
        'style_divergences_across_episodes': style_divergences,
        'actor_inventory': dict(all_actors),
        'episodes': episodes
    }



def sync_fbf_document(doc, offset_frames, fps=24000/1001, target_style=None, output_path=None):
    """
    Sync frame-by-frame (FBF) lines with exact integer millisecond floor division:
    pts_ms = round(n_target * 1001 * 1000 / 24000)
    st_cs = pts_ms // 10
    Guarantees 100% frame hit in libass without duration expansion or dead-zone gaps.
    """
    synced_lines = []
    synced_count = 0
    
    def fmt_cs(cs):
        total_sec = cs // 100
        rem_cs = cs % 100
        h = total_sec // 3600
        rem_s = total_sec % 3600
        m = rem_s // 60
        s = rem_s % 60
        return f"{h}:{m:02d}:{s:02d}.{rem_cs:02d}"

    for full in doc.lines:
        line_ending = ending(full)
        body = full[:-len(line_ending)] if line_ending else full
        if not (body.startswith("Dialogue:") or body.startswith("Comment:")):
            synced_lines.append(full)
            continue
        parts = body.split(",", 9)
        style = parts[3].strip()
        if target_style and style != target_style:
            synced_lines.append(full)
            continue
        
        try:
            h1, m1, s1 = parts[1].split(":")
            st_sec = int(h1)*3600 + int(m1)*60 + float(s1)
            h2, m2, s2 = parts[2].split(":")
            et_sec = int(h2)*3600 + int(m2)*60 + float(s2)
        except (ValueError, IndexError):
            synced_lines.append(full)
            continue
            
        dur_sec = et_sec - st_sec
        dur_cs = round(dur_sec * 100)
        
        n_orig = round(st_sec * fps)
        n_target = n_orig + offset_frames
        if abs(fps - (24000.0 / 1001.0)) < 1e-4:
            pts_ms = round((n_target * 1001 * 1000) / 24000)
        else:
            pts_ms = round((n_target * 1000.0) / fps)
        
        st_cs = pts_ms // 10
        et_cs = st_cs + dur_cs
        
        parts[1] = fmt_cs(st_cs)
        parts[2] = fmt_cs(et_cs)
        new_body = ",".join(parts)
        synced_lines.append(new_body + line_ending)
        synced_count += 1

    if output_path:
        out_p = Path(output_path)
        out_text = "".join(synced_lines)
        out_p.write_bytes(doc.bom + out_text.encode(doc.encoding))

    return {
        'schema': 'ass-studio.sync-fbf.v1',
        'offset_frames': offset_frames,
        'target_style': target_style,
        'synced_events': synced_count,
        'output': str(output_path) if output_path else None
    }


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    inv = sub.add_parser('inspect'); inv.add_argument('ass'); inv.add_argument('--encoding')
    edit = sub.add_parser('patch'); edit.add_argument('ass'); edit.add_argument('plan')
    edit.add_argument('--output', required=True); edit.add_argument('--encoding'); edit.add_argument('--force', action='store_true')
    diff = sub.add_parser('compare'); diff.add_argument('before'); diff.add_argument('after')
    diff.add_argument('--allowed-fields', nargs='+'); diff.add_argument('--encoding')

    lint_p = sub.add_parser('lint-tags', help='Audit ASS override tag syntax, unclosed braces, trailing \\}, and duplicate block tags')
    lint_p.add_argument('ass'); lint_p.add_argument('--encoding')
    lint_p.add_argument('--strict', action='store_true', help='Return non-zero exit code if any tag lint issue is found')

    tqc_p = sub.add_parser('timing-qc', help='Audit dialogue CPS, flash cues, micro-gaps, and scene-cut bleeds with 1:N cluster immunity')
    tqc_p.add_argument('ass'); tqc_p.add_argument('--styles', help='Comma-separated dialogue styles')
    tqc_p.add_argument('--cuts-ms', type=int, nargs='*', help='Scene cut timestamps in ms')
    tqc_p.add_argument('--bleed-scene-cuts', help='Optional JSON file containing scene cut timestamps in ms')
    tqc_p.add_argument('--max-cps', '--cps-warn', dest='max_cps', type=float, default=22.0)
    tqc_p.add_argument('--min-duration-ms', '--flash-ms', dest='min_duration_ms', type=int, default=350)
    tqc_p.add_argument('--min-gap-ms', type=int, default=120)
    tqc_p.add_argument('--cut-bleed-ms', type=int, default=120)
    tqc_p.add_argument('--encoding')

    fa_p = sub.add_parser('font-audit', help='Verify font family names, Vietnamese glyph coverage, and [Fonts] uuencoding')
    fa_p.add_argument('ass'); fa_p.add_argument('--font-dir', action='append', default=[])
    fa_p.add_argument('--check-vietnamese', action='store_true', help='Verify Vietnamese glyph coverage (enabled by default)')
    fa_p.add_argument('--encoding')

    sa_p = sub.add_parser('series-audit', help='Compare multiple episode ASS files for Style, PlayRes, YCbCr Matrix, and Actor consistency')
    sa_p.add_argument('ass_files', nargs='+'); sa_p.add_argument('--strict-styles', action='store_true')
    sa_p.add_argument('--encoding')

    fbf_p = sub.add_parser('sync-fbf', help='Sync FBF lines with integer millisecond floor division')
    fbf_p.add_argument('ass')
    fbf_p.add_argument('--offset-frames', type=int, required=True, help='Number of video frames to shift')
    fbf_p.add_argument('--fps', type=float, default=24000/1001, help='Video frame rate (default: 23.976)')
    fbf_p.add_argument('--style', help='Target style (default: all styles)')
    fbf_p.add_argument('--output', required=True, help='Output candidate ASS file')
    fbf_p.add_argument('--encoding')

    args = p.parse_args(argv)
    try:
        if args.command == 'inspect':
            result = Document.read(args.ass, args.encoding).inventory()
        elif args.command == 'patch':
            result = patch(args.ass, args.plan, args.output, args.encoding, args.force)
        elif args.command == 'compare':
            result = compare(Document.read(args.before, args.encoding), Document.read(args.after, args.encoding), args.allowed_fields)
        elif args.command == 'lint-tags':
            result = lint_document_tags(Document.read(args.ass, args.encoding))
        elif args.command == 'timing-qc':
            cuts = list(args.cuts_ms or [])
            if getattr(args, 'bleed_scene_cuts', None):
                sc_data = json.loads(Path(args.bleed_scene_cuts).read_text(encoding='utf-8'))
                cuts.extend(sc_data if isinstance(sc_data, list) else sc_data.get('cuts_ms', []))
            result = audit_timing(
                Document.read(args.ass, args.encoding), styles=args.styles, cuts_ms=cuts,
                max_cps=args.max_cps, min_duration_ms=args.min_duration_ms,
                min_gap_ms=args.min_gap_ms, cut_bleed_ms=args.cut_bleed_ms
            )
        elif args.command == 'font-audit':
            result = audit_fonts(Document.read(args.ass, args.encoding), font_dirs=args.font_dir)
        elif args.command == 'series-audit':
            result = audit_series(args.ass_files, encoding=args.encoding)
        elif args.command == 'sync-fbf':
            result = sync_fbf_document(
                Document.read(args.ass, args.encoding),
                offset_frames=args.offset_frames,
                fps=args.fps,
                target_style=args.style,
                output_path=args.output
            )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2 if result.get('scope_pass') is False else 0
    except (ValueError, OSError, KeyError, json.JSONDecodeError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
