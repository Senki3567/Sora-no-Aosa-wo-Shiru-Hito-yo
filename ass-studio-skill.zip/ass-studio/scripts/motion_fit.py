#!/usr/bin/env python3
"""Fit reference-to-frame transforms from measured native-pixel landmark CSVs.

Requires NumPy. Never tracks an image, interpolates missing frames, or writes ASS.
"""
import argparse
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import sys

MINIMUM = {'translation': 1, 'similarity': 2, 'affine': 3, 'homography': 4}


def numpy():
    try:
        import numpy as np
    except ImportError as exc:
        raise ValueError('Landmark fitting needs NumPy in this Python interpreter') from exc
    return np


def normalize(points):
    np = numpy()
    center = points.mean(axis=0)
    distance = np.sqrt(((points - center) ** 2).sum(axis=1)).mean()
    if distance < 1e-10:
        raise ValueError('Reference or target landmarks collapse to one point')
    scale = math.sqrt(2) / distance
    transform = np.array([[scale, 0, -scale * center[0]],
                          [0, scale, -scale * center[1]], [0, 0, 1.]])
    return (points - center) * scale, transform


def project(matrix, points):
    np = numpy()
    result = np.c_[points, np.ones(len(points))] @ matrix.T
    if np.any(np.abs(result[:, 2]) < 1e-10):
        raise ValueError('Projective horizon crosses a measured point')
    return result[:, :2] / result[:, 2:3]


def fit_matrix(reference, target, model):
    np = numpy()
    if len(reference) < MINIMUM[model]:
        raise ValueError(f'{model} needs at least {MINIMUM[model]} fit points')
    if model == 'translation':
        matrix = np.eye(3)
        matrix[:2, 2] = (target - reference).mean(axis=0)
        return matrix
    if model == 'similarity':
        r = reference - reference.mean(axis=0)
        t = target - target.mean(axis=0)
        denominator = float((r * r).sum())
        if denominator < 1e-10:
            raise ValueError('Similarity needs distinct reference points')
        a = float((r * t).sum() / denominator)
        b = float((r[:, 0] * t[:, 1] - r[:, 1] * t[:, 0]).sum() / denominator)
        if a*a + b*b < 1e-14:
            raise ValueError('Similarity scale collapses to zero')
        matrix = np.array([[a, -b, 0.], [b, a, 0.], [0., 0., 1.]])
        matrix[:2, 2] = target.mean(axis=0) - matrix[:2, :2] @ reference.mean(axis=0)
        return matrix
    ref, tr = normalize(reference)
    dst, td = normalize(target)
    if model == 'affine':
        solution, _, rank, _ = np.linalg.lstsq(np.c_[ref, np.ones(len(ref))], dst, rcond=None)
        if rank < 3:
            raise ValueError('Affine landmarks are collinear or rank deficient')
        local = np.eye(3)
        local[:2, :] = solution.T
    else:
        design = []
        for (x, y), (u, v) in zip(ref, dst):
            design.extend([[-x, -y, -1, 0, 0, 0, u*x, u*y, u],
                           [0, 0, 0, -x, -y, -1, v*x, v*y, v]])
        design = np.asarray(design)
        if np.linalg.matrix_rank(design) < 8:
            raise ValueError('Homography landmarks are degenerate; spread points over the plane')
        _, _, vh = np.linalg.svd(design, full_matrices=True)
        local = vh[-1].reshape(3, 3)
    matrix = np.linalg.inv(td) @ local @ tr
    if np.linalg.matrix_rank(matrix) < 3:
        raise ValueError('Transform is singular')
    matrix /= matrix[2, 2] if abs(matrix[2, 2]) > 1e-10 else np.linalg.norm(matrix)
    if not np.isfinite(matrix).all():
        raise ValueError('Transform contains non-finite values')
    return matrix


def robust_fit(reference, target, model, threshold, seed=0, trials=256):
    np = numpy()
    count, minimum = len(reference), MINIMUM[model]
    if count < minimum:
        raise ValueError(f'{model} needs at least {minimum} fit points')
    if math.comb(count, minimum) <= trials:
        samples = list(itertools.combinations(range(count), minimum))
    else:
        rng, choices = random.Random(seed), set()
        while len(choices) < trials:
            choices.add(tuple(sorted(rng.sample(range(count), minimum))))
        samples = sorted(choices)
    best = None
    for sample in samples:
        try:
            matrix = fit_matrix(reference[list(sample)], target[list(sample)], model)
            error = np.linalg.norm(project(matrix, reference) - target, axis=1)
        except (ValueError, np.linalg.LinAlgError):
            continue
        inliers = error <= threshold
        if int(inliers.sum()) < minimum:
            continue
        score = (int(inliers.sum()), -float(np.median(error[inliers])))
        if best is None or score > best[0]:
            best = score, inliers
    if best is None:
        raise ValueError('No nondegenerate consensus transform found')
    inliers = best[1]
    matrix = fit_matrix(reference[inliers], target[inliers], model)
    # Conservative one-pass reclassification followed by refit; report final residuals.
    updated = np.linalg.norm(project(matrix, reference) - target, axis=1) <= threshold
    if updated.sum() >= minimum:
        inliers = updated
        matrix = fit_matrix(reference[inliers], target[inliers], model)
    final = np.linalg.norm(project(matrix, reference) - target, axis=1) <= threshold
    if not np.array_equal(final, inliers):
        # Do not silently call a fit valid when refitting lost its own consensus.
        raise ValueError('RANSAC consensus unstable after refit; inspect the points')
    return matrix, inliers


def read_points(path):
    required = {'frame_index_0based', 'pts_ms', 'point_id', 'reference_x', 'reference_y', 'x', 'y'}
    groups, skipped, anchors = {}, [], {}
    with Path(path).open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        if not required.issubset(reader.fieldnames or []):
            raise ValueError('CSV missing columns: ' + ', '.join(sorted(required - set(reader.fieldnames or []))))
        for lineno, raw in enumerate(reader, 2):
            frame, pts = int(raw['frame_index_0based']), float(raw['pts_ms'])
            if frame < 0 or not math.isfinite(pts):
                raise ValueError(f'Invalid frame/PTS at CSV row {lineno}')
            segment = raw.get('segment', '').strip() or 'default'
            if (raw.get('status', '').strip() or 'measured') != 'measured':
                skipped.append({'csv_row': lineno, 'frame_index_0based': frame,
                                'segment': segment, 'reason': raw['status']})
                continue
            role = raw.get('role', '').strip() or 'fit'
            if role not in ('fit', 'check'):
                raise ValueError(f'Role must be fit or check at row {lineno}')
            name = raw['point_id'].strip()
            coordinates = [float(raw[c]) for c in ['reference_x', 'reference_y', 'x', 'y']]
            if not name or not all(math.isfinite(v) for v in coordinates):
                raise ValueError(f'Invalid point at row {lineno}')
            anchor_key = segment, name
            if anchor_key in anchors and anchors[anchor_key] != coordinates[:2]:
                raise ValueError(f'Reference coordinates changed for {name} in segment {segment}')
            anchors[anchor_key] = coordinates[:2]
            group = groups.setdefault((segment, frame), {'pts_ms': pts, 'points': []})
            if abs(group['pts_ms'] - pts) > 1e-6 or any(p['point_id'] == name for p in group['points']):
                raise ValueError(f'Duplicate landmark or inconsistent PTS at row {lineno}')
            group['points'].append({'point_id': name, 'reference': coordinates[:2],
                                    'observed': coordinates[2:], 'role': role})
    if not groups:
        raise ValueError('CSV has no measured landmarks')
    by_segment = {}
    for (segment, frame), group in sorted(groups.items()):
        previous = by_segment.get(segment)
        if previous and group['pts_ms'] <= previous[1]:
            raise ValueError('PTS must increase with frame index within each segment')
        by_segment[segment] = frame, group['pts_ms']
    return groups, skipped


def run_fit(path, model, threshold=2., ransac=False, seed=0):
    np = numpy()
    if not math.isfinite(threshold) or threshold <= 0:
        raise ValueError('Threshold must be a positive finite native-pixel distance')
    groups, skipped = read_points(path)
    frames, gaps, previous = [], [], {}
    for (segment, frame), group in sorted(groups.items()):
        if segment in previous and frame > previous[segment] + 1:
            gaps.append({'segment': segment, 'first': previous[segment]+1, 'last': frame-1})
        previous[segment] = frame
        row = {'segment': segment, 'frame_index_0based': frame, 'pts_ms': group['pts_ms']}
        points = group['points']
        fit = [p for p in points if p['role'] == 'fit']
        try:
            reference = np.asarray([p['reference'] for p in fit], dtype=float).reshape(-1, 2)
            target = np.asarray([p['observed'] for p in fit], dtype=float).reshape(-1, 2)
            if ransac:
                matrix, inliers = robust_fit(reference, target, model, threshold, seed)
            else:
                matrix, inliers = fit_matrix(reference, target, model), np.ones(len(fit), dtype=bool)
            predicted = project(matrix, np.asarray([p['reference'] for p in points], dtype=float))
            errors, fit_index = [], 0
            for point, estimate in zip(points, predicted):
                error = float(np.linalg.norm(estimate - point['observed']))
                used = point['role'] == 'fit' and bool(inliers[fit_index])
                if point['role'] == 'fit': fit_index += 1
                errors.append({**point, 'predicted': estimate.tolist(), 'error_px': error,
                               'used_in_fit': used, 'within_threshold': error <= threshold})
            used_errors = [p['error_px'] for p in errors if p['used_in_fit']]
            checks = [p['error_px'] for p in errors if p['role'] == 'check']
            reasons = []
            if len(used_errors) == MINIMUM[model] and not checks:
                reasons.append('Minimal fit only; add extra or held-out check landmarks')
            if max(used_errors) > threshold or (checks and max(checks) > threshold):
                reasons.append('Residual exceeds the requested native-pixel threshold')
            if int(inliers.sum()) < len(fit):
                reasons.append('Outliers excluded; inspect the rejected landmarks before accepting')
            row.update(matrix_reference_to_frame=matrix.tolist(), points=errors,
                       inlier_count=int(inliers.sum()), fit_count=len(fit), check_count=len(checks),
                       fit_rmse_px=float(np.sqrt(np.mean(np.square(used_errors)))),
                       max_check_error_px=max(checks) if checks else None,
                       status='needs_review' if reasons else 'fitted', review_reasons=reasons)
            if model == 'similarity':
                row['scale'] = math.hypot(matrix[0,0], matrix[1,0])
                row['rotation_clockwise_deg_y_down'] = math.degrees(math.atan2(matrix[1,0], matrix[0,0]))
            if model in ('translation', 'similarity', 'affine'):
                row['origin_translation_px'] = matrix[:2, 2].tolist()
        except (ValueError, np.linalg.LinAlgError) as exc:
            row.update(status='failed', error=str(exc), points=points)
        frames.append(row)
    return {'schema': 'ass-studio.motion.v1', 'source_csv': str(Path(path).resolve()),
            'source_sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            'model': model, 'coordinate_space': 'native pixels; x right, y down; column-vector matrix reference -> frame',
            'threshold_px': threshold, 'ransac': ransac, 'seed': seed if ransac else None,
            'frames': frames, 'skipped_points': skipped, 'unmeasured_frame_intervals': gaps,
            'limits': 'Forward reprojection error only. No automatic tracking, interpolation, ASS conversion or visual acceptance. Measured reference coordinates must be common within each segment.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('csv'); parser.add_argument('--model', choices=MINIMUM, required=True)
    parser.add_argument('--threshold-px', type=float, default=2.)
    parser.add_argument('--ransac', action='store_true'); parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--output', required=True); parser.add_argument('--force', action='store_true')
    args = parser.parse_args()
    try:
        output, source = Path(args.output).resolve(), Path(args.csv).resolve()
        if output == source or (output.exists() and not args.force):
            raise ValueError('Output would replace the source or an existing artifact')
        report = run_fit(source, args.model, args.threshold_px, args.ransac, args.seed)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
        counts = {key: sum(row['status'] == key for row in report['frames']) for key in ['fitted', 'needs_review', 'failed']}
        print(json.dumps({'output': str(output), 'frame_status_counts': counts, 'unmeasured_frame_intervals': report['unmeasured_frame_intervals']}))
        return 3 if counts['failed'] or counts['needs_review'] else 0
    except (ValueError, OSError, KeyError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
