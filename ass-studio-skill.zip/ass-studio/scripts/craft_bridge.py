#!/usr/bin/env python3
r"""Deep Production Bridge between VectorCraft / EffectCraft and ASS Studio.

Provides subcommands:
  check              - Verify tool binaries, Snap confinement, and bridge status.
  svg-to-ass         - Parse SVG paths (supporting M, L, H, V, C, S, Q, T, Z) with
                       automatic quadratic-to-cubic degree elevation, coordinate scaling,
                       and formatting into ASS \p1 drawing or \clip(m...) tags.
  extract-keyframes  - Run ExtendScript in EffectCraft to sample high-precision layer
                       transformations (Position, Scale, Rotation, Opacity) at video PTS intervals.
  keyframes-to-ass   - Convert sampled keyframe stream into valid ASS tags (\move + multi-segment \t
                       for property interpolation, or cadence-locked FBF lines for curved paths).
  render-compare     - Render a reference frame from EffectCraft, render the ASS candidate
                       via libass_render.py, and generate visual difference metrics.
"""

import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


def get_snap_workdir(app_name):
    """Return a safe staging directory within Snap's writable sandbox."""
    home = Path.home()
    snap_dir = home / "snap" / app_name / "current" / "ass_studio_work"
    snap_dir.mkdir(parents=True, exist_ok=True)
    return snap_dir


def check_subcommand(args):
    """Verify tool binaries, Snap sandbox access, and CLI capabilities."""
    results = {}
    for name, bin_name, snap_app in [
        ("VectorCraft", "vectorcraft.cli", "vectorcraft"),
        ("EffectCraft", "effectcraft.cli", "effectcraft")
    ]:
        full_path = shutil.which(f"/snap/bin/{bin_name}") or shutil.which(bin_name)
        if not full_path:
            results[name] = {"status": "MISSING", "path": None}
            continue

        workdir = get_snap_workdir(snap_app)
        can_write = os.access(workdir, os.W_OK)

        info = {
            "status": "OK",
            "path": full_path,
            "snap_workdir": str(workdir),
            "sandbox_writable": can_write
        }

        try:
            if name == "EffectCraft":
                out = subprocess.check_output(
                    [full_path, "script", "--eval", "1+1"],
                    stderr=subprocess.PIPE, text=True, timeout=5
                )
                info["extendscript_engine"] = "OK" if "2" in out else "UNEXPECTED"
            else:
                subprocess.check_output(
                    [full_path, "commands"],
                    stderr=subprocess.PIPE, text=True, timeout=5
                )
                info["commands_catalog"] = "OK"
        except Exception as e:
            info["status"] = "WARN"
            info["error"] = str(e)

        results[name] = info

    print(json.dumps(results, indent=2))
    return 0


def quad_to_cubic(p0, p1, p2):
    """Elevate Quadratic Bezier (p0, p1, p2) to Cubic Bezier (c1, c2, p2)."""
    c1 = (p0[0] + (2.0 / 3.0) * (p1[0] - p0[0]), p0[1] + (2.0 / 3.0) * (p1[1] - p0[1]))
    c2 = (p2[0] + (2.0 / 3.0) * (p1[0] - p2[0]), p2[1] + (2.0 / 3.0) * (p1[1] - p2[1]))
    return c1, c2, p2


def parse_svg_path_advanced(d_str, scale_x=1.0, scale_y=1.0, offset_x=0.0, offset_y=0.0, decimals=1):
    """Full SVG path tokenizer and parser supporting M, L, H, V, C, S, Q, T, Z."""
    tokens = re.findall(r"([a-df-z]|[-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)", d_str, re.IGNORECASE)
    ass_tokens = []

    def fmt(val):
        if decimals == 0:
            return str(int(round(val)))
        return f"{val:.{decimals}f}".rstrip("0").rstrip(".") or "0"

    def tx(x):
        return fmt(x * scale_x + offset_x)

    def ty(y):
        return fmt(y * scale_y + offset_y)

    i = 0
    curr_x, curr_y = 0.0, 0.0
    start_x, start_y = 0.0, 0.0
    last_cubic_ctrl = None
    last_quad_ctrl = None
    last_cmd = ""

    while i < len(tokens):
        tok = tokens[i]
        if tok.isalpha():
            cmd = tok
            i += 1
        else:
            cmd = last_cmd

        if cmd in ("M", "m"):
            x = float(tokens[i])
            y = float(tokens[i + 1])
            i += 2
            curr_x = curr_x + x if cmd == "m" else x
            curr_y = curr_y + y if cmd == "m" else y
            start_x, start_y = curr_x, curr_y
            ass_tokens.extend(["m", tx(curr_x), ty(curr_y)])
            last_cubic_ctrl, last_quad_ctrl = None, None
            last_cmd = "l" if cmd == "m" else "L"

        elif cmd in ("L", "l"):
            x = float(tokens[i])
            y = float(tokens[i + 1])
            i += 2
            curr_x = curr_x + x if cmd == "l" else x
            curr_y = curr_y + y if cmd == "l" else y
            ass_tokens.extend(["l", tx(curr_x), ty(curr_y)])
            last_cubic_ctrl, last_quad_ctrl = None, None
            last_cmd = cmd

        elif cmd in ("H", "h"):
            x = float(tokens[i])
            i += 1
            curr_x = curr_x + x if cmd == "h" else x
            ass_tokens.extend(["l", tx(curr_x), ty(curr_y)])
            last_cubic_ctrl, last_quad_ctrl = None, None
            last_cmd = cmd

        elif cmd in ("V", "v"):
            y = float(tokens[i])
            i += 1
            curr_y = curr_y + y if cmd == "v" else y
            ass_tokens.extend(["l", tx(curr_x), ty(curr_y)])
            last_cubic_ctrl, last_quad_ctrl = None, None
            last_cmd = cmd

        elif cmd in ("C", "c"):
            x1 = float(tokens[i])
            y1 = float(tokens[i + 1])
            x2 = float(tokens[i + 2])
            y2 = float(tokens[i + 3])
            x = float(tokens[i + 4])
            y = float(tokens[i + 5])
            i += 6
            if cmd == "c":
                c1 = (curr_x + x1, curr_y + y1)
                c2 = (curr_x + x2, curr_y + y2)
                curr_x += x
                curr_y += y
            else:
                c1 = (x1, y1)
                c2 = (x2, y2)
                curr_x, curr_y = x, y
            ass_tokens.extend(["b", tx(c1[0]), ty(c1[1]), tx(c2[0]), ty(c2[1]), tx(curr_x), ty(curr_y)])
            last_cubic_ctrl = c2
            last_quad_ctrl = None
            last_cmd = cmd

        elif cmd in ("S", "s"):
            x2 = float(tokens[i])
            y2 = float(tokens[i + 1])
            x = float(tokens[i + 2])
            y = float(tokens[i + 3])
            i += 4
            if last_cubic_ctrl:
                c1 = (2 * curr_x - last_cubic_ctrl[0], 2 * curr_y - last_cubic_ctrl[1])
            else:
                c1 = (curr_x, curr_y)
            if cmd == "s":
                c2 = (curr_x + x2, curr_y + y2)
                curr_x += x
                curr_y += y
            else:
                c2 = (x2, y2)
                curr_x, curr_y = x, y
            ass_tokens.extend(["b", tx(c1[0]), ty(c1[1]), tx(c2[0]), ty(c2[1]), tx(curr_x), ty(curr_y)])
            last_cubic_ctrl = c2
            last_quad_ctrl = None
            last_cmd = cmd

        elif cmd in ("Q", "q"):
            x1 = float(tokens[i])
            y1 = float(tokens[i + 1])
            x = float(tokens[i + 2])
            y = float(tokens[i + 3])
            i += 4
            p0 = (curr_x, curr_y)
            p1 = (curr_x + x1, curr_y + y1) if cmd == "q" else (x1, y1)
            p2 = (curr_x + x, curr_y + y) if cmd == "q" else (x, y)
            c1, c2, p2 = quad_to_cubic(p0, p1, p2)
            curr_x, curr_y = p2
            ass_tokens.extend(["b", tx(c1[0]), ty(c1[1]), tx(c2[0]), ty(c2[1]), tx(curr_x), ty(curr_y)])
            last_quad_ctrl = p1
            last_cubic_ctrl = None
            last_cmd = cmd

        elif cmd in ("T", "t"):
            x = float(tokens[i])
            y = float(tokens[i + 1])
            i += 2
            if last_quad_ctrl:
                p1 = (2 * curr_x - last_quad_ctrl[0], 2 * curr_y - last_quad_ctrl[1])
            else:
                p1 = (curr_x, curr_y)
            p0 = (curr_x, curr_y)
            p2 = (curr_x + x, curr_y + y) if cmd == "t" else (x, y)
            c1, c2, p2 = quad_to_cubic(p0, p1, p2)
            curr_x, curr_y = p2
            ass_tokens.extend(["b", tx(c1[0]), ty(c1[1]), tx(c2[0]), ty(c2[1]), tx(curr_x), ty(curr_y)])
            last_quad_ctrl = p1
            last_cubic_ctrl = None
            last_cmd = cmd

        elif cmd in ("Z", "z"):
            ass_tokens.append("c")
            curr_x, curr_y = start_x, start_y
            last_cubic_ctrl, last_quad_ctrl = None, None
            last_cmd = cmd
        else:
            i += 1

    return " ".join(ass_tokens)


def svg_to_ass_subcommand(args):
    """Process SVG or VectorCraft exported vector file into ASS drawing or clip."""
    svg_path = Path(args.svg_file)
    if svg_path.exists():
        content = svg_path.read_text(encoding="utf-8")
        paths = re.findall(r'<path[^>]+d="([^"]+)"', content, re.IGNORECASE)
        if not paths:
            paths = re.findall(r'd="([^"]+)"', content, re.IGNORECASE)
        if not paths:
            print("Error: No path elements found in SVG file.", file=sys.stderr)
            return 1
        d_str = " ".join(paths)
    else:
        d_str = args.svg_file

    ass_drawing = parse_svg_path_advanced(
        d_str,
        scale_x=args.scale_x,
        scale_y=args.scale_y,
        offset_x=args.offset_x,
        offset_y=args.offset_y,
        decimals=args.decimals
    ).strip()

    body = ass_drawing if ass_drawing.startswith("m ") else f"m {ass_drawing}"

    if args.format == "clip":
        print(f"\\clip({body})")
    elif args.format == "iclip":
        print(f"\\iclip({body})")
    elif args.format == "dialogue":
        pos_tag = f"\\pos({args.offset_x},{args.offset_y})" if args.offset_x or args.offset_y else ""
        line = f"Dialogue: 0,{args.start},{args.end},{args.style},,0,0,0,,{{{pos_tag}\\p1}}{body}{{\\p0}}"
        print(line)
    else:
        print(body)
    return 0


def extract_keyframes_subcommand(args):
    """Extract layer properties from EffectCraft via ExtendScript CLI."""
    ec_bin = shutil.which("/snap/bin/effectcraft.cli") or shutil.which("effectcraft.cli")
    if not ec_bin:
        print("Error: effectcraft.cli not found.", file=sys.stderr)
        return 1

    script_code = f"""
    var comp = app.project.activeItem;
    if (!comp && app.project.items.length > 0) {{
        for (var i = 1; i <= app.project.items.length; i++) {{
            if (app.project.items[i] instanceof CompItem) {{
                comp = app.project.items[i];
                break;
            }}
        }}
    }}
    if (!comp) {{
        writeLn(JSON.stringify({{"error": "No composition found"}}));
    }} else {{
        var layer = comp.layer({json.dumps(args.layer)});
        if (!layer) {{
            layer = comp.layer(1);
        }}
        if (!layer) {{
            writeLn(JSON.stringify({{"error": "Layer not found"}}));
        }} else {{
            var start = {args.start_s};
            var end = {args.end_s};
            var fps = {args.fps};
            var dt = 1.0 / fps;
            var samples = [];

            var posProp = layer.property("Position");
            var rotProp = layer.property("Rotation");
            var scaleProp = layer.property("Scale");
            var opProp = layer.property("Opacity");

            for (var t = start; t <= end + 0.0001; t += dt) {{
                var p = posProp ? posProp.valueAtTime(t, false) : [0, 0, 0];
                var r = rotProp ? rotProp.valueAtTime(t, false) : 0;
                var s = scaleProp ? scaleProp.valueAtTime(t, false) : [100, 100, 100];
                var o = opProp ? opProp.valueAtTime(t, false) : 100;

                samples.push({{
                    "time": parseFloat(t.toFixed(4)),
                    "x": parseFloat(p[0].toFixed(2)),
                    "y": parseFloat(p[1].toFixed(2)),
                    "rot": parseFloat((typeof r === "number" ? r : r[2] || 0).toFixed(2)),
                    "scale_x": parseFloat(s[0].toFixed(2)),
                    "scale_y": parseFloat(s[1].toFixed(2)),
                    "opacity": parseFloat(o.toFixed(2))
                }});
            }}
            writeLn(JSON.stringify(samples));
        }}
    }}
    """

    cmd = [ec_bin]
    if getattr(args, "demo", False):
        cmd.append("--demo")
    elif args.project:
        cmd.extend(["--project", args.project])
    cmd.extend(["script", "--eval", script_code])

    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30)
        lines = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
        json_line = None
        for line in reversed(lines):
            if line.startswith("[") or line.startswith("{"):
                json_line = line
                break
        if not json_line:
            print(f"Error executing EffectCraft script: {proc.stderr}\nOutput: {proc.stdout}", file=sys.stderr)
            return 1

        data = json.loads(json_line)
        if isinstance(data, dict) and "error" in data:
            print(f"Error from EffectCraft: {data['error']}", file=sys.stderr)
            return 1

        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        print(f"Successfully extracted {len(data)} keyframe samples to {out_path}")
        return 0
    except Exception as e:
        print(f"Failed to run script: {e}", file=sys.stderr)
        return 1


def _sec_to_ass(s):
    if s < 0:
        s = 0.0
    total_cs = int(math.floor(s * 100.0 + 1e-9))
    cs = total_cs % 100
    total_s = total_cs // 100
    sec = total_s % 60
    total_m = total_s // 60
    m = total_m % 60
    h = total_m // 60
    return f"{h}:{m:02d}:{sec:02d}.{cs:02d}"


def _emit_fbf_lines(keyframes, style, text):
    lines = []
    for i in range(len(keyframes) - 1):
        k1 = keyframes[i]
        k2 = keyframes[i + 1]
        t1 = float(k1["time"])
        t2 = float(k2["time"])

        x = float(k1.get("x", 0.0))
        y = float(k1.get("y", 0.0))
        rot = float(k1.get("rot", 0.0))
        sx = float(k1.get("scale_x", 100.0))
        sy = float(k1.get("scale_y", 100.0))
        op = float(k1.get("opacity", 100.0))
        alpha_hex = f"&H{int(round((1.0 - op / 100.0) * 255)):02X}&"

        tag = f"{{\\pos({x:.2f},{y:.2f})"
        if abs(rot) > 1e-3:
            tag += f"\\frz{rot:.2f}"
        if abs(sx - 100.0) > 1e-3 or abs(sy - 100.0) > 1e-3:
            tag += f"\\fscx{sx:.1f}\\fscy{sy:.1f}"
        if op < 100.0 - 1e-3:
            tag += f"\\alpha{alpha_hex}"
        tag += "}"

        lines.append(f"Dialogue: 0,{_sec_to_ass(t1)},{_sec_to_ass(t2)},{style},,0,0,0,,{tag}{text}")
    return lines


def keyframes_to_ass_subcommand(args):
    """Compile sampled keyframes into valid ASS tags (never placing \\pos inside \\t)."""
    in_file = Path(args.json_file)
    if not in_file.exists():
        print(f"Error: {in_file} does not exist.", file=sys.stderr)
        return 1

    keyframes = json.loads(in_file.read_text(encoding="utf-8"))
    if not isinstance(keyframes, list) or len(keyframes) < 2:
        print("Error: Keyframes list must contain at least 2 entries.", file=sys.stderr)
        return 1

    if args.mode == "fbf":
        print("\n".join(_emit_fbf_lines(keyframes, args.style, args.text)))
        return 0

    k0 = keyframes[0]
    k_end = keyframes[-1]
    t0 = float(k0.get("time", 0.0))
    t_end = float(k_end.get("time", t0))
    dt_total = max(1e-6, t_end - t0)

    x0, y0 = float(k0.get("x", 0.0)), float(k0.get("y", 0.0))
    x1, y1 = float(k_end.get("x", x0)), float(k_end.get("y", y0))

    max_dev_px = 0.0
    for k in keyframes[1:-1]:
        u = (float(k.get("time", t0)) - t0) / dt_total
        lx = x0 + u * (x1 - x0)
        ly = y0 + u * (y1 - y0)
        dev = math.hypot(float(k.get("x", lx)) - lx, float(k.get("y", ly)) - ly)
        max_dev_px = max(max_dev_px, dev)

    if max_dev_px > getattr(args, "linear_tol_px", 1.5) and getattr(args, "strict_linear", False):
        print(
            f"Warning: Trajectory deviates by {max_dev_px:.2f}px from straight line; "
            "falling back to FBF because libass cannot interpolate \\pos inside \\t().",
            file=sys.stderr
        )
        print("\n".join(_emit_fbf_lines(keyframes, args.style, args.text)))
        return 0

    base_rot = float(k0.get("rot", 0.0))
    base_sx = float(k0.get("scale_x", 100.0))
    base_sy = float(k0.get("scale_y", 100.0))
    base_op = float(k0.get("opacity", 100.0))
    base_t_ms = int(round(t0 * 1000))
    end_t_ms = int(round(t_end * 1000))

    if math.hypot(x1 - x0, y1 - y0) > 1e-2:
        init_tag = f"\\move({x0:.2f},{y0:.2f},{x1:.2f},{y1:.2f},0,{max(0, end_t_ms - base_t_ms)})"
    else:
        init_tag = f"\\pos({x0:.2f},{y0:.2f})"

    if abs(base_rot) > 1e-3:
        init_tag += f"\\frz{base_rot:.2f}"
    if abs(base_sx - 100.0) > 1e-3 or abs(base_sy - 100.0) > 1e-3:
        init_tag += f"\\fscx{base_sx:.1f}\\fscy{base_sy:.1f}"
    if base_op < 100.0 - 1e-3:
        alpha_hex = f"&H{int(round((1.0 - base_op / 100.0) * 255)):02X}&"
        init_tag += f"\\alpha{alpha_hex}"

    t_tags = []
    prev_rot, prev_sx, prev_sy, prev_op = base_rot, base_sx, base_sy, base_op
    for i in range(1, len(keyframes)):
        k_prev = keyframes[i - 1]
        k_curr = keyframes[i]
        t1 = int(round(float(k_prev.get("time", t0)) * 1000)) - base_t_ms
        t2 = int(round(float(k_curr.get("time", t0)) * 1000)) - base_t_ms
        rot = float(k_curr.get("rot", prev_rot))
        sx = float(k_curr.get("scale_x", prev_sx))
        sy = float(k_curr.get("scale_y", prev_sy))
        op = float(k_curr.get("opacity", prev_op))

        inner = ""
        if abs(rot - prev_rot) > 1e-3:
            inner += f"\\frz{rot:.2f}"
            prev_rot = rot
        if abs(sx - prev_sx) > 1e-3 or abs(sy - prev_sy) > 1e-3:
            inner += f"\\fscx{sx:.1f}\\fscy{sy:.1f}"
            prev_sx, prev_sy = sx, sy
        if abs(op - prev_op) > 1e-3:
            alpha_hex = f"&H{int(round((1.0 - op / 100.0) * 255)):02X}&"
            inner += f"\\alpha{alpha_hex}"
            prev_op = op
        if inner:
            t_tags.append(f"\\t({t1},{t2},{inner})")

    full_tag = f"{{{init_tag}{''.join(t_tags)}}}"
    print(f"{full_tag}{args.text}")
    return 0


def render_compare_subcommand(args):
    """Render reference frame from EffectCraft (or use pre-rendered PNG), render ASS candidate via libass_render, and diff via visual_evidence."""
    scripts_dir = Path(__file__).resolve().parent
    out_dir = Path(args.output).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    time_ms = int(round(float(args.time_s) * 1000))

    if args.ec_png:
        ec_png = Path(args.ec_png).resolve()
        if not ec_png.exists():
            print(f"Error: EffectCraft reference PNG not found: {ec_png}", file=sys.stderr)
            return 1
    else:
        ec_bin = shutil.which("/snap/bin/effectcraft.cli") or shutil.which("effectcraft.cli")
        if not ec_bin:
            print("Error: effectcraft.cli not found and --ec-png was not supplied.", file=sys.stderr)
            return 1
        snap_work = get_snap_workdir("effectcraft")
        ec_png = snap_work / f"ec_ref_{time_ms}ms.png"
        cmd = [ec_bin]
        if args.project:
            cmd.extend(["--project", str(Path(args.project).resolve())])
        cmd.extend(["render-frame", "--time", str(args.time_s), "--out", str(ec_png)])
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if proc.returncode != 0 or not ec_png.exists():
            print(f"Error rendering frame in EffectCraft: {proc.stderr}", file=sys.stderr)
            return 1

    rgba_dir = out_dir / "ass_rgba"
    render_rep = out_dir / "libass_render.json"
    libass_cmd = [
        sys.executable, str(scripts_dir / "libass_render.py"),
        str(Path(args.ass).resolve()),
        "--size", args.size,
        "--times-ms", str(time_ms),
        "--png-dir", str(rgba_dir),
        "--report", str(render_rep),
        "--force"
    ]
    for fd in (args.font_dir or []):
        libass_cmd.extend(["--font-dir", fd])

    proc_ass = subprocess.run(libass_cmd, capture_output=True, text=True)
    if proc_ass.returncode != 0:
        print(f"Error rendering ASS via libass_render.py: {proc_ass.stderr}", file=sys.stderr)
        return proc_ass.returncode

    ass_png = rgba_dir / f"render_0000_{time_ms}.png"
    sys.path.insert(0, str(scripts_dir))
    import visual_evidence
    diff_report = visual_evidence.compare_images(
        ec_png, ass_png, out_dir, roi=args.roi, force=True
    )
    print(json.dumps(diff_report, indent=2, ensure_ascii=False))
    return 0


def main():
    parser = argparse.ArgumentParser(description="Deep Production Bridge for ASS Studio")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # check
    subparsers.add_parser("check", help="Verify tool binaries and sandbox paths")

    # svg-to-ass
    p_svg = subparsers.add_parser("svg-to-ass", help="Convert SVG path to ASS drawing or clip")
    p_svg.add_argument("svg_file", help="Path to SVG file or raw path string")
    p_svg.add_argument("--scale-x", type=float, default=1.0)
    p_svg.add_argument("--scale-y", type=float, default=1.0)
    p_svg.add_argument("--offset-x", type=float, default=0.0)
    p_svg.add_argument("--offset-y", type=float, default=0.0)
    p_svg.add_argument("--decimals", type=int, default=1)
    p_svg.add_argument("--format", choices=["raw", "drawing", "clip", "iclip", "dialogue"], default="raw")
    p_svg.add_argument("--style", default="Sign_Shape")
    p_svg.add_argument("--start", default="0:00:00.00")
    p_svg.add_argument("--end", default="0:00:05.00")

    # extract-keyframes
    p_ext = subparsers.add_parser("extract-keyframes", help="Extract layer keyframes from EffectCraft")
    p_ext.add_argument("--demo", action="store_true", help="Use built-in demo project")
    p_ext.add_argument("--project", help="Path to .ecproj file (optional)")
    p_ext.add_argument("--layer", default="1", help="Layer name or 1-based index")
    p_ext.add_argument("--start-s", type=float, default=0.0, help="Start time in seconds")
    p_ext.add_argument("--end-s", type=float, default=2.0, help="End time in seconds")
    p_ext.add_argument("--fps", type=float, default=23.976, help="Sampling FPS")
    p_ext.add_argument("--output", required=True, help="Output JSON path")

    # keyframes-to-ass
    p_kf = subparsers.add_parser("keyframes-to-ass", help="Convert keyframe stream to ASS tags")
    p_kf.add_argument("json_file", help="Keyframes JSON file")
    p_kf.add_argument("--mode", choices=["t", "fbf"], default="t")
    p_kf.add_argument("--fps", type=float, default=23.976)
    p_kf.add_argument("--style", default="Sign_Motion")
    p_kf.add_argument("--text", default="TYPESET_SIGN")
    p_kf.add_argument("--linear-tol-px", type=float, default=1.5, help="Linearity tolerance in pixels")
    p_kf.add_argument("--strict-linear", action="store_true", help="Automatically fall back to FBF if path is curved")

    # render-compare
    p_rc = subparsers.add_parser("render-compare", help="Compare EffectCraft reference render against libass candidate")
    p_rc.add_argument("ass", help="Candidate ASS file")
    p_rc.add_argument("--time-s", type=float, required=True, help="Timestamp in seconds")
    p_rc.add_argument("--project", help="Path to EffectCraft .ecproj file")
    p_rc.add_argument("--ec-png", help="Pre-rendered EffectCraft reference PNG (optional)")
    p_rc.add_argument("--font-dir", action="append", default=[], help="Font directory for libass")
    p_rc.add_argument("--size", default="1920x1080", help="Render resolution WIDTHxHEIGHT")
    p_rc.add_argument("--roi", type=int, nargs=4, metavar=("LEFT", "TOP", "RIGHT", "BOTTOM"))
    p_rc.add_argument("--output", required=True, help="Output directory for diff artifacts")

    args = parser.parse_args()
    if args.subcommand == "check":
        sys.exit(check_subcommand(args))
    elif args.subcommand == "svg-to-ass":
        sys.exit(svg_to_ass_subcommand(args))
    elif args.subcommand == "extract-keyframes":
        sys.exit(extract_keyframes_subcommand(args))
    elif args.subcommand == "keyframes-to-ass":
        sys.exit(keyframes_to_ass_subcommand(args))
    elif args.subcommand == "render-compare":
        sys.exit(render_compare_subcommand(args))


if __name__ == "__main__":
    main()
