#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ass_parser.py - Subtitle AST Parser, Serializer, Sanitizer & Offset Detector
Part of skill `softsub-align`.
"""

import re
import os
import math
import statistics
from typing import List, Dict, Any, Tuple, Optional
from text_utils import (
    clean_dialogue,
    extract_leading_tags,
    unescape_and_clean_html,
    normalize_nfc,
    format_ass_line_text,
    source_dialogue_text
)

def time_to_seconds(t_str: str) -> float:
    """Convert ASS timestamp 'H:MM:SS.cs' or SRT timestamp 'HH:MM:SS,mmm' to seconds."""
    t_str = t_str.strip().replace(",", ".")
    parts = t_str.split(":")
    if len(parts) == 3:
        h = float(parts[0])
        m = float(parts[1])
        s = float(parts[2])
        return h * 3600.0 + m * 60.0 + s
    elif len(parts) == 2:
        m = float(parts[0])
        s = float(parts[1])
        return m * 60.0 + s
    return 0.0

def seconds_to_ass_time(sec: float) -> str:
    """Convert float seconds to ASS format 'H:MM:SS.cs'."""
    if sec < 0:
        sec = 0.0
    h = int(sec // 3600)
    rem = sec - h * 3600
    m = int(rem // 60)
    s = rem - m * 60
    return f"{h}:{m:02d}:{s:05.2f}"

class SubtitleCue:
    def __init__(self, idx: int, start: float, end: float, text: str,
                 style: str = "Default", orig_idx: int = -1, leading_tags: str = "",
                 raw_line: str = "", is_dialogue: bool = True,
                 source_text: str = "", raw_text: str = ""):
        self.idx = idx                      # Index within dialogue stream
        self.start = start                  # In seconds
        self.end = end                      # In seconds
        self.text = text                    # Clean plain text
        self.style = style                  # ASS Style
        self.orig_idx = orig_idx            # Position in original input file
        self.leading_tags = leading_tags    # ASS override tags (e.g. {\an8})
        self.raw_line = raw_line            # Original line string
        self.is_dialogue = is_dialogue      # Dialogue vs Sign/Typesetting
        self.source_text = source_text or text
        self.raw_text = raw_text or text

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.idx,
            "orig_idx": self.orig_idx,
            "start": round(self.start, 2),
            "end": round(self.end, 2),
            "style": self.style,
            "lead_tag": self.leading_tags,
            "text": self.text,
            "source_text": self.source_text,
            "raw_text": self.raw_text
        }

class ASSFile:
    def __init__(self):
        self.header_lines: List[str] = []
        self.styles_lines: List[str] = []
        self.events_format: str = "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"
        self.all_events: List[Dict[str, Any]] = [] # Raw parsed event lines with orig_idx
        self.dialogue_cues: List[SubtitleCue] = []
        self.non_dialogue_events: List[Dict[str, Any]] = []

def is_dialogue_style(style_name: str, dialogue_styles: Optional[List[str]] = None) -> bool:
    """Determine if a style is dialogue."""
    s = style_name.strip()
    if dialogue_styles:
        if any(ds.strip() == "*" for ds in dialogue_styles):
            return True
        return any(ds.lower() == s.lower() for ds in dialogue_styles)
    # Default heuristic: ignore signs, titles, OP, ED, Kara, Notes
    s_low = s.lower()
    ignore_keywords = ["sign", "signs", "title", "titles", "insert", "op", "ed", "kara", "karaoke", "note", "staff", "credit"]
    style_tokens = set(re.findall(r"[a-z0-9]+", s_low))
    if any(k in style_tokens for k in ignore_keywords) or any(re.fullmatch(r"(?:op|ed)\d+", token) for token in style_tokens):
        return False
    return True

def _event_field_map(event_format: str) -> Dict[str, int]:
    fields = [part.strip().lower() for part in event_format.partition(":")[2].split(",")]
    return {name: i for i, name in enumerate(fields)}


def parse_ass(file_path: str, dialogue_styles: Optional[List[str]] = None) -> ASSFile:
    """Parse an ASS file into header, styles, dialogue cues and non-dialogue events."""
    ass = ASSFile()
    current_section = None
    event_idx = 0
    dialogue_idx = 0
    
    with open(file_path, "r", encoding="utf-8-sig", errors="replace") as f:
        lines = f.readlines()

    for line in lines:
        line_stripped = line.strip()
        if line_stripped.startswith("[") and line_stripped.endswith("]"):
            current_section = line_stripped
            if current_section != "[Events]":
                ass.header_lines.append(line)
            continue

        if current_section == "[V4+ Styles]" or current_section == "[V4 Styles]":
            ass.styles_lines.append(line)
            ass.header_lines.append(line)
        elif current_section == "[Events]":
            if line_stripped.startswith("Format:"):
                ass.events_format = line_stripped
            elif line_stripped.startswith("Dialogue:") or line_stripped.startswith("Comment:"):
                is_comment = line_stripped.startswith("Comment:")
                field_map = _event_field_map(ass.events_format)
                field_count = len(field_map)
                parts = line_stripped.split(",", max(0, field_count - 1))
                required = {"start", "end", "style", "text"}
                if len(parts) == field_count and required.issubset(field_map):
                    start_str = parts[field_map["start"]]
                    end_str = parts[field_map["end"]]
                    style = parts[field_map["style"]]
                    text = parts[field_map["text"]]
                    start = time_to_seconds(start_str)
                    end = time_to_seconds(end_str)
                    
                    is_dial = (not is_comment) and is_dialogue_style(style, dialogue_styles)
                    
                    if is_dial:
                        lead_tags, clean_body = extract_leading_tags(text)
                        clean_txt = clean_dialogue(clean_body)
                        cue = SubtitleCue(
                            idx=dialogue_idx,
                            start=start,
                            end=end,
                            text=clean_txt,
                            style=style,
                            orig_idx=event_idx,
                            leading_tags=lead_tags,
                            raw_line=line_stripped,
                            is_dialogue=True,
                            source_text=source_dialogue_text(clean_body),
                            raw_text=text
                        )
                        ass.dialogue_cues.append(cue)
                        dialogue_idx += 1
                        ass.all_events.append({
                            "orig_idx": event_idx,
                            "type": "dialogue",
                            "dialogue_idx": cue.idx,
                            "parts": parts,
                            "field_map": field_map
                        })
                    else:
                        ass.non_dialogue_events.append({
                            "orig_idx": event_idx,
                            "raw_line": line
                        })
                        ass.all_events.append({
                            "orig_idx": event_idx,
                            "type": "non_dialogue",
                            "raw_line": line
                        })
                    event_idx += 1
                else:
                    ass.all_events.append({
                        "orig_idx": event_idx,
                        "type": "raw",
                        "raw_line": line
                    })
                    event_idx += 1
            else:
                ass.all_events.append({
                    "orig_idx": event_idx,
                    "type": "raw",
                    "raw_line": line
                })
                event_idx += 1
        else:
            ass.header_lines.append(line)

    return ass

def parse_srt(file_path: str) -> List[SubtitleCue]:
    """Parse an SRT file into a list of SubtitleCue objects."""
    with open(file_path, "r", encoding="utf-8-sig", errors="replace") as f:
        content = f.read()

    blocks = re.split(r"\n\s*\n", content.strip())
    cues = []
    cue_idx = 0
    
    for b in blocks:
        lines = [l.strip() for l in b.splitlines() if l.strip()]
        if len(lines) >= 2:
            time_line_idx = -1
            for i, l in enumerate(lines[:3]):
                if "-->" in l:
                    time_line_idx = i
                    break
            if time_line_idx != -1:
                time_line = lines[time_line_idx]
                text_lines = lines[time_line_idx + 1:]
                m = re.match(r"(\d+:\d+:\d+[,.]\d+)\s*-->\s*(\d+:\d+:\d+[,.]\d+)", time_line)
                if m:
                    start = time_to_seconds(m.group(1))
                    end = time_to_seconds(m.group(2))
                    raw_text = "\n".join(text_lines)
                    source_text = source_dialogue_text(unescape_and_clean_html(raw_text))
                    clean_txt = clean_dialogue(source_text)
                    if clean_txt:
                        cue = SubtitleCue(
                            idx=cue_idx,
                            start=start,
                            end=end,
                            text=clean_txt,
                            orig_idx=cue_idx,
                            source_text=source_text,
                            raw_text=raw_text
                        )
                        cues.append(cue)
                        cue_idx += 1
    return cues

def sanitize_source_vi(file_path: str, dialogue_styles: Optional[List[str]] = None) -> List[SubtitleCue]:
    """
    Universally sanitize Vietnamese source file (supports either .srt or .ass).
    Returns list of clean SubtitleCue objects.
    """
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".srt":
        return parse_srt(file_path)
    elif ext == ".ass":
        ass = parse_ass(file_path, dialogue_styles=dialogue_styles)
        # In case the source ASS has all dialogue under standard styles
        if not ass.dialogue_cues:
            # Fallback: treat all Dialogue lines as dialogue
            ass = parse_ass(file_path, dialogue_styles=["*"])
        return ass.dialogue_cues
    else:
        raise ValueError(f"Unsupported subtitle format: {ext} (must be .srt or .ass)")

def detect_global_time_offset(en_cues: List[SubtitleCue], vi_cues: List[SubtitleCue],
                              sample_size: int = 60, max_offset: float = 120.0) -> Dict[str, Any]:
    """Estimate a global offset from monotonic, one-to-one timing matches.

    The estimate is accepted only with at least three pairs, a strong match
    ratio, low residual spread, and a clear lead over the second-best offset.
    """
    if not en_cues or not vi_cues:
        return {"offset": 0.0, "accepted": False, "pairs": 0, "mad": None,
                "confidence": "low", "reason": "one or both sources have no cues"}

    en_sample = en_cues[:sample_size]
    vi_sample = vi_cues[:sample_size]
    # Quantized start-time differences provide candidate offsets. Evaluate only
    # the strongest histogram peaks to keep the monotonic matcher inexpensive.
    votes: Dict[float, int] = {}
    for en in en_sample:
        for vi in vi_sample:
            ratio = len(en.text) / max(1, len(vi.text))
            delta = round(en.start - vi.start, 1)
            if 0.3 <= ratio <= 3.0 and abs(delta) <= max_offset:
                votes[delta] = votes.get(delta, 0) + 1
    candidates = sorted(votes, key=lambda value: votes[value], reverse=True)[:30]
    if not candidates:
        return {"offset": 0.0, "accepted": False, "pairs": 0, "mad": None,
                "confidence": "low", "reason": "no plausible timing pairs"}

    scored = []
    for candidate in candidates:
        # Longest monotonic matching; a pair must agree with this offset within
        # 1.25 seconds. Score favors more pairs, then lower residual error.
        rows, cols = len(en_sample), len(vi_sample)
        dp = [[(0, 0.0) for _ in range(cols + 1)] for _ in range(rows + 1)]
        back = [[None for _ in range(cols + 1)] for _ in range(rows + 1)]
        for i in range(1, rows + 1):
            for j in range(1, cols + 1):
                best = dp[i - 1][j]
                direction = "up"
                if dp[i][j - 1][0] > best[0] or (dp[i][j - 1][0] == best[0] and dp[i][j - 1][1] < best[1]):
                    best, direction = dp[i][j - 1], "left"
                residual = abs((en_sample[i - 1].start - vi_sample[j - 1].start) - candidate)
                ratio = len(en_sample[i - 1].text) / max(1, len(vi_sample[j - 1].text))
                if residual <= 1.25 and 0.3 <= ratio <= 3.0:
                    prior = dp[i - 1][j - 1]
                    matched = (prior[0] + 1, prior[1] + residual)
                    if matched[0] > best[0] or (matched[0] == best[0] and matched[1] < best[1]):
                        best, direction = matched, "diag"
                dp[i][j], back[i][j] = best, direction
        pairs = []
        i, j = rows, cols
        while i and j:
            direction = back[i][j]
            if direction == "diag":
                pairs.append((en_sample[i - 1], vi_sample[j - 1]))
                i, j = i - 1, j - 1
            elif direction == "up":
                i -= 1
            else:
                j -= 1
        deltas = [en.start - vi.start for en, vi in pairs]
        offset = statistics.median(deltas) if deltas else 0.0
        mad = statistics.median([abs(delta - offset) for delta in deltas]) if deltas else None
        scored.append({"offset": round(offset, 2), "pairs": len(pairs), "mad": round(mad, 3) if mad is not None else None,
                       "residual": dp[rows][cols][1], "ratio": len(pairs) / max(1, min(rows, cols))})
    scored.sort(key=lambda item: (item["pairs"], -item["residual"]), reverse=True)
    best = scored[0]
    runner_up = next((item for item in scored[1:] if abs(item["offset"] - best["offset"]) >= 2.5), None)
    clear_lead = (runner_up is None or best["pairs"] >= runner_up["pairs"] + 2 or
                  best["residual"] <= runner_up["residual"] * 0.5)
    accepted = (best["pairs"] >= min(6, max(3, min(len(en_sample), len(vi_sample)) // 4))
                and best["ratio"] >= 0.25 and best["mad"] is not None and best["mad"] <= 0.5
                and clear_lead)
    return {**best, "accepted": accepted, "confidence": "high" if accepted else "low",
            "reason": "consistent monotonic matches" if accepted else "insufficient or ambiguous timing evidence"}

def apply_time_offset(cues: List[SubtitleCue], offset: float) -> None:
    """Apply time offset in-place to all cues."""
    if not math.isfinite(offset):
        raise ValueError("Time offset must be finite.")
    if abs(offset) > 0.001:
        for cue in cues:
            cue.start = max(0.0, cue.start + offset)
            cue.end = max(cue.start + 0.1, cue.end + offset)

def export_aligned_ass(master_ass: ASSFile,
                       mapped_dialogues: Dict[int, Dict[str, Any]],
                       output_path: str,
                       dialogue_only_path: Optional[str] = None) -> None:
    """
    Reconstruct full ASS file preserving 100% of header, styles, non-dialogue events,
    and original line positions (orig_idx). Writes output with UTF-8 BOM.
    Optionally exports a clean dialogue-only ASS file.
    """
    output_lines: List[Tuple[int, str]] = []
    dialogue_only_lines: List[str] = []

    # Process all events in their orig_idx order
    for ev in master_ass.all_events:
        o_idx = ev["orig_idx"]
        ev_type = ev["type"]
        
        if ev_type == "dialogue":
            d_idx = ev["dialogue_idx"]
            parts = list(ev["parts"]) # [prefix_layer, start, end, style, name, ml, mr, mv, effect, text]
            map_info = mapped_dialogues.get(d_idx)
            
            if map_info:
                # Retrieve updated fields
                effect = map_info.get("effect", "")
                vi_text = map_info.get("vi_text", "")
                # The master ASS owns the reference and override tags even if
                # an intermediate mapping file contains stale copies.
                master_cue = master_ass.dialogue_cues[d_idx]
                en_ref = master_cue.text
                lead_tags = master_cue.leading_tags
                
                field_map = ev.get("field_map", _event_field_map(master_ass.events_format))
                if "effect" in field_map:
                    parts[field_map["effect"]] = effect
                parts[field_map["text"]] = format_ass_line_text(lead_tags, en_ref, vi_text)
            
            formatted_line = ",".join(parts)
            output_lines.append((o_idx, formatted_line))
            dialogue_only_lines.append(formatted_line)
        else:
            raw_line = ev["raw_line"].rstrip("\r\n")
            output_lines.append((o_idx, raw_line))

    # Sort by orig_idx to ensure 100% exact original line position
    output_lines.sort(key=lambda x: x[0])

    # 1. Write Full ASS with UTF-8 BOM
    with open(output_path, "w", encoding="utf-8-sig") as f:
        # Write header
        for h in master_ass.header_lines:
            f.write(h if h.endswith("\n") else h + "\n")
        # Write Events section header
        f.write("[Events]\n")
        f.write(master_ass.events_format + "\n")
        # Write reconstructed events
        for _, line in output_lines:
            f.write(line + "\n")

    # 2. Write Dialogue.vi if requested
    if dialogue_only_path:
        os.makedirs(os.path.dirname(os.path.abspath(dialogue_only_path)), exist_ok=True)
        with open(dialogue_only_path, "w", encoding="utf-8-sig") as f:
            for h in master_ass.header_lines:
                f.write(h if h.endswith("\n") else h + "\n")
            f.write("[Events]\n")
            f.write(master_ass.events_format + "\n")
            for line in dialogue_only_lines:
                f.write(line + "\n")
