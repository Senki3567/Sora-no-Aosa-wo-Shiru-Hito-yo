#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_sub_align.py - Unit Tests & Regression Verification for softsub-align skill
"""

import os
import sys
import unittest
import tempfile
import unicodedata
import json
from types import SimpleNamespace

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from text_utils import (
    normalize_nfc,
    clean_dialogue,
    extract_leading_tags,
    unescape_and_clean_html,
    clean_whitespace,
    format_ass_line_text
)
from ass_parser import (
    time_to_seconds,
    seconds_to_ass_time,
    parse_ass,
    parse_srt,
    detect_global_time_offset,
    apply_time_offset,
    export_aligned_ass,
    SubtitleCue
)
from sub_align import calculate_overlap_and_iou
from sub_align import cmd_cluster
from mapping import validate_map, audit_outputs

class TestTextUtils(unittest.TestCase):
    def test_nfc(self):
        decomposed = "tiê\u0301ng Viê\u0323t" # NFD
        composed = normalize_nfc(decomposed)
        self.assertEqual(composed, "tiếng Việt")
        self.assertEqual(unicodedata.normalize("NFC", composed), composed)

    def test_clean_dialogue(self):
        raw = r"{\an8\c&HFFFFFF&}{Some ref comment}Đây là câu thoại\Nngắt dòng."
        clean = clean_dialogue(raw)
        self.assertEqual(clean, "Đây là câu thoại ngắt dòng.")

    def test_extract_leading_tags(self):
        raw = r"{\an8\pos(100,200)}Thoại trên đỉnh"
        tags, rest = extract_leading_tags(raw)
        self.assertEqual(tags, r"{\an8\pos(100,200)}")
        self.assertEqual(rest, "Thoại trên đỉnh")

    def test_unescape_html(self):
        raw = "<i>&quot;Đây là câu &amp; thoại&quot;</i>"
        clean = unescape_and_clean_html(raw)
        self.assertEqual(clean, '"Đây là câu & thoại"')

    def test_format_ass_line_text(self):
        line = format_ass_line_text(r"{\an8}", "You dumb animals", "Lũ súc vật")
        self.assertEqual(line, r"{\an8}{You dumb animals} Lũ súc vật")

        # Missing case (empty vi_text)
        missing_line = format_ass_line_text(r"{\an8}", "Sigh...", "")
        self.assertEqual(missing_line, r"{\an8}{Sigh...}")


class TestAssParser(unittest.TestCase):
    def test_time_conversions(self):
        self.assertAlmostEqual(time_to_seconds("0:01:23.45"), 83.45, places=2)
        self.assertAlmostEqual(time_to_seconds("00:01:23,450"), 83.45, places=2)
        self.assertEqual(seconds_to_ass_time(83.45), "0:01:23.45")

    def test_overlap_and_iou(self):
        inter, iou = calculate_overlap_and_iou(10.0, 15.0, 12.0, 17.0)
        self.assertAlmostEqual(inter, 3.0, places=2)
        self.assertAlmostEqual(iou, 3.0 / 7.0, places=2)

    def test_global_offset_detection(self):
        en_cues = [
            SubtitleCue(0, 10.0, 13.0, "Hello world"),
            SubtitleCue(1, 20.0, 24.0, "How are you doing today?"),
            SubtitleCue(2, 35.0, 40.0, "We are going to Anima City right now.")
        ]
        # VI cues delayed by +2.0 seconds
        vi_cues = [
            SubtitleCue(0, 8.0, 11.0, "Xin chào thế giới"),
            SubtitleCue(1, 18.0, 22.0, "Hôm nay bạn thế nào rồi?"),
            SubtitleCue(2, 33.0, 38.0, "Chúng ta đang đến Anima-City ngay bây giờ.")
        ]
        sync = detect_global_time_offset(en_cues, vi_cues)
        self.assertTrue(sync["accepted"])
        self.assertAlmostEqual(sync["offset"], 2.0, places=1)

    def test_source_preserves_speaker_lines_for_srt_and_ass(self):
        with tempfile.TemporaryDirectory() as folder:
            srt_path = os.path.join(folder, "vi.srt")
            ass_path = os.path.join(folder, "vi.ass")
            with open(srt_path, "w", encoding="utf-8") as fp:
                fp.write("1\n00:00:01,000 --> 00:00:03,000\n- Đi thôi.\n- Chờ tôi.\n")
            with open(ass_path, "w", encoding="utf-8") as fp:
                fp.write("[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
                         "Dialogue: 0,0:00:01.00,0:00:03.00,Default,,0,0,0,,{\\an8}- Đi thôi.\\N- Chờ tôi.\n")
            self.assertEqual(parse_srt(srt_path)[0].source_text, "- Đi thôi.\n- Chờ tôi.")
            parsed = parse_ass(ass_path).dialogue_cues[0]
            self.assertEqual(parsed.source_text, "- Đi thôi.\n- Chờ tôi.")
            self.assertEqual(parsed.raw_text, r"{\an8}- Đi thôi.\N- Chờ tôi.")

    def test_full_export_cycle(self):
        # Create a mock ASS file
        sample_ass = """[Script Info]
Title: Test
ScriptType: v4.00+

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,20,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,2,2,10,10,10,1
Style: Signs,Arial,20,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,2,2,10,10,10,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:01.00,0:00:03.00,Signs,,0,0,0,,{\\pos(50,50)}ANIMA CITY SIGN
Dialogue: 0,0:00:05.00,0:00:08.00,Default,,0,0,0,,Hello there.
Dialogue: 0,0:00:09.00,0:00:12.00,Default,,0,0,0,,I am Michiru.
"""
        with tempfile.NamedTemporaryFile("w", encoding="utf-8-sig", delete=False, suffix=".ass") as f_in:
            f_in.write(sample_ass)
            in_path = f_in.name

        out_path = in_path.replace(".ass", "_out.ass")
        dial_out_path = in_path.replace(".ass", "_dial.ass")

        try:
            parsed = parse_ass(in_path)
            self.assertEqual(len(parsed.dialogue_cues), 2)
            self.assertEqual(len(parsed.non_dialogue_events), 1)

            # Map dialogues
            mapped = {
                0: {"vi_text": "Xin chào đằng ấy.", "effect": "", "en_ref": "Hello there.", "lead_tag": ""},
                1: {"vi_text": "Tôi là Michiru.", "effect": "split", "en_ref": "I am Michiru.", "lead_tag": ""}
            }

            export_aligned_ass(parsed, mapped, out_path, dial_out_path)

            # Verify UTF-8 BOM
            with open(out_path, "rb") as fp:
                raw = fp.read()
            self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))

            # Verify line contents and order
            lines = raw.decode("utf-8").splitlines()
            event_lines = [l for l in lines if l.startswith("Dialogue:")]
            self.assertEqual(len(event_lines), 3)

            # Check that Sign was preserved at position 0
            self.assertIn("ANIMA CITY SIGN", event_lines[0])
            self.assertIn("Signs", event_lines[0])

            # Check that dialogue lines have en_ref and effect
            self.assertIn("{Hello there.} Xin chào đằng ấy.", event_lines[1])
            self.assertIn(",split,{I am Michiru.} Tôi là Michiru.", event_lines[2])

            # Check dialogue-only file
            with open(dial_out_path, "rb") as fp:
                dial_raw = fp.read()
            self.assertTrue(dial_raw.startswith(b"\xef\xbb\xbf"))
            dial_events = [l for l in dial_raw.decode("utf-8").splitlines() if l.startswith("Dialogue:")]
            self.assertEqual(len(dial_events), 2)
            self.assertNotIn("ANIMA CITY SIGN", dial_raw.decode("utf-8"))
            for ev in dial_events:
                self.assertNotIn("Signs", ev)

        finally:
            for p in [in_path, out_path, dial_out_path]:
                if os.path.exists(p):
                    os.remove(p)


class TestSemanticMapping(unittest.TestCase):
    en_path = "/tmp/semantic-en.ass"
    vi_path = "/tmp/semantic-vi.srt"

    def span(self, source, phrase, vi_id, start_at=0):
        start = source.index(phrase, start_at)
        return {"vi_id": vi_id, "start": start, "end": start + len(phrase)}

    def data_and_map(self, en_texts, vi_sources, entries, unassigned=None):
        data = {"eng_lines": [{"text": text, "lead_tag": ""} for text in en_texts],
                "vie_lines": [{"source_text": source} for source in vi_sources]}
        converted = []
        for original in entries:
            item = dict(original)
            if "segments" in item:
                item["source_parts"] = item.pop("segments")
            for repetition in item.get("repetitions", []):
                if "segment_index" in repetition:
                    repetition["source_part_index"] = repetition.pop("segment_index")
            if item.get("source_parts"):
                item.setdefault("semantic_review", {"meaning_matches": True, "coverage_complete": True,
                                                      "no_extra_content": True, "speaker_matches": True})
            converted.append(item)
        mapping = {"schema_version": 4, "complete": True,
                   "source": {"en_file": self.en_path, "vi_file": self.vi_path},
                   "mappings": {str(i): item for i, item in enumerate(converted)}}
        return data, mapping

    def test_overlapping_chant_and_baseball_from_user_example(self):
        en_ass = """[Script Info]
Title: Overlap
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 10,0:07:42.15,0:07:45.16,Default,,0,0,0,,With you on our team, becoming the champion isn't just a dream.
Dialogue: 10,0:07:45.16,0:07:50.03,Default,,0,0,0,,{\\an8}Champion! Champion! Champion! Champion!
Dialogue: 10,0:07:46.69,0:07:50.03,Alt,,0,0,0,,{\\an8}I really don't think I can play baseball after all. Sorry.
Dialogue: 10,0:07:50.37,0:07:50.99,Default,,0,0,0,,Eh?
"""
        vi0 = "Michiru, có cô trong đội,\nchúng tôi có thể trở thành nhà vô địch."
        vi1 = "Vô địch! - Cơ mà, tôi không biết chơi bóng chày.\n- Xin lỗi."
        vi2 = "Hả?"
        data, mapping = self.data_and_map(
            ["With you on our team, becoming the champion isn't just a dream.",
             "Champion! Champion! Champion! Champion!",
             "I really don't think I can play baseball after all. Sorry.", "Eh?"],
            [vi0, vi1, vi2],
            [{"segments": [{"vi_id": 0, "start": 0, "end": len(vi0)}],
              "vi_text": "Michiru, có cô trong đội,\\Nchúng tôi có thể trở thành nhà vô địch."},
             {"segments": [self.span(vi1, "Vô địch!", 1)],
              "vi_text": "Vô địch! Vô địch! Vô địch! Vô địch!",
              "repetitions": [{"segment_index": 0, "times": 4}]},
             {"segments": [self.span(vi1, "Cơ mà, tôi không biết chơi bóng chày.", 1),
                           self.span(vi1, "Xin lỗi.", 1)],
              "vi_text": "Cơ mà, tôi không biết chơi bóng chày. Xin lỗi."},
             {"segments": [self.span(vi2, "Hả?", 2)], "vi_text": "Hả?"}])
        result = validate_map(mapping, data, self.en_path, self.vi_path)
        self.assertEqual([result[i]["effect"] for i in range(4)], ["", "split", "split", ""])
        with tempfile.TemporaryDirectory() as temp_dir:
            en_path = os.path.join(temp_dir, "en.ass")
            out_path = os.path.join(temp_dir, "out.ass")
            with open(en_path, "w", encoding="utf-8") as fp:
                fp.write(en_ass)
            parsed = parse_ass(en_path)
            export_aligned_ass(parsed, result, out_path)
            with open(out_path, "r", encoding="utf-8-sig") as fp:
                rows = [line.strip() for line in fp if line.startswith("Dialogue:")]
        self.assertEqual(len(rows), 4)
        self.assertIn("0:07:45.16,0:07:50.03,Default", rows[1])
        self.assertIn(r"{\an8}{Champion! Champion! Champion! Champion!} Vô địch! Vô địch! Vô địch! Vô địch!", rows[1])
        self.assertNotIn("bóng chày", rows[1])
        self.assertIn("0:07:46.69,0:07:50.03,Alt", rows[2])
        self.assertIn("Cơ mà, tôi không biết chơi bóng chày. Xin lỗi.", rows[2])
        self.assertNotIn("Vô địch", rows[2])
        self.assertTrue(rows[3].endswith("{Eh?} Hả?"))

    def test_extra_vi_does_not_require_whole_source_inventory(self):
        vi = "- Đi thôi.\n- Chờ tôi.\nLời thêm không có trong EN."
        data, mapping = self.data_and_map(
            ["Let's go.", "Wait for me."], [vi],
            [{"segments": [self.span(vi, "Đi thôi.", 0)], "vi_text": "Đi thôi."},
             {"segments": [self.span(vi, "Chờ tôi.", 0)], "vi_text": "Chờ tôi."}])
        self.assertEqual(validate_map(mapping, data, self.en_path, self.vi_path)[0]["effect"], "split")
        mapping["mappings"]["1"]["source_parts"] = [self.span(vi, "Đi thôi.", 0)]
        with self.assertRaisesRegex(ValueError, "assigned more than once"):
            validate_map(mapping, data, self.en_path, self.vi_path)

    def test_direct_match_uses_whole_cue_without_character_offsets(self):
        data, mapping = self.data_and_map(["See you."], ["Hẹn gặp lại."],
                                          [{"source_parts": [{"vi_id": 0}], "vi_text": "Hẹn gặp lại."}])
        self.assertEqual(validate_map(mapping, data, self.en_path, self.vi_path)[0]["effect"], "")

    def test_one_vi_sentence_is_not_duplicated_across_adjacent_en_clauses(self):
        vi = ("Khoảng sáu tháng trước, khi một người tên Cliff Boris gia nhập, "
              "nó đã mở rộng và phát triển mạnh mẽ.")
        data, mapping = self.data_and_map(
            ["but after a man named Cliff Boris joined approximately six months ago, they rapidly expanded",
             "and gained a measure of political power."],
            [vi],
            [{"source_parts": [{"vi_id": 0}], "vi_text": vi},
             {"source_parts": [], "vi_text": "", "missing_review": {
                 "candidate_window_checked": True,
                 "concurrent_and_neighboring_en_checked": True}}])
        result = validate_map(mapping, data, self.en_path, self.vi_path)
        self.assertEqual([result[i]["effect"] for i in range(2)], ["", "missing"])

        mapping["mappings"]["1"] = {
            "source_parts": [{"vi_id": 0}], "vi_text": vi,
            "semantic_review": {"meaning_matches": True, "coverage_complete": True,
                                "no_extra_content": True, "speaker_matches": True}}
        with self.assertRaisesRegex(ValueError, "assigned more than once"):
            validate_map(mapping, data, self.en_path, self.vi_path)

    def test_two_speakers_in_one_en_and_sequential_en(self):
        vi = "- Đi thôi.\n- Chờ tôi."
        full = [{"segments": [self.span(vi, "Đi thôi.", 0), self.span(vi, "Chờ tôi.", 0)],
                 "vi_text": "- Đi thôi.\\N- Chờ tôi."}]
        data, mapping = self.data_and_map(["Let's go. Wait for me."], [vi], full)
        self.assertEqual(validate_map(mapping, data, self.en_path, self.vi_path)[0]["effect"], "")
        data, mapping = self.data_and_map(
            ["Let's go.", "Wait for me."], [vi],
            [{"segments": [self.span(vi, "Đi thôi.", 0)], "vi_text": "Đi thôi."},
             {"segments": [self.span(vi, "Chờ tôi.", 0)], "vi_text": "Chờ tôi."}])
        self.assertEqual([v["effect"] for v in validate_map(mapping, data, self.en_path, self.vi_path).values()],
                         ["split", "split"])

    def test_multiple_temporal_candidates_do_not_imply_merge(self):
        data, mapping = self.data_and_map(
            ["Champion!", "I cannot play baseball."], ["Vô địch!", "Tôi không biết chơi bóng chày."],
            [{"segments": [{"vi_id": 0, "start": 0, "end": len("Vô địch!")}], "vi_text": "Vô địch!"},
             {"segments": [{"vi_id": 1, "start": 0, "end": len("Tôi không biết chơi bóng chày.")}],
              "vi_text": "Tôi không biết chơi bóng chày."}])
        self.assertEqual([v["effect"] for v in validate_map(mapping, data, self.en_path, self.vi_path).values()], ["", ""])
        data["eng_lines"][0].update(start=0, end=2)
        data["eng_lines"][1].update(start=0.5, end=2)
        data["vie_lines"][0].update(start=0, end=2)
        data["vie_lines"][1].update(start=0.5, end=2)
        with tempfile.TemporaryDirectory() as temp_dir:
            in_path = os.path.join(temp_dir, "data.json")
            out_path = os.path.join(temp_dir, "candidates.json")
            with open(in_path, "w", encoding="utf-8") as fp:
                json.dump(data, fp)
            cmd_cluster(SimpleNamespace(in_data=in_path, out_candidates=out_path))
            with open(out_path, "r", encoding="utf-8") as fp:
                candidates = json.load(fp)
        self.assertEqual(candidates["groups"][0]["kind"], "temporal_review_group")
        self.assertNotIn("merge_candidates", candidates)

    def test_semantic_audit_flags_leakage_into_other_en(self):
        vi = "Vô địch!\nCơ mà, tôi không biết chơi bóng chày."
        data, mapping = self.data_and_map(
            ["Champion!", "I cannot play baseball."], [vi],
            [{"segments": [self.span(vi, "Vô địch!", 0)],
              "vi_text": "Vô địch! Cơ mà, tôi không biết chơi bóng chày."},
             {"segments": [self.span(vi, "Cơ mà, tôi không biết chơi bóng chày.", 0)],
              "vi_text": "Cơ mà, tôi không biết chơi bóng chày."}])
        validate_map(mapping, data, self.en_path, self.vi_path)
        self.assertTrue(any("selected for EN 1" in warning for warning in audit_outputs(mapping, data)))

    def test_merge_and_missing_are_derived_from_selection(self):
        data, mapping = self.data_and_map(
            ["I cannot play baseball. Sorry.", "Eh?"],
            ["Tôi không biết chơi bóng chày.", "Xin lỗi."],
            [{"segments": [{"vi_id": 0, "start": 0, "end": len("Tôi không biết chơi bóng chày.")},
                           {"vi_id": 1, "start": 0, "end": len("Xin lỗi.")}],
              "vi_text": "Tôi không biết chơi bóng chày. Xin lỗi."},
             {"segments": [], "vi_text": "", "missing_review": {
                 "candidate_window_checked": True, "concurrent_and_neighboring_en_checked": True}}])
        self.assertEqual([v["effect"] for v in validate_map(mapping, data, self.en_path, self.vi_path).values()],
                         ["merge", "missing"])
        mapping["mappings"]["0"]["effect"] = "split"
        with self.assertRaisesRegex(ValueError, "effect must be"):
            validate_map(mapping, data, self.en_path, self.vi_path)

if __name__ == "__main__":
    unittest.main()
