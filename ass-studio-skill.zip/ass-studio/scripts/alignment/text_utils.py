#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
text_utils.py - Vietnamese Text Utilities, Normalization & ASS Tag Management
Part of skill `softsub-align`.
"""

import re
import html
import unicodedata
from typing import Tuple

def normalize_nfc(text: str) -> str:
    """Normalize string to standard Unicode NFC (Normalization Form C)."""
    if not text:
        return ""
    return unicodedata.normalize("NFC", text)

def unescape_and_clean_html(text: str) -> str:
    """Remove HTML tags (<i>, <b>, <font>, etc.) and unescape HTML entities."""
    if not text:
        return ""
    # Strip HTML tags
    clean = re.sub(r"<[^>]+>", "", text)
    # Unescape HTML entities
    clean = html.unescape(clean)
    return normalize_nfc(clean)

def clean_dialogue(text: str) -> str:
    """Strip all ASS override tags {\\...} and curly comments {...} to get raw plain text."""
    if not text:
        return ""
    # Remove all {...} blocks
    clean = re.sub(r"\{[^}]*\}", "", text)
    # Replace real newlines with space
    clean = clean.replace("\r\n", " ").replace("\n", " ")
    # Replace literal \N or \n with space
    clean = re.sub(r"\\[Nn]", " ", clean)
    # Clean whitespace
    clean = re.sub(r"\s+", " ", clean).strip()
    return normalize_nfc(clean)

def source_dialogue_text(text: str) -> str:
    """Plain source text with speaker turns and line breaks intact.

    Character offsets into this value are the provenance coordinates used by
    schema v4. Do not flatten it before an agent selects an EN-specific source.
    """
    if not text:
        return ""
    clean = re.sub(r"\{[^}]*\}", "", text)
    clean = re.sub(r"\\[Nn]", "\n", clean.replace("\r\n", "\n").replace("\r", "\n"))
    return normalize_nfc("\n".join(re.sub(r"[ \t]+", " ", line).strip()
                                   for line in clean.split("\n"))).strip()

def extract_leading_tags(text: str) -> Tuple[str, str]:
    """
    Extract leading ASS override tags (e.g. {\\an8}, {\\pos(x,y)}, {\\c&H...&}).
    Returns (leading_tags, remaining_text).
    """
    if not text:
        return "", ""
    leading = []
    idx = 0
    while idx < len(text):
        if text[idx] == "{" and (idx + 1 < len(text) and text[idx + 1] == "\\"):
            close_idx = text.find("}", idx)
            if close_idx != -1:
                leading.append(text[idx:close_idx + 1])
                idx = close_idx + 1
            else:
                break
        else:
            break
    leading_str = "".join(leading)
    remainder = text[idx:].strip()
    return leading_str, remainder

def clean_whitespace(text: str) -> str:
    """Normalize internal spacing and clean spaces around literal \\N."""
    if not text:
        return ""
    # Replace multiple spaces with one
    text = re.sub(r"[ \t]+", " ", text)
    # Clean spaces around \N
    text = re.sub(r"\s*\\N\s*", r"\\N", text)
    return text.strip()

def format_ass_line_text(leading_tags: str, en_ref: str, vi_text: str) -> str:
    """
    Format standard ASS output text with leading tags, {en_ref} inline comment, and vi_text.
    Format: {\\leading_tags}{en_ref} vi_text  (or {\\leading_tags}{en_ref} if vi_text is empty)
    """
    # Sanitize en_ref to not contain unescaped curly braces
    safe_en_ref = en_ref.replace("{", "(").replace("}", ")").strip()
    
    leading = leading_tags.strip()
    comment = f"{{{safe_en_ref}}}"
    vi = clean_whitespace(vi_text).strip()
    
    if leading:
        if vi:
            return f"{leading}{comment} {vi}"
        else:
            return f"{leading}{comment}"
    else:
        if vi:
            return f"{comment} {vi}"
        else:
            return f"{comment}"

def measure_visual_length(text: str) -> int:
    """Return character count of text excluding ASS override tags and curly comments."""
    plain = clean_dialogue(text)
    return len(plain)
