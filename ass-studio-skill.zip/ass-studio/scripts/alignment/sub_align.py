#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sub_align.py - Universal Softsub Semantic Alignment & Mux Engine CLI
Part of skill `softsub-align`.
Commands:
  preflight      : Scan directories, pair EN/VI files, analyze styles.
  sanitize-sync  : Clean inputs, separate dialogue vs non-dialogue, auto-detect global offset.
  cluster        : Temporal review groups (IoU & Delta T), without semantic labels.
  review         : Print a compact EN batch and nearby VI wording.
  compile-map    : Expand reviewed JSONL decisions into the validated map.
  export         : Reconstruct full ASS with UTF-8 BOM, {en_ref} comments, Effect flags.
"""

import os
import sys
import json
import argparse
import re
import tempfile
import math
from typing import List, Dict, Any, Tuple, Optional

# Add script directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ass_parser import (
    parse_ass,
    sanitize_source_vi,
    detect_global_time_offset,
    apply_time_offset,
    export_aligned_ass,
    SubtitleCue,
    ASSFile
)
from mapping import validate_map, audit_outputs

def calculate_overlap_and_iou(start1: float, end1: float, start2: float, end2: float) -> Tuple[float, float]:
    """Calculate overlap duration and Intersection over Union (IoU) between two time intervals."""
    inter_start = max(start1, start2)
    inter_end = min(end1, end2)
    inter_dur = max(0.0, inter_end - inter_start)
    union_dur = max(end1, end2) - min(start1, start2)
    iou = inter_dur / union_dur if union_dur > 0 else 0.0
    return inter_dur, iou


def temporal_vi_candidates(en_cue: Dict[str, Any], vi_cues: List[Dict[str, Any]],
                           window: float = 5.0) -> List[int]:
    """Find timing hints for one EN cue; semantic matching remains the agent's work."""
    candidates = []
    for vi_id, vi_cue in enumerate(vi_cues):
        overlap, iou = calculate_overlap_and_iou(
            en_cue["start"], en_cue["end"], vi_cue["start"], vi_cue["end"])
        if overlap > 0.3 or iou > 0.15 or abs(en_cue["start"] - vi_cue["start"]) <= window:
            candidates.append(vi_id)
    return candidates

def cmd_preflight(args: argparse.Namespace) -> None:
    """Preflight: Scan directories, match episode pairs, inspect styles."""
    en_dir = args.en_dir
    vi_dir = args.vi_dir or en_dir
    
    def find_files(dir_path: str, exts: Tuple[str, ...]) -> List[str]:
        res = []
        if os.path.isdir(dir_path):
            for fname in sorted(os.listdir(dir_path)):
                if fname.lower().endswith(exts):
                    res.append(os.path.join(dir_path, fname))
        return res

    en_files = find_files(en_dir, (".ass",))
    vi_files = find_files(vi_dir, (".srt", ".ass"))

    print(f"=== Preflight Inspection ===")
    print(f"EN Master Directory : {en_dir} (found {len(en_files)} .ass files)")
    print(f"VI Source Directory : {vi_dir} (found {len(vi_files)} files)")

    def extract_ep_num(filename: str) -> Optional[str]:
        # 1. Match S01E02 or E02 or EP02
        m = re.search(r"(?:[Ee][Pp]?|\b[Ee])(\d{1,3})", filename)
        if m:
            return f"{int(m.group(1)):02d}"
        # 2. Match [02] or - 02
        m = re.search(r"(?:\[|\s-\s)(\d{2,3})(?:\]|\s)", filename)
        if m:
            return f"{int(m.group(1)):02d}"
        # 3. Standalone 2-digit not preceded by S
        m = re.search(r"(?<![Ss\d])(\d{2})(?!\d)", filename)
        if m:
            return f"{int(m.group(1)):02d}"
        return None

    def series_signature(filename: str) -> str:
        stem = os.path.splitext(os.path.basename(filename))[0].lower()
        stem = re.sub(r"s\d{1,2}e\d{1,3}|e?p\s*\d{1,3}|\be\d{1,3}\b", " ", stem)
        stem = re.sub(r"\b(1080p|720p|480p|2160p|bd|web|webrip|bluray|h264|x264|x265|en|eng|english|vi|vietnamese|sub|subs|subbed|subtitle|subtitles)\b", " ", stem)
        return " ".join(re.findall(r"[a-z0-9]+", stem))

    pairs = []
    ambiguous = []
    for ef in en_files:
        ep_num = extract_ep_num(os.path.basename(ef))
        if ep_num:
            en_signature = series_signature(ef)
            matches = []
            for vf in vi_files:
                if os.path.abspath(vf) == os.path.abspath(ef):
                    continue
                v_ep = extract_ep_num(os.path.basename(vf))
                if v_ep == ep_num and en_signature and en_signature == series_signature(vf):
                    matches.append(vf)
            if len(matches) == 1:
                pairs.append((ep_num, ef, matches[0]))
            elif len(matches) > 1:
                ambiguous.append((ep_num, ef, matches))
            elif not matches:
                same_episode = [vf for vf in vi_files if os.path.abspath(vf) != os.path.abspath(ef)
                                and extract_ep_num(os.path.basename(vf)) == ep_num]
                if same_episode:
                    ambiguous.append((ep_num, ef, same_episode))

    vi_pair_counts: Dict[str, int] = {}
    for _, _, vf in pairs:
        vi_pair_counts[vf] = vi_pair_counts.get(vf, 0) + 1
    duplicated_vi = {vf for vf, count in vi_pair_counts.items() if count > 1}
    if duplicated_vi:
        retained = []
        for pair in pairs:
            if pair[2] in duplicated_vi:
                ambiguous.append((pair[0], pair[1], [pair[2]]))
            else:
                retained.append(pair)
        pairs = retained

    print(f"\nMatched {len(pairs)} Episode Pairs:")
    for ep, ef, vf in pairs:
        print(f"  [EP {ep}]")
        print(f"    EN: {os.path.basename(ef)}")
        print(f"    VI: {os.path.basename(vf)}")
    if ambiguous:
        print("\nAmbiguous episode pairs (no automatic choice made):")
        for ep, ef, matches in ambiguous:
            print(f"  [EP {ep}] EN: {os.path.basename(ef)}")
            for vf in matches:
                print(f"    VI candidate: {os.path.basename(vf)}")
    paired_en = {ef for _, ef, _ in pairs} | {ef for _, ef, _ in ambiguous}
    for ef in en_files:
        if ef not in paired_en:
            print(f"  Missing VI pair: {os.path.basename(ef)}")

    if args.inspect_styles and pairs:
        sample_en = pairs[0][1]
        print(f"\nAnalyzing Styles in Sample EN: {os.path.basename(sample_en)}")
        ass = parse_ass(sample_en)
        style_counts: Dict[str, int] = {}
        for c in ass.dialogue_cues:
            style_counts[c.style] = style_counts.get(c.style, 0) + 1
        print(f"  Dialogue Styles detected ({len(ass.dialogue_cues)} dialogue cues):")
        for s, cnt in style_counts.items():
            print(f"    - {s}: {cnt} lines")
        print(f"  Non-dialogue Events: {len(ass.non_dialogue_events)} lines")

def cmd_sanitize_sync(args: argparse.Namespace) -> None:
    """Sanitize both inputs, separate dialogue vs non-dialogue, detect global offset, save data.json."""
    en_file = args.en_file
    vi_file = args.vi_file
    out_data = args.out_data
    styles = [s.strip() for s in args.styles.split(",")] if args.styles else None

    print(f"Parsing and categorizing Master EN: {os.path.basename(en_file)}")
    master_ass = parse_ass(en_file, dialogue_styles=styles)
    en_cues = master_ass.dialogue_cues
    print(f"  Dialogue cues: {len(en_cues)}, Non-dialogue events: {len(master_ass.non_dialogue_events)}")

    print(f"Sanitizing Source VI: {os.path.basename(vi_file)}")
    vi_cues = sanitize_source_vi(vi_file)
    print(f"  Clean VI dialogue cues: {len(vi_cues)}")

    # Detect or explicitly select global timing behavior.
    if args.offset == "none":
        sync = {"offset": 0.0, "accepted": True, "pairs": 0, "mad": None,
                "confidence": "manual", "reason": "offset disabled by user", "mode": "none"}
    elif args.offset == "auto":
        sync = detect_global_time_offset(en_cues, vi_cues)
        sync["mode"] = "auto"
    else:
        try:
            manual_offset = float(args.offset)
        except ValueError as exc:
            raise SystemExit("--offset must be auto, none, or a number of seconds") from exc
        if not math.isfinite(manual_offset):
            raise SystemExit("--offset must be a finite number of seconds")
        sync = {"offset": round(manual_offset, 2), "accepted": True, "pairs": 0, "mad": None,
                "confidence": "manual", "reason": "offset supplied by user", "mode": "manual"}
    print(f"  Global Time Offset: {sync['offset']:+.2f}s ({sync['confidence']}; {sync['reason']})")
    if sync.get("mode") == "auto":
        print(f"  Timing Evidence: {sync.get('pairs', 0)} monotonic pairs; median absolute deviation {sync.get('mad')}s")
    if sync["accepted"] and abs(sync["offset"]) > 0.001:
        apply_time_offset(vi_cues, sync["offset"])
        print(f"  Applied {sync['offset']:+.2f}s offset to all VI cues.")
    elif not sync["accepted"]:
        print("  Automatic offset was not applied. Rerun with --offset <seconds> or --offset none after review.")

    data = {
        "en_file": os.path.abspath(en_file),
        "vi_file": os.path.abspath(vi_file),
        "global_offset": sync["offset"] if sync["accepted"] else 0.0,
        "sync": sync,
        "styles": styles,
        "eng_lines": [c.to_dict() for c in en_cues],
        "vie_lines": [c.to_dict() for c in vi_cues]
    }

    os.makedirs(os.path.dirname(os.path.abspath(out_data)), exist_ok=True)
    with open(out_data, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, allow_nan=False)
    print(f"Saved clean synchronized data to: {out_data}")

def cmd_cluster(args: argparse.Namespace) -> None:
    """Group nearby EN and VI cues for semantic review; do not assign VI text."""
    in_data = args.in_data
    out_candidates = args.out_candidates

    with open(in_data, "r", encoding="utf-8") as f:
        data = json.load(f)

    eng_lines = data["eng_lines"]
    vie_lines = data["vie_lines"]

    print(f"Clustering {len(eng_lines)} EN cues against {len(vie_lines)} VI cues...")

    en_candidates: Dict[int, List[int]] = {}
    vi_usage: Dict[int, List[int]] = {}

    for e_idx, e in enumerate(eng_lines):
        cand_list = temporal_vi_candidates(e, vie_lines)
        for v_idx in cand_list:
            if v_idx not in vi_usage:
                vi_usage[v_idx] = []
            vi_usage[v_idx].append(e_idx)
        en_candidates[e_idx] = cand_list

    groups = []
    seen_en, seen_vi = set(), set()
    for start_en, start_candidates in en_candidates.items():
        if not start_candidates or start_en in seen_en:
            continue
        component_en, component_vi = set(), set()
        pending_en, pending_vi = [start_en], []
        while pending_en or pending_vi:
            while pending_en:
                e_idx = pending_en.pop()
                if e_idx in component_en:
                    continue
                component_en.add(e_idx)
                pending_vi.extend(en_candidates.get(e_idx, []))
            while pending_vi:
                v_idx = pending_vi.pop()
                if v_idx in component_vi:
                    continue
                component_vi.add(v_idx)
                pending_en.extend(vi_usage.get(v_idx, []))
        seen_en.update(component_en)
        seen_vi.update(component_vi)
        groups.append({"en_indices": sorted(component_en), "vi_indices": sorted(component_vi),
                       "kind": "temporal_review_group"})

    result = {
        "summary": {
            "total_en": len(eng_lines),
            "total_vi": len(vie_lines),
            "review_group_count": len(groups),
            "without_temporal_candidate_count": sum(not c for c in en_candidates.values())
        },
        "en_review_queue": [
            {"en_id": en_id, "en_text": cue["text"],
             "candidate_vi_ids": en_candidates[en_id]}
            for en_id, cue in enumerate(eng_lines)
        ],
        "raw_mapping_candidates": en_candidates,
        "groups": groups,
        "unused_vi_candidates": [i for i in range(len(vie_lines)) if i not in seen_vi],
        "classification_note": "Review en_review_queue in EN order. Candidate VI IDs and temporal groups are search hints, not matches or missing verdicts. Inspect the full VI source when needed."
    }

    os.makedirs(os.path.dirname(os.path.abspath(out_candidates)), exist_ok=True)
    with open(out_candidates, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"Clustering Complete:")
    print(f"  Temporal review groups      : {len(groups)}")
    print(f"  EN without temporal hints   : {sum(not c for c in en_candidates.values())} (not a missing verdict)")
    print(f"Saved candidate clusters to: {out_candidates}")


def cmd_review(args: argparse.Namespace) -> None:
    """Print only the EN batch and nearby VI text needed for semantic review."""
    with open(args.in_data, "r", encoding="utf-8") as f:
        data = json.load(f)
    en_cues, vi_cues = data["eng_lines"], data["vie_lines"]
    if (args.start_en < 0 or args.start_en >= len(en_cues) or
            args.count < 1 or args.count > 100 or
            not math.isfinite(args.window) or args.window < 0 or
            args.vi_neighbors < 0 or args.vi_neighbors > 10):
        raise ValueError("Review requires a valid EN start, count 1-100, nonnegative window, and VI neighbors 0-10.")

    stop_en = min(len(en_cues), args.start_en + args.count)
    visible_vi = set()
    en_rows = []
    for en_id in range(args.start_en, stop_en):
        cue = en_cues[en_id]
        candidates = temporal_vi_candidates(cue, vi_cues, args.window)
        visible_vi.update(candidates)
        row = {"id": en_id, "time": [cue["start"], cue["end"]],
               "text": cue["text"], "vi_ids": candidates}
        if args.show_raw:
            row["raw_text"] = cue.get("raw_text", "")
        en_rows.append(row)

    for vi_id in list(visible_vi):
        visible_vi.update(range(max(0, vi_id - args.vi_neighbors),
                                min(len(vi_cues), vi_id + args.vi_neighbors + 1)))
    vi_rows = []
    for vi_id in sorted(visible_vi):
        cue = vi_cues[vi_id]
        row = {"id": vi_id, "time": [cue["start"], cue["end"]],
               "text": cue["source_text"]}
        if args.show_raw:
            row["raw_text"] = cue.get("raw_text", "")
        vi_rows.append(row)

    context = []
    for en_id in (args.start_en - 1, stop_en):
        if 0 <= en_id < len(en_cues):
            cue = en_cues[en_id]
            context.append({"id": en_id, "text": cue["text"]})
    print(json.dumps({"en": en_rows, "vi": vi_rows, "context_en": context},
                     ensure_ascii=False, separators=(",", ":")))

def _atomic_json(path: str, value: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fd, temp_path = tempfile.mkstemp(prefix=".softsub-map-", suffix=".json", dir=os.path.dirname(os.path.abspath(path)))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(value, f, indent=2, ensure_ascii=False)
            f.write("\n")
        os.replace(temp_path, path)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def _load_and_validate_map(map_data: Any, data: Dict[str, Any], en_file: str, vi_file: str) -> Dict[int, Dict[str, Any]]:
    return validate_map(map_data, data, en_file, vi_file)


def cmd_convert_map(args: argparse.Namespace) -> None:
    with open(args.in_data, "r", encoding="utf-8") as f:
        data = json.load(f)
    with open(args.in_map, "r", encoding="utf-8") as f:
        old = json.load(f)
    items = old.get("mappings", old) if isinstance(old, dict) else old
    if isinstance(items, dict):
        old_items = items
    elif isinstance(items, list):
        old_items = {str(item.get("id", i)): item for i, item in enumerate(items) if isinstance(item, dict)}
    else:
        raise ValueError("Legacy map must be an object or list.")
    mappings = {}
    en_lines = data.get("eng_lines", [])
    for en_id, _ in enumerate(en_lines):
        old_item = old_items.get(str(en_id), {})
        if not isinstance(old_item, dict):
            old_item = {}
        mappings[str(en_id)] = {"source_parts": [], "vi_text": "", "review_required": True,
                                "legacy_suggestion": {"vi_ids": old_item.get("vi_ids", []),
                                                      "vi_text": old_item.get("vi_text", "")}}
    output = {"schema_version": 4, "complete": False, "review_required": True,
              "source": {"en_file": data["en_file"], "vi_file": data["vi_file"]},
              "mappings": mappings,
              "conversion_note": "Review each EN cue first. Confirm direct matches with whole-cue refs; add character ranges only when selecting part of a VI cue."}
    _atomic_json(args.out_map, output)
    print(f"Draft schema v4 map written: {args.out_map}")
    print(f"EN cues requiring semantic review: {len(en_lines)}")


def cmd_compile_map(args: argparse.Namespace) -> None:
    """Expand explicitly reviewed compact decisions into the validated v4 map."""
    with open(args.in_data, "r", encoding="utf-8") as f:
        data = json.load(f)
    if os.path.abspath(args.out_map) in {
            os.path.abspath(path) for path in (
                args.in_data, args.in_decisions, data["en_file"], data["vi_file"])}:
        raise ValueError("Map output must not overwrite input data, decisions, or subtitles.")
    mappings = {}
    with open(args.in_decisions, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Decision line {line_no} is invalid JSON.") from exc
            if (not isinstance(row, dict) or type(row.get("en")) is not int or
                    not isinstance(row.get("parts"), list) or
                    not isinstance(row.get("text"), str) or row.get("reviewed") is not True):
                raise ValueError(f"Decision line {line_no} needs en, parts, text, and reviewed: true.")
            key = str(row["en"])
            if key in mappings:
                raise ValueError(f"EN {key} appears more than once in decisions.")
            source_parts = []
            for part in row["parts"]:
                if not isinstance(part, list) or len(part) not in (1, 3) or any(type(n) is not int for n in part):
                    raise ValueError(f"Decision line {line_no} parts need [vi_id] or [vi_id,start,end].")
                source_parts.append({"vi_id": part[0]} if len(part) == 1 else
                                    {"vi_id": part[0], "start": part[1], "end": part[2]})
            item = {"source_parts": source_parts, "vi_text": row["text"]}
            if source_parts:
                item["semantic_review"] = {
                    "meaning_matches": True, "coverage_complete": True,
                    "no_extra_content": True, "speaker_matches": True}
            else:
                item["missing_review"] = {
                    "candidate_window_checked": True,
                    "concurrent_and_neighboring_en_checked": True}
            if "repetitions" in row:
                reps = row["repetitions"]
                if (not isinstance(reps, list) or
                        any(not isinstance(rep, list) or len(rep) != 2 or
                            any(type(n) is not int for n in rep) for rep in reps)):
                    raise ValueError(f"Decision line {line_no} repetitions need [source_part_index,times] pairs.")
                item["repetitions"] = [
                    {"source_part_index": rep[0], "times": rep[1]} for rep in reps]
            if "note" in row:
                if not isinstance(row["note"], str):
                    raise ValueError(f"Decision line {line_no} note must be text.")
                item["alignment_note"] = row["note"]
            mappings[key] = item

    output = {"schema_version": 4, "complete": True,
              "source": {"en_file": data["en_file"], "vi_file": data["vi_file"]},
              "mappings": mappings}
    validate_map(output, data, data["en_file"], data["vi_file"])
    _atomic_json(args.out_map, output)
    print(f"Validated map written: {args.out_map} ({len(mappings)} EN cues)")


def cmd_export(args: argparse.Namespace) -> None:
    """Export final ASS file with UTF-8 BOM, {en_ref} comments, Effect flags, and optional Dialogue.vi."""
    en_file = args.en_file
    map_pr_file = args.map_pr_file
    out_file = args.out_file
    dialogue_out = args.dialogue_out
    styles = [s.strip() for s in args.styles.split(",")] if args.styles else None
    output_paths = [os.path.abspath(out_file)] + ([os.path.abspath(dialogue_out)] if dialogue_out else [])
    input_paths = {os.path.abspath(en_file), os.path.abspath(args.in_data), os.path.abspath(args.map_pr_file)}
    if len(set(output_paths)) != len(output_paths) or input_paths.intersection(output_paths):
        raise ValueError("Output paths must be distinct and must not overwrite an input file.")

    print(f"Loading Master EN: {os.path.basename(en_file)}")
    master_ass = parse_ass(en_file, dialogue_styles=styles)

    print(f"Loading Mapping & Proofread data: {os.path.basename(map_pr_file)}")
    with open(args.in_data, "r", encoding="utf-8") as f:
        alignment_data = json.load(f)
    with open(map_pr_file, "r", encoding="utf-8") as f:
        map_pr_data = json.load(f)
    if os.path.abspath(alignment_data.get("en_file", "")) != os.path.abspath(en_file):
        raise ValueError("Alignment data does not belong to the supplied EN file.")
    current_vi = sanitize_source_vi(alignment_data["vi_file"])
    if [cue.source_text for cue in current_vi] != [cue.get("source_text") for cue in alignment_data.get("vie_lines", [])]:
        raise ValueError("VI source changed after sanitize-sync; regenerate alignment data and map.")
    if len(master_ass.dialogue_cues) != len(alignment_data.get("eng_lines", [])):
        raise ValueError("Dialogue style selection differs from sanitize-sync data; use the same --styles value.")
    for cue, saved in zip(master_ass.dialogue_cues, alignment_data["eng_lines"]):
        if cue.text != saved.get("text") or cue.style != saved.get("style"):
            raise ValueError("Master EN changed after sanitize-sync; regenerate alignment data and map.")
    requested_styles = [s.strip() for s in args.styles.split(",")] if args.styles else None
    if requested_styles != alignment_data.get("styles"):
        raise ValueError("The --styles value must exactly match the sanitize-sync run.")
    if alignment_data.get("sync", {}).get("accepted") is False:
        raise ValueError("sanitize-sync did not accept an automatic offset; resolve it with --offset <seconds> or --offset none and regenerate data.")
    dialogue_map = _load_and_validate_map(map_pr_data, alignment_data, en_file, alignment_data["vi_file"])
    warnings = audit_outputs(map_pr_data, alignment_data)
    if warnings:
        print("Semantic review warnings (inspect before accepting output):")
        for warning in warnings:
            print(f"  - {warning}")

    print(f"Exporting to: {out_file}")
    temp_paths = []
    def temp_sibling(final_path: str) -> str:
        directory = os.path.dirname(os.path.abspath(final_path))
        os.makedirs(directory, exist_ok=True)
        fd, temp_path = tempfile.mkstemp(prefix=".softsub-export-", suffix=".ass", dir=directory)
        os.close(fd)
        os.remove(temp_path)
        temp_paths.append(temp_path)
        return temp_path
    staged_out = temp_sibling(out_file)
    staged_dialogue = temp_sibling(dialogue_out) if dialogue_out else None
    try:
        export_aligned_ass(master_ass, dialogue_map, staged_out, staged_dialogue)
        with open(staged_out, "rb") as fp:
            raw = fp.read()
        if not raw.startswith(b"\xef\xbb\xbf"):
            raise ValueError(f"Validation Failed: {staged_out} missing UTF-8 BOM!")
        expected_events = sum(1 for ev in master_ass.all_events if ev.get("type") in ("dialogue", "non_dialogue") or
                              ev.get("raw_line", "").lstrip().startswith(("Dialogue:", "Comment:")))
        output_events = [line for line in raw.decode("utf-8-sig").splitlines()
                         if line.startswith(("Dialogue:", "Comment:"))]
        if len(output_events) != expected_events:
            raise ValueError(f"Event count changed during export: expected {expected_events}, got {len(output_events)}")
        event_format = master_ass.events_format.partition(":")[2].strip()
        expected_fields = len(event_format.split(","))
        for line in output_events:
            if len(line.split(",", max(0, expected_fields - 1))) != expected_fields:
                raise ValueError(f"ASS event field count error: {line}")
        if staged_dialogue:
            with open(staged_dialogue, "rb") as fp:
                dialogue_raw = fp.read()
            dialogue_events = [line for line in dialogue_raw.decode("utf-8-sig").splitlines()
                               if line.startswith(("Dialogue:", "Comment:"))]
            if not dialogue_raw.startswith(b"\xef\xbb\xbf") or len(dialogue_events) != len(master_ass.dialogue_cues):
                raise ValueError("Dialogue-only output failed BOM or cue-count validation.")
            if any(not line.startswith("Dialogue:") for line in dialogue_events):
                raise ValueError("Dialogue-only output contains a non-dialogue event.")
        os.replace(staged_out, out_file)
        if staged_dialogue:
            os.replace(staged_dialogue, dialogue_out)
    finally:
        for temp_path in temp_paths:
            if os.path.exists(temp_path):
                os.remove(temp_path)

    # Report verified output after staged files have been committed.
    with open(out_file, "rb") as fp:
        raw = fp.read()
    
    line_count = 0
    dial_count = 0
    effect_stats: Dict[str, int] = {}
    
    for l in raw.decode("utf-8-sig").splitlines():
        line_count += 1
        if l.startswith("Dialogue:"):
            dial_count += 1
            event_format = master_ass.events_format.partition(":")[2].strip()
            fields = [name.strip().lower() for name in event_format.split(",")]
            parts = l.split(",", max(0, len(fields) - 1))
            if len(parts) != len(fields):
                raise ValueError(f"CSV field error on line: {l}")
            field_map = {name: i for i, name in enumerate(fields)}
            eff = parts[field_map["effect"]].strip() if "effect" in field_map else ""
            effect_stats[eff] = effect_stats.get(eff, 0) + 1

    print(f"Verification 100% Passed (Exit code 0):")
    print(f"  UTF-8 BOM present: Yes")
    print(f"  Total lines in ASS: {line_count}")
    print(f"  Total Dialogue events: {dial_count}")
    print(f"  Effect Classification Statistics:")
    for eff, cnt in effect_stats.items():
        label = eff if eff else "DIRECT (empty)"
        print(f"    - {label}: {cnt} lines")

    if dialogue_out and os.path.exists(dialogue_out):
        print(f"  Dialogue-only ASS exported: {dialogue_out}")

def main():
    parser = argparse.ArgumentParser(description="Universal Softsub Semantic Alignment & Mux Engine")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # 1. Preflight
    p_pref = subparsers.add_parser("preflight", help="Scan folders and list episode pairs and styles")
    p_pref.add_argument("--en-dir", required=True, help="Directory containing Master EN .ass files")
    p_pref.add_argument("--vi-dir", help="Directory containing VI source files (.srt or .ass)")
    p_pref.add_argument("--inspect-styles", action="store_true", help="Inspect style counts in sample episode")

    # 2. Sanitize-sync
    p_sync = subparsers.add_parser("sanitize-sync", help="Clean inputs and detect global temporal offset")
    p_sync.add_argument("--en-file", required=True, help="Master EN ASS file")
    p_sync.add_argument("--vi-file", required=True, help="Source VI file (.srt or .ass)")
    p_sync.add_argument("--out-data", required=True, help="Output path for epXX_data.json")
    p_sync.add_argument("--styles", help="Comma-separated dialogue styles (optional)")
    p_sync.add_argument("--offset", default="auto", help="auto, none, or an explicit offset in seconds added to VI cues")

    # 3. Cluster
    p_clus = subparsers.add_parser("cluster", help="Group temporal candidates for EN-first semantic review")
    p_clus.add_argument("--in-data", required=True, help="Input epXX_data.json path")
    p_clus.add_argument("--out-candidates", required=True, help="Output path for epXX_candidates.json")

    p_review = subparsers.add_parser("review", help="Print a compact EN-first batch with nearby VI text")
    p_review.add_argument("--in-data", required=True, help="sanitize-sync data file")
    p_review.add_argument("--start-en", type=int, default=0, help="First EN ID to show")
    p_review.add_argument("--count", type=int, default=16, help="Number of EN cues to show (1-100)")
    p_review.add_argument("--window", type=float, default=5.0, help="Start-time search window in seconds")
    p_review.add_argument("--vi-neighbors", type=int, default=1, help="Neighboring VI cues to include (0-10)")
    p_review.add_argument("--show-raw", action="store_true", help="Include raw text and formatting tags")

    # 4. Export
    p_exp = subparsers.add_parser("export", help="Export synthesized ASS file")
    p_exp.add_argument("--en-file", required=True, help="Master EN ASS file")
    p_exp.add_argument("--in-data", required=True, help="sanitize-sync data file used to create the map")
    p_exp.add_argument("--map-pr-file", required=True, help="Agent's mapped and proofread JSON file")
    p_exp.add_argument("--out-file", required=True, help="Output path for final .Full.vi.ass")
    p_exp.add_argument("--dialogue-out", help="Optional output path for pure dialogue .ass")
    p_exp.add_argument("--styles", help="Comma-separated dialogue styles")

    p_migrate = subparsers.add_parser("convert-map", help="Convert a legacy mapping into a review-required schema v4 draft")
    p_migrate.add_argument("--in-data", required=True, help="sanitize-sync data file")
    p_migrate.add_argument("--in-map", required=True, help="Legacy map JSON")
    p_migrate.add_argument("--out-map", required=True, help="Schema v4 draft output")

    p_compile = subparsers.add_parser("compile-map", help="Expand reviewed JSONL decisions into a schema v4 map")
    p_compile.add_argument("--in-data", required=True, help="sanitize-sync data file")
    p_compile.add_argument("--in-decisions", required=True, help="One reviewed EN decision per JSON line")
    p_compile.add_argument("--out-map", required=True, help="Validated schema v4 map output")

    args = parser.parse_args()
    if args.command == "preflight":
        cmd_preflight(args)
    elif args.command == "sanitize-sync":
        cmd_sanitize_sync(args)
    elif args.command == "cluster":
        cmd_cluster(args)
    elif args.command == "review":
        cmd_review(args)
    elif args.command == "export":
        cmd_export(args)
    elif args.command == "convert-map":
        cmd_convert_map(args)
    elif args.command == "compile-map":
        cmd_compile_map(args)

if __name__ == "__main__":
    main()
