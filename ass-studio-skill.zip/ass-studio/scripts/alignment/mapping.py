"""Mechanical source-reference checks for EN-first semantic subtitle maps."""

import os
import re
from typing import Any, Dict, List, Tuple


def _words(text: str) -> List[str]:
    return re.findall(r"\w+", text.casefold(), flags=re.UNICODE)


def _source_part(item: Any, sources: List[str], label: str) -> Tuple[int, int, int]:
    if not isinstance(item, dict):
        raise ValueError(f"{label} must be an object with vi_id and optional start/end.")
    vi_id = item.get("vi_id")
    start, end = item.get("start"), item.get("end")
    if type(vi_id) is not int or vi_id < 0 or vi_id >= len(sources):
        raise ValueError(f"{label} has invalid vi_id.")
    if start is None and end is None:
        start, end = 0, len(sources[vi_id])
    elif type(start) is not int or type(end) is not int:
        raise ValueError(f"{label} needs both start and end, or neither for a whole-cue match.")
    source = sources[vi_id]
    if start < 0 or end > len(source) or start >= end or not _words(source[start:end]):
        raise ValueError(f"{label} has an invalid or empty source range.")
    if (start > 0 and source[start - 1].isalnum() and source[start].isalnum()) or (
            end < len(source) and source[end - 1].isalnum() and source[end].isalnum()):
        raise ValueError(f"{label} cuts through a source word.")
    return vi_id, start, end


def validate_map(map_data: Any, data: Dict[str, Any], en_file: str, vi_file: str) -> Dict[int, Dict[str, Any]]:
    if not isinstance(map_data, dict) or map_data.get("schema_version") != 4:
        raise ValueError("Mapping must use schema_version: 4; convert-map creates a review draft.")
    if map_data.get("complete") is not True or map_data.get("review_required"):
        raise ValueError("Mapping is a draft or still requires review.")
    declared = map_data.get("source")
    if not isinstance(declared, dict):
        raise ValueError("Mapping needs source.en_file and source.vi_file.")
    for name, path in (("en_file", en_file), ("vi_file", vi_file)):
        if os.path.abspath(str(declared.get(name, ""))) != os.path.abspath(path):
            raise ValueError(f"Mapping source mismatch for {name}.")

    en_lines, vi_lines = data.get("eng_lines", []), data.get("vie_lines", [])
    if any("source_text" not in cue for cue in vi_lines):
        raise ValueError("VI data lacks source_text; rerun sanitize-sync before mapping.")
    sources = [cue["source_text"] for cue in vi_lines]
    raw = map_data.get("mappings")
    expected = {str(i) for i in range(len(en_lines))}
    if not isinstance(raw, dict) or set(raw) != expected:
        raise ValueError(f"Mappings must contain exactly EN IDs {sorted(expected, key=int)}.")

    result: Dict[int, Dict[str, Any]] = {}
    owners: Dict[int, List[Tuple[int, int, int, int]]] = {i: [] for i in range(len(sources))}
    refs_by_en: Dict[int, List[Tuple[int, int, int]]] = {}
    for key in sorted(expected, key=int):
        en_id = int(key)
        item = raw[key]
        if (not isinstance(item, dict) or not isinstance(item.get("source_parts"), list) or
                not isinstance(item.get("vi_text"), str)):
            raise ValueError(f"Mapping {key} needs source_parts and vi_text.")
        refs = [_source_part(ref, sources, f"Mapping {key} source part {i}")
                for i, ref in enumerate(item["source_parts"])]
        if refs != sorted(refs):
            raise ValueError(f"Mapping {key} source_parts must follow VI source order.")
        refs_by_en[en_id] = refs
        for vi_id, start, end in refs:
            owners[vi_id].append((start, end, en_id, vi_id))

        if not refs:
            if item["vi_text"].strip():
                raise ValueError(f"Missing mapping {key} must have empty vi_text.")
            review = item.get("missing_review")
            checks = ("candidate_window_checked", "concurrent_and_neighboring_en_checked")
            if not isinstance(review, dict) or any(review.get(check) is not True for check in checks):
                raise ValueError(f"Missing mapping {key} needs all three missing_review checks.")
            effect = "missing"
        else:
            if not item["vi_text"].strip():
                raise ValueError(f"Mapping {key} needs non-empty vi_text.")
            review = item.get("semantic_review")
            checks = ("meaning_matches", "coverage_complete", "no_extra_content", "speaker_matches")
            if not isinstance(review, dict) or any(review.get(check) is not True for check in checks):
                raise ValueError(f"Mapping {key} needs all semantic_review checks before export.")
            effect = ""

        repetitions = item.get("repetitions", [])
        if not isinstance(repetitions, list):
            raise ValueError(f"Mapping {key} repetitions must be a list.")
        for rep in repetitions:
            if (not isinstance(rep, dict) or type(rep.get("source_part_index")) is not int or
                    type(rep.get("times")) is not int or rep["times"] < 2 or
                    rep["source_part_index"] < 0 or rep["source_part_index"] >= len(refs)):
                raise ValueError(f"Mapping {key} has invalid repetition provenance.")
            vi_id, start, end = refs[rep["source_part_index"]]
            phrase = _words(sources[vi_id][start:end])
            output = _words(item["vi_text"])
            occurrences = sum(output[i:i + len(phrase)] == phrase for i in range(len(output) - len(phrase) + 1))
            if not phrase or occurrences < rep["times"]:
                raise ValueError(f"Mapping {key} does not contain the declared {rep['times']} repetitions.")
        result[en_id] = {"vi_text": item["vi_text"], "en_ref": en_lines[en_id]["text"],
                         "lead_tag": en_lines[en_id].get("lead_tag", "")}

    for vi_id, spans in owners.items():
        spans.sort()
        for previous, current in zip(spans, spans[1:]):
            if current[0] < previous[1]:
                raise ValueError(f"VI {vi_id} source is assigned more than once (EN {previous[2]} and EN {current[2]} overlap).")

    for en_id, refs in refs_by_en.items():
        if not refs:
            declared_effect = raw[str(en_id)].get("effect")
            if declared_effect is not None and declared_effect != "missing":
                raise ValueError(f"Mapping {en_id} effect must be 'missing' because it has no VI source.")
            result[en_id]["effect"] = "missing"
            continue
        vi_ids = {vi_id for vi_id, _, _ in refs}
        merge = len(vi_ids) > 1
        split = any(len({en_id_owner for _, _, en_id_owner, _ in owners[vi_id]}) > 1 for vi_id in vi_ids)
        effect = "split+merge" if split and merge else "split" if split else "merge" if merge else ""
        result[en_id]["effect"] = effect
        declared_effect = raw[str(en_id)].get("effect")
        if declared_effect is not None and declared_effect != effect:
            raise ValueError(f"Mapping {en_id} effect must be {effect!r} based on selected sources.")
    return result


def audit_outputs(map_data: Dict[str, Any], data: Dict[str, Any]) -> List[str]:
    """Lexical warnings for agent review; they do not claim semantic validation."""
    warnings = []
    entries = map_data["mappings"]
    output_words = {key: _words(item["vi_text"]) for key, item in entries.items()}
    for owner, item in entries.items():
        for part in item["source_parts"]:
            vi_id = part["vi_id"]
            start = part.get("start", 0)
            end = part.get("end", len(data["vie_lines"][vi_id]["source_text"]))
            phrase = _words(data["vie_lines"][vi_id]["source_text"][start:end])
            if len(phrase) < 2:
                continue
            for other_key, words in output_words.items():
                if other_key != owner and any(words[i:i + len(phrase)] == phrase
                                              for i in range(len(words) - len(phrase) + 1)):
                    warnings.append(f"EN {other_key} repeats VI {vi_id} words selected for EN {owner}: {' '.join(phrase)}")
    for key, words in output_words.items():
        for other_key, other_words in output_words.items():
            if int(other_key) <= int(key):
                continue
            shared = {tuple(words[i:i + 4]) for i in range(len(words) - 3)} & {
                tuple(other_words[i:i + 4]) for i in range(len(other_words) - 3)}
            if shared:
                warnings.append(f"EN {key} and EN {other_key} repeat a 4-word phrase: {' '.join(sorted(shared)[0])}")
    return list(dict.fromkeys(warnings))
