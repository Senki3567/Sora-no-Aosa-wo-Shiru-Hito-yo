#!/usr/bin/env python3
"""Inverse-Forward Motion Engine for ASS Studio (Probe, Curve Fit, and Declarative ASS Compiler).

Provides three core subcommands:
  1. probe: Extract quantitative temporal/spatial/photometric signals from a frame manifest + ROI
            (optionally rectifying surface motion via a motion_fit.py track.json) to detect animation
            cadence (1s/2s/3s), phase boundaries, foreground bbox/centroid evolution, alpha/luminance
            progression, and directional edge spread (blur vs directional motion blur).
  2. fit-curve: Fit normalized timing curves (linear, power/ASS accel, cubic-bezier, spring/overshoot,
            step/hold) to measured property series and output ASS multi-segment \t approximations.
  3. compile: Remotion-style Declarative Motion IR compiler that takes timeline phases, surface track,
            parametric curves, and dual clocks (timeline vs content/lyric onsets) and compiles
            deterministically into native multi-segment \t events or Frame-by-Frame (FBF) ASS events
            without ever restarting \t/\fad per frame.
"""
import argparse
from decimal import Decimal, ROUND_FLOOR
import json
import math
from pathlib import Path
import sys


def _numpy():
    try:
        import numpy as np
    except ImportError as exc:
        raise ValueError('motion_studio requires NumPy in this Python interpreter') from exc
    return np


def _imaging():
    try:
        from PIL import Image
    except ImportError as exc:
        raise ValueError('motion_studio probe requires Pillow in this Python interpreter') from exc
    return Image


def _path_from(value, parent):
    p = Path(value)
    return p.resolve() if p.is_absolute() else (parent / p).resolve()


def _preflight(output_path, input_paths, force=False):
    out = Path(output_path).resolve()
    protected = {Path(p).resolve() for p in input_paths if p is not None}
    if out in protected:
        raise ValueError(f'Output would overwrite input: {out}')
    if out.exists() and not force:
        raise ValueError(f'Output already exists: {out}')
    out.parent.mkdir(parents=True, exist_ok=True)
    return out


def _frame_pts_ms(record, ass_offset_ms=0):
    if 'pts_time_text' in record:
        val = Decimal(str(record['pts_time_text'])) * 1000
    elif 'pts_time_s' in record:
        val = Decimal(str(record['pts_time_s'])) * 1000
    elif 'pts_ms' in record:
        val = Decimal(str(record['pts_ms']))
    else:
        val = Decimal(str(record['pts_ms_rounded']))
    if not val.is_finite():
        raise ValueError('PTS must be finite')
    ass_ms = int((val + ass_offset_ms).to_integral_value(rounding=ROUND_FLOOR))
    return float(val), ass_ms


def format_ass_time(ms):
    """Format milliseconds into ASS timestamp H:MM:SS.cc using centisecond floor."""
    if ms < 0:
        ms = 0
    total_cs = int(math.floor(ms / 10.0 + 1e-9))
    cs = total_cs % 100
    total_s = total_cs // 100
    s = total_s % 60
    total_m = total_s // 60
    m = total_m % 60
    h = total_m // 60
    return f'{h}:{m:02d}:{s:02d}.{cs:02d}'


def format_ass_bgr(rgb):
    """Format [R, G, B] (0..255) into ASS &HBBGGRR&."""
    r, g, b = [max(0, min(255, int(round(v)))) for v in rgb]
    return f'&H{b:02X}{g:02X}{r:02X}&'


def format_ass_alpha(alpha_byte):
    """Format ASS alpha byte (0=opaque, 255=transparent) into &HAA&."""
    a = max(0, min(255, int(round(alpha_byte))))
    return f'&H{a:02X}&'


def _warp_patch_to_ref(img_arr, matrix_ref_to_cur, roi):
    """Sample current frame back into reference ROI coordinates using forward ref->cur projection."""
    np = _numpy()
    x0, y0, x1, y1 = roi
    h, w = y1 - y0, x1 - x0
    ys, xs = np.mgrid[y0:y1, x0:x1]
    ones = np.ones_like(xs, dtype=float)
    ref_pts = np.stack([xs, ys, ones], axis=-1).reshape(-1, 3)
    cur_h = ref_pts @ np.asarray(matrix_ref_to_cur, dtype=float).T
    denom = np.where(np.abs(cur_h[:, 2:3]) < 1e-10, 1e-10, cur_h[:, 2:3])
    cur_xy = cur_h[:, :2] / denom
    cx = np.clip(np.rint(cur_xy[:, 0]).astype(int), 0, img_arr.shape[1] - 1)
    cy = np.clip(np.rint(cur_xy[:, 1]).astype(int), 0, img_arr.shape[0] - 1)
    return img_arr[cy, cx].reshape(h, w, -1)


def probe_frames(manifest_path, roi=None, track_path=None, bg_color=None, fg_threshold=25.0, ass_offset_ms=0):
    np = _numpy()
    Image = _imaging()
    manifest_file = Path(manifest_path).resolve()
    data = json.loads(manifest_file.read_text(encoding='utf-8'))
    records = data.get('frames', [])
    if not records:
        raise ValueError('Frame manifest is empty')

    track_by_frame = {}
    if track_path:
        for f_idx, fr in _load_surface_track_map(track_path).items():
            track_by_frame[f_idx] = fr['matrix_reference_to_current']

    samples = []
    prev_patch = None
    native_size = None
    checked_box = None

    for rec in records:
        frame_idx = int(rec['frame_index_0based'])
        pts_ms, ass_ms = _frame_pts_ms(rec, ass_offset_ms)
        img_path = _path_from(rec['file'], manifest_file.parent)
        with Image.open(img_path) as im:
            rgb = im.convert('RGB')
            if native_size is None:
                native_size = rgb.size
                if roi:
                    x0, y0, x1, y1 = roi
                    if not (0 <= x0 < x1 <= native_size[0] and 0 <= y0 < y1 <= native_size[1]):
                        raise ValueError('ROI must be a valid box inside native frame dimensions')
                    checked_box = (int(x0), int(y0), int(x1), int(y1))
                else:
                    checked_box = (0, 0, native_size[0], native_size[1])
            elif rgb.size != native_size:
                raise ValueError('Mixed frame dimensions in manifest')
            arr = np.asarray(rgb, dtype=float)

        x0, y0, x1, y1 = checked_box
        if frame_idx in track_by_frame:
            patch = _warp_patch_to_ref(arr, track_by_frame[frame_idx], checked_box)
            rectified = True
        else:
            patch = arr[y0:y1, x0:x1]
            rectified = False

        if bg_color is not None:
            bg = np.asarray(bg_color, dtype=float)
        else:
            border_pixels = np.concatenate([
                patch[0, :, :], patch[-1, :, :], patch[:, 0, :], patch[:, -1, :]
            ], axis=0)
            bg = np.median(border_pixels, axis=0)

        diff_from_bg = np.linalg.norm(patch - bg, axis=-1)
        fg_mask = diff_from_bg >= fg_threshold
        fg_count = int(fg_mask.sum())

        if fg_count > 0:
            ys, xs = np.nonzero(fg_mask)
            weights = diff_from_bg[ys, xs]
            w_sum = float(weights.sum())
            cx_local = float((xs * weights).sum() / w_sum)
            cy_local = float((ys * weights).sum() / w_sum)
            bbox_native = [
                int(x0 + xs.min()), int(y0 + ys.min()),
                int(x0 + xs.max() + 1), int(y0 + ys.max() + 1)
            ]
            centroid_native = [round(x0 + cx_local, 3), round(y0 + cy_local, 3)]
            q75 = float(np.percentile(weights, 75))
            core_pixels = patch[ys[weights >= q75], xs[weights >= q75]]
            fg_rgb = [round(float(v), 2) for v in np.median(core_pixels, axis=0)]
            visibility_score = round(float(np.clip(q75 / 128.0, 0.0, 1.0)), 4)
        else:
            bbox_native = None
            centroid_native = None
            fg_rgb = None
            visibility_score = 0.0

        luma = 0.2126 * patch[:, :, 0] + 0.7152 * patch[:, :, 1] + 0.0722 * patch[:, :, 2]
        if luma.shape[1] >= 3 and luma.shape[0] >= 3:
            gx = np.abs(luma[:, 2:] - luma[:, :-2]) * 0.5
            gy = np.abs(luma[2:, :] - luma[:-2, :]) * 0.5
            max_gx = float(np.percentile(gx, 99)) if gx.size else 0.0
            max_gy = float(np.percentile(gy, 99)) if gy.size else 0.0
            luma_range = float(np.percentile(luma, 99) - np.percentile(luma, 1))
            edge_spread_x = round(luma_range / max(max_gx, 1.0), 3) if luma_range > 5.0 else 0.0
            edge_spread_y = round(luma_range / max(max_gy, 1.0), 3) if luma_range > 5.0 else 0.0
        else:
            edge_spread_x, edge_spread_y = 0.0, 0.0

        frame_l1_diff = float(np.abs(patch - prev_patch).mean()) if prev_patch is not None else 0.0
        prev_patch = patch

        samples.append({
            'frame_index_0based': frame_idx,
            'pts_ms': round(pts_ms, 3),
            'ass_time_ms': ass_ms,
            'rectified_to_reference': rectified,
            'frame_l1_diff': round(frame_l1_diff, 4),
            'is_hold_frame': bool(frame_l1_diff < 1.2 and len(samples) > 0),
            'fg_pixel_count': fg_count,
            'bbox_native': bbox_native,
            'centroid_native': centroid_native,
            'fg_rgb_estimate': fg_rgb,
            'bg_rgb_estimate': [round(float(v), 2) for v in bg],
            'visibility_progress': visibility_score,
            'edge_spread_px': {'x': edge_spread_x, 'y': edge_spread_y}
        })

    active_changes = [s['frame_index_0based'] for i, s in enumerate(samples) if i == 0 or not s['is_hold_frame']]
    gaps = [b - a for a, b in zip(active_changes[:-1], active_changes[1:])]
    dominant_step = int(round(float(np.median(gaps)))) if gaps else 1
    cadence_label = f'{dominant_step}s' if dominant_step in (1, 2, 3, 4) else f'irregular(median={dominant_step})'

    return {
        'schema': 'ass-studio.motion-probe.v1',
        'manifest': str(manifest_file),
        'native_size': list(native_size),
        'roi': list(checked_box),
        'estimated_cadence': cadence_label,
        'active_change_frames': active_changes,
        'frames': samples
    }


def _cubic_bezier_eval(u, x1, y1, x2, y2):
    np = _numpy()
    u_arr = np.clip(np.asarray(u, dtype=float), 0.0, 1.0)
    s = u_arr.copy()
    for _ in range(12):
        one_s = 1.0 - s
        bx = 3.0 * one_s * one_s * s * x1 + 3.0 * one_s * s * s * x2 + s * s * s - u_arr
        dbx = 3.0 * one_s * one_s * x1 + 6.0 * one_s * s * (x2 - x1) + 3.0 * s * s * (1.0 - x2)
        s = np.clip(s - bx / np.where(np.abs(dbx) < 1e-8, 1e-8, dbx), 0.0, 1.0)
    one_s = 1.0 - s
    return 3.0 * one_s * one_s * s * y1 + 3.0 * one_s * s * s * y2 + s * s * s


def _spring_eval(u, zeta, omega):
    np = _numpy()
    u_arr = np.clip(np.asarray(u, dtype=float), 0.0, 1.0)
    zeta = float(np.clip(zeta, 0.05, 0.99))
    omega = float(max(1.0, omega))
    wd = omega * math.sqrt(1.0 - zeta * zeta)
    raw = 1.0 - np.exp(-zeta * omega * u_arr) * (
        np.cos(wd * u_arr) + (zeta / math.sqrt(1.0 - zeta * zeta)) * np.sin(wd * u_arr)
    )
    end_val = 1.0 - math.exp(-zeta * omega) * (
        math.cos(wd) + (zeta / math.sqrt(1.0 - zeta * zeta)) * math.sin(wd)
    )
    if abs(end_val) < 1e-6:
        end_val = 1.0
    return raw / end_val


def evaluate_easing(u, easing_spec):
    np = _numpy()
    u_scalar = np.isscalar(u)
    u_arr = np.clip(np.asarray(u, dtype=float), 0.0, 1.0)
    if not easing_spec:
        kind = 'linear'
    elif isinstance(easing_spec, str):
        kind = easing_spec
    else:
        kind = easing_spec.get('type', 'linear')

    if kind == 'linear':
        out = u_arr
    elif kind in ('power', 'accel', 'ease-in'):
        gamma = float(easing_spec.get('gamma', easing_spec.get('accel', 1.0))) if isinstance(easing_spec, dict) else 2.0
        out = np.power(u_arr, max(0.05, gamma))
    elif kind == 'ease-out':
        gamma = float(easing_spec.get('gamma', 2.0)) if isinstance(easing_spec, dict) else 2.0
        out = 1.0 - np.power(1.0 - u_arr, max(0.05, gamma))
    elif kind in ('cubic-bezier', 'ease-in-out'):
        if isinstance(easing_spec, dict) and 'control_points' in easing_spec:
            x1, y1, x2, y2 = [float(v) for v in easing_spec['control_points']]
        else:
            x1, y1, x2, y2 = 0.42, 0.0, 0.58, 1.0
        out = _cubic_bezier_eval(u_arr, x1, y1, x2, y2)
    elif kind == 'spring':
        zeta = float(easing_spec.get('damping_ratio', 0.45)) if isinstance(easing_spec, dict) else 0.45
        omega = float(easing_spec.get('angular_freq', 9.5)) if isinstance(easing_spec, dict) else 9.5
        out = _spring_eval(u_arr, zeta, omega)
    elif kind in ('step', 'hold'):
        steps = int(easing_spec.get('steps', 1)) if isinstance(easing_spec, dict) else 1
        if steps <= 1:
            out = np.where(u_arr >= 1.0, 1.0, 0.0)
        else:
            out = np.floor(u_arr * steps) / float(steps)
            out = np.where(u_arr >= 1.0, 1.0, out)
    else:
        raise ValueError(f'Unsupported easing type: {kind}')
    return float(out) if u_scalar else out


def approximate_curve_as_ass_transforms(t0_ms, t1_ms, v0, v1, easing_spec, segments=1):
    np = _numpy()
    if t1_ms <= t0_ms:
        raise ValueError('Curve end time must be greater than start time')
    k = max(1, int(segments))
    bounds = np.linspace(0.0, 1.0, k + 1)
    result = []
    for i in range(k):
        ua, ub = float(bounds[i]), float(bounds[i + 1])
        ta = int(round(t0_ms + ua * (t1_ms - t0_ms)))
        tb = int(round(t0_ms + ub * (t1_ms - t0_ms)))
        va = float(v0 + evaluate_easing(ua, easing_spec) * (v1 - v0))
        vb = float(v0 + evaluate_easing(ub, easing_spec) * (v1 - v0))
        umid = 0.5 * (ua + ub)
        vmid = float(v0 + evaluate_easing(umid, easing_spec) * (v1 - v0))
        dv = vb - va
        if abs(dv) < 1e-6:
            accel = 1.0
        else:
            ratio = (vmid - va) / dv
            if 0.02 < ratio < 0.98:
                accel = round(max(0.1, min(10.0, math.log(ratio) / math.log(0.5))), 3)
            else:
                accel = 1.0
        result.append({
            'segment_index': i,
            'start_ms': ta,
            'end_ms': tb,
            'start_value': round(va, 4),
            'end_value': round(vb, 4),
            'ass_accel': accel
        })
    return result


def fit_curve_series(times_ms, values, max_segments=3):
    np = _numpy()
    t = np.asarray(times_ms, dtype=float)
    y = np.asarray(values, dtype=float)
    if len(t) < 3 or len(t) != len(y):
        raise ValueError('Need at least 3 paired (time_ms, value) observations to fit a curve')
    if not np.all(np.diff(t) > 0):
        raise ValueError('Timestamps must be strictly increasing')

    t0, t1 = float(t[0]), float(t[-1])
    v0, v1 = float(y[0]), float(y[-1])
    span_v = v1 - v0
    if abs(span_v) < 1e-8:
        raise ValueError('Start and end values are identical; split at the peak/extremum first')

    u = (t - t0) / (t1 - t0)
    v_norm = (y - v0) / span_v

    candidates = []
    rmse_lin = float(np.sqrt(np.mean((v_norm - u) ** 2)))
    candidates.append({
        'model': 'linear',
        'easing': {'type': 'linear'},
        'rmse_normalized': round(rmse_lin, 5),
        'complexity_penalty': 0.0,
        'recommended_ass_segments': 1
    })

    gammas = np.logspace(-0.8, 0.8, 81)
    best_gamma, best_power_rmse = 1.0, 999.0
    for g in gammas:
        pred = np.power(u, g)
        err = float(np.sqrt(np.mean((v_norm - pred) ** 2)))
        if err < best_power_rmse:
            best_power_rmse, best_gamma = err, float(g)
    candidates.append({
        'model': 'power',
        'easing': {'type': 'power', 'gamma': round(best_gamma, 3)},
        'rmse_normalized': round(best_power_rmse, 5),
        'complexity_penalty': 0.005,
        'recommended_ass_segments': 1
    })

    best_bz, best_bz_rmse = (0.42, 0.0, 0.58, 1.0), 999.0
    for x1 in (0.2, 0.35, 0.5, 0.65, 0.8):
        for y1 in (0.0, 0.15):
            for x2 in (0.2, 0.35, 0.5, 0.65, 0.8):
                for y2 in (0.85, 1.0):
                    pred = _cubic_bezier_eval(u, x1, y1, x2, y2)
                    err = float(np.sqrt(np.mean((v_norm - pred) ** 2)))
                    if err < best_bz_rmse:
                        best_bz_rmse, best_bz = err, (x1, y1, x2, y2)
    candidates.append({
        'model': 'cubic-bezier',
        'easing': {'type': 'cubic-bezier', 'control_points': [round(c, 3) for c in best_bz]},
        'rmse_normalized': round(best_bz_rmse, 5),
        'complexity_penalty': 0.012,
        'recommended_ass_segments': min(max_segments, 2)
    })

    has_overshoot = bool(np.any(v_norm > 1.03) or np.any(v_norm < -0.03))
    best_sp, best_sp_rmse = (0.45, 9.0), 999.0
    for zeta in np.linspace(0.2, 0.85, 14):
        for omega in np.linspace(5.0, 16.0, 15):
            pred = _spring_eval(u, zeta, omega)
            err = float(np.sqrt(np.mean((v_norm - pred) ** 2)))
            if err < best_sp_rmse:
                best_sp_rmse, best_sp = err, (float(zeta), float(omega))
    candidates.append({
        'model': 'spring',
        'easing': {
            'type': 'spring',
            'damping_ratio': round(best_sp[0], 3),
            'angular_freq': round(best_sp[1], 3)
        },
        'rmse_normalized': round(best_sp_rmse, 5),
        'complexity_penalty': 0.008 if has_overshoot else 0.03,
        'recommended_ass_segments': min(max_segments, 3)
    })

    scored = sorted(candidates, key=lambda c: c['rmse_normalized'] + c['complexity_penalty'])
    winner = scored[0]
    ass_segments = approximate_curve_as_ass_transforms(
        t0, t1, v0, v1, winner['easing'], segments=winner['recommended_ass_segments']
    )

    return {
        'schema': 'ass-studio.curve-fit.v1',
        'time_range_ms': [t0, t1],
        'value_range': [v0, v1],
        'has_overshoot': has_overshoot,
        'selected_model': winner['model'],
        'selected_easing': winner['easing'],
        'rmse_normalized': winner['rmse_normalized'],
        'ass_transform_segments': ass_segments,
        'all_candidates': scored
    }


def evaluate_keyframes(time_ms, keyframes, default_val=0.0):
    if not keyframes:
        return default_val
    kfs = sorted(keyframes, key=lambda k: float(k['time_ms']))
    if time_ms <= float(kfs[0]['time_ms']):
        return kfs[0]['value']
    if time_ms >= float(kfs[-1]['time_ms']):
        return kfs[-1]['value']
    for a, b in zip(kfs[:-1], kfs[1:]):
        ta, tb = float(a['time_ms']), float(b['time_ms'])
        if ta <= time_ms <= tb:
            u = (time_ms - ta) / max(1e-9, tb - ta)
            w = evaluate_easing(u, b.get('easing'))
            va, vb = a['value'], b['value']
            if isinstance(va, list) and isinstance(vb, list):
                return [float(x + w * (y - x)) for x, y in zip(va, vb)]
            return float(va + w * (vb - va))
    return kfs[-1]['value']


def _load_surface_track_map(track_path):
    if not track_path:
        return {}
    data = json.loads(Path(track_path).resolve().read_text(encoding='utf-8'))
    by_frame = {}
    raw_frames = list(data.get('frames', []))
    for seg in data.get('segments', []):
        raw_frames.extend(seg.get('frames', []))
    for fr in raw_frames:
        mat = fr.get('matrix_reference_to_current') or fr.get('matrix_reference_to_frame')
        if not mat:
            continue
        norm = dict(fr)
        norm['matrix_reference_to_current'] = mat
        if 'similarity_parameters' not in norm and ('scale' in norm or 'rotation_clockwise_deg_y_down' in norm):
            norm['similarity_parameters'] = {
                'scale': float(norm.get('scale', 1.0)),
                'rotation_clockwise_deg_y_down': float(norm.get('rotation_clockwise_deg_y_down', 0.0)),
            }
        by_frame[int(fr['frame_index_0based'])] = norm
    return by_frame


def _apply_matrix_2d(matrix, pt):
    x, y = float(pt[0]), float(pt[1])
    m = matrix
    w = m[2][0] * x + m[2][1] * y + m[2][2]
    if abs(w) < 1e-10:
        w = 1e-10
    return ((m[0][0] * x + m[0][1] * y + m[0][2]) / w,
            (m[1][0] * x + m[1][1] * y + m[1][2]) / w)


def _format_override_tag(prop, val):
    if prop == 'fscx':
        return f'\\fscx{val:.2f}'.rstrip('0').rstrip('.')
    if prop == 'fscy':
        return f'\\fscy{val:.2f}'.rstrip('0').rstrip('.')
    if prop == 'frz':
        return f'\\frz{val:.2f}'.rstrip('0').rstrip('.')
    if prop == 'frx':
        return f'\\frx{val:.2f}'.rstrip('0').rstrip('.')
    if prop == 'fry':
        return f'\\fry{val:.2f}'.rstrip('0').rstrip('.')
    if prop == 'fax':
        return f'\\fax{val:.4f}'.rstrip('0').rstrip('.')
    if prop == 'fay':
        return f'\\fay{val:.4f}'.rstrip('0').rstrip('.')
    if prop == 'blur':
        return f'\\blur{max(0.0, val):.2f}'.rstrip('0').rstrip('.')
    if prop == 'bord':
        return f'\\bord{max(0.0, val):.2f}'.rstrip('0').rstrip('.')
    if prop == 'shad':
        return f'\\shad{max(0.0, val):.2f}'.rstrip('0').rstrip('.')
    if prop == 'fsp':
        return f'\\fsp{val:.2f}'.rstrip('0').rstrip('.')
    if prop == 'alpha':
        return f'\\alpha{format_ass_alpha(val)}'
    if prop in ('1a', '2a', '3a', '4a'):
        return f'\\{prop}{format_ass_alpha(val)}'
    if prop in ('c', '1c', '2c', '3c', '4c'):
        tag = 'c' if prop == 'c' else prop
        return f'\\{tag}{format_ass_bgr(val)}'
    return ''


def compile_declarative_spec(spec_path):
    spec_file = Path(spec_path).resolve()
    spec = json.loads(spec_file.read_text(encoding='utf-8'))

    ass_offset_ms = int(spec.get('ass_time_equals_pts_ms_plus', 0))
    track_map = {}
    if spec.get('surface_track'):
        track_map = _load_surface_track_map(_path_from(spec['surface_track'], spec_file.parent))

    frame_timeline = []
    if spec.get('frames_manifest'):
        fm_path = _path_from(spec['frames_manifest'], spec_file.parent)
        fm_data = json.loads(fm_path.read_text(encoding='utf-8'))
        for r in fm_data.get('frames', []):
            pts_ms, ass_ms = _frame_pts_ms(r, ass_offset_ms)
            frame_timeline.append({
                'frame_index_0based': int(r['frame_index_0based']),
                'pts_ms': pts_ms,
                'ass_time_ms': ass_ms
            })
    elif spec.get('fbf_interval_ms'):
        t_start, t_end, step_ms = spec['fbf_interval_ms']
        idx = 0
        cur = float(t_start)
        while cur < float(t_end) - 1e-6:
            frame_timeline.append({
                'frame_index_0based': idx,
                'pts_ms': cur,
                'ass_time_ms': int(math.floor(cur + ass_offset_ms))
            })
            cur += float(step_ms)
            idx += 1

    clock_violations = []
    content_onsets = spec.get('content_clock_onsets', [])
    for item in content_onsets:
        syl_id = item.get('id', 'unnamed')
        sung_start = float(item['sung_start_ms'])
        settled_by = float(item.get('settled_by_ms', sung_start))
        if settled_by > sung_start + 1e-6:
            clock_violations.append({
                'id': syl_id,
                'settled_by_ms': settled_by,
                'sung_start_ms': sung_start,
                'violation_ms': round(settled_by - sung_start, 2)
            })
    if clock_violations and not spec.get('allow_clock_violation', False):
        raise ValueError(f'Dual-clock invariant violated (intro settles after sung_start): {clock_violations}')

    events_out = []
    components = sorted(spec.get('components', []), key=lambda c: int(c.get('layer', 0)))

    for comp in components:
        comp_id = comp['id']
        layer = int(comp.get('layer', 0))
        style = comp.get('style', 'Default')
        actor = comp.get('actor', '')
        effect = comp.get('effect', f'ass-studio:{comp_id}')
        text = comp.get('text', '')
        an = int(comp.get('alignment', 5))
        base_pos = comp.get('reference_pos', [960.0, 540.0])
        mode = comp.get('compilation_mode', spec.get('compilation_mode', 'native_tags'))
        start_ms = float(comp['start_ms'])
        end_ms = float(comp['end_ms'])
        curves = comp.get('curves', {})
        static_tags = comp.get('static_tags', {})

        if mode == 'baked_fbf':
            if not frame_timeline:
                raise ValueError(f'Component {comp_id} uses baked_fbf but no frames_manifest or fbf_interval_ms was supplied')
            comp_frames = [f for f in frame_timeline if start_ms - 1e-6 <= f['pts_ms'] < end_ms - 1e-6]
            if not comp_frames:
                raise ValueError(f'No frames fall inside [{start_ms}, {end_ms}) for component {comp_id}')

            for idx, fr in enumerate(comp_frames):
                t_cur = fr['pts_ms']
                ev_start = fr['ass_time_ms']
                if idx + 1 < len(comp_frames):
                    ev_end = comp_frames[idx + 1]['ass_time_ms']
                else:
                    ev_end = int(math.floor(end_ms + ass_offset_ms))
                if ev_end <= ev_start:
                    ev_end = ev_start + 10

                dx = evaluate_keyframes(t_cur, curves.get('dx', []), 0.0)
                dy = evaluate_keyframes(t_cur, curves.get('dy', []), 0.0)
                local_pt = [base_pos[0] + dx, base_pos[1] + dy]

                f_idx = fr['frame_index_0based']
                track_scale_x, track_scale_y, track_rot = 1.0, 1.0, 0.0
                if f_idx in track_map:
                    tr_entry = track_map[f_idx]
                    screen_pt = _apply_matrix_2d(tr_entry['matrix_reference_to_current'], local_pt)
                    if tr_entry.get('similarity_parameters'):
                        sp = tr_entry['similarity_parameters']
                        track_scale_x = float(sp.get('scale', 1.0))
                        track_scale_y = float(sp.get('scale', 1.0))
                        track_rot = -float(sp.get('rotation_clockwise_deg_y_down', 0.0))
                else:
                    screen_pt = local_pt

                tags = [f'\\an{an}', f'\\pos({screen_pt[0]:.2f},{screen_pt[1]:.2f})']

                for k, v in static_tags.items():
                    t_str = _format_override_tag(k, v)
                    if t_str:
                        tags.append(t_str)

                fscx = evaluate_keyframes(t_cur, curves.get('fscx', []), static_tags.get('fscx', 100.0)) * track_scale_x
                fscy = evaluate_keyframes(t_cur, curves.get('fscy', []), static_tags.get('fscy', 100.0)) * track_scale_y
                frz = evaluate_keyframes(t_cur, curves.get('frz', []), static_tags.get('frz', 0.0)) + track_rot

                if 'fscx' in curves or abs(fscx - 100.0) > 1e-3:
                    tags.append(_format_override_tag('fscx', fscx))
                if 'fscy' in curves or abs(fscy - 100.0) > 1e-3:
                    tags.append(_format_override_tag('fscy', fscy))
                if 'frz' in curves or abs(frz) > 1e-3:
                    tags.append(_format_override_tag('frz', frz))

                for prop in ('frx', 'fry', 'fax', 'fay', 'blur', 'bord', 'shad', 'fsp',
                             'alpha', '1a', '2a', '3a', '4a', 'c', '1c', '2c', '3c', '4c'):
                    if prop in curves:
                        val = evaluate_keyframes(t_cur, curves[prop], static_tags.get(prop, 0.0))
                        tags.append(_format_override_tag(prop, val))

                tag_block = '{' + ''.join(tags) + '}'
                line_str = (
                    f'Dialogue: {layer},{format_ass_time(ev_start)},{format_ass_time(ev_end)},'
                    f'{style},{actor},0,0,0,{effect},{tag_block}{text}'
                )
                events_out.append({
                    'component_id': comp_id,
                    'frame_index_0based': f_idx,
                    'start_ms': ev_start,
                    'end_ms': ev_end,
                    'ass_line': line_str
                })
        else:
            ev_start = int(math.floor(start_ms + ass_offset_ms))
            ev_end = int(math.floor(end_ms + ass_offset_ms))
            tags = [f'\\an{an}']

            dx_kfs = curves.get('dx', [])
            dy_kfs = curves.get('dy', [])
            p_start = [
                base_pos[0] + evaluate_keyframes(start_ms, dx_kfs, 0.0),
                base_pos[1] + evaluate_keyframes(start_ms, dy_kfs, 0.0),
            ]
            p_end = [
                base_pos[0] + evaluate_keyframes(end_ms, dx_kfs, 0.0),
                base_pos[1] + evaluate_keyframes(end_ms, dy_kfs, 0.0),
            ]
            track_frames_sorted = sorted(
                (fr for fr in track_map.values() if start_ms - 1e-6 <= float(fr.get('pts_ms', start_ms)) <= end_ms + 1e-6),
                key=lambda r: int(r['frame_index_0based'])
            ) if track_map else []
            if not track_frames_sorted and track_map:
                track_frames_sorted = [track_map[k] for k in sorted(track_map)]
            if track_frames_sorted:
                p0_screen = _apply_matrix_2d(track_frames_sorted[0]['matrix_reference_to_current'], p_start)
                p1_screen = _apply_matrix_2d(track_frames_sorted[-1]['matrix_reference_to_current'], p_end)
                if math.hypot(p1_screen[0] - p0_screen[0], p1_screen[1] - p0_screen[1]) > 1e-3 or dx_kfs or dy_kfs:
                    t_m0 = 0
                    t_m1 = max(0, int(round(end_ms - start_ms)))
                    tags.append(f'\\move({p0_screen[0]:.2f},{p0_screen[1]:.2f},{p1_screen[0]:.2f},{p1_screen[1]:.2f},{t_m0},{t_m1})')
                else:
                    tags.append(f'\\pos({p0_screen[0]:.2f},{p0_screen[1]:.2f})')
            elif dx_kfs or dy_kfs:
                all_pos_kfs = dx_kfs + dy_kfs
                t_move_0 = int(round(min(float(k['time_ms']) for k in all_pos_kfs) - start_ms))
                t_move_1 = int(round(max(float(k['time_ms']) for k in all_pos_kfs) - start_ms))
                tags.append(f'\\move({p_start[0]:.2f},{p_start[1]:.2f},{p_end[0]:.2f},{p_end[1]:.2f},{max(0, t_move_0)},{max(0, t_move_1)})')
            else:
                tags.append(f'\\pos({base_pos[0]:.2f},{base_pos[1]:.2f})')

            for k, v in static_tags.items():
                t_str = _format_override_tag(k, v)
                if t_str:
                    tags.append(t_str)

            for prop, kfs in curves.items():
                if prop in ('dx', 'dy') or not kfs:
                    continue
                kfs_sorted = sorted(kfs, key=lambda k: float(k['time_ms']))
                init_val = kfs_sorted[0]['value']
                tags.append(_format_override_tag(prop, init_val))

                for a, b in zip(kfs_sorted[:-1], kfs_sorted[1:]):
                    ta, tb = float(a['time_ms']), float(b['time_ms'])
                    va, vb = a['value'], b['value']
                    easing = b.get('easing', {'type': 'linear'})
                    segs = int(b.get('segments', 2 if isinstance(easing, dict) and easing.get('type') in ('cubic-bezier', 'spring') else 1))
                    if isinstance(va, list):
                        rel_a = max(0, int(round(ta - start_ms)))
                        rel_b = max(0, int(round(tb - start_ms)))
                        tags.append(f'\\t({rel_a},{rel_b},{_format_override_tag(prop, vb)})')
                    else:
                        approx = approximate_curve_as_ass_transforms(ta, tb, float(va), float(vb), easing, segments=segs)
                        for seg in approx:
                            rel_a = max(0, int(round(seg['start_ms'] - start_ms)))
                            rel_b = max(0, int(round(seg['end_ms'] - start_ms)))
                            end_tag = _format_override_tag(prop, seg['end_value'])
                            if abs(seg['ass_accel'] - 1.0) > 1e-2:
                                tags.append(f'\\t({rel_a},{rel_b},{seg["ass_accel"]},{end_tag})')
                            else:
                                tags.append(f'\\t({rel_a},{rel_b},{end_tag})')

            tag_block = '{' + ''.join(tags) + '}'
            line_str = (
                f'Dialogue: {layer},{format_ass_time(ev_start)},{format_ass_time(ev_end)},'
                f'{style},{actor},0,0,0,{effect},{tag_block}{text}'
            )
            events_out.append({
                'component_id': comp_id,
                'frame_index_0based': None,
                'start_ms': ev_start,
                'end_ms': ev_end,
                'ass_line': line_str
            })

    return {
        'schema': 'ass-studio.compiled-motion.v1',
        'spec': str(spec_file),
        'event_count': len(events_out),
        'dual_clock_verified': True,
        'events': events_out
    }



def transform_ass_drawing(drawing_str, matrix_3x3, p_scale=1, precision=2):
    """Project an ASS \\p1..\\p4 vector drawing string through a 3x3 homogeneous matrix."""
    import re
    scale = float(1 << (max(1, int(p_scale)) - 1))
    tokens = re.findall(r"[mnlbspc]|-?\d+(?:\.\d+)?", drawing_str)
    out = []
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if tok in ("m", "n", "l", "b", "s", "p", "c"):
            out.append(tok)
            i += 1
            continue
        if i + 1 >= len(tokens):
            raise ValueError("Odd number of coordinates in ASS drawing command")
        x_draw = float(tokens[i]) / scale
        y_draw = float(tokens[i + 1]) / scale
        xp, yp = _apply_matrix_2d(matrix_3x3, (x_draw, y_draw))
        xf = xp * scale
        yf = yp * scale
        fmt = f"{{:.{precision}f}}"
        xs = fmt.format(xf).rstrip("0").rstrip(".") if precision > 0 else str(int(round(xf)))
        ys = fmt.format(yf).rstrip("0").rstrip(".") if precision > 0 else str(int(round(yf)))
        out.extend([xs or "0", ys or "0"])
        i += 2
    return " ".join(out)



# ---------------------------------------------------------------------------
# 4. COMMUNITY AUTOMATION ALGORITHMS (quad-to-ass3d, text-to-shape, clip-gradient)
# ---------------------------------------------------------------------------

def solve_ass_perspective_quad(quad_xy, ref_w=200.0, ref_h=100.0, org_xy=None, camera_dist=312.5):
    r"""Decompose a 4-corner planar quad [TL, TR, BR, BL] into exact native ASS 3D tags
    (\an7, \pos, \org, \fscx, \fscy, \fax, \frx, \fry, \frz) following arch.Perspective / libass math.
    """
    np = _numpy()
    q = np.asarray(quad_xy, dtype=float)
    if q.shape != (4, 2):
        raise ValueError("quad_xy must be 4 corners [[x0,y0], [x1,y1], [x2,y2], [x3,y3]] in order TL, TR, BR, BL")
    if ref_w <= 0 or ref_h <= 0:
        raise ValueError("ref_w and ref_h must be positive")
    if org_xy is None:
        ox, oy = float(q[:, 0].mean()), float(q[:, 1].mean())
    else:
        ox, oy = float(org_xy[0]), float(org_xy[1])

    d = float(camera_dist)
    qr = q - np.array([ox, oy])

    V = np.c_[qr, np.full(4, d)]
    A = np.column_stack([V[1], -V[2], V[3]])
    if abs(np.linalg.det(A)) < 1e-9:
        raise ValueError("Degenerate or non-convex quad; cannot solve 3D perspective plane")
    z1, z2, z3 = np.linalg.solve(A, V[0])
    z_raw = np.array([1.0, z1, z2, z3], dtype=float)
    if np.any(z_raw <= 0.05):
        raise ValueError("Quad crosses camera horizon (z <= 0); use transform-shape FBF instead")

    P_cam = z_raw[:, None] * V
    Eu_raw = P_cam[1] - P_cam[0]
    Ev_raw = P_cam[3] - P_cam[0]
    normal = np.cross(Eu_raw, Ev_raw)
    n_len = float(np.linalg.norm(normal))
    if n_len < 1e-9:
        raise ValueError("Collinear quad edges")
    normal /= n_len

    denom = float(np.dot(normal, P_cam[0]))
    if abs(denom) < 1e-9:
        raise ValueError("Plane passes through camera focal point")
    scale_s = (normal[2] * d) / denom
    z = z_raw * scale_s

    P = np.column_stack([z * qr[:, 0], z * qr[:, 1], (z - 1.0) * d])
    Eu = P[1] - P[0]
    Ev = P[3] - P[0]

    e_x = Eu / float(np.linalg.norm(Eu))
    e_y = np.cross(normal, e_x)
    e_y /= float(np.linalg.norm(e_y))
    R = np.column_stack([e_x, e_y, normal])

    sx = -float(np.clip(R[1, 2], -1.0, 1.0))
    ax = math.asin(sx)
    cx = math.cos(ax)
    if abs(cx) > 1e-6:
        ay = math.atan2(R[0, 2], R[2, 2])
        az = math.atan2(R[1, 0], R[1, 1])
    else:
        ay = 0.0
        az = math.atan2(-R[0, 1], R[0, 0])

    frx = -math.degrees(ax)
    fry = -math.degrees(ay)
    frz = -math.degrees(az)

    p0_local = R.T @ P[0]
    eu_local = R.T @ Eu
    ev_local = R.T @ Ev

    pos_x = ox + float(p0_local[0])
    pos_y = oy + float(p0_local[1])

    sx_scale = float(eu_local[0]) / float(ref_w)
    sy_scale = float(ev_local[1]) / float(ref_h)
    fax = (float(ev_local[0]) / float(ref_h)) / sx_scale if abs(sx_scale) > 1e-9 else 0.0

    tag_str = (
        f"\\an7\\pos({pos_x:.2f},{pos_y:.2f})\\org({ox:.2f},{oy:.2f})"
        f"\\fscx{sx_scale * 100.0:.2f}\\fscy{sy_scale * 100.0:.2f}"
        f"\\fax{fax:.4f}\\frx{frx:.2f}\\fry{fry:.2f}\\frz{frz:.2f}"
    )
    return {
        "schema": "ass-studio.perspective-quad.v1",
        "pos": [round(pos_x, 3), round(pos_y, 3)],
        "org": [round(ox, 3), round(oy, 3)],
        "fscx": round(sx_scale * 100.0, 3),
        "fscy": round(sy_scale * 100.0, 3),
        "fax": round(fax, 5),
        "frx": round(frx, 3),
        "fry": round(fry, 3),
        "frz": round(frz, 3),
        "camera_distance": d,
        "z_plane_residual": round(float(abs(p0_local[2])), 6),
        "ass_tag_block": "{" + tag_str + "}"
    }


def text_to_ass_shape(text, font_path, fontsize=64.0, spacing=0.0, p_scale=1, precision=2):
    """Convert a text string (including Vietnamese diacritics) into an exact ASS \\p1..\\p4 vector drawing
    using fontTools glyph outlines and TrueType quadratic-to-cubic Bezier degree elevation (Yutils / ILL equivalent).
    """
    try:
        from fontTools.ttLib import TTFont, TTCollection
        from fontTools.pens.basePen import BasePen
    except ImportError as exc:
        raise ValueError("text-to-shape requires fontTools in this Python interpreter") from exc

    fpath = Path(font_path).resolve()
    if fpath.suffix.casefold() == ".ttc":
        tt = TTCollection(str(fpath)).fonts[0]
    else:
        tt = TTFont(str(fpath))

    gset = tt.getGlyphSet()
    cmap = tt.getBestCmap()
    if not cmap:
        raise ValueError(f"No Unicode cmap table found in font: {fpath}")
    upm = float(tt["head"].unitsPerEm)
    ascender = float(tt["hhea"].ascent) if "hhea" in tt else upm * 0.8
    p_mult = float(1 << (max(1, int(p_scale)) - 1))
    scale = (float(fontsize) / upm) * p_mult
    baseline_y = (ascender / upm) * float(fontsize) * p_mult

    class _AssPen(BasePen):
        def __init__(self, gs, ox, oy):
            super().__init__(gs)
            self.ox = ox
            self.oy = oy
            self.cmds = []
            self._curr = (0.0, 0.0)

        def _fmt(self, x, y):
            sx = self.ox + x * scale
            sy = self.oy - y * scale
            if precision <= 0:
                return f"{int(round(sx))} {int(round(sy))}"
            fmt = f"{{:.{precision}f}}"
            xs = fmt.format(sx).rstrip("0").rstrip(".") or "0"
            ys = fmt.format(sy).rstrip("0").rstrip(".") or "0"
            return f"{xs} {ys}"

        def _moveTo(self, p0):
            self.cmds.append(f"m {self._fmt(p0[0], p0[1])}")
            self._curr = p0

        def _lineTo(self, p1):
            self.cmds.append(f"l {self._fmt(p1[0], p1[1])}")
            self._curr = p1

        def _curveToOne(self, p1, p2, p3):
            self.cmds.append(f"b {self._fmt(p1[0], p1[1])} {self._fmt(p2[0], p2[1])} {self._fmt(p3[0], p3[1])}")
            self._curr = p3

        def _qCurveToOne(self, p1, p2):
            p0 = self._curr
            c1 = (p0[0] + (2.0 / 3.0) * (p1[0] - p0[0]), p0[1] + (2.0 / 3.0) * (p1[1] - p0[1]))
            c2 = (p2[0] + (2.0 / 3.0) * (p1[0] - p2[0]), p2[1] + (2.0 / 3.0) * (p1[1] - p2[1]))
            self._curveToOne(c1, c2, p2)

        def _closePath(self):
            self.cmds.append("c")

    cursor_x = 0.0
    all_cmds = []
    missing_chars = []
    hmtx = tt["hmtx"].metrics if "hmtx" in tt else {}

    for ch in text:
        cp = ord(ch)
        if cp not in cmap:
            missing_chars.append(ch)
            continue
        gname = cmap[cp]
        pen = _AssPen(gset, cursor_x, baseline_y)
        gset[gname].draw(pen)
        if pen.cmds:
            all_cmds.extend(pen.cmds)
        adv_units = float(hmtx.get(gname, (upm * 0.5, 0))[0])
        cursor_x += adv_units * scale + float(spacing) * p_mult

    drawing_str = " ".join(all_cmds)
    return {
        "schema": "ass-studio.text-to-shape.v1",
        "text": text,
        "font": str(fpath),
        "fontsize": fontsize,
        "p_scale": p_scale,
        "advance_width_px": round(cursor_x / p_mult, 3),
        "missing_glyphs": missing_chars,
        "drawing": drawing_str,
        "ass_snippet": f"{{\\an7\\p{p_scale}}}{drawing_str}{{\\p0}}"
    }


def generate_clip_gradient(spec):
    """Generate rectangular strip-sliced ASS gradient lines (Gradient Everything / Colorize equivalent)
    with optional automatic border/shadow layer separation to prevent libass border-striping artifacts.
    """
    axis = spec.get("axis", "vertical").lower()
    x0, y0, x1, y1 = [int(round(float(v))) for v in spec["bounds"]]
    if x1 <= x0 or y1 <= y0:
        raise ValueError("Gradient bounds [x0, y0, x1, y1] must have x1 > x0 and y1 > y0")
    step_px = max(1, int(spec.get("step_px", 2)))
    accel = float(spec.get("accel", 1.0))
    colors = spec.get("colors_rgb", [[255, 255, 255], [0, 0, 0]])
    if len(colors) < 2:
        raise ValueError("colors_rgb must contain at least 2 RGB stops")

    layer = int(spec.get("layer", 0))
    style = spec.get("style", "Default")
    start_str = format_ass_time(float(spec.get("start_ms", 0)))
    end_str = format_ass_time(float(spec.get("end_ms", 5000)))
    pos = spec.get("pos", [x0, y0])
    an = int(spec.get("alignment", 7))
    text = spec.get("text", "")
    extra_tags = spec.get("extra_tags", "")
    separate_border = bool(spec.get("separate_border_layer", False))

    lines_out = []
    fill_layer = layer
    if separate_border:
        # Emit a single unclipped border/shadow underlay with transparent fill (\1a&HFF&)
        bg_tags = f"{{\\an{an}\\pos({pos[0]},{pos[1]})\\1a&HFF&{extra_tags}}}"
        lines_out.append(
            f"Dialogue: {layer},{start_str},{end_str},{style},,0,0,0,ass-studio:grad-border,{bg_tags}{text}"
        )
        fill_layer = layer + 1

    span = (y1 - y0) if axis == "vertical" else (x1 - x0)
    strips = []
    cur = 0
    while cur < span:
        nxt = min(span, cur + step_px)
        u_linear = ((cur + nxt) * 0.5) / float(span)
        u = math.pow(max(0.0, min(1.0, u_linear)), max(0.05, accel))
        # Multi-stop interpolation
        scaled_u = u * (len(colors) - 1)
        seg_idx = min(len(colors) - 2, int(math.floor(scaled_u)))
        local_u = scaled_u - seg_idx
        c_a, c_b = colors[seg_idx], colors[seg_idx + 1]
        rgb = [c_a[k] + local_u * (c_b[k] - c_a[k]) for k in range(3)]
        bgr_tag = format_ass_bgr(rgb)

        if axis == "vertical":
            clip_box = (x0, y0 + cur, x1, y0 + nxt)
        else:
            clip_box = (x0 + cur, y0, x0 + nxt, y1)

        border_suppression = "\\bord0\\shad0" if separate_border else ""
        tag_str = (
            f"{{\\an{an}\\pos({pos[0]},{pos[1]}){border_suppression}"
            f"\\1c{bgr_tag}\\clip({clip_box[0]},{clip_box[1]},{clip_box[2]},{clip_box[3]}){extra_tags}}}"
        )
        line = f"Dialogue: {fill_layer},{start_str},{end_str},{style},,0,0,0,ass-studio:grad-strip,{tag_str}{text}"
        lines_out.append(line)
        strips.append({"clip": list(clip_box), "rgb": [round(v, 1) for v in rgb], "ass_bgr": bgr_tag})
        cur = nxt

    return {
        "schema": "ass-studio.clip-gradient.v1",
        "axis": axis,
        "strip_count": len(strips),
        "total_events": len(lines_out),
        "separate_border_layer": separate_border,
        "lines": lines_out
    }



# ---------------------------------------------------------------------------
# 5. ADVANCED MOTION & TRANSFORM ENGINES
# (Extrapolate Tracking, Wobble/Jitter, Wave, Path Following, Envelope Warping)
# ---------------------------------------------------------------------------

def extrapolate_tracking_series(frames, values, count_extra, direction="end", max_degree=4, circular_center=None):
    """Extrapolate motion tracking values (PhosCity Extrapolate Tracking equivalent)
    using polynomial regression with leave-one-out cross validation or polar extrapolation.
    """
    np = _numpy()
    fr = np.asarray(frames, dtype=float)
    val = np.asarray(values, dtype=float)
    if len(fr) < 3 or len(fr) != len(val):
        raise ValueError("Need at least 3 paired (frame, value) observations to extrapolate")
    n_extra = max(1, int(count_extra))
    step = float(np.median(np.diff(fr))) if len(fr) > 1 else 1.0

    if direction == "start":
        target_frames = np.array([fr[0] - (n_extra - i) * step for i in range(n_extra)])
    else:
        target_frames = np.array([fr[-1] + (i + 1) * step for i in range(n_extra)])

    deg_limit = min(max_degree, len(fr) - 2)
    if deg_limit < 1:
        deg_limit = 1

    best_deg, best_score = 1, 999999.0
    for deg in range(1, deg_limit + 1):
        errors = []
        for fold in range(len(fr)):
            train_idx = [i for i in range(len(fr)) if i != fold]
            try:
                poly = np.polyfit(fr[train_idx], val[train_idx], deg)
                pred = np.polyval(poly, fr[fold])
                errors.append(float((pred - val[fold]) ** 2))
            except (np.linalg.LinAlgError, ValueError):
                continue
        if errors:
            score = float(np.mean(errors))
            if best_score < 1e-8:
                break
            if score < best_score * 0.95:
                best_score, best_deg = score, deg

    poly_final = np.polyfit(fr, val, best_deg)
    extrapolated_vals = np.polyval(poly_final, target_frames)

    return {
        "direction": direction,
        "selected_polynomial_degree": best_deg,
        "cross_validation_mse": round(best_score, 5),
        "target_frames": [round(float(f), 2) for f in target_frames],
        "extrapolated_values": [round(float(v), 3) for v in extrapolated_vals]
    }


def generate_wobble_animation(spec):
    """Generate organic shake, harmonic oscillation, or gelatin jiggle (PhosCity Wobble equivalent)
    as either per-frame FBF lines or per-character animated events.
    """
    mode = spec.get("mode", "damped_harmonic")
    total_frames = max(1, int(spec.get("frames", 24)))
    fps = float(spec.get("fps", 24.0))
    base_pos = [float(v) for v in spec.get("pos", [960.0, 540.0])]
    amp_x = float(spec.get("amplitude_x", 12.0))
    amp_y = float(spec.get("amplitude_y", 8.0))
    amp_rot = float(spec.get("amplitude_rot_deg", 5.0))
    freq_hz = float(spec.get("freq_hz", 4.0))
    decay = float(spec.get("decay", 2.0))
    seed = int(spec.get("seed", 42))

    rng = _numpy().random.RandomState(seed)
    records = []
    omega = 2.0 * math.pi * freq_hz

    for f_idx in range(total_frames):
        t_s = f_idx / fps
        env = math.exp(-decay * t_s)
        if mode == "damped_harmonic":
            dx = amp_x * env * math.sin(omega * t_s)
            dy = amp_y * env * math.cos(omega * t_s * 1.3)
            drot = amp_rot * env * math.sin(omega * t_s * 0.8)
        elif mode == "camera_shake":
            # Smoothed random walk / low-pass filtered jitter
            dx = amp_x * env * float(rng.normal(0, 0.6))
            dy = amp_y * env * float(rng.normal(0, 0.6))
            drot = amp_rot * env * float(rng.normal(0, 0.5))
        else:
            raise ValueError(f"Unsupported wobble mode: {mode}")

        cur_pos = [round(base_pos[0] + dx, 2), round(base_pos[1] + dy, 2)]
        records.append({
            "frame_index": f_idx,
            "time_s": round(t_s, 4),
            "pos": cur_pos,
            "frz": round(drot, 2),
            "ass_tag_snippet": f"\\pos({cur_pos[0]},{cur_pos[1]})\\frz{drot:.2f}"
        })

    return {
        "schema": "ass-studio.wobble.v1",
        "mode": mode,
        "frames": records
    }


def generate_wave_characters(spec):
    """Generate traveling sinusoidal wave motion across text characters (PhosCity Wave equivalent)
    with automatic tangential rotation (\frz) matching the instantaneous wave slope.
    """
    text = spec["text"]
    base_pos = [float(v) for v in spec.get("pos", [400.0, 500.0])]
    amp_y = float(spec.get("amplitude_y", 16.0))
    wavelength_px = float(spec.get("wavelength_px", 240.0))
    freq_hz = float(spec.get("freq_hz", 2.0))
    time_s = float(spec.get("time_s", 0.0))
    char_advance_px = float(spec.get("char_advance_px", 36.0))
    an = int(spec.get("alignment", 5))

    k = (2.0 * math.pi) / max(1.0, wavelength_px)
    omega = 2.0 * math.pi * freq_hz
    chars_out = []

    for idx, ch in enumerate(text):
        x_char = base_pos[0] + idx * char_advance_px
        phase = k * (idx * char_advance_px) - omega * time_s
        y_char = base_pos[1] + amp_y * math.sin(phase)
        slope = amp_y * k * math.cos(phase)
        frz_deg = math.degrees(math.atan2(slope, 1.0))
        chars_out.append({
            "char": ch,
            "char_index": idx,
            "pos": [round(x_char, 2), round(y_char, 2)],
            "frz": round(frz_deg, 2),
            "ass_tag_block": f"{{\\an{an}\\pos({x_char:.2f},{y_char:.2f})\\frz{frz_deg:.2f}}}"
        })

    return {
        "schema": "ass-studio.wave.v1",
        "text": text,
        "time_s": time_s,
        "characters": chars_out
    }


def parse_ass_drawing_commands(drawing_str):
    """Parse an ASS drawing string into structured contours of commands."""
    import re
    tokens = re.findall(r"[mnlbspc]|-?\d+(?:\.\d+)?", drawing_str)
    commands = []
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if tok in ("m", "n", "l"):
            if i + 2 >= len(tokens):
                break
            commands.append({"cmd": tok, "pts": [[float(tokens[i + 1]), float(tokens[i + 2])]]})
            i += 3
        elif tok == "b":
            if i + 6 >= len(tokens):
                break
            commands.append({"cmd": "b", "pts": [
                [float(tokens[i + 1]), float(tokens[i + 2])],
                [float(tokens[i + 3]), float(tokens[i + 4])],
                [float(tokens[i + 5]), float(tokens[i + 6])]
            ]})
            i += 7
        elif tok in ("s", "p", "c"):
            commands.append({"cmd": tok, "pts": []})
            i += 1
        else:
            i += 1
    return commands


def evaluate_spline_path(path_drawing_str, samples_count=100):
    """Build an arc-length parameterized table from an ASS vector path for spline path following."""
    np = _numpy()
    cmds = parse_ass_drawing_commands(path_drawing_str)
    curr = None
    polyline = []
    tangents = []

    for c in cmds:
        if c["cmd"] in ("m", "n"):
            curr = np.array(c["pts"][0])
            if not polyline:
                polyline.append(curr.copy())
                tangents.append(np.array([1.0, 0.0]))
        elif c["cmd"] == "l":
            p_next = np.array(c["pts"][0])
            tang = p_next - curr if curr is not None else np.array([1.0, 0.0])
            polyline.append(p_next.copy())
            tangents.append(tang.copy())
            curr = p_next.copy()
        elif c["cmd"] == "b":
            p0 = curr.copy() if curr is not None else np.array([0.0, 0.0])
            p1 = np.array(c["pts"][0])
            p2 = np.array(c["pts"][1])
            p3 = np.array(c["pts"][2])
            for t in np.linspace(0.01, 1.0, 100):
                pt = (1-t)**3 * p0 + 3*(1-t)**2*t * p1 + 3*(1-t)*t**2 * p2 + t**3 * p3
                deriv = 3*(1-t)**2 * (p1 - p0) + 6*(1-t)*t * (p2 - p1) + 3*t**2 * (p3 - p2)
                polyline.append(pt)
                tangents.append(deriv)
            curr = p3.copy()

    poly = np.array(polyline)
    diffs = np.diff(poly, axis=0)
    seg_lens = np.linalg.norm(diffs, axis=1)
    cum_lens = np.r_[0, np.cumsum(seg_lens)]
    total_length = float(cum_lens[-1]) if len(cum_lens) else 0.0

    return {
        "polyline": poly,
        "tangents": np.array(tangents),
        "cum_lens": cum_lens,
        "total_length": total_length
    }


def sample_path_at_distance(path_data, distance_px):
    """Sample position [x, y] and tangential angle (\\frz) at an exact arc-length distance."""
    np = _numpy()
    poly = path_data["polyline"]
    tangents = path_data["tangents"]
    cum = path_data["cum_lens"]
    total = path_data["total_length"]
    if total <= 1e-6:
        return [0.0, 0.0], 0.0

    d = float(np.clip(distance_px, 0.0, total))
    idx = int(np.searchsorted(cum, d))
    if idx <= 0:
        pt = poly[0]
        tangent = tangents[0]
    elif idx >= len(cum):
        pt = poly[-1]
        tangent = tangents[-1]
    else:
        d0, d1 = cum[idx - 1], cum[idx]
        u = (d - d0) / max(1e-9, d1 - d0)
        pt = poly[idx - 1] + u * (poly[idx] - poly[idx - 1])
        tangent = (1.0 - u) * tangents[idx - 1] + u * tangents[idx]

    frz = math.degrees(math.atan2(float(tangent[1]), float(tangent[0])))
    return [round(float(pt[0]), 2), round(float(pt[1]), 2)], round(frz, 2)


def animate_along_path(spec):
    """Animate an object or text sequence along an ASS vector spline path with auto-aligned \\frz."""
    path_str = spec["path"]
    path_data = evaluate_spline_path(path_str)
    total_len = path_data["total_length"]
    keyframes = spec.get("keyframes", [{"time_ms": 0, "progress": 0.0}, {"time_ms": 2000, "progress": 1.0}])
    times_ms = spec.get("sample_times_ms", [int(k["time_ms"]) for k in keyframes])

    frames_out = []
    for t_ms in times_ms:
        u_prog = float(evaluate_keyframes(t_ms, [{"time_ms": k["time_ms"], "value": k["progress"], "easing": k.get("easing")} for k in keyframes]))
        dist = u_prog * total_len
        pos, frz = sample_path_at_distance(path_data, dist)
        frames_out.append({
            "time_ms": t_ms,
            "progress": round(u_prog, 4),
            "distance_px": round(dist, 2),
            "pos": pos,
            "frz": frz,
            "ass_tag_snippet": f"\\pos({pos[0]},{pos[1]})\\frz{frz:.2f}"
        })

    return {
        "schema": "ass-studio.path-motion.v1",
        "total_path_length_px": round(total_len, 2),
        "trajectory": frames_out
    }


def deform_drawing_envelope(drawing_str, grid_4x4, p_scale=1, precision=2):
    """Deform an ASS \\p1..\\p4 vector drawing using a 4x4 bicubic Bezier / Coons patch mesh
    (ILL.EnvelopeDistort / Shapery equivalent for banners, cylinder wraps, and perspective bulges).
    """
    np = _numpy()
    grid = np.asarray(grid_4x4, dtype=float)
    if grid.shape != (4, 4, 2):
        raise ValueError("grid_4x4 must have shape (4, 4, 2) defining 16 control points")

    scale = float(1 << (max(1, int(p_scale)) - 1))
    cmds = parse_ass_drawing_commands(drawing_str)
    all_coords = []
    for c in cmds:
        for pt in c["pts"]:
            all_coords.append(pt)
    if not all_coords:
        return drawing_str
    coords_arr = np.array(all_coords) / scale
    min_x, min_y = coords_arr[:, 0].min(), coords_arr[:, 1].min()
    max_x, max_y = coords_arr[:, 0].max(), coords_arr[:, 1].max()
    span_x = max(1e-6, max_x - min_x)
    span_y = max(1e-6, max_y - min_y)

    def _bernstein_3(t_val):
        t = float(np.clip(t_val, 0.0, 1.0))
        return np.array([(1 - t)**3, 3 * (1 - t)**2 * t, 3 * (1 - t) * t**2, t**3])

    def _warp_pt(pt):
        u = (pt[0] / scale - min_x) / span_x
        v = (pt[1] / scale - min_y) / span_y
        bu = _bernstein_3(u)
        bv = _bernstein_3(v)
        warped = np.einsum("i,j,ijk->k", bu, bv, grid) * scale
        fmt = f"{{:.{precision}f}}"
        xs = fmt.format(warped[0]).rstrip("0").rstrip(".") or "0"
        ys = fmt.format(warped[1]).rstrip("0").rstrip(".") or "0"
        return f"{xs} {ys}"

    out_tokens = []
    for c in cmds:
        out_tokens.append(c["cmd"])
        for pt in c["pts"]:
            out_tokens.append(_warp_pt(pt))

    return " ".join(out_tokens)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)

    p_probe = sub.add_parser('probe', help='Extract quantitative motion/cadence/photometric signals from raw frames')
    p_probe.add_argument('manifest', help='Path to video_frames.py frames.json')
    p_probe.add_argument('--roi', nargs=4, type=int, metavar=('X0', 'Y0', 'X1', 'Y1'), help='Native pixel ROI box')
    p_probe.add_argument('--track', help='Optional motion_fit.py track.json to rectify surface motion')
    p_probe.add_argument('--bg-color', nargs=3, type=float, metavar=('R', 'G', 'B'), help='Explicit background RGB')
    p_probe.add_argument('--fg-threshold', type=float, default=25.0, help='RGB distance threshold for foreground')
    p_probe.add_argument('--ass-offset-ms', type=int, default=0, help='Offset added to PTS for ASS clock')
    p_probe.add_argument('--output', required=True, help='Output JSON path')
    p_probe.add_argument('--force', action='store_true', help='Overwrite existing output')

    p_fit = sub.add_parser('fit-curve', help='Fit normalized timing/easing curve and ASS \\t segments to measured series')
    p_fit.add_argument('input_json', help='JSON file with {"times_ms": [...], "values": [...]}')
    p_fit.add_argument('--max-segments', type=int, default=3, help='Max ASS \\t segments for S-curve/spring')
    p_fit.add_argument('--output', required=True, help='Output JSON report path')
    p_fit.add_argument('--force', action='store_true', help='Overwrite existing output')

    p_comp = sub.add_parser('compile', help='Compile declarative motion spec to ASS events')
    p_comp.add_argument('spec_json', help='Declarative motion spec JSON')
    p_comp.add_argument('--output-ass', help='Optional file to write generated ASS Dialogue lines')
    p_comp.add_argument('--output-report', required=True, help='Output compilation report JSON')
    p_comp.add_argument('--force', action='store_true', help='Overwrite existing outputs')

    p_shape = sub.add_parser('transform-shape', help='Project ASS \\p1..\\p4 vector drawing or \\clip path through a 3x3 matrix')
    p_shape.add_argument('--drawing', required=True, help='ASS drawing string (e.g. "m 0 0 l 100 0 100 50 0 50 c")')
    p_shape.add_argument('--matrix', nargs=9, type=float, required=True, help='Row-major 3x3 homogeneous matrix')
    p_shape.add_argument('--p-scale', type=int, default=1, help='ASS \\pN scale exponent (default 1)')
    p_shape.add_argument('--precision', type=int, default=2, help='Decimal precision for output coordinates')
    p_shape.add_argument('--output', help='Optional output JSON path')

    p_quad = sub.add_parser('quad-to-ass3d', help='Decompose a 4-corner planar quad [TL, TR, BR, BL] into native ASS 3D perspective tags')
    p_quad.add_argument('--quad', nargs=8, type=float, required=True, metavar=('TLX', 'TLY', 'TRX', 'TRY', 'BRX', 'BRY', 'BLX', 'BLY'))
    p_quad.add_argument('--ref-size', nargs=2, type=float, default=[200.0, 100.0], metavar=('W', 'H'))
    p_quad.add_argument('--org', nargs=2, type=float, metavar=('OX', 'OY'))
    p_quad.add_argument('--camera-dist', type=float, default=312.5)
    p_quad.add_argument('--output', help='Optional output JSON path')

    p_t2s = sub.add_parser('text-to-shape', help='Convert text + font into exact ASS \\p1 vector drawing paths')
    p_t2s.add_argument('--text', required=True)
    p_t2s.add_argument('--font', required=True, help='Path to .ttf/.otf/.ttc font file')
    p_t2s.add_argument('--fontsize', type=float, default=64.0)
    p_t2s.add_argument('--spacing', type=float, default=0.0)
    p_t2s.add_argument('--p-scale', type=int, default=1)
    p_t2s.add_argument('--precision', type=int, default=2)
    p_t2s.add_argument('--output', help='Optional output JSON path')

    p_grad = sub.add_parser('clip-gradient', help='Generate rectangular strip-clip gradient ASS lines')
    p_grad.add_argument('spec_json', help='Gradient specification JSON')
    p_grad.add_argument('--output-ass', help='Optional output ASS lines file')
    p_grad.add_argument('--force', action='store_true')

    p_extra = sub.add_parser('extrapolate-track', help='Extrapolate tracking data forwards/backwards using k-fold cross-validated polynomials')
    p_extra.add_argument('series_json', help='JSON with {"frames": [...], "values": [...]}')
    p_extra.add_argument('--count', '--count-extra', dest='count', type=int, default=10, help='Number of extra frames to extrapolate')
    p_extra.add_argument('--direction', choices=['start', 'end'], default='end')
    p_extra.add_argument('--max-degree', type=int, default=4)
    p_extra.add_argument('--output', help='Optional output JSON path')

    p_wobble = sub.add_parser('wobble', help='Generate organic shake, harmonic vibration, or gelatin jiggle')
    p_wobble.add_argument('spec_json', help='Wobble specification JSON')

    p_wave = sub.add_parser('wave', help='Generate traveling wave motion with tangential rotation for characters')
    p_wave.add_argument('spec_json', help='Wave specification JSON')

    p_path = sub.add_parser('path-motion', help='Animate object or text sequence along an arbitrary ASS vector spline path')
    p_path.add_argument('spec_json', help='Path motion specification JSON')

    p_env = sub.add_parser('envelope-warp', help='Deform ASS \\p1 vector drawing using a 4x4 bicubic Bezier mesh')
    p_env.add_argument('--drawing', required=True, help='ASS vector drawing string')
    p_env.add_argument('--grid-json', required=True, help='JSON file containing a 4x4x2 array of control points')
    p_env.add_argument('--p-scale', type=int, default=1)
    p_env.add_argument('--precision', type=int, default=2)

    args = parser.parse_args(argv)
    try:
        if args.command == 'probe':
            out_path = _preflight(args.output, [args.manifest, args.track], force=args.force)
            report = probe_frames(
                args.manifest, roi=args.roi, track_path=args.track,
                bg_color=args.bg_color, fg_threshold=args.fg_threshold,
                ass_offset_ms=args.ass_offset_ms
            )
            out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
            print(json.dumps({'output': str(out_path), 'cadence': report['estimated_cadence'], 'frames': len(report['frames'])}))
        elif args.command == 'fit-curve':
            out_path = _preflight(args.output, [args.input_json], force=args.force)
            series = json.loads(Path(args.input_json).read_text(encoding='utf-8'))
            report = fit_curve_series(series['times_ms'], series['values'], max_segments=args.max_segments)
            out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
            print(json.dumps({'output': str(out_path), 'selected_model': report['selected_model'], 'rmse': report['rmse_normalized']}))
        elif args.command == 'compile':
            out_rep = _preflight(args.output_report, [args.spec_json], force=args.force)
            out_ass = _preflight(args.output_ass, [args.spec_json], force=args.force) if args.output_ass else None
            report = compile_declarative_spec(args.spec_json)
            out_rep.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
            if out_ass:
                lines = [ev['ass_line'] for ev in report['events']]
                out_ass.write_text('\n'.join(lines) + '\n', encoding='utf-8')
            print(json.dumps({'output_report': str(out_rep), 'event_count': report['event_count']}))
        elif args.command == 'transform-shape':
            m = [args.matrix[0:3], args.matrix[3:6], args.matrix[6:9]]
            transformed = transform_ass_drawing(args.drawing, m, p_scale=args.p_scale, precision=args.precision)
            payload = {'p_scale': args.p_scale, 'transformed_drawing': transformed}
            if getattr(args, 'output', None):
                out_p = Path(args.output).resolve()
                out_p.parent.mkdir(parents=True, exist_ok=True)
                out_p.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            print(json.dumps(payload, ensure_ascii=False))
        elif args.command == 'quad-to-ass3d':
            q = [args.quad[0:2], args.quad[2:4], args.quad[4:6], args.quad[6:8]]
            res = solve_ass_perspective_quad(q, ref_w=args.ref_size[0], ref_h=args.ref_size[1], org_xy=args.org, camera_dist=args.camera_dist)
            if getattr(args, 'output', None):
                out_p = Path(args.output).resolve()
                out_p.parent.mkdir(parents=True, exist_ok=True)
                out_p.write_text(json.dumps(res, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            print(json.dumps(res, ensure_ascii=False, indent=2))
        elif args.command == 'text-to-shape':
            res = text_to_ass_shape(args.text, args.font, fontsize=args.fontsize, spacing=args.spacing, p_scale=args.p_scale, precision=args.precision)
            if getattr(args, 'output', None):
                out_p = Path(args.output).resolve()
                out_p.parent.mkdir(parents=True, exist_ok=True)
                out_p.write_text(json.dumps(res, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            print(json.dumps(res, ensure_ascii=False, indent=2))
        elif args.command == 'clip-gradient':
            spec = json.loads(Path(args.spec_json).read_text(encoding='utf-8'))
            res = generate_clip_gradient(spec)
            if args.output_ass:
                out_p = _preflight(args.output_ass, [args.spec_json], force=args.force)
                out_p.write_text('\n'.join(res['lines']) + '\n', encoding='utf-8')
            print(json.dumps(res, ensure_ascii=False, indent=2))
        elif args.command == 'extrapolate-track':
            data = json.loads(Path(args.series_json).read_text(encoding='utf-8'))
            res = extrapolate_tracking_series(data['frames'], data['values'], count_extra=args.count, direction=args.direction, max_degree=args.max_degree)
            if getattr(args, 'output', None):
                out_p = Path(args.output).resolve()
                out_p.parent.mkdir(parents=True, exist_ok=True)
                out_p.write_text(json.dumps(res, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            print(json.dumps(res, ensure_ascii=False, indent=2))
        elif args.command == 'wobble':
            spec = json.loads(Path(args.spec_json).read_text(encoding='utf-8'))
            res = generate_wobble_animation(spec)
            print(json.dumps(res, ensure_ascii=False, indent=2))
        elif args.command == 'wave':
            spec = json.loads(Path(args.spec_json).read_text(encoding='utf-8'))
            res = generate_wave_characters(spec)
            print(json.dumps(res, ensure_ascii=False, indent=2))
        elif args.command == 'path-motion':
            spec = json.loads(Path(args.spec_json).read_text(encoding='utf-8'))
            res = animate_along_path(spec)
            print(json.dumps(res, ensure_ascii=False, indent=2))
        elif args.command == 'envelope-warp':
            grid = json.loads(Path(args.grid_json).read_text(encoding='utf-8'))
            res = deform_drawing_envelope(args.drawing, grid, p_scale=args.p_scale, precision=args.precision)
            print(json.dumps({'warped_drawing': res}, ensure_ascii=False, indent=2))
    except (ValueError, KeyError, OSError, json.JSONDecodeError) as exc:
        print(json.dumps({'error': str(exc)}), file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
