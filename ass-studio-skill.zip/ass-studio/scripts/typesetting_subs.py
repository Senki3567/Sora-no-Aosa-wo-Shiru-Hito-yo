#!/usr/bin/env python3
"""
CLI & API client for subs.typesetting.cc (Anime & Fansub Subtitle Archive).
Supports fixed password authentication, search via /api/search, metadata inspection via /api/anime and /api/episodes,
and direct subtitle file downloading via /api/scripts/{fid}.
"""
from __future__ import annotations

import argparse
import http.cookiejar
import json
import os
from pathlib import Path
import re
import sys
import urllib.error
import urllib.parse
import urllib.request


CONFIG_FILE = Path.home() / ".config" / "ass-studio" / "typesetting_subs.json"
DEFAULT_PASSWORD = "SlothStationAlpha"


class TypesettingSubsClient:
    def __init__(self, base_url: str = "https://subs.typesetting.cc", password: str | None = None, cookie_str: str | None = None):
        self.base_url = base_url.rstrip("/")
        self.cj = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cj))
        self.opener.addheaders = [
            ("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"),
            ("Accept", "application/json, text/html, */*"),
        ]
        
        saved = self._load_saved_config()
        self.password = password or saved.get("password") or DEFAULT_PASSWORD
        cookie_to_load = cookie_str or saved.get("cookie")
        if cookie_to_load:
            self.set_cookie_string(cookie_to_load)
        else:
            # Auto-login with default password if no cookie stored
            self.login()

    def _load_saved_config(self) -> dict:
        if CONFIG_FILE.is_file():
            try:
                return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {}

    def save_config(self, password: str | None = None, cookie_str: str | None = None) -> None:
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        data = self._load_saved_config()
        if password is not None:
            data["password"] = password
        if cookie_str is not None:
            data["cookie"] = cookie_str
        CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def set_cookie_string(self, cookie_str: str) -> None:
        domain = urllib.parse.urlparse(self.base_url).hostname or "subs.typesetting.cc"
        for item in cookie_str.split(";"):
            item = item.strip()
            if "=" in item:
                k, v = item.split("=", 1)
                c = http.cookiejar.Cookie(
                    version=0, name=k.strip(), value=v.strip(),
                    port=None, port_specified=False,
                    domain=domain, domain_specified=True, domain_initial_dot=False,
                    path="/", path_specified=True,
                    secure=True, expires=None, discard=False,
                    comment=None, comment_url=None, rest={"HttpOnly": None}
                )
                self.cj.set_cookie(c)

    def get_cookie_header(self) -> str:
        domain = urllib.parse.urlparse(self.base_url).hostname or "subs.typesetting.cc"
        cookies = [f"{c.name}={c.value}" for c in self.cj if c.domain == domain or domain.endswith(c.domain)]
        return "; ".join(cookies)

    def login(self, password: str | None = None) -> tuple[bool, str]:
        pwd = password or self.password or DEFAULT_PASSWORD
        data = urllib.parse.urlencode({"password": pwd, "next": "/"}).encode("utf-8")
        req = urllib.request.Request(f"{self.base_url}/login", data=data, method="POST")
        try:
            resp = self.opener.open(req)
            html = resp.read().decode("utf-8", errors="replace")
            if "Wrong password" in html:
                return False, "Mật khẩu không đúng (Wrong password)."
            cookie_hdr = self.get_cookie_header()
            self.save_config(password=pwd, cookie_str=cookie_hdr)
            return True, f"Đăng nhập thành công! Đã lưu phiên làm việc."
        except urllib.error.HTTPError as e:
            if e.code == 401:
                return False, "401 Unauthorized: Mật khẩu không đúng."
            return False, f"Lỗi HTTP {e.code}: {e.reason}"
        except Exception as e:
            return False, str(e)

    def _api_get(self, endpoint: str) -> dict | list:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        req = urllib.request.Request(url)
        try:
            resp = self.opener.open(req)
            return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code in (302, 401):
                ok, msg = self.login()
                if ok:
                    req = urllib.request.Request(url)
                    resp = self.opener.open(req)
                    return json.loads(resp.read().decode("utf-8"))
                raise PermissionError(f"Cần đăng nhập: {msg}")
            raise

    def search(self, query: str) -> list[dict]:
        """
        Search for anime titles on subs.typesetting.cc.
        Returns list of anime records: {aid, title, title_en, title_ja, n_episodes, langs, ...}
        """
        data = self._api_get(f"/api/search?q={urllib.parse.quote(query)}")
        if isinstance(data, dict):
            return data.get("anime", [])
        elif isinstance(data, list):
            return data
        return []

    def get_anime_details(self, aid: int | str) -> dict:
        """Get anime details including all episodes and script counts."""
        return self._api_get(f"/api/anime/{aid}")

    def get_episode_scripts(self, eid: int | str) -> list[dict]:
        """Get all subtitle scripts for an episode."""
        data = self._api_get(f"/api/episodes/{eid}")
        if isinstance(data, dict):
            return data.get("scripts", [])
        return []

    def download_script(self, fid: int | str, output_path: str | Path | None = None) -> Path:
        """
        Download a subtitle file (.ass) by fid from /api/scripts/{fid}.
        """
        url = f"{self.base_url}/api/scripts/{fid}/download"
        req = urllib.request.Request(url)
        try:
            resp = self.opener.open(req)
        except urllib.error.HTTPError as e:
            if e.code in (302, 401):
                self.login()
                req = urllib.request.Request(url)
                resp = self.opener.open(req)
            else:
                raise

        cd = resp.headers.get("Content-Disposition", "")
        filename = None
        if "filename=" in cd:
            m = re.search(r'filename=["\']?([^"\';]+)["\']?', cd)
            if m:
                filename = m.group(1).strip()
        if not filename:
            filename = f"script_{fid}.ass"

        if output_path is None:
            dest = Path(filename)
        else:
            dest = Path(output_path)
            if dest.is_dir():
                dest = dest / filename

        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(dest, "wb") as f:
            f.write(resp.read())
        return dest


def main():
    parser = argparse.ArgumentParser(description="CLI tool to search and download subtitles from subs.typesetting.cc")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Login
    p_login = subparsers.add_parser("login", help="Authenticate with subs.typesetting.cc")
    p_login.add_argument("--password", "-p", default=DEFAULT_PASSWORD, help="Site password (default: SlothStationAlpha)")

    # Search
    p_search = subparsers.add_parser("search", help="Search anime by title")
    p_search.add_argument("query", help="Anime title or keyword")
    p_search.add_argument("--json", action="store_true", help="Output raw JSON")

    # Anime
    p_anime = subparsers.add_parser("anime", help="Get anime details and episode list")
    p_anime.add_argument("aid", help="Anime ID (aid)")

    # Episode
    p_ep = subparsers.add_parser("episode", help="List all subtitle scripts for an episode")
    p_ep.add_argument("eid", help="Episode ID (eid)")

    # Download
    p_dl = subparsers.add_parser("download", help="Download a subtitle script by fid")
    p_dl.add_argument("fid", help="Script File ID (fid)")
    p_dl.add_argument("--output", "-o", default=".", help="Output directory or file path")

    args = parser.parse_args()
    client = TypesettingSubsClient()

    if args.command == "login":
        ok, msg = client.login(args.password)
        print(msg)
        sys.exit(0 if ok else 1)

    elif args.command == "search":
        try:
            results = client.search(args.query)
            if args.json:
                print(json.dumps(results, ensure_ascii=False, indent=2))
            else:
                if not results:
                    print(f"Không tìm thấy anime nào khớp với: '{args.query}'")
                else:
                    print(f"Tìm thấy {len(results)} anime cho '{args.query}':")
                    for a in results:
                        print(f"  [aid: {a.get('aid')}] {a.get('title')} ({a.get('title_ja') or ''}) | {a.get('n_episodes')} eps | Langs: {', '.join(a.get('langs', []))}")
        except Exception as e:
            print(f"Lỗi: {e}", file=sys.stderr)
            sys.exit(1)

    elif args.command == "anime":
        try:
            data = client.get_anime_details(args.aid)
            print(f"Anime: {data.get('title')} [aid: {data.get('aid')}]")
            print(f"Episodes ({len(data.get('episodes', []))}):")
            for ep in data.get("episodes", []):
                print(f"  [eid: {ep.get('eid')}] Ep {ep.get('number')}: {ep.get('title') or ''} | {ep.get('n_bodies')} scripts | Langs: {', '.join(ep.get('langs', []))}")
        except Exception as e:
            print(f"Lỗi: {e}", file=sys.stderr)
            sys.exit(1)

    elif args.command == "episode":
        try:
            scripts = client.get_episode_scripts(args.eid)
            print(f"Tìm thấy {len(scripts)} scripts cho episode {args.eid}:")
            for s in scripts:
                print(f"  [fid: {s.get('fid')}] {s.get('filename')} | Group: {s.get('group')} | Lang: {s.get('lang')} | TS lines: {s.get('n_ts')} | TS peak: {s.get('ts_peak')}")
        except Exception as e:
            print(f"Lỗi: {e}", file=sys.stderr)
            sys.exit(1)

    elif args.command == "download":
        try:
            dest = client.download_script(args.fid, args.output)
            print(f"Đã tải thành công file về: {dest.resolve()}")
        except Exception as e:
            print(f"Lỗi khi tải: {e}", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
