# Thoại, dịch và nhất quán giữa các tập

## Xác định hợp đồng nguồn và đầu ra

Tách ba việc: biên tập bản dịch hiện có; căn các nguồn khác cue; dịch trực tiếp từ JP. Xác định master quyết định cue/timing/style và nguồn quyết định nghĩa. Không mặc định EN luôn master hoặc luôn nghĩa chuẩn: dùng điều người dùng yêu cầu. Nếu là EN-first alignment, EN xác định câu hỏi/cấu trúc cần tìm, VI là nguồn câu chữ đã có, JP/audio giải quyết nghĩa gốc.

Nếu đã chọn workflow Full.vi.ass có `{EN cue text}`, provenance Effect hoặc schema map, giữ các phần đó theo đúng hợp đồng. Không hậu xử lý xóa provenance sau exporter. Một bản dịch trực tiếp JP độc lập không được giả làm bản VI đã căn từ nguồn, và không dùng Text của Full làm nghĩa đầu vào. Giữ các đầu ra riêng khi được yêu cầu.

Workflow căn và trực dịch đã có tại [alignment-workflow.md](alignment-workflow.md) và [direct-japanese-workflow.md](direct-japanese-workflow.md), cùng code/schema đi kèm. Dùng đúng mode; không cần cài hoặc gọi skill khác.

Chốt vai trò ghi chú theo **từng output**: trans note phân tích JP, provenance căn nguồn và note kỹ thuật cần người dùng rà là ba loại khác nhau. Nếu người dùng chỉ muốn trans note trong bản Nhật tham chiếu thì không nhân chúng sang bản Việt rót hoặc bản dịch độc lập. Note cần phân tích vế/lược chủ ngữ/quan hệ/sắc thái và bất định có ích cho người dịch; đường dẫn vị trí câu Việt không thay phân tích dịch.

## Audit có tiêu chí ổn định

Đọc nguồn thực sự liên quan tới cue: lời JP trọn vế và ngữ cảnh trước, rồi bảng quan hệ/giọng, transcript, tư liệu tác phẩm hoặc phỏng vấn khi có. Review/wiki giúp hiểu bối cảnh; không dùng diễn giải tác phẩm để thêm ý không có trong câu. Ghi rõ tài liệu nào đã mở và điều nào nó hỗ trợ. Bản người dịch có thể làm mẫu giọng; mức độ độc lập và quyền sửa vẫn theo hợp đồng của output.

Với mỗi lỗi, giữ cue identity, câu hiện tại, nguồn/vế làm căn cứ, loại sai, đề xuất và phép kiểm ngược. Ưu tiên sai nghĩa/chủ thể/phủ định/thông tin thêm, sai vai/giọng theo scene, callback hoặc motif có chứng cứ và nhịp đọc. Đổi từ đồng nghĩa chỉ vì “nghe có tính người hơn” không tự là lỗi. Đừng lập blacklist mọi từ Hán Việt từ vài câu không hợp vai, hoặc bắt lời lặp luôn giống chữ nếu ngữ cảnh mới yêu cầu khác. Khi audit thêm, kiểm các lỗi còn mở và nguy cơ hồi quy theo cùng tiêu chí; không thay tiêu chí sau mỗi round để tạo sửa mới. “Không thấy lỗi mới trong phạm vi đã kiểm” không có nghĩa đã chứng minh mọi câu hoàn hảo.

Khi xét CPS cho thoại nhiều lớp hoặc nhiều đoạn nối, xác định lifetime của cùng lời nói và phần chữ thực sự hiện ở từng đoạn; không tính mỗi event chớp ngắn như một câu độc lập. Chỉnh cho dễ đọc phải giữ các ý gốc; tác vụ chỉ sửa lời không cho phép retime. Kiểm lại mapping, tag, phần lời không đổi và phạm vi bản đích sau khi bung từ bảng gọn.

## Căn theo nghĩa, dùng timing để tìm

Dùng offset sơ bộ để khoanh ứng viên rồi đọc cả chuỗi hội thoại. Cue có thể tách/gộp khác nguồn; index và overlap không chứng minh nghĩa. Cho phép một–nhiều/nhiều–một với span cụ thể, không nhân nguyên câu dịch lên mọi cue con. Xử lý phần đồng thời, câu kéo dài, cue kề và lệch thời gian trước khi kết luận missing.

Một bản VI dịch sai vẫn có thể là ứng viên của đúng câu. Chốt nghĩa rồi ghi nguồn VI; không đánh missing chỉ vì lexical match thấp. Nếu source part được dùng ở nhiều chỗ, kiểm tra có phân chia hợp lý hay đang vô tình lặp nội dung. Thiếu cue và thiếu một phần ý là hai tình huống khác nhau.

## Đọc đúng ngữ cảnh và speaker

Đọc câu trước/sau, quan hệ nhân vật, scene và audio khi có. Giữ phủ định, điều kiện, mức chắc chắn, người thực hiện hành động và sắc thái. Kiểm chứng tên/biệt danh/địa danh; đừng thêm tên người vào âm mơ hồ để làm câu có vẻ trôi chảy. Transcript label/Actor hiện tại là dữ liệu cần kiểm tra.

Xưng hô là quan hệ có hướng, có scene và có tiến triển: nhân vật A nói với B không nhất thiết giống B nói A. Tạo bảng ngắn từ các tập đã duyệt: người nói–người nghe, tớ/cậu/anh/em, kính ngữ, từ xưng, biệt danh, giọng và ngoại lệ cảnh. Không chuẩn hóa mọi cuộc nói chuyện của một nhân vật theo một cặp xưng hô duy nhất.

Không có audio thì chưa thể chốt một số tranh chấp speaker/từ đồng âm. Giữ phần chưa chắc và note cụ thể điều cần nghe; không đẩy quyết định vào sửa Actor tự động. Các đồng thời Default/Alt có thể có chủ đích, chỉ sửa lỗi layer/layout khi render chứng minh có vấn đề.

## Giải một câu khó và kiểm bản biên tập

Khi có nhiều cách hiểu, đọc trọn lượt thoại và các cue chứa phần còn lại của mệnh đề. Ghi những yếu tố làm đổi nghĩa: ai thực hiện/nhận hành động, phủ định, thời/thể, điều kiện, mức chắc chắn, từ chỉ người và quan hệ nhân vật. Dùng JP/audio/ngữ cảnh theo hợp đồng nguồn để phân xử; bản EN/VI tham chiếu và Actor hiện tại là giả thuyết cần đối chiếu, không phải phiếu biểu quyết.

Có thể thử vài cách Việt ngắn với cùng ý cốt lõi, rồi kiểm ngược từng yếu tố trên. Sau đó đọc riêng bản Việt theo thứ tự xuất hiện để phát hiện câu vấp, garden path, đổi giọng hoặc xưng hô không rõ người nghe. Viết lại cho tự nhiên cần qua lượt kiểm nghĩa lần nữa; câu trôi chảy không tự chứng minh đúng. Không thêm tên/chủ thể hoặc giải thích văn hóa chỉ để lấp một điểm chưa chắc.

Với thuật ngữ, chơi chữ hoặc văn hóa, tra nguồn phù hợp khi cần và lưu lý do lựa chọn đủ ngắn cho editor tiếp tục. Với speaker/xưng hô, dùng bằng chứng của đúng scene và tầng câu chuyện; một quan hệ trong hồi tưởng không tự áp sang hiện tại. Nếu audio không được model nghe hoặc vẫn có hai cách hiểu làm đổi dịch, giữ note nêu rõ điểm cần phân xử.

Đối với căn EN–VI, tìm đoạn Việt đã có trả lời đúng câu hỏi EN trước; chỉ biên tập trong scope. Đối với OCR-only, quy trình lựa chọn lời mới này không được thay thế chữ trong ảnh. Đọc [problem-solving.md](problem-solving.md) để chọn đúng nguồn cho từng mode.

### Năm pass tách mục tiêu

1. **Hiểu nguồn:** ghi mệnh đề, quan hệ, chủ thể/đối tượng, phủ định, thời/thể, mức chắc chắn, register và điểm mơ hồ. Chưa viết câu Việt đẹp ở pass này.
2. **Chuyển nghĩa:** tạo một bản Việt giữ đủ semantic commitments; đánh dấu thuật ngữ/xưng hô cần glossary hoặc scene evidence.
3. **Biên tập tiếng Việt:** sửa trật tự, lược chủ ngữ đã rõ, nhịp và giọng nhân vật. Mỗi thay đổi lớn phải kiểm ngược lại pass 1 để không làm rơi ý.
4. **Liên tục:** đọc cue trước/sau và toàn lượt thoại để bắt garden path, lặp/mất ý do split/merge, đổi speaker và xưng hô theo tầng cảnh.
5. **Hiển thị:** kiểm duration, line break, width/font và tải đọc. Chỉ quay lại rút gọn nghĩa khi brief cho phép và có phương án giữ thông tin cốt lõi.

Khi review, phân loại finding thành `source-understanding`, `semantic-loss/addition`, `reference/pronoun`, `register/voice`, `continuity`, `naturalness`, `readability/layout` hoặc `uncertain-needs-source`. Các loại cần bằng chứng khác nhau; lỗi layout không tự cho phép đổi nghĩa, và câu chưa chắc audio không được nâng thành lỗi dịch xác nhận.

Với mỗi thay đổi đáng kể, giữ evidence pack ngắn: cue/time, source span, context cần thiết, câu hiện tại, semantic commitments, đề xuất, loại finding, confidence và nguồn cần nghe/tra thêm. Điều này cho phép editor khác phản biện quyết định mà không cần tin vào một điểm similarity hoặc lời giải thích chung chung.

## Việt tự nhiên và đọc được

Biên tập câu Việt theo giọng đã duyệt, tránh EN calque, thừa chủ ngữ, từ trừu tượng gượng và lời quá dài. Giữ hàm ý/nhịp đối thoại; không làm văn hoa hơn nhân vật. Ngắt dòng theo cụm nghĩa và đối xứng thị giác, tránh bỏ một từ ngắn lẻ; kiểm tra font/width trong frame thay vì chỉ đếm ký tự. CPS là tín hiệu cần xem lại, không tự cho phép đổi timing hoặc lược ý.

Đọc bản Việt **theo đúng thứ tự xuất hiện**, kể cả khi một câu trải qua nhiều cue. Nếu người xem phải quay lại diễn giải cue trước sau khi thấy cue sau (garden path), thử đổi trật tự/cấu trúc câu mà vẫn giữ ai làm gì, phủ định, điều kiện và thông tin hé lộ. [Kaleido: Editing](https://kaleido-subs.github.io/handbook/roles/editing/) nêu lỗi đọc tuần tự này; ví dụ tiếng Anh trong đó chỉ là cách nhận diện, không áp quy tắc dấu câu tiếng Anh cho VI.

Khi dịch trực tiếp JP, chốt ý cốt lõi và giọng nhân vật rồi chọn mức diễn đạt tự nhiên; giữ lại từ Nhật, chuyển thành tương đương Việt hay giải thích bằng ngữ cảnh là quyết định theo câu/dự án. Kiểm cách diễn đạt sáng tạo có làm mất thông tin, phủ định hoặc quan hệ không. Tra cứu thuật ngữ/văn hóa khi cần và ghi nguồn/độ chắc chắn. [Kaleido: Translation](https://kaleido-subs.github.io/handbook/roles/translation/) thảo luận cân bằng dịch sát và diễn giải, đồng thời nói trang của họ còn là bản nháp; không biến quan điểm một nhóm thành chuẩn chung.

Phân biệt **trans note nội bộ** trong `Effect`/sổ biên tập với **translation note hiện trên màn hình**. Khi hợp đồng xuất Full hoặc `.vi.from-jp.ass` yêu cầu note nội bộ, giữ đầy đủ provenance; nó không mặc định phải hiện cho khán giả. Note hiện trên màn hình chỉ khi thật sự cần để hiểu cảnh hoặc người dùng yêu cầu, sau khi thử chuyển ý vào câu dịch và kiểm tải đọc.

Giữ tags chức năng, line breaks đã yêu cầu, Actor, timing và style nếu việc chỉ là Text. Nếu thay chữ trong các override xen kẽ từng char, map lại phần text thực và bảo toàn tag có chức năng; không blanket-strip brace rồi mất effect.

## Đồng bộ nhiều tập

Tạo glossary và bảng giọng nhỏ từ bằng chứng, kèm cue/source. Khi câu lặp, so JP/context hiện tại với bản đã duyệt; chỉ dùng lại câu khi cùng nghĩa và quan hệ. Intro/flashback có thể cắt/tách cue khác; căn nội dung, không copy theo số dòng.

Rà đủ phạm vi người dùng yêu cầu. Báo nhóm chắc chắn sai và nhóm còn lựa chọn dịch, với cue/time, đoạn nguồn, bản hiện tại, đề xuất và lý do. Khi được phép sửa, dùng baseline hiện hành và guard trường như [field-edits-qc.md](field-edits-qc.md). Không tự sửa mọi tập chỉ vì phát hiện một thuật ngữ ở tập đang làm.

## Actor kỹ thuật, người nghe và tầng câu chuyện

Tách chuẩn hóa **cách ghi Actor** khỏi xác định **ai đang nói**. Khoảng trắng quanh `&`, ký tự ẩn, Unicode và nhãn nhóm có thể là lỗi kỹ thuật; `Minami/Manami`, `Sister/tên riêng` vẫn cần nguồn/ngữ cảnh. Actor ghép có thể giữ thứ tự theo thứ tự nói; chỉ sort khi quy ước dự án xác nhận đó là nhóm không thứ tự. Không đổi tên gần giống hàng loạt bằng edit distance.

Khi tìm thoại, loại các Actor kỹ thuật như lead-in/hi-light/translation/lead-out bằng vai trò event, Text và Effect; không giả định mọi Actor không rỗng là người nói. Một Style Default/Alt trùng time có thể là hai vị trí khác nhau khi cut hoặc lời đồng thời. Render và đọc ngữ cảnh trước khi gộp; cue count giữ nguyên không chứng minh ý không bị mất.

Xưng hô cần thêm tầng câu chuyện: hiện tại, hồi tưởng, lời dẫn, độc thoại, thoại hướng cả nhóm, và vai diễn trong phim nhân vật đang xem. Một cặp đã đổi anh–em ngoài đời có thể vẫn dùng chị–em/bạn–mình trong footage cũ hoặc vai diễn. Mốc đổi là cảnh/quan hệ người dùng chốt, không phải đầu tập hay toàn bộ sau số tập N. Theo dõi ai được nhắc tới: “bạn ấy” chỉ người thứ ba không phải đại từ để đổi theo cặp người nói–người nghe.

Honorific đứng riêng và suffix cạnh tên có quy ước khác: case repo này yêu cầu Senpai viết hoa khi gọi độc lập nhưng `Ichika-senpai` viết thường. Đó là lựa chọn dự án; phân biệt danh xưng dịch thành “đàn chị”, tiếng gọi trực tiếp và hậu tố, không regex thay mọi substring.

## Kiểm chứng ngữ nghĩa mà không bịa chứng cứ

Theo dõi thiếu phủ định, chủ thể, đối tượng, thời/thể và mức chắc chắn; “chưa làm” khác “chưa định làm”, “suýt hối tiếc” khác “từng hối tiếc”. Đối chiếu nguồn trọn câu và cue tiếp theo, không sửa chỉ vì một từ JP có thể dịch thành X. Câu về lịch học/ngày nghỉ cần lời gốc và scene trước/sau; nguồn fact bên ngoài chỉ dùng khi cần và ghi nguồn rõ.

Một transcript bổ sung hoặc nhãn EN chỉ là chứng cứ hỗ trợ. Các cách nghe như 目が/メガネ hay từ đầu câu mơ hồ cần audio thực hoặc note còn chưa nghe; hình một người đeo kính không chứng minh âm họ phát ra. Không nhận mình đã “nghe” chỉ vì tách WAV, chạy waveform hoặc đọc transcript. Nếu công cụ/phiên không nghe được, ghi đúng giới hạn và tiếp tục phần đọc/xem đã được giao.

Những report cũ có thể tự mâu thuẫn: ví dụ từng coi VI khác nghĩa là missing rồi về sau sửa tiêu chí. Ưu tiên hợp đồng hiện tại và bằng chứng cue, không tái tạo lỗi của report chỉ để giữ số lượng missing. Sau exporter, kiểm tra bản giao **trùng bytes với output được duyệt** hoặc có diff nằm trong phạm vi đã yêu cầu; không âm thầm làm sạch EN ẩn/provenance vì nghĩ chúng rườm rà.

## Giọng nhân vật và ngắt dòng có giới hạn

Một bảng đại từ là điểm khởi đầu, không phải máy replace. Khi thoại bị “tôi–cậu” lặp cứng, xem quan hệ, độ thân, tuổi/vai, lúc tự sự và cách gọi tên/chức danh; tiếng Việt có thể lược chủ ngữ đã rõ. Không gán đại từ theo giới tính giả định của nhân vật; với gem/nhân vật phi nhân cần bằng chứng tác phẩm và quy ước bản dịch. Khi người dùng chỉ yêu cầu pass xưng hô, không viết lại toàn bộ lời Việt theo sở thích.

Đọc các cue nối nhau trước khi kết luận thiếu điều kiện/độ bất định. Cue sau có thể được phủ bởi “có lẽ/nếu” ở cue trước. Tách lỗi mức chắc chắn, đối tượng, thời lượng (“ít nhất” khác “khoảng”), và sự diễn giải thêm ra khỏi lựa chọn giọng; ghi JP/nguồn trọn vế trong report.

Với yêu cầu ngắt dòng mà không sửa chữ: chèn `\N` vào run visible, giữ tags/khoảng trắng theo scope, tránh cắt danh từ–bổ ngữ/tên riêng/cụm cố định. Cân đối theo **chiều rộng render** của font và margin, không chỉ số ký tự. Case Houseki có quy tắc tối đa một `\N` mới, ưu tiên trên ngắn hơn dưới, dòng ngắn giữ một dòng; đó là brief riêng. Kiểm tra breaks hiện có trước khi chèn và chứng minh visible content ngoài break không đổi. `\n`/newline thực không thay `\N`; cần xem WrapStyle/tag q khi render.

Nếu đánh giá mức tương đồng giữa các bản dịch, định nghĩa đơn vị (cue/đoạn), normalization tags/linebreak, duplicate và split/merge; dùng mapping nghĩa rồi báo metric và denominator rõ. Phần trăm giống câu chữ không là xác suất nguồn gốc hay độ đúng dịch. Không suy chất lượng/nguồn tác giả chỉ từ một số cosine/edit similarity.

## Căn chỉnh từng đoạn thích ứng (Adaptive Piecewise Alignment)

Khi đối chiếu timing giữa hai nguồn khác bản phát hành (ví dụ TV broadcast vs Blu-Ray BD RAW):
- **Trôi thời gian phi tuyến (Non-linear Jumps)**: Sự xuất hiện của đoạn tóm tắt (recap), màn hình nhà tài trợ (sponsor card), hoặc dời vị trí bài hát OP/ED khiến độ lệch thời gian không phải là một hằng số cố định trên toàn tập. Ví dụ: Cụm A lệch ~+830ms, Cụm B sau OP lệch ~+20ms, Cụm C qua đoạn recap nhảy vọt lên +10.150ms rồi quay về +10ms.
- **Chọn mô hình độ lệch theo anchor**: Nếu delta $T_{target}-T_{ref}$ nhất quán trên nhiều mốc độc lập, offset toàn cục có thể đủ. Nếu delta trôi đều, kiểm timebase/tốc độ; nếu nhảy ở recap/OP/cut, chia đoạn. Clustering/sliding window có thể giúp tìm ranh, nhưng cần đối chiếu cảnh và cue; không bắt buộc một thuật toán cho mọi tập.

## Miễn nhiễm Tách 1:N và Gộp N:1 (1:N Splitting & N:1 Merging Immunity)

Một câu tiếng Nhật dài có thể tách thành nhiều cue Việt, hoặc nhiều câu được gộp theo nhịp cảnh. Số cue và CPS mục tiêu do audio, nghĩa, độ dài chữ và khả năng đọc thực quyết định; không áp mặc định 2–3 cue hoặc một ngưỡng 20 CPS:
- **Bẫy lỗi cắt âm giả (False Cutoff Trap)**: Nếu so sánh 1:1 ngây thơ theo timestamp, câu con đầu tiên sẽ bị cờ báo "hết thoại trước khi âm thanh kết thúc" (false cutoff).
- **Kiểm tra ranh giới cụm (Cluster Boundary Verification)**: Nhóm các cue liên tiếp thuộc cùng một câu thoại thành một span. So điểm bắt đầu của cue đầu tiên ($Start_1$) và điểm kết thúc của cue cuối cùng ($End_N$) với audio, rồi kiểm tiếp nhịp/nghĩa tại các biên nội bộ. Cách này tránh gắn nhãn sai một cue con chỉ vì lời nói còn tiếp; không có tỷ lệ loại cờ cố định nếu chưa đo trên corpus cụ thể.

## Ma trận Xưng hô và Đa tầng Ngữ cảnh (Cross-Episode Persona Matrix)

- **Theo dõi cặp quan hệ có hướng**: Lập bảng ma trận theo dõi xuyên suốt toàn bộ series (ví dụ Kaito ↔ Ichika, Kaito ↔ Kanna, Tetsuro ↔ Mio, Remon, Manami, Rinon).
- **Phân tầng câu chuyện**: Tách biệt rõ ràng 4 tầng thoại:
  1. *Thực tại*: Diễn biến bình thường.
  2. *Cảnh bước ngoặt*: Ví dụ sau cảnh tỏ tình, xưng hô có thể đổi từ bạn bè sang thân mật hơn (anh–em) nhưng phải kiểm tra xem nhân vật đổi ngay lập tức hay qua ngày hôm sau mới đổi.
  3. *Hồi tưởng / Lời độc thoại nội tâm*: Giữ giọng điệu riêng biệt.
  4. *Phim trong phim (Play-within-a-play)*: Khi các nhân vật diễn kịch bản phim họ đang quay, đại từ xưng hô phải tuân theo vai diễn trong kịch bản chứ không theo quan hệ đời thực.
- **Quy ước hậu tố và danh xưng riêng**: Tôn trọng quy ước dự án (ví dụ `Senpai` viết hoa khi gọi độc lập, nhưng `Ichika-senpai` viết thường khi đi kèm tên riêng).

## Ngắt dòng thông minh theo Margin và PlayRes

Khi kiểm tra và xử lý ngắt dòng cho phụ đề:
1. **Đo chiều rộng khả dụng thực tế**:
   - $\text{eff\_L} = (\text{Event.MarginL} > 0 \ ?\ \text{Event.MarginL} : \text{Style.MarginL})$
   - $\text{eff\_R} = (\text{Event.MarginR} > 0 \ ?\ \text{Event.MarginR} : \text{Style.MarginR})$
   - $\text{avail\_w} = \text{PlayResX} - \text{eff\_L} - \text{eff\_R}$
   - $\text{center\_x} = \mathrm{round}\left(\frac{\text{eff\_L} + (\text{PlayResX} - \text{eff\_R})}{2}\right)$
2. **Đo đạc chính xác qua libass**:
   - Chạy `scripts/scan_layout_overflow.py <file.ass>` với `WrapStyle: 2` (unwrapped) để đo kích thước pixel thực tế của từng dòng/nửa dòng.
   - Tránh dựa vào số ký tự đếm thô; font chữ tỉ lệ (proportional) có độ rộng ký tự khác nhau rất lớn.
3. **Quy tắc ngắt dòng bằng khả năng ngôn ngữ của agent**:
   - **Tôn trọng ngữ pháp**: Ngắt tại ranh giới mệnh đề, sau dấu câu, trước liên từ (`thì`, `và`, `mà`, `nhưng`), hoặc ranh giới cụm giới từ.
   - **Bảo toàn ngữ nghĩa**: Tuyệt đối không ngắt đôi từ ghép tiếng Việt (ví dụ: `quà lưu / niệm`, `đại / lễ`, `xác / con`).
   - **Cân đối thị giác**: Độ dài hiển thị của hai dòng chênh lệch tối thiểu; cả 2 nửa đều phải $< \text{avail\_w}$.
4. **Xử lý khoảng cách dòng khi tách**:
   - Nếu font có line spacing mặc định quá rộng trong libass, tách câu thành 2 event song song:
     - Dòng 1 (trên): `{\pos(center_x, y_top)}`, gán `Effect = Split_L1`.
     - Dòng 2 (dưới): `{\pos(center_x, y_bot)}`, gán `Effect = Split_L2`.
     - Đặt `MarginL=0, MarginR=0` trên 2 event này để tránh xung đột lề với `\pos`.

Với OCR và lyric editable, đọc [ocr-source-preservation.md](ocr-source-preservation.md) và [lyrics-layout-retargeting.md](lyrics-layout-retargeting.md) khi phù hợp.


