# Các ca đã làm và cách tái sử dụng

Các ca này cung cấp quyết định và failure modes. File path/hash/thông số là bằng chứng một dự án tại một thời điểm, không là cấu hình mặc định cho phim khác. Khi đang ở repo cũ, đọc bản hiện hành và báo cáo đúng hash trước khi chạy lại script lịch sử.

## OP Waiting in the Summer

Motif film đưa từng chữ từ cửa sổ phim tới vị trí dòng chuẩn; chỉ Romaji đang hát rung nhẹ theo gate phim 8mm. Điều quyết định timing là deadline từng syllable/glyph, không phải cả dòng intro hoàn tất rồi mới bật karaoke. Dòng đầu tại cut có thể không intro; giữ mốc hát đã time thay vì dời nhấn.

Nguồn `op_fx/op_source.ass`; generator `op_fx/generate_op_fx.py` / `rebuild/build.py`; cấu hình `palette.json`, `karaoke_motion.json`; output `op_effect.ass`. Dữ liệu ví dụ: 180 khoảng sung, 16.239 effect events, khoảng 7,76 MB. Frame đầu tập 1 là 2800; Start ASS 116.780 s và highlight đầu 116.980 s là hai mốc riêng.

Grade đầu OP được khảo sát qua storyboard toàn bài và frame kề; hồi xanh theo curve đo, không lặp xanh tự động ở montage tự nhiên. Rung 12 Hz, dưới 1px ngang và roll rất nhỏ là lựa chọn riêng ở 1080p; không thêm particle/noise layers. Benchmark có tuần tự, renderer mới, cache nhỏ và bitmap area, ghi rõ chưa chứng minh playback máy yếu.

Triển khai source comments + effect trong cùng fold, sau thoại, style chung theo brief; 11 tập có anchor riêng, 12/OVA ngoại lệ. Các comment Romaji/Việt cần preserve appearance khi gom hai style; chỉ đổi tên style chưa đủ.

Bản NC raw so được first OP frame 234 với frame 2800 tập 1, kiểm tra thêm giữa/cuối; đủ 437 title events gồm các layer không có Name. Video output 2208 frames, 92.094s, MP4 khoảng 48 MB. Cần verify đường dẫn sau người dùng di chuyển video; những path trong báo cáo render không tự là path commit hiện tại.

## Title TV/OVA

`typeset_ova_title/` chứa nguồn, đo tracking/blur, generator và deployment. Title có progression nét, camera zoom/rung, box strip và pha invert. Những lần sửa quan trọng:

- Landmark đang hình thành/invert gây fit sai; dùng kana đã rõ và registration tuyệt đối về frame rõ để giảm drift.
- Chữ “hè” khoét box bằng outline font thật; shape khoét vẽ tay không khớp chữ đổi màu.
- Motion blur có core rõ + underlay động được fit từ footprint, không chỉ một sigma giả hoặc hai ghost lấy từ frame sau.
- Event đặt sau Extradata bị Aegisub bỏ; sửa insertion vào đúng Events, không chỉ nhìn parser tìm Dialogue.
- Generator phải đọc nguồn cố định, không lấy bản đã triển khai rồi nhân effect lại.

Giá trị đo, số strip, thời điểm đủ nét và quãng trượt là của footage này; yêu cầu mới cần đo lại.

## Sign Công viên / KAIKOEN

Mask đã khớp nhưng glyph méo/trôi khi phối fixed org, 3D rotation và move. Cách sửa là fit chữ thật ở frame đầu bằng 2D scale/roll/shear/position phù hợp cảnh, giữ masking, rồi kiểm chứng toàn 83 frame. Max centroid error dưới 0.13px là bằng chứng hỗ trợ; quan trọng là visible glyph shape và alignment cũng đúng. Không biến ca này thành lệnh xóa frx/fry/org của mọi sign.

## OVA thoại và ghi note

Một đợt QC 383 cue phân biệt lỗi chắc với cần nghe; note chỉ trong Effect. ASCII comma trong Effect làm hỏng phân tách, nên plan guard field và nguyên BOM/CRLF. Tên riêng từ audio mơ hồ không được tự thêm; pronoun ở điện thoại và hai speaker đồng thời cần ngữ cảnh/audio, không chỉ Actor/transcript label.

## Căn nguồn và phục hồi karaoke

EN-first nghĩa là đi tìm VI đúng theo từng câu EN rồi dùng JP xác minh; timing không được quyết định split/merge/missing. Bản Full theo hợp đồng có thể giữ EN reference và provenance; không dùng bước hậu xử lý xóa chúng. Bản dịch JP độc lập là một output khác nếu được yêu cầu.

Khi phục hồi karaoke chỉ còn rendered effect, giữ master render và tái tạo source lyrics/timing + generator. Thay font Việt cần render shaping và right alignment thực; tách bản variant khỏi master khi brief yêu cầu. “Có nguồn” chưa đủ nếu generator không thể tái tạo ngoại hình đã duyệt.

## Rà soát thoại 13 tập, sửa gradient ED và chú thích không phá hủy

- **Phạm vi**: 13 tập (12 tập TV + 1 OVA), 5.412 cue thoại, 12 tập JP sub đối chiếu.
- **Sửa chính tả ED bảo toàn chuyển màu**: Khắc phục lỗi lặp chữ "cũng cũng", "nửa nửa" trên các dòng có `\3c&H...&` từng ký tự. Áp dụng nội suy tuyến tính RGB giữa hai màu anchor, bảo toàn hoàn hảo độ mượt của gradient. Đồng bộ `\fad(180,180)` → `\fad(200,200)` nhưng loại trừ hoàn toàn các dòng có `0` (`\fad(0,200)`). Kiểm chứng bằng screenshot render thực tế trước khi chốt.
- **Dọn asset & Style**: Đồng bộ margin tập 9 từ `20,20,20,2` sang `160,160,60,1` và màu thoại trùng khớp các tập khác. Dọn 12 style mồ côi. Bóc tách 2.783 dòng font nhúng khỏi ASS tập 6 sau khi kiểm tra font đã có trong thư mục `fonts/`.
- **Đội ngũ Multi-Agent & Chống Facade**: Triển khai nhóm chuyên trách (Orchestrator, Linguistic Worker, Timing Worker, Challenger, Forensic Auditor). Ép buộc giao thức kiểm toán pháp y: cấm kết quả hardcoded, chạy test suite tự động parse trực tiếp từ file trên đĩa và khóa hash baseline SHA-256.
- **Ghi chú QC không phá hủy**: Ghi nhận 38 lỗi vào file dưới dạng dòng `Comment:` mang style `Sign-CưongwtBas`, tag `{\an9\fnArial\fs40\bord2}`, ghim góc trên bên phải màn hình và mang đúng timing của câu thoại. Giữ nguyên 100% nội dung và số lượng câu thoại `Dialogue:` ban đầu.

