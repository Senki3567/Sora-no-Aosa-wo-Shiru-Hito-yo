# Tạo một bản phụ đề từ nguồn đến bản giao

Đọc khi yêu cầu là làm một tập hoặc một bản phát hành hoàn chỉnh. Đây là tuyến quyết định và điểm kiểm chứng, không áp đặt đúng một công cụ hay thứ tự cứng cho mọi dự án. Trước khi bắt đầu, dùng [problem-solving.md](problem-solving.md) để gán vai trò cho từng nguồn và chọn tiêu chí qua bước: nghĩa cần nguồn lời/ngữ cảnh, timing cần audio/cut, hình cần footage/render, còn bảo toàn dữ liệu cần diff/hash. Một ví dụ đạt ở một sign hoặc một cue chỉ xác nhận cơ chế đó, chưa xác nhận cả tập.

Phân vai dịch, biên tập, timing, typeset, karaoke, QC và kỹ thuật phát hành giúp phát hiện phần việc còn thiếu ngay cả khi một agent làm nhiều vai. [Kaleido: group roles](https://kaleido-subs.github.io/handbook/group/roles/); quy định của dự án/người dùng là chuẩn đầu tiên, vì handbook tự xác định là hướng dẫn của nhóm.

## 1. Khoá nguồn và hợp đồng đầu ra

Liệt kê video chính, audio, timecodes/keyframes nếu có, ASS/SRT nguồn, hardsub cần OCR, font/attachment, bản dịch tham chiếu, tập trước đã duyệt, target renderer/player và định dạng giao. Lấy hash, metadata video (frame rate thực/PTS, storage size, SAR/DAR, matrix/range), các track và độ lệch giữa nguồn. Không coi tên `final` hay thời gian trên file là quyền ưu tiên so với bản đang mở trong Aegisub.

Chọn rõ mode ngôn ngữ: OCR chữ Việt trong hình, căn lời Việt đã có theo EN, hay dịch độc lập từ JP. Chọn rõ quyền sửa Text/Start/End/Style/Effect/Actor và sự khác biệt giữa source editable, ASS render được, MKV softsub và video hardsub. Nếu nguồn đã có sub ảnh (VobSub/PGS), nhận diện track và OCR trên ảnh bằng pipeline riêng; không đọc nó như text và không nhập nhằng với OCR hardsub nằm trong frame. [Subarashii: VobSub OCR](https://subarashii-no-fansub.github.io/Subbing-Tutorial/Convert-vobsub-file-into-srt/).

## 2. Dựng cấu trúc có thể kiểm toán

Khởi đầu ASS có Script Info/PlayRes, style, Events Format đúng, các event nguồn và metadata cần thiết. Giữ `Comment` làm nguồn hoặc note khi hợp đồng cần; generated `Dialogue` là bản phân phối. Mỗi cue có nội dung, timing và vai trò rõ: thoại, sign, lyric, effect hoặc comment. Đừng dùng số dòng hay style làm định danh duy nhất nếu split/merge/reorder. Đọc [ass-model.md](ass-model.md) và workflow ngôn ngữ tương ứng trước khi xuất.

Tách ba loại clock: thời gian media/frame thực; Start/End cue; và nhịp syllable/animation tương đối. Quy đổi bằng đơn vị có khai báo, kiểm tra biên nửa mở `[Start, End)` và khớp PTS ở đầu/giữa/cuối tập. Nếu hai bản video khác cut, lưu mốc ghép đoạn thay vì dùng một offset toàn tập.

## 3. Biên tập và time theo bằng chứng

Viết hoặc căn lời theo audio/ngữ cảnh và hợp đồng nguồn. Chốt cue semantic trước khi quyết định line break và độ dài hiển thị; với lời dài, thử split/merge theo nhịp, đơn vị nghĩa, người nói và chỗ cắt. Timing dựa trên tiếng nói và scene, rồi xem đọc được ở tốc độ xem thật. Quy tắc lead-in/out, snap và overlap là tham số dự án, không là chân lý độc lập; xem [timing-practice.md](timing-practice.md).

## 4. Sign và karaoke

Lập danh sách sign theo cảnh: nội dung, thời điểm, occlusion, chuyển động, font/độ tương phản và mức ưu tiên đọc. Dựng một mẫu render trên raw trước khi nhân toàn track; lưu tracking measurement, generator/config và nguồn có thể chỉnh. Karaoke cần lời/nhịp và clock source được khoá riêng với intro/outro. Chọn Templater hay generator có thể tái tạo theo [automation-tooling.md](automation-tooling.md); không biến output sinh thành source.

## 5. QC theo lớp và phát hành

QC nội dung: nghĩa, nhân vật, thuật ngữ, chính tả, dấu Việt, line break. QC thời gian: onset/off, cut bleed, gap, overlap, drift, mốc lyric. QC hình: font thật, fallback, matrix, layer, mask, các frame biên và trajectory. QC kỹ thuật: ASS parse, section, fonts, renderer/player target, output mux/encode, audio/video sync. Ghi finding cụ thể với mức chắc chắn; không tự biến note QC thành sửa thoại ngoài phạm vi.

Lấy baseline/candidate diff theo các trường được phép, sau đó render representative stills và xem playback nếu được yêu cầu/phù hợp. Với softsub, kiểm tra track ASS và attachment trong MKV sau mux; với hardsub, kiểm tra decoded output thực. Một quy trình build có thể tái lập hữu ích cho nhiều tập nhưng không tự áp đặt công cụ SubKt/Gradle chỉ vì handbook dùng nó. [Kaleido: build template](https://kaleido-subs.github.io/handbook/building/getting-started/). Bàn giao file, nguồn editable/generator nếu có, manifest input/hash/font/renderer, thay đổi và giới hạn kiểm chứng.
