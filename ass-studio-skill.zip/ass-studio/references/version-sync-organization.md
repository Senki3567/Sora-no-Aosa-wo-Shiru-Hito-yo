# So phiên bản, đồng bộ trường và sắp xếp event

Đọc khi nhận một bộ ASS revised/ZIP/XLSX từ người hoặc agent khác, sync vào bản hiện hành, gom nhóm thoại/sign/song/comment, hoặc dọn tag/note. Dùng [field-edits-qc.md](field-edits-qc.md) cho patch guards.

## Đặt tên hai đầu phép so

Ghi rõ **nguồn lấy thay đổi → đích giữ cấu trúc**, hash/path thật, trường được copy và trạng thái baseline. Đừng dùng “bản cũ/bản mới” mà không gắn file. So revised với original và so revised với current là hai phép khác nhau. Case Houseki từng báo còn 3 cue dựa nhầm folder; kiểm tra folder nguồn đúng tìm ra 350 Text diff và 745 Effect diff. Số 495 trong báo cáo cũ không thay việc so file hiện tại.

Đếm field diff riêng: Text, Effect, Actor, timing, style, margin, kind/Layer, header và metadata. Một spreadsheet 237 dòng không chứng minh chỉ 237 cue khác, vì report có thể nhóm nhiều cue, khác baseline hoặc chưa cập nhật. Report là chứng cứ phụ; quyết định patch lấy từ ASS/source được chỉ định.

Nếu cue/timing/thứ tự khớp hoàn toàn, assert invariants rồi map theo ordinal có kiểm chứng. Nếu không, tạo identity từ tập/kind/time/style/actor và context; xử lý duplicate hoặc split/merge bằng map rõ. Không nối theo timing một cách mù quáng hoặc ép bỏ cue cho bằng số lượng.

## Sync Text nhưng giữ Effect và tag

Nếu có bản chung B, current C do người dùng đang sửa và proposed P, so theo **từng trường/cue identity**: P=B thì giữ C; C=B thì có thể áp P trong scope; C=P thì đã đồng nhất; cả hai khác B và khác nhau thì là xung đột cần đối chiếu nguồn. Không dùng mtime hoặc file tên “new” để thắng một phía. Nếu không còn B, so hai phía và đánh dấu phần không biết nguồn thay đổi thay vì gọi đó là merge ba phía.

Nguồn revised có thể mang note mới trong Effect nhưng yêu cầu chỉ sync thoại: copy đúng Text và giữ Effect đích. Nếu yêu cầu giữ functional tags/ngắt dòng của đích, phân tách text run và override trước khi đưa câu mới vào; nguyên trường Text chứa cả tag nên copy toàn trường có thể vượt scope. Nếu nguồn đã đổi layout, cần map text có tag theo nghĩa; không tự strip mọi brace.

Đọc đích lại ngay trước write, reconcile các thay đổi Aegisub của người dùng. Sau patch, chứng minh đúng các cue/field đã cho phép; style/header/fonts/fold/event không liên quan giữ nguyên. Trước khi nói “đã sync”, xác nhận file đích thực tế và diff sau ghi, không chỉ candidate/temp output.

## CSV hoặc Sheet gọn rồi bung về ASS

Một hàng chỉnh sửa đại diện **cùng một lời nói**, không chỉ cùng visible Text. Chỉ gộp styling trùng khi đã xét Actor, kind, ngữ cảnh, timing/lifetime và thứ tự; cùng chữ ở người khác hoặc lần lặp khác phải giữ identity riêng. `Dialogue:` chuyển thành `Comment:` là đổi loại event, không mặc nhiên là bị xóa. Ô fallback rỗng không được tự biến thành lời dịch hoặc yêu cầu xóa nội dung.

Manifest gắn hash các input và bảng gọn; mỗi row có ID ổn định, danh sách event nguồn kèm kind/fingerprint, text gốc và mapping các text run/override. Physical line index chỉ là địa chỉ tại baseline đó. Trước import, kiểm lại input hiện hành; hash/identity lệch thì reconcile hoặc báo conflict, không chỉ kiểm số hàng/Actor/note rồi ghi theo index cũ. Nếu hai bảng gọn dùng thuật toán nhóm khác, map qua membership/cue gốc; không ghép theo vị trí hàng hoặc chuỗi gần giống rồi gọi là khớp.

Chỉ xuất cột được giao, nhận diện cột bằng ID/header có kiểm tra, không đóng đinh B/C khi đã thêm cột tham chiếu. Actor và note review độc lập không đi vào ASS nếu chỉ cho phép sửa thoại. Giữ tags theo từng thành viên và các đoạn text có tag nội bộ; chỉ nối lại prefix có thể làm mất styling giữa câu. Phân biệt ô không sửa với yêu cầu xóa có chủ đích theo hợp đồng của bảng.

Kiểm roundtrip trên bản sao: không sửa phải giữ bytes; sửa một row phải đổi đúng Text của đủ thành viên, không chạm nhóm cùng chữ khác Actor/kind; bản đích đã sửa đồng thời phải được phát hiện. No-op pass không chứng minh edited roundtrip an toàn. Với Sheet đang được người dùng sửa, đọc bản mới ngay trước thao tác, chỉ ghi field/range được giao rồi đọc lại; đổi theme chỉ đổi format. Không thử sửa ô dữ liệu thật rồi hoàn nguyên làm phép test; dùng fixture hoặc bảng thử riêng.

## Gom nhóm ổn định

Phân loại theo event role + nội dung + style/tags/effect, không chỉ name substring. Comment chứa source, code/template hay ghi chú và lyric `rocks OPr` không phải thoại dù có Actor. Style Default có thể là shape hoặc event trống. Kiểm kê **event đang dùng style**, không suy “style có definition” nghĩa là được dùng.

Stable partition theo nhóm yêu cầu, giữ thứ tự tương đối ban đầu trong từng nhóm. Không sort nội bộ theo Start/Layer nếu yêu cầu giữ nguyên thứ tự: event trùng Layer có thể đổi stacking, karaoke/source templates có dependency. Ghi original ordinal hoặc hash event để chứng minh; multiset payload bằng nhau chỉ chứng minh không mất dòng, chưa chứng minh thứ tự đúng.

Nếu người dùng yêu cầu lyric/ED/OP ở ngay dưới thoại hoặc fold tương tự sign, đọc cách fold đang lưu và chèn đúng vị trí. Marker phải khớp event/comment/extradata của dự án, không sáng tạo label rồi gọi đó là fold. Render vùng stacking và đọc lại bằng editor/renderer target nếu ảnh hưởng.

## Dọn tag, note và file

“Xóa inline tag” khác “xóa tag đầu cue”, “xóa comment inline” khác xóa Comment event. Nhận diện block override và `{ghi chú}`; preserve các tag đầu đã yêu cầu, `\N`, escaped text và braces có vai trò. Các leading blocks liên tiếp hoặc metadata `{=...}` cần phân loại riêng. Scope thoại không cho phép dọn tags của karaoke/sign.

Effect vừa có nhãn engine như fx/Effector, vừa có note review/provenance. Inventory nhóm trước; nếu chỉ xóa `ED generated` và note văn bản thì giữ engine tags không thuộc yêu cầu. Không suy “dọn” là xóa cả nguồn/backup/video hay mọi file không có trong danh sách cuối. Với file deletion được yêu cầu, liệt kê exact targets và nguồn cần giữ; lời “folder chỉ cần hai output” không mặc nhiên áp sang thư mục dự án chứa raw.

## Đồng bộ Style và Kỹ thuật hàng loạt giữa các tập (Batch Multi-Episode Sync)

Khi audit một series nhiều tập, cần quét ma trận style trên toàn bộ các file:
- **Margins & Colors**: Lập ma trận các trường thật giữa các tập để tìm outlier; đọc scene/override/biến thể và quy ước đã duyệt trước khi chốt lỗi. Chỉ đồng bộ đúng trường/nhóm được giao, không ép mọi tập giống nhau vì một giá trị chiếm đa số.
- **Style có vẻ không dùng**: Event.Style count 0 chỉ là ứng viên rà. Kiểm cả reset `\rTênStyle`, source comment/template, generator và các biến thể cần giữ; chỉ bỏ khi đủ bằng chứng và nằm trong scope. [Aegisub tags](https://aegisub.org/docs/latest/ass_tags/) mô tả reset có tên style.
- **Font nhúng (`[Fonts]`)**: Kiểm font thực nạp, face/glyph dùng, cơ chế phân phối và target player. Font nằm trong thư mục không bảo đảm player tự nạp thay attachment. Nếu được giao chuyển cơ chế đóng gói, decode/extract đúng, so hash font, attach/nạp theo cơ chế target rồi render glyph thật trước khi bỏ bản nhúng. [Attachment Manager](https://aegisub.org/docs/latest/attachment_manager/) và [font-selection.md](font-selection.md). Không gọi embedded asset là rác chỉ vì file lớn.
- **Đồng bộ Fade có điều kiện (Selective Fade Sync)**:
  - Khi được giao chuẩn hóa fade, kiểm cut/phase và source trước khi đổi. Fade 0 có thể là chủ đích hard cut, nhưng cũng có thể là trường user muốn sửa rõ; không tự thay và cũng không cấm sửa bất chấp yêu cầu. Giữ clock tuyệt đối và kiểm frame biên/các lớp liên quan.

## Bàn giao đúng artifact

Đóng gói đúng thư mục/các file vừa sửa, mở ZIP kiểm tra tên và bytes/hash từng ASS so với bản giao. Đặt tên phân biệt rõ phiên bản, nhưng tên UPDATED/final không thay kiểm chứng hash. Giữ bảng trước/sau theo đúng cặp baseline, đừng báo tổng từ original như số sửa thêm. Đọc lại đường link/file tải đưa cho người dùng; đừng trỏ ZIP cũ tên gần giống.

Phân biệt đã review, đã patch, đã render, đã copy vào đích và đã publish. Tác vụ ngữ nghĩa toàn diện còn dở không được gọi hoàn tất vì pass xưng hô hoặc cấu trúc đã đạt.

## Hoàn nguyên đúng lần can thiệp

Lưu snapshot/manifest trước thao tác, gồm cả chỉnh sửa chưa commit của người dùng. Khi bản thử bị bác, khôi phục đúng snapshot hoặc đảo đúng delta do agent tạo trên các path đó. HEAD, remote và autosave là các phiên bản tham chiếu khác nhau, không mặc nhiên là trạng thái “trước khi bạn đụng vào”. Không dùng reset/checkout/pull để dọn render tạm hoặc sửa một ASS; có thể xóa mất chỉnh sửa chưa push/commit. Nếu không còn snapshot đủ để khôi phục chính xác, đối chiếu các bản còn lại và báo phần chưa chứng minh được; đừng gọi “nguyên trạng 100%” chỉ vì file mở lại được hoặc git status hợp lý.


---

## Giao thức Phẫu thuật Cục bộ (In-Place Sectional Slicing Protocol) cho File ASS Phức tạp

### 1. Cấm hoàn toàn Rebuild/Rewrite Monolithic trên file đang sống
Khi làm việc với các dự án lớn nhiều Fold (Fold 1 Hội thoại, Fold 2 Sign, Fold 3 Song/Karaoke, Fold 4 Extra):
- **Tuyệt đối cấm** đọc toàn bộ file vào script rồi ghi đè nguyên khối (monolithic rewrite). Cách làm này sẽ:
  - Phá vỡ các mốc snap mà người dùng đã tự tay vi chỉnh trực tiếp trong Aegisub.
  - Xóa sạch cấu trúc thẻ đóng/mở Fold nội bộ Aegisub (`{=...}`).
  - Làm trôi các dòng cut vắt ngang mốc (cut-straddling lines).
- **Quy tắc bất di bất dịch**:
  - **Cô lập Fold bất khả xâm phạm**: Fold nào người dùng đã duyệt/sửa (đặc biệt Fold 1 Hội thoại) phải được bảo vệ nguyên vẹn 100% byte-for-byte.
  - **Phẫu thuật theo section**: Chỉ đọc và ghi cục bộ đúng đoạn cần sửa (Fold 2 Sign hoặc Fold 3 Song) bằng phương pháp stream slicing hoặc in-place replacement.
  - **Kiểm tra SHA256 & byte-check**: Trước và sau mọi thao tác, so sánh hash hoặc line-by-line của các Fold không liên quan để đảm bảo không một byte nào bị xê dịch ngoài ý muốn.

### 2. Xác thực bản chất nội dung trước khi cắt gọt (Cut Verification Protocol)
Khi một nhóm sự kiện (Sign, Typeset, Credits, MV) bị vượt thời lượng video đích (ví dụ sau khi cộng offset BD thì timestamp vượt quá thời lượng video BD):
- **Cấm giả định mù quáng**: Không được vội kết luận là do timing sai, cũng không được tùy tiện xóa bỏ hàng ngàn dòng mà không có bằng chứng hình ảnh.
- **Quy trình thẩm định 3 bước bắt buộc**:
  1. **Khảo sát frame thực tế**: Trích xuất các frame video tại mốc kết thúc của video nguồn (WEB) và video đích (BD).
  2. **So sánh cấu trúc phân cảnh**: Đối chiếu xem đoạn nội dung đó (ví dụ MV cuối phim, cuộn credit) có thực sự xuất hiện trong bản video đích hay đã bị cắt bỏ hoàn toàn bởi nhà sản xuất đĩa Blu-ray.
  3. **Xử lý an toàn**:
     - Nếu nội dung thực sự bị cắt bỏ trong video đích: Phân loại rõ ràng và xóa bỏ hoặc chuyển thành `Comment:` kèm nhãn ghi chú nguồn gốc (ví dụ `[WEB Only - Không xuất hiện trong BD]`).
     - Nếu chỉ rơi vào màn hình đen (black screen) cuối phim: Chuyển sang `Comment:` để không làm rác log render.
