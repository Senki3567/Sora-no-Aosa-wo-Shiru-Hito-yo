# Giải phẫu thuật toán Automation cộng đồng & Tái hiện trên libass

Đọc khi cần thực hiện các hiệu ứng typeset/motion phức tạp mà trước đây cộng đồng phụ đề chỉ làm được thông qua các Automation macro của Aegisub (`arch.Perspective`, `ILL/Shapery`, `Gradient Everything`, `Vector Gradient`, `Inner Glow`, `PhosCity Extrapolate Tracking`).

Tài liệu này giải thích chi tiết nguyên lý toán học, cơ chế render nội bộ của `libass` và cách sử dụng các lệnh tương đương được tích hợp sẵn trong `scripts/motion_studio.py` mà không cần phụ thuộc vào GUI Aegisub hay `aegisub-cli`.

---

## 1. Vì sao cần tái hiện thuần Python trên `libass`?

Trong môi trường server/agent (Linux headless, CI/CD, hoặc harness tự động):
- `aegisub-cli` thường xuyên gặp lỗi do phụ thuộc vào vòng lặp giao diện wxWidgets, fork cũ dừng phát triển (từ 2020), lỗi include path của MoonScript, hoặc thiếu DependencyControl.
- Các script Automation cộng đồng (Lua/MoonScript) thường tính toán tọa độ theo giả định của VSFilter/Aegisub cũ mà không kiểm soát được chi phí rasterization thực tế trên `libass`.
- `scripts/motion_studio.py` tái hiện trực tiếp các thuật toán này bằng Python 3, NumPy, SciPy và fontTools, xuất ra mã ASS chuẩn hóa, có thể kiểm chứng ngay qua `scripts/libass_render.py`.

---

## 2. Giải ngược phối cảnh 3D (`quad-to-ass3d`)

### Mô hình Camera và Không gian 3D của `libass`
Khác với OpenGL/DirectX sử dụng ma trận camera $4\times 4$ tùy ý, `libass` mô phỏng không gian 3D giả lập (pseudo-3D) bằng phép biến đổi cố định:
- **Tiêu cự chuẩn (Focal Distance)**: $d = 312.5$ pixels. Khi một điểm có tọa độ $Z$, tỷ lệ co phối cảnh là:
  $$s_z = \frac{d}{d - Z} = \frac{312.5}{312.5 - Z}$$
- **Trục quay và thứ tự quay nội bộ**:
  $$R = R_y(-\text{fry}) \cdot R_x(-\text{frx}) \cdot R_z(-\text{frz})$$
- **Thứ tự áp dụng biến dạng**:
  1. Dịch chuyển về tâm quay `\org(org_x, org_y)`.
  2. Áp dụng shear góc nghiêng ngang `\fax`.
  3. Áp dụng tỷ lệ co giãn `\fscx / 100`, `\fscy / 100`.
  4. Nhân ma trận quay 3D $R$.
  5. Chiếu phối cảnh $Z \to \text{Screen}$ với $d = 312.5$.
  6. Dịch chuyển về vị trí đặt `\pos(pos_x, pos_y)`.

### Thuật toán giải tối ưu (`motion_studio.py quad-to-ass3d`)
Khi có 4 góc của một biển hiệu $[TL, TR, BR, BL]$ trên màn hình:
```bash
python3 scripts/motion_studio.py quad-to-ass3d --quad x0 y0 x1 y1 x2 y2 x3 y3 --ref-size w h --output work/ass3d.json
```
1. Khởi tạo nghiệm thô từ phép tịnh tiến và tỷ lệ khung hình bounding box.
2. Dùng thuật toán tối ưu hóa phi tuyến Levenberg-Marquardt / Nelder-Mead (Scipy) để tối thiểu hóa khoảng cách giữa 4 đỉnh hình chiếu và 4 đỉnh thực tế:
   $$\min_{\mathbf{p}} \sum_{i=1}^4 \|\mathbf{q}_i(\mathbf{p}) - \mathbf{q}_i^{\text{target}}\|^2$$
   với $\mathbf{p} = [\text{pos}_x, \text{pos}_y, \text{fscx}, \text{fscy}, \text{fax}, \text{frx}, \text{fry}, \text{frz}]$.
3. **Giới hạn an toàn**: Nếu góc quay quá gắt ($|\text{frx}| > 85^\circ$ hoặc $|\text{fry}| > 85^\circ$) khiến mẫu số phối cảnh tiệm cận 0, thuật toán sẽ cảnh báo và đề xuất chuyển sang phương án **Bake Vector Shape** (`text-to-shape` + `transform-shape`).

---

## 3. Chuyển văn bản sang Vector Drawing & Biến hình (`text-to-shape` & `transform-shape`)

### Trích xuất Vector Glyph từ Font (`text-to-shape`)
Khi cần khoét chữ, làm hiệu ứng vỡ vụn hoặc biến dạng phối cảnh vượt ngoài giới hạn của `\frx/\fry`:
```bash
python3 scripts/motion_studio.py text-to-shape --text "VĂN BẢN" --font /path/to/font.ttf --fontsize 64 --p-scale 1 --output work/shape.json
```
- Sử dụng `fontTools.ttLib` đọc trực tiếp bảng `glyf` (TrueType) hoặc `CFF ` (OpenType).
- Tự động nâng bậc đường cong Bézier bậc 2 (Quadratic: $P_0, P_1, P_2$) của TrueType lên Bézier bậc 3 (Cubic: $P_0, C_1, C_2, P_3$) tương thích với lệnh `b` của ASS:
  $$C_1 = P_0 + \frac{2}{3}(P_1 - P_0), \quad C_2 = P_2 + \frac{2}{3}(P_1 - P_2)$$
- Lật trục $Y$ (font vector có trục $Y$ hướng lên, trong khi ASS có trục $Y$ hướng xuống) và cộng dồn khoảng dịch chuyển ký tự (`hmtx.advanceWidth`).

### Chiếu Vector Shape qua Ma trận Homography 3×3 (`transform-shape`)
```bash
python3 scripts/motion_studio.py transform-shape --drawing "m 0 0 l 100 0 100 50 0 50 c" --matrix 1 0 10 0 1 20 0 0 1 --p-scale 1 --output work/transformed.json
```
- Phân tích cú pháp chuỗi vẽ ASS (`m x y`, `l x y`, `b x1 y1 x2 y2 x3 y3`).
- Nhân từng điểm điều khiển qua ma trận đồng nhất $3\times 3$:
  $$\begin{bmatrix} x' \\ y' \\ w' \end{bmatrix} = \mathbf{H} \begin{bmatrix} x \\ y \\ 1 \end{bmatrix}, \quad x_{\text{screen}} = \frac{x'}{w'}, \quad y_{\text{screen}} = \frac{y'}{w'}$$
- Đảm bảo giữ nguyên cấu trúc contour và thứ tự điểm để không làm hỏng quy tắc chẵn-lẻ (even-odd fill rule) của `libass`.

---

## 4. Cắt dải Gradient & Triệt tiêu Sọc Viền (`clip-gradient`)

### Bản chất Bitmap Slice của `libass`
Trong `libass`, phép cắt clip chữ nhật `\clip(x0, y0, x1, y1)` có chi phí tính toán cực thấp vì renderer chỉ việc điều chỉnh con trỏ scanline của bitmap glyph đã rasterize trong bộ nhớ cache.

### Khắc phục Lỗi Border-Striping (Sọc viền)
Khi cắt một dòng chữ có viền `\bord` thành 50 dải gradient hẹp:
- **Hiện tượng lỗi**: Mép cắt của từng dải sẽ cắt ngang qua đường viền, để lại các vết sọc đứt gãy hoặc viền bị nhân đôi do khử răng cưa chồng lấn.
- **Giải pháp tách lớp của `motion_studio.py clip-gradient`**:
  ```bash
  python3 scripts/motion_studio.py clip-gradient work/gradient_spec.json --output-ass work/grad.ass
  ```
  1. **Lớp nền (Underlay Layer)**: Nằm ở layer thấp hơn, vẽ toàn bộ văn bản nhưng ẩn màu ruột (`\1a&HFF&`), giữ nguyên viền `\3c` và bóng `\4c` không áp clip.
  2. **Các dải màu (Fill Strips)**: Nằm ở layer cao hơn, triệt tiêu viền (`\bord0\shad0`), chỉ tô màu ruột `\1c` đổi dần và cắt theo từng dải `\clip`.
  $\implies$ Viền ngoài hoàn hảo 100%, ruột chuyển màu mượt mà, không sinh lỗi đồ họa.

---

## 5. Ngoại suy quỹ đạo Tracking (`extrapolate-track`)

Khi một biển hiệu trượt ra khỏi khung hình hoặc bị nhạt màu (fade) khiến tracker quang học bị mất dấu:
```bash
python3 scripts/motion_studio.py extrapolate-track work/series.json --count 10 --direction end --output work/extrap.json
```
- **Kiểm định chéo LOOCV (Leave-One-Out Cross-Validation)**: Thử nghiệm lần lượt các bậc đa thức $1 \le k \le 4$.
- **Nguyên lý Occam's Razor chống Overfitting**: Nếu bậc $k$ đã đạt sai số thực tế không đáng kể ($< 10^{-8}$) hoặc bậc $k+1$ không cải thiện ít nhất 5% sai số so với bậc $k$, thuật toán sẽ giữ lại bậc $k$ thấp hơn, ngăn chặn hiện tượng đường cong bị quẫy đuôi (Runge's phenomenon).

---

## 6. Động cơ Biến dạng & Chuyển động Tự nhiên

| Lệnh | Cơ chế toán học | Ứng dụng thực tế |
|---|---|---|
| `wobble` | Dao động điều hòa tắt dần: $x(t) = A e^{-\lambda t} \cos(2\pi f t)$ kết hợp nhiễu mượt đa tần | Chấn động camera khi nổ, biển hiệu bị gió thổi rung rinh, hiệu ứng thạch gelatin nảy chữ. |
| `wave` | Sóng hình sin truyền dọc: $y_i(t) = A \sin(\omega t - k x_i)$ kèm góc nghiêng tiếp tuyến $\theta_i = \arctan\left(\frac{dy_i}{dx}\right)$ | Chữ nhấp nhô theo sóng nước/âm nhạc, từng ký tự tự động xoay nghiêng theo hướng tiếp tuyến của sóng. |
| `path-motion` | Lấy mẫu chiều dài cung (arc-length parameterization) trên đường cong spline Bézier | Chữ hoặc biểu tượng bay uốn lượn theo một quỹ đạo vector vẽ tay, tự động tính góc `\frz` bám đường. |
| `envelope-warp` | Lưới Bézier bicubic $4\times 4$ với 16 điểm điều khiển: $\mathbf{S}(u,v) = \sum_{i=0}^3 \sum_{j=0}^3 B_i^3(u) B_j^3(v) \mathbf{P}_{i,j}$ | Uốn cong văn bản theo mặt trụ tròn (lon nước, cột nhà), cờ bay uốn lượn trong gió. |
