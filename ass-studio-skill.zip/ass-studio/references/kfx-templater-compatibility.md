# KFX bằng Templater: chọn đúng bản và giữ nguồn

Đọc khi dựng/sửa karaoke bằng Automation. Ba tài liệu địa phương `kfx_guide_0x539.md`, `kfx_guide_arch1t3ch(1).md`, `kfx_guide_demo.md` trong thư mục `fansubbing` là tài liệu học và ví dụ, **không phải một cú pháp chung**. Chốt tên script, commit/version, dependencies, renderer đích và nguồn ASS trước khi áp. Mã/tài liệu hiện hành của [The0x539](https://github.com/The0x539/Aegisub-Scripts/blob/trunk/doc/0x.KaraTemplater.md), [karaOK](https://github.com/slackingway/karaOK) và [Aegisub gốc](https://aegisub.org/docs/latest/automation/karaoke_templater/declaring_template_and_code_lines/) là nguồn xác minh hành vi của từng bản.

## Ma trận tương thích tối thiểu

| Vấn đề | Aegisub gốc | karaOK | The0x539 |
|---|---|---|---|
| Dòng lyric nguồn | `Effect` rỗng, `Karaoke` hoặc `karaoke` | Kiểm script bản cài; bản sửa từ gốc nhưng không suy marker khi chưa thử | **phải** là `kara` hoặc `karaoke`; rỗng không được lấy làm nguồn |
| Dòng tạo một output theo toàn line | `template pre-line` | `template line` | `template line` |
| Nội dung/template áp theo từng syllable trong một line | `template line` | `template lsyl` | `mixin syl` đặt trên `template line` |
| Output riêng từng syllable | `template syl` | `template syl` | `template syl` |
| Trộn modifier | `code`/`template`, `fxgroup`, `all`, `multi` theo docs gốc | Kiểm README và mã đúng bản | `code`/`template`/`mixin`, `style`, `actor`, `t_actor`, `layer`, `if`/`unless`, `multi` |

Không chuyển nguyên Effect token hoặc biểu thức giữa các cột. Cùng tên `template line` có đơn vị output khác. The0x539 có `mixin` sửa dòng do `template` tạo; `template` mới tạo dòng. `mixin line` áp vào đầu output, `mixin syl`/`char` chèn gần phần text tương ứng; `t_actor` lọc template cơ sở còn `actor` lọc lyric đầu vào. `noblank` bỏ khoảng trắng, **không** bỏ syllable có thời lượng 0; dùng `nok0` khi phù hợp. `notext` ngăn lyric tự gắn sau tag/shape particle. `loop tên N` và biến `$loop_tên` là cú pháp đặt tên của The0x539; không mang sang bản gốc.

Guide arch1t3cht cũ nói The0x539 thiếu `multi`, nhưng tài liệu và mã The0x539 hiện nay đã có `template syl multi`. Vì vậy ghi rõ phiên bản khi dùng ví dụ. Với `multi`, ký hiệu `#` đánh dấu lần nhấn lại của cùng syllable; kiểm `syl` (nhấn hiện tại) với `msyl` (syllable gốc) và retime output, không hiện dấu `#` trong lời. [Tài liệu The0x539](https://github.com/The0x539/Aegisub-Scripts/blob/trunk/doc/0x.KaraTemplater.md) là điểm kiểm lại khi script cập nhật.

## Profile riêng của `nyaa.kara-templater.lua`

Tài liệu Muteki cập nhật ngày 2026-08-03 mô tả một **local build**, không phải tính năng chung của Aegisub gốc, karaOK hay The0x539. Ngoài macro, build này còn đăng ký export filter; CLI Myaamori chỉ gọi macro nên không được dùng tên filter thay thế. Package có `include/nyaa` nhưng không kèm `nyaa/util`; ILL, Yutils và các dependency khác vẫn phải tồn tại trong installation target.

- `fbf` chạy template một lượt warm-up để helper timing thiết lập `line.startFrame`, `line.endFrame`, `line.frameCount`, sau đó mới phát một event cho mỗi frame. Trong warm-up, `frame.frame` có thể là `nil`; đặt `retime`/`settime` trước biểu thức phụ thuộc frame range và guard absolute frame. `frame.j/frame.maxj` chỉ là tiến trình của range output đã chốt.
- `recalculate` xây context hình học mới từ các leading override liên tiếp trước ký tự nhìn thấy. Nó đọc một tập tag tĩnh như font/scale/spacing/rotation/placement/màu/alpha; bỏ qua tag trong `\t`, và `\move` chỉ dùng cặp tọa độ đầu để tính. Đây là snapshot trạng thái đầu, không phải evaluator animation.
- `shape` lấy outline qua ILL và đặt drawing vào tọa độ script tuyệt đối. Render bằng `\an7\pos(0,0)` khi chưa có lý do khác để tránh cộng vị trí hai lần. Whitespace không có outline; `shape notext` phù hợp pure drawing, còn output cố ý không có visible text cần `allowempty`.
- Kết hợp `recalculate shape` chỉ đáng tin cho trạng thái leading đã được parser hỗ trợ. Render fixture có dấu Việt, kerning, rotation và placement thật; không suy rằng mọi tag/renderer đều được bake.

Trước khi dùng profile này, kiểm filename/hash/changelog của script đang cài và dependency load log. Không copy modifier của profile này vào template The0x539 chỉ vì tên tài liệu đều ghi Karaoke Templater. [Muteki local build](https://mutekifansub.hu/public/karaoke-docs/en/).

## Từ ý tưởng hình thành generator KFX

1. Dựng **một output ASS thủ công** cho một line/syllable đại diện: layer, text/drawing, Start/End và tags phải tự render đúng. Đây là oracle của generator.
2. Tách effect thành base, active highlight, accent/glow, particle/mask và outro. Mỗi lớp ghi input unit (`line/syl/word/char/frame`), phase, clock và điều kiện Actor/inline-fx. Nếu một lớp không có chức năng rõ, bỏ khỏi prototype trước khi nhân.
3. Chọn primitive: native `\t`/`\move` cho đoạn tuyến tính/biến đổi hỗ trợ được; easing helper hoặc đoạn transform lấy mẫu khi curve cần khác; FBF chỉ khi primitive không biểu diễn được shape/occlusion/trajectory. Easing overshoot phải là thiết kế quan sát được, không là mặc định “mượt”.
4. Ước lượng output trước khi chạy: `source units × output templates × loop products × FBF frames`, rồi cộng các nhánh điều kiện. Mixin không tự tạo event nhưng có thể nhân text/tags trong từng output. Sau chạy, so số thực với dự báo và truy ít nhất một generated event về source/component/loop.
5. Với random/noise, seed theo nguồn ổn định như line/syllable identity nếu cần tái lập; không seed lại mỗi frame. Lưu implementation/version, dependency, seed, parameters và source comments cùng output.

Easing library như `petzku.easings` có thể sinh chuỗi transform theo step; step lớn giảm output nhưng có thể giật, step nhỏ tăng event/tag và chi phí. Kiểm curve, frame transition và renderer target; đừng nhận module có mặt là bằng chứng effect phù hợp brief.

## Clock, lớp và hiệu ứng

- `\k`, `\kf`, `\ko` ghi **centisecond**; `syl.start_time`, `syl.duration`, `line.start_time` trong Lua/karaskel tính **millisecond**. Muốn lọc âm dài ít nhất 550 ms thì so `syl.duration >= 550`, không dùng `>= 55`. [karaskel](https://aegisub.org/docs/latest/automation/lua/modules/karaskel.lua/) nêu các trường; `kfx_guide_demo.md` có cả ví dụ sai rồi sửa.
- `template syl` thường tạo output có Start/End bằng cả cue nguồn cho tới khi gọi `retime`. Sau `retime("syl", -180, 260)`, thời gian trong `\t`, `\move`, `\fad` phải tính lại từ **Start mới của output**. Ghi ba clock: video absolute, cue nguồn và output event relative. `retime` ở từng bản có các mode/chi tiết khác; kiểm tài liệu đúng bản.
- Chữ nền, highlight, glow và particle cần mục đích/layer rõ. Có thể tái dùng `mixin` cho vị trí/chuyển động chung, tạo glow ở layer dưới và fill đọc được ở layer trên. `mixin char`/`util.xf` của The0x539 giúp gradient theo vị trí ký tự, nhưng cách đo từng ký tự không đảm bảo đúng chuỗi đã shape có kerning/ligature/dấu Việt; xác nhận bằng full text render. ASS lưu màu theo BGR.
- `util.fbf` hoặc particle theo frame chỉ dùng khi native tags không thể mô tả chuyển động/hình. Lưu seed của random, giới hạn số event và bitmap, so render/CPU theo đoạn cao điểm. Những mốc lyric và generator editable phải tái tạo được output.

## Debug KFX theo tầng

Đầu tiên phân biệt bốn tầng: script/dependency được nạp; source/template được chọn; generator tạo ASS; renderer hiển thị ASS. Lỗi ở tầng nào cần bằng chứng của tầng ấy:

| Triệu chứng | Phép thử nhỏ | Hướng xử lý |
|---|---|---|
| Module/syntax/API lỗi | Nạp đúng script trên fixture riêng; đọc stack và registration | Sửa dependency/version hoặc cú pháp trước khi đổi thiết kế |
| Macro chạy nhưng không sinh dòng | Đếm source marker, Style/filter, component tạo output, selection và nhánh Cancel | Sửa phạm vi/điều kiện; `mixin` đơn lẻ không tạo output ở The0x539 |
| Số dòng nổ lớn | Tính số input × class items × loops × layers/FBF rồi so số thực | Tìm vòng nhân không cần, `notext`/filter chưa đúng; không chỉ xóa output thủ công |
| Output có nhưng không thấy/sai chỗ | Mở một event đã sinh: Text, alpha, clip, `\p`, font, layer, Start/End và pos | Render chính event ấy trên fixture; tách lỗi tag khỏi lỗi generator |
| Nhịp hoặc phase sai | Truy một syllable tới source onset, output Start và offset `\t`/`\move` | Sửa phép đổi clock; giữ source rhythm đã duyệt |

Bắt đầu từ một lyric đại diện và một component, rồi thêm code/mixin/loop lần lượt để xác định thay đổi gây lỗi. Khi dùng random, cố định seed trong phép so; lưu script version và các thông số. Nếu sửa generated output để chẩn đoán, đưa sửa đúng về source/template trước khi bàn giao để reapply không làm mất nó. Chỉ mở rộng toàn OP/ED sau khi có mapping source→output, hình, timing và chi phí phù hợp; thiếu môi trường chạy phải giữ trạng thái chưa kiểm.

Chạy `python3 scripts/kfx_inspect.py file.ass` để lấy kiểm kê read-only trước macro. Report phân biệt source explicit/implicit, component, `fx`, tổng `\k`, dấu hiệu dialect và rủi ro trộn implementation. Nó không parse Lua hoặc chứng minh expansion/renderer, nên luôn kiểm generated ASS thật sau macro.

## Quy trình áp an toàn

1. Chụp hash và tách candidate ASS; kiểm `Event` loại Comment/Dialogue, `Effect`, Style, Actor. Phân biệt component, lyric nguồn, output sinh và `fx` thuộc công việc khác. [Aegisub gốc](https://aegisub.org/docs/latest/automation/karaoke_templater/declaring_template_and_code_lines/) ghi rõ output `fx` bị xóa khi chạy lại; mã The0x539 cũng dọn output `fx` trước khi tái sinh. **Không áp trên master có `fx` khác chưa bảo toàn.**
2. Time và kiểm lyric `\k`: từng mốc âm tiết, tổng duration so cue, zero-duration, khoảng trắng, dấu `#` khi multi. Nếu dời Start để làm intro, chứng minh mọi onset tuyệt đối vẫn giữ.
3. Tạo 1–2 câu đại diện gồm âm ngắn/dài, khoảng trắng/dấu Việt, cut và nhiều highlight; chạy macro trên candidate. Với `aegisub-cli`, xác nhận macro có đăng ký, dependency tải được và selection đúng; xem [aegisub-cli.md](aegisub-cli.md).
4. So source→generated: số dòng theo `template`/`loop`, layer, Style, Actor, Text, start/end, `Effect=fx`; kiểm một output cụ thể bằng tính tay absolute→relative. Chạy lại trên bản sao của **cùng nguồn** để chứng minh idempotence và không xóa phần ngoài phạm vi.
5. Render đầu/giữa/cuối phase, frame sát cut, âm ngắn, giao hai cue, và test glyph/font thật. Chỉ triển khai các line còn lại sau khi ví dụ qua QC; giữ cả source comments, script version, config, seed và bản output.

Các ví dụ trong `kfx_guide_demo.md` có bước cố ý sai để minh họa; đừng copy nguyên bảng mẫu vào production. Với extension khác, xác minh modifier/hàm từ mã và docs đúng build; một trang tài liệu chi tiết vẫn chưa chứng minh package hiện có trên máy hoặc chạy được qua CLI/headless.
