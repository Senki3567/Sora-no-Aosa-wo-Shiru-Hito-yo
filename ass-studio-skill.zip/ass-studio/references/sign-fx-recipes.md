# FX cho sign: chọn cơ chế theo footage

Đọc sau [typesetting-tracking.md](typesetting-tracking.md) khi sign cần nhiều lớp, mask, gradient, blur hoặc biến hình. Dựng một đoạn ngắn trên footage gốc và giữ text/font/shape nguồn chỉnh được. [Phos: Blur and Glow](https://phoscity.github.io/Phos-Fansubbing-Guide/Typesetting/Blur%20and%20Glow/) và [Masking](https://phoscity.github.io/Phos-Fansubbing-Guide/Typesetting/Masking/) mô tả những thành phần cơ bản; số layer/cường độ là lựa chọn theo ảnh, không là preset chung.

| Hình cần đạt | Cấu trúc ứng viên | Kiểm tra dễ bỏ sót |
|---|---|---|
| Chữ cùng bề mặt, chỉ tịnh tiến/xoay/scale | Text source + `\pos`/`\move`/`\frz`/`\fscx`/`\fscy` quanh pivot | Chữ Việt, baseline và outline có cùng chuyển động với nền không? |
| Chữ có viền, viền kép, glow | Fill đọc được ở trên; từng viền/outer glow riêng dưới, blur và alpha của glow độc lập | Chồng lớp làm nét dày/đục quá, glow che glyph kế, bitmap quá rộng |
| Chữ nằm trên bảng phải che JP gốc | Mask shape dưới chữ; clip/shape chia theo vùng che và occlusion | Mép antialias có hở; fade chữ làm JP gốc lộ bên dưới |
| Chữ bị vật thể trong cảnh che | Sign và mask occluder theo hai vùng/layer; có thể shape/clip FBF ở đoạn giao | Frame đầu/cuối che khuất, rìa vật thể, motion blur, thứ tự layer |
| Wipe/gradient/chuyển màu | Ưu tiên `\t`/`\clip` native khi đủ; chia band/shape hoặc FBF nếu biên/màu theo hình biến đổi | Banding, dấu Việt bị tách, sai BGR/alpha, clip mép cứng |

## Cách dựng và khoanh lỗi hình học nhiều lớp

- Tách yêu cầu thành chữ, phần che chữ gốc, vật thể che phía trước và lớp trang trí. Dựng bản tối thiểu đọc được trước, rồi thêm từng lớp có chức năng. “Mềm hơn” có thể là blur, alpha, độ nặng nét hoặc easing; chọn bằng ảnh hiện hành và thử riêng các thuộc tính ấy.
- Với cắt/gọt shape: ghi contour đang ở local hay screen space, drawing/clip scale, anchor và transform. Thử một đường cắt rõ trên bản tĩnh trước khi áp Boolean cả track. So silhouette có/không clip, holes và mép antialias; `merge` drawing commands không thay phép hợp hình học.
- Khi có đường nối/hở: render từng miếng trên nền tương phản, rồi render toàn bộ để kiểm alpha chồng, blur và cạnh clip cứng. Chỉnh hình học/overlap có kiểm soát; không tăng outline toàn chữ chỉ để che một seam ở mask.
- Với mask trên nền có texture/gradient hoặc đang fade, thử ngay frame khó nhất giữa fade/occlusion. Nếu mask phẳng không tái tạo được nền, cân nhắc đặt dịch cạnh sign, dựng nền cục bộ hoặc cơ chế khác theo brief; thêm nhiều lớp màu phẳng chưa giải quyết được texture bị lộ.
- Để làm shape/glyph editable, giữ text/font/outline gốc và phép biến đổi. Sau simplify/flatten/bake, so bản cũ và mới ở scale mục tiêu, đặc biệt dấu/counter/góc nhọn; số điểm ít hơn chỉ là một đặc tính dữ liệu.

Đọc [geometry-animation.md](geometry-animation.md) khi shape đổi theo phase; [color-palette-validation.md](color-palette-validation.md) khi lỗi đến từ alpha/màu; [typesetting-tracking.md](typesetting-tracking.md) khi layer đúng hình nhưng lệch vật thể.

## Mask và fade

Mask che JP gốc phải còn che trong suốt lúc chữ dịch đang fade; nếu mask cũng fade, chữ cũ có thể lộ. Chọn cách theo footage: đặt dịch ngoài vùng gốc, rút fade, mở rộng thời lượng mask, điều màu nền, hoặc tái dựng nền ngắn. Render frame trong **giữa fade**, không chỉ trạng thái hoàn tất. Phos nêu các lựa chọn và ví dụ nền chuyển động; không tự coi một cách là mặc định.

Với Shapery, `Clip to Shape` để tạo mask chỉnh được, `Shape to Clip` để tái dùng biên, `Shape Clipper` có thể loại phần shape ngoài clip thay vì giữ một mép clip cứng. `Shape Expand` bake tag vào contour, `Shape Merge` chỉ nối drawing commands, không tự boolean union; `Pathfinder` mới làm union/intersect/difference. Kiểm contour lỗ và winding sau thao tác. `Simplify`/`Flatten` thay đường hình, phải so silhouette trước/sau. Những macro này chỉ áp trên bản sao, so toàn bộ Text, Style, timing và các event ngoài selection.

## Nền hữu cơ ôm chữ và chuyển hình

Với mây/khói hoặc nền nhiều búp ôm hai dòng, lấy vùng **ink đã render** của từng dòng cùng outline/blur cần giữ làm căn cứ, không chỉ bounding box font hay chung một `\an`. Hai dòng dài ngắn khác nhau có thể cần vai/bậc trong silhouette. Giữ khoảng đệm theo đường chữ và kiểm riêng mép trên/dưới/hai bên; gọt đỉnh toàn cục để sửa một chỗ nhô có thể làm mất margin ở câu khác. Căn mép Nhật–Việt theo ink thật vì sidebearing font khác nhau; bù vị trí phải đi theo mọi state intro/stable/continuous/outro và mask, không chỉ frame ổn định.

“Tự nhiên” cần hình mẫu và ràng buộc quan sát được: nhịp búp lớn nhỏ/khoảng cách/độ cao khác nhau, mật độ phù hợp và biến thể theo từng cặp chữ. Random noise hoặc chuỗi hình tròn bán kính đều không tự thành mây. Giữ mẫu/seed nhất quán trong một đối tượng để không rung hình giữa frame; kiểm câu ngắn, câu dài và cặp lệch độ dài trước khi nhân toàn bài. Khi yêu cầu chỉ sửa bước hụt và đỉnh cao trên bản đã chốt, giữ các đặc điểm tốt của bản đó thay vì tạo một silhouette mới cho mọi câu.

Phân biệt đổi màu **theo không gian** (mảng sáng/xanh cùng tồn tại) với đổi màu theo thời gian; lời yêu cầu chất liệu mây không tự là một `\t` đổi màu toàn khối. Với “nhiều mảng nhỏ hợp thành khối lớn rồi rã”, phải theo dõi chính cấu trúc hình qua phase; vài hạt phóng to cộng một khối nền fade-in độc lập không đáp ứng cơ chế ấy. `\t` chỉ nội suy các thuộc tính được renderer hỗ trợ, không morph đường drawing/vector clip tùy ý; dùng generator/FBF khi contour thật sự đổi. [Aegisub: Animated transform](https://aegisub.org/docs/latest/ass_tags/#animated-transform).

Đặt cửa sổ phase chung cho chữ và nền khi brief yêu cầu chúng liên kết. Mask reveal, alpha fade và blur là các lớp điều khiển khác nhau; người dùng có thể muốn kết hợp cả ba. Giữ continuous đã duyệt, không tự thêm trượt/bounce để “mượt hơn”. Kiểm đoạn nối cả hai phía với tiến trình dùng chung, độ phủ/độ đục và motion của từng lớp, rồi xem đầu–giữa–cuối pha thay vì chỉ hình mây hoàn chỉnh.

## Chuyển động và ngân sách render

Native transform giữ số dòng thấp và nguồn gọn khi chuyển động đơn giản; FBF chỉ cho phần thực sự thay shape/occlusion/perspective. Nếu video hoạt họa giữ ảnh hai frame liên tiếp, có thể thử cadence tương ứng nhưng xác nhận từng span; không áp “2s” lên mọi cảnh. Khi chia FBF, dùng PTS thật, `[Start, End)` không hở/đè, chú ý cut và line đang fade. Khi nhiều band/glow/clip, benchmark vùng peak theo bitmap/cache như [render-performance.md](render-performance.md), giữ candidate dễ rollback. [Phos: Frame by Frame](https://phoscity.github.io/Phos-Fansubbing-Guide/Typesetting/Frame%20by%20Frame/) cho công cụ FBF; vẫn phải xem footage để quyết định cadence.
