# Cách đối chiếu theo từng cue EN

Tài liệu này hướng dẫn quyết định ngữ nghĩa khi EN và VI chia cue khác nhau. Đơn vị cần giải quyết luôn là cue EN; VI là nơi tìm bằng chứng dịch tương ứng.

## Vòng quyết định cho một cue EN

1. Đọc EN hiện tại và ngữ cảnh EN liền kề hoặc đồng thời. Xác định ý chính, người nói, câu đang tiếp nối hay lượt thoại mới. Không lấy độ dài hoặc style làm đại diện cho nội dung.
2. Xem các VI gần thời gian, gồm cả câu trước/sau. Nếu không thấy lời phù hợp, tìm rộng hơn theo tiến trình câu chuyện; danh sách `cluster` không bao trùm mọi khả năng.
3. So từng khả năng với câu hỏi từ EN: VI này có diễn đạt lời EN trong ngữ cảnh không, có trộn lời của người khác hoặc thêm ý thuộc EN khác không? Bản dịch có thể đảo trật tự, lược bớt hoặc diễn đạt lại, nên đối chiếu ý và chức năng của lời thoại thay vì số từ.
4. Chọn nguồn sau khi khớp nghĩa: nguyên cue, một đoạn của cue, hoặc nhiều đoạn. Nếu còn hai cách gán hợp lý, đối chiếu cùng các EN/VI liên quan rồi mới chốt. Cue VI chưa dùng không phải lý do để gán nó cho EN đang xét.
5. Viết `vi_text` từ phần đã chọn, kiểm tra lần nữa từ EN sang VI. Sau khi duyệt mọi EN, đọc lại mạch thoại để phát hiện ý bị mất, lặp hoặc đặt sai chỗ.

## Khi ranh giới hai bản khác nhau

Một cue EN có thể lấy nhiều cue VI; một cue VI có thể chứa lời ứng với nhiều cue EN. Tách theo phần nghĩa thực sự có trong nguồn VI, không tách bằng số ký tự hoặc vì số cue hai bên khác nhau. Nếu một phần VI diễn đạt lại nhiều ý EN, xét cả cụm EN để đặt lời VI ở vị trí dễ hiểu và tránh lặp. Không tự tạo câu VI mới chỉ để mỗi EN có một dòng chữ.

Tham chiếu cả cue chỉ cần `vi_id`. Với một phần cue, ghi `[start,end)` theo `source_text` sau khi chọn xong ý. Các phần của một EN phải theo thứ tự nguồn; cùng ký tự VI không được cấp cho hai EN trong schema hiện tại.

## Cue chồng thời gian và người nói

Khi nhiều EN dùng chung vùng VI, đọc chúng như một nhóm để phân biệt người nói và nội dung, rồi trả kết quả về từng EN ID. Dấu `-` trong VI có thể đánh dấu lượt thoại; giữ nó khi cue EN tương ứng có nhiều người nói, bỏ khi đó chỉ là dấu phân vai của nguồn VI và EN hiện tại có một người. Style và thời gian chỉ hỗ trợ phân biệt, không thay thế việc đọc nghĩa.

## Chưa tìm thấy lời VI

Chỉ dùng `missing` sau khi kiểm tra nguồn VI quanh thời gian dự kiến, xem độ lệch thời gian có thể có, và đối chiếu các EN lân cận hoặc đồng thời. Một ứng viên rỗng của `cluster` chưa chứng minh nguồn VI thiếu bản dịch. Nếu ý EN đã được diễn đạt trong lời VI gán cho cue EN khác, ghi chú điều đó khi rà soát; `missing` trong ASS chỉ cho biết cue này không có chữ VI riêng. `missing_review` ghi nhận việc tìm kiếm này; `semantic_review` ghi nhận việc đã đọc và đối chiếu một match thực sự. Các cờ review không phải bằng chứng mà script tự tạo ra.

`Effect` do script tính từ các phần nguồn đã gán. Số lượng ứng viên thời gian không quyết định `split` hay `merge`; chỉ các tham chiếu nguồn thực tế mới quyết định.


## Rà phong cách và xác minh bằng tiếng Nhật

Khi có các tập Việt đã duyệt, rút ra ghi chú gọn theo nhân vật/quan hệ: cách xưng hô, cách gọi, thuật ngữ, độ khẩu ngữ, nhịp và những cách diễn đạt đã thành quy ước. Dùng tham chiếu này cho cả tập, không chỉ đại từ. Với câu/cảnh lặp, giữ cách dịch cũ khi lời Nhật và ngữ cảnh vẫn cùng nghĩa; nếu lời Nhật khác hoặc bản cũ sai, sửa theo JP. Không bê lời ở cảnh khác chỉ vì cùng nhân vật.

JP dùng để xác nhận nghĩa và giải quyết chỗ EN lệch, không thay thế VI nguồn trong việc tìm câu đã dịch. Nếu người dùng xác nhận VI nguồn thực sự thiếu và yêu cầu điền, có thể soạn câu VI từ JP/ngữ cảnh vào Full; theo dõi tình trạng thiếu JP riêng cho đầu ra trực dịch. Bản Full auditable giữ EN ẩn và nhãn ghép/tách do exporter tạo. Chỉ dọn provenance khi người dùng yêu cầu riêng một bản biên tập cuối; không tự hậu xử lý output exporter.
