# Map schema v4 và xuất ASS

Đọc tài liệu này khi ghi quyết định hoặc xử lý lỗi `compile-map`/`export`.

## Quyết định ngắn cho từng EN

Ghi một JSON object trên mỗi dòng của file `.jsonl`, theo thứ tự EN. `parts` dùng `[vi_id]` cho nguyên cue hoặc `[vi_id,start,end]` cho một phần cue. `start,end` là vị trí ký tự Unicode `[start,end)` trong `source_text`. `text` là lời VI sẽ xuất.

```json
{"en":0,"parts":[[0]],"text":"Hẹn gặp lại.","reviewed":true}
{"en":1,"parts":[],"text":"","reviewed":true}
```

Chỉ ghi `reviewed: true` sau khi đã kiểm tra nghĩa, đủ ý thiết yếu, không thừa và đúng người nói. Với dòng không có nguồn VI riêng, phải kiểm tra vùng ứng viên cùng các EN liên quan trước. `compile-map` chỉ mở rộng lời xác nhận này thành các cờ schema v4; nó không tự xét nghĩa. Phải có đúng một quyết định cho mỗi EN ID. Các phần nguồn phải theo thứ tự và không được dùng trùng ký tự VI giữa các EN. Chỉ khi cần, thêm `"repetitions":[[0,2]]` để khai báo lặp phần nguồn số 0 hai lần, hoặc `"note":"..."` để ghi lý do căn chỉnh.

## Schema v4 do script tạo

```json
{
  "schema_version": 4,
  "complete": true,
  "source": {"en_file": "/abs/en.ass", "vi_file": "/abs/vi.srt"},
  "mappings": {
    "0": {
      "source_parts": [{"vi_id": 0}],
      "vi_text": "Hẹn gặp lại.",
      "semantic_review": {
        "meaning_matches": true,
        "coverage_complete": true,
        "no_extra_content": true,
        "speaker_matches": true
      }
    },
    "1": {
      "source_parts": [],
      "vi_text": "",
      "missing_review": {
        "candidate_window_checked": true,
        "concurrent_and_neighboring_en_checked": true
      }
    }
  }
}
```

Chỉ đặt cờ review thành `true` sau khi đã đối chiếu thực sự. `coverage_complete` xét ý thiết yếu trong ngữ cảnh, không đòi giống từng từ. Entry không có chữ VI được gán cần `source_parts` và `vi_text` rỗng, cùng hai cờ `missing_review` là `true`. `repetitions` ghi xuất xứ khi cố ý lặp một cụm VI đã chọn trong đầu ra, theo dạng `[{"source_part_index": 0, "times": 2}]`.

Script tự tính `Effect`: `merge` khi một EN dùng nhiều cue VI; `split` khi các phần riêng của một cue VI được gán cho nhiều EN; `split+merge` khi có cả hai; `missing` khi EN này không được gán chữ VI; để trống khi chỉ một cue VI cấp nguồn cho EN này. `missing` không chứng minh nguồn VI thiếu ý đó: xem các mapping EN lân cận trước khi kết luận.

`--offset` của `sanitize-sync` nhận `auto`, `none` hoặc số giây. Nếu auto không được chấp nhận, hoặc lệch so với các đoạn đã đối chiếu nghĩa, chạy lại với offset phù hợp hoặc `none`. Dùng cùng lựa chọn `--styles` ở `sanitize-sync` và `export`. `--dialogue-out` tùy chọn xuất riêng thoại. `convert-map` chỉ tạo bản nháp, không xác nhận khớp nghĩa.
