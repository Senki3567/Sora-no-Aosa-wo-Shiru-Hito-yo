# Vietnamese wording and line breaks

Use this guide when the alignment task includes light proofreading or line-break adjustments. These are practical preferences, not hard rules: follow the supplied translation's established voice and the subtitle's needs.

## Preserve the translation

- Keep the source's meaning, level of formality, and established pronouns. Do not rewrite a translation just to make it resemble the English wording.
- Correct clear typing or spelling mistakes when the intended wording is unambiguous. Adjust punctuation when needed for readable dialogue, without changing its force or meaning.
- Remove accidental duplicate spaces and spaces around punctuation. Preserve intentional formatting and ASS tags.
- Do not add translated content that is absent from the Vietnamese source. If no source wording matches an English cue, use the alignment workflow's `missing` handling.

## Choose readable line breaks

- Prefer a natural phrase or clause boundary. Avoid splitting a word, a name, a number with its unit, or a phrase whose parts need to stay together.
- Consider subtitle width, reading speed, timing, and the visual balance of the two lines. These are competing considerations; there is no universal character threshold or required line shape.
- A short line may stay on one line. A longer line may also stay intact when it reads better or fits the subtitle layout.
- Use a speaker break when one destination cue genuinely contains multiple speakers. Do not preserve a source dash when the destination cue contains only one speaker.
- Follow the target format's line-break convention. For ASS, use `\\N` when a deliberate line break is needed.

When no proofreading or reflow is needed, keep the selected source wording as it is.
