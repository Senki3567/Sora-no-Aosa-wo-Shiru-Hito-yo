# Time thoại và câu hát từ audio, cut và PTS

Đọc khi tạo hoặc sửa timing. Các guide timing của cộng đồng mô tả nhiều phong cách; số mili giây mặc định của một nhóm chỉ là điểm thử. Timing postprocessor không thay QC thủ công, và keyframe không phải danh sách đầy đủ của mọi scene cut. [unanimated: Timing Basics](https://unanimated.github.io/timing-basics.htm), [Timing without TPP](https://unanimated.github.io/timing-without-tpp.htm), [Timing Notes](https://unanimated.github.io/timing-notes.htm), [yaneura: timing links and QC warning](https://yaneura.neocities.org/fansub).

## Bằng chứng trước thao tác

Xác nhận video/audio đúng bản, độ trễ audio, CFR/VFR và timecodes. Dùng waveform và nghe để đánh dấu âm đầu/cuối, khoảng im, người nói và câu bị chồng; dùng frame/PTS để ghi cut. Scene detector hoặc keyframe file chỉ gợi ý vị trí kiểm tra: keyframe mã hoá không nhất thiết là cut, cut không nhất thiết tạo keyframe phù hợp. Đừng suy thoại từ waveform một mình hoặc từ Text EN.

Với mỗi cue, lưu mốc nghe được `speech_start/speech_end`, cue Start/End dự kiến, cut gần nhất và lý do nếu lệch. Câu hát lưu onset từng syllable/nguyên âm hoặc nhịp nhạc theo nguồn đã được duyệt; giữ mốc tuyệt đối trước khi sinh `\k` và effect. Khi thiếu audio hoặc khác bản video, gắn cờ cần nghe/đối chiếu thay vì gán thời gian chính xác giả.

Một record đủ để người khác kiểm lại có thể gồm: cue identity/hash; speaker hoặc `unknown`; `audio_span`; Start/End trước và sau; cut trước/sau; cue kề và khoảng gap/overlap; loại quyết định (`onset`, `lead`, `link`, `snap`, `split`, `merge`, `shift`); lý do và mức chắc chắn. Không cần bảng này cho từng cue sạch, nhưng phải có cho batch shift, cue tranh chấp và ngoại lệ.

## Ba lượt thao tác

1. **Rough từ audio:** nghe một đoạn đủ ngữ cảnh, đánh dấu lượt nói và vùng âm thanh. Waveform giúp định vị, nhưng phụ âm nhẹ, hơi thở, nhạc/SFX và thoại chồng cần nghe lại. Với nguồn dịch có split/merge, gom mẩu thành một span lời nói trước khi đánh giá cắt âm.
2. **Fine từng biên:** nghe trước/sau Start và End trong playback bình thường; điều chỉnh theo âm đầu/cuối, nhịp đọc và câu kế. Quét cut bằng frame thật; quyết định snap hoặc giữ qua cut dựa vào cảnh và người nói, không theo keyframe mã hóa. Với sign, Start/End ưu tiên frame sign thực xuất hiện/mất; với thoại, onset/end và khả năng đọc là bằng chứng chính.
3. **QC liên tục:** chạy cả đoạn không dừng ở từng cue. Kiểm flash, lead-in/out quá lớn, gap vô lý, hai cue đổi người nói, thoại chồng, cut bleed và đoạn sau OP/recap. Xem diff trước/sau TPP; chỉnh ngoại lệ thay vì lặp postprocessor. [unanimated: timing without TPP](https://unanimated.github.io/timing-without-tpp.htm) nêu lý do rough timing có thể nhanh hơn khi không dựa hoàn toàn vào TPP.

## Chọn biên cue

- Đặt Start gần sự bắt đầu lời, nhưng xét nhận thức người xem và cut. Đặt End đủ để đọc câu sau khi âm dứt nếu cảnh cho phép; không kéo qua shot làm subtitle thuộc về cảnh khác.
- Với hai cue nối nhau, ưu tiên rõ ràng người nói và nhịp nghĩa. Đừng dùng overlap hoặc nối kín mọi khoảng im theo thói quen. Nếu hai người nói đồng thời, mô hình thành hai cue/layer theo yêu cầu hiển thị, không ép chung thành một câu.
- Với câu dài, đo xem người xem có đọc được ở tốc độ thực; split tại đơn vị nghĩa, không chỉ tại dấu câu hoặc một ngưỡng ký tự cố định. Sau split/merge, nghe và kiểm tra toàn vùng lân cận.
- Snap vào cut khi ranh giới nghĩa và shot cho phép. Nếu không, giữ nhịp nói; một cut không tự chứng minh cue phải kết thúc tại đó. Kiểm tra frame trước/tại/sau cut và hiện tượng bleed.

ASS Start/End lượng tử centisecond nhưng video có frame PTS riêng. Quy tắc rounding phải hướng tới frame đầu/cuối thực cần hiển thị; dùng `[Start, End)` và xác nhận bằng render ở hai phía biên. VFR không thể kiểm chứng bằng giả định `frame = round(t * fps)` cố định. TPP/lead-in/lead-out có thể cải thiện hàng loạt rồi gây overlap, clip ở cut hoặc sai cue ngắn; áp trên bản sao, xem diff thời gian và QC các ngoại lệ thay vì chạy lại mù quáng. [video-evidence.md](video-evidence.md) giải thích đo PTS và lấy frame.

Nếu hai speaker ngắt nhau, phân biệt **âm thanh thực sự đồng thời** với một chuyển lượt nhanh. Khi không cần hai dòng cùng hiện để hiểu, một cue đổi ngay lúc người thứ hai bắt đầu có thể dễ đọc hơn; nếu đồng thời có ý nghĩa, giữ hai event và kiểm vị trí/layer. Đừng để TPP tự nối hai dòng độc lập rồi tạo kết luận giả về overlap. [unanimated: Timing Notes](https://unanimated.github.io/timing-notes.htm) bàn riêng tình huống này. Không lấy các con số lead/CPS trong guide làm luật cứng cho VI hay cho mọi thể loại.

Batch operation phải nêu invariant: shift giữ duration và quan hệ nội bộ; link chỉ đổi boundary đã chọn; snap không được tạo overlap hoặc tăng tải đọc ngoài mức chấp nhận; split/merge giữ toàn bộ lời và speaker order. Chạy trên candidate, thống kê cue đổi theo loại, rồi nghe/xem sample ở đầu–giữa–cuối và mọi ranh version/cut. Một batch có số delta đồng đều vẫn có thể sai nếu nó đi qua OP/recap khác bản.

## Chẩn đoán khi timing “không khớp”

| Dạng lỗi quan sát | Bằng chứng cần thêm | Chọn phép sửa |
|---|---|---|
| Nhiều anchor lệch gần cùng một lượng | Nghe/xem mốc độc lập đầu–giữa–cuối của đúng bản media | Thử offset cố định, rồi kiểm lại anchor và cut; không ép clustering nếu không có bước nhảy |
| Càng về cuối càng lệch | Timebase/tốc độ media, các delta theo thời gian | Kiểm drift/rate trước; không kéo từng cue thủ công để che một lỗi tốc độ chung |
| Chỉ nhảy sau OP/recap/cảnh chèn | Frame/câu hai bên ranh và khác biệt bản phát hành | Chia đoạn/anchor theo cut thật; giữ mapping cho vùng không đổi |
| Một câu bị flag “cắt âm” nhưng cue kế nối tiếp ý | Audio cả lượt nói và mapping split/merge | Kiểm span tổng rồi các biên nội bộ; tránh flag mọi cue con là cutoff |
| Chữ đọc quá gấp dù biên âm đúng | Playback thật, wording/line break và khoảng trống cảnh | Chọn ngắt/gộp, biên tập hoặc điều timing trong quyền được giao; CPS đơn lẻ không quyết định |
| Chỉ player/preview lệch | Cùng native frame/PTS, event active, fonts và pipeline phát | Dùng [playback-diagnostics.md](playback-diagnostics.md); không đổi timing nguồn trước khi xác định nơi lệch |

Khi nghe chưa rõ vì nhạc/SFX, nghe vùng rộng hơn hoặc nguồn audio đúng/khác kênh đã được cấp nếu có; spectrogram chỉ hỗ trợ tìm vùng âm, không tự chứng minh speaker/từ. Sau mỗi kiểu sửa, kiểm vùng vừa đổi và mốc kiểm độc lập; giữ bất định cụ thể thay vì gán độ chính xác không có bằng chứng.

## Pass cuối

Quét theo thứ tự playback để phát hiện flash, cue quá ngắn, khoảng trống bất thường, out-of-order, cut bleed, subtitle của nhân vật còn hiện sau khi người khác nói, và nhịp lặp OP/ED lệch audio. Sau khi retime toàn tập, kiểm tra đầu/giữa/cuối để phân biệt offset cố định với drift. Báo cue nào nghe chưa xác thực; chỉ sửa trường Start/End nếu phạm vi cho phép.
