# Bài thực hành bao quát workflow ASS Studio

Đọc khi đánh giá một bản skill hoặc một harness/model. Bộ này kiểm cách agent chọn nguồn, khoanh nguyên nhân, sửa đúng phạm vi và nghiệm thu artifact; không phải checklist bắt chạy hết cho mọi công việc. Mỗi case chưa thực sự chạy trên input có đáp án phải mang trạng thái `not_run`. Validator markdown, unit test helper hoặc số lượng tài liệu không được đổi thành điểm chất lượng prompt.

## Ma trận tình huống

| Họ bài toán và prompt mẫu | Oracle/bằng chứng để chấm | Bẫy cần bắt |
|---|---|---|
| Font/layout: “Tìm font gần sign này nhưng giữ layout” | Bảng cùng toàn câu/glyph Việt trên một baseline; fontselect log hoặc font dùng thật; so width, baseline, weight | Đổi đồng thời font/scale/spacing rồi không biết nguyên nhân; chỉ so tên/font preview vài chữ |
| Shape/mask: “Chữ phải đi sau vật thể trong 12 frame” | Raw + layer/mask-only + composite tại biên occlusion; contour cùng hệ tọa độ | Mask đẹp ở một frame nhưng lộ giữa fade; đảo layer để che luôn phần phải thấy |
| FX/animation: “Làm intro mềm hơn, giữ nhịp đã duyệt” | Phase/clock endpoints; onset tuyệt đối trước/sau; render tại chuyển pha | Dời cả syllable clock; chồng `\t` xung đột; output đẹp nhưng mất source chỉnh được |
| Màu/alpha/blur: “Khớp glow của sign gốc” | Cùng frame/renderer/background; isolate core/halo/alpha; composite chứ không chỉ RGBA overlay | Suy một RGB duy nhất từ pixel đã blend; tăng blur để bù sai alpha |
| KFX/Automation: “Script chạy nhưng không thấy effect” | Inventory nguồn/component/output; xác định stock/The0x/nyaa và đúng build; viết một dòng ASS đích làm oracle; fixture nhỏ; dependency/selection log; generated Events; renderer output; đối chiếu số line/layer/clock rồi truy output về template | Trộn dialect; thấy exit 0 rồi chốt; debug renderer trong khi generator không sinh event; tạo FBF/particle toàn bài trước khi khóa primitive và expansion budget |
| Motion/perspective: “Bám bảng qua đoạn camera nghiêng” | Landmark/PTS/native coords; held-out residual; frame thiếu; glyph composite qua quỹ đạo | Chỉ khớp bốn góc hoặc đầu–cuối; nội suy qua occlusion không ghi; mask đúng nhưng glyph drift |
| Timing/sync: “Bản này lệch dần về cuối” | Nhiều anchor audio/cut độc lập; phân biệt offset, drift, piecewise và version cut | Sửa global shift từ một cue; dùng waveform để kết luận speaker; coi pause có chủ ý là lỗi |
| OCR/rescue: “Lấy đúng chữ Việt bị che dần” | Crop/sequence gốc, transcript/provenance, uncertainty theo glyph/frame, retry scope | Dịch từ EN để lấp chữ không đọc được; biến lỗi API thành `missing`; chỉ OCR một frame |
| Dịch/biên tập: “Câu này tự nhiên hơn nhưng không đổi nghĩa” | Semantic commitments, context/speaker, phương án VI và reverse check; reading pass | Viết trôi chảy nhưng mất phủ định/chủ thể/quan hệ; timing score quyết định nghĩa |
| Căn EN–VI: “Đưa đúng mẩu Việt có sẵn sang cue này” | EN làm câu hỏi; candidates VI nguyên văn; cue kề/provenance; kiểm thiếu/lặp/rò ý | Dịch mới từ EN; chọn theo timestamp gần nhất; merge hai người nói vì text giống nhau |
| Field edit/sync: “Chỉ đổi Actor; giữ mọi byte khác” | Baseline hash, event identity, candidate field diff, BOM/newline/Comment/duplicate rows | Rewrite toàn file; dùng số dòng sau reorder; lấy một phía ghi đè conflict ba phía |
| Hiệu suất: “Giảm lag sign nhưng giữ hình” | Profile cùng scene/renderer/cache; peak layer/bitmap/CPU; image comparison | Chỉ giảm dung lượng ASS; benchmark warm cache thay cho seek; nhanh vì mất layer/font |
| Asset/nhiều tập/bàn giao: “Đóng gói bản dùng được cho 12 tập” | Per-episode variant checks; dependency walk; archive/mux được mở lại; hash, tracks, fonts, endpoints | Kiểm working folder thay vì package; font ngoài thư mục nhưng không attach; lấy một tập đại diện báo đủ 12 |

Tập hình chi tiết hơn nằm ở [visual-evals.md](visual-evals.md). Các workflow OCR, alignment và field edit có thể dùng test kỹ thuật để kiểm parser/IO, nhưng test đó không tự chấm khả năng đọc ảnh, nghe audio hay quyết định ngôn ngữ.

## Các tình huống hồi quy từ phản hồi thực tế

| Prompt/fixture | Điều kiện cần quan sát |
|---|---|
| “Bản cũ tốt hơn; chỉ sửa búp hụt và đỉnh cao”, kèm một hình khoanh lỗi | Bắt đầu đúng baseline, giữ đặc điểm đã duyệt, rà các shape cùng cơ chế; không gọt đỉnh làm hỏng margin hoặc rebuild toàn bộ |
| “Kiểm toàn bộ Actor bằng audio, cấm retime”, batch có speaker ID trùng và cue chưa có cờ | Ledger phủ toàn corpus; không dùng mặc định MATCH hay map speaker ID toàn phim; ghi chưa nghe nếu capability thiếu; không sửa timing |
| “Audit thêm bản dịch”, corpus đúng nghĩa nhưng có vài cách viết khác hợp lệ | Áp tiêu chí ổn định, không bắt buộc tạo patch; nguồn JP/context phân xử lỗi, không script từ khóa chấm ngữ nghĩa |
| “Bung cột Việt đã sửa từ bảng gọn”, có nhóm cùng chữ khác Actor, Comment, tag nội bộ và ASS đích đã đổi | No-op giữ bytes, edit đổi đủ đúng thành viên; row ID/header không lệch khi thêm cột; stale baseline bị phát hiện, review metadata không xuất |
| “Giảm dung lượng bằng glyph nhưng giữ FX”, font hệ thống đúng còn attachment cố ý hỏng | Font decode/hash và test đường nạp riêng bắt lỗi che bởi fallback; chữ native và glyph khớp layout qua biên pha, không chỉ so hai intermediate |
| “Render lại toàn bộ sign theo fold”, hai nhóm sát nhau và master có sửa chưa commit | Đủ mỗi nhóm, raw/render cùng cut, master nguyên vẹn; cleanup/revert chỉ theo manifest, không checkout HEAD/remote |

Các hàng này là ca đánh giá cần input/oracle thực và khả năng tương ứng; việc thêm chúng vào tài liệu không có nghĩa đã chạy hoặc đã đạt trên bất kỳ model/harness nào.

## Cách chạy và ghi kết quả

Cho agent prompt, input và skill; giữ oracle tách khỏi phần agent nhìn nếu đang benchmark. Chấm cả quá trình chọn bằng chứng lẫn artifact cuối. Mỗi case ghi:

- `status`: `pass`, `partial`, `fail` hoặc `not_run`;
- harness/surface/model/version nếu runtime cung cấp;
- input/hash, quyền sửa và target renderer/player;
- artifact/cue/frame/log dùng làm bằng chứng;
- điều đúng, lỗi quan sát được và loại sai lầm;
- thay đổi instruction/helper đề xuất và case cần chạy lại.

Chỉ so model/harness trên cùng case, input, quyền tool và oracle. Thiếu audio/vision/renderer phải được ghi như capability thiếu hoặc check chưa chạy, không tự quy thành lỗi suy luận hay pass. Sau khi sửa skill, chạy lại case từng thất bại cùng một case lân cận để phát hiện quy tắc quá khớp một ví dụ.

## Tách kiểm helper khỏi kiểm agent

Có thể chạy các regression suite đi kèm để bắt hỏng parser, field guard, transform, ảnh và alignment. Báo chúng theo tên suite và phạm vi thật. Chúng không thay thế 13 case trên, vì không gọi model và không có footage/audio/ngữ cảnh người dùng thật. Báo riêng số case prompt đã chạy; nếu chưa chạy, giữ toàn bộ là `not_run`.
