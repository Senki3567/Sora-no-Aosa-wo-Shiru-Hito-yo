# Tích hợp Thực chiến Chuyên sâu: VectorCraft & EffectCraft vào ASS Studio

Tài liệu quy định kiến trúc kỹ thuật và quy trình thực chiến khi kết hợp **VectorCraft** và **EffectCraft** vào chu kỳ nhận thức 4 vai trò (**4-Role Cognitive Loop**) của `ass-studio`. Đây không phải là cấu hình bọc ngoài hình thức, mà là công cụ trực tiếp giải quyết các nút thắt cổ chai (bottlenecks) bare-metal trong việc tạo sign, vẽ vector, tracking phối cảnh và kiểm định thị giác.

---

## 1. Phân tích Nút thắt Cũ & Bước nhảy Kỹ thuật Thực tế

| Khâu sản xuất ASS | Cách làm cũ (Trước đây) | Hạn chế / Điểm gãy | Giải pháp Thực chiến mới với Craft Apps |
|---|---|---|---|
| **Vẽ Vector & Logo (`\p1`)** | Dùng `fontTools` trích glyph từ font, hoặc đoán mò tọa độ `m x y b...` bằng mắt. | Không vẽ được logo anime mới, biểu tượng, khung viền, ruy băng; không nắn được điểm Bézier có visual feedback. | **VectorCraft**: Dựng hình Bézier trên canvas, nắn anchor points, dùng `pathfinder` đục lỗ/gộp khối; `craft_bridge.py svg-to-ass` nâng bậc $Q \to C$ tự động ra `\p1`. |
| **Mask che vật cản (`\clip`)** | Đo bounding box chữ nhật, hoặc cắt thô bằng đa giác ít điểm. | Khi có nhân vật chuyển động đè qua biển hiệu (tóc, tay, vạt áo), mask chữ nhật làm lộ chữ gốc hoặc cắt cụt nhân vật. | **VectorCraft**: Vẽ đường bao contour bám sát silhouette nhân vật bằng Pen tool; xuất mask phức hợp `\clip(m...)` hoặc `\iclip(m...)` sub-pixel. |
| **Motion Tracking & Physics** | Đo landmark 4 điểm thủ công (`motion_fit.py`), hoặc Blender $\to$ AAE Export $\to$ Aegisub-Motion. | Đo tay dễ drift/nhiễu; không mô phỏng được vật lý rung (wiggle), nảy (spring overshoot), quán tính hoặc phân cấp cha-con (parent-child rigs). | **EffectCraft**: Chạy After Effects ExtendScript (`effectcraft.cli script`), mô phỏng biểu thức toán học, trích xuất toạ độ tại đúng video PTS qua `extract-keyframes`. |
| **Kiểm chứng Thị giác (Critic Loop)** | Mux video hoặc compile ASS $\to$ `libass_render.py` $\to$ so sánh với raw frame. | Nếu lệch, không phân định được lỗi do đường tracking sai hay do lúc biên dịch sang tag `\t` bị méo. | **EffectCraft Dual-Diff**: Render frame tham chiếu từ EffectCraft trong ~700ms (`render-frame`), đối chứng kép: Raw vs EffectCraft (chuẩn model) $\to$ EffectCraft vs ASS (chuẩn biên dịch). |

---

## 2. Quy trình Thực chiến theo Chu kỳ 4 Vai trò (4-Role Cognitive Loop)

```mermaid
flowchart TD
    subgraph Role1["1. Decomposer (Dịch ngược Tín hiệu)"]
        R1_Raw["Video Raw Frames"] --> R1_VC["VectorCraft: Vẽ Contour Mask vật cản foreground"]
        R1_Raw --> R1_EC["EffectCraft: Rigging & Tracking bề mặt comp"]
    end

    subgraph Role2["2. Motion Architect (Kiến trúc Sáng tạo)"]
        R1_VC --> R2_VC["VectorCraft: Boolean Pathfinder & Tinh chỉnh Anchor"]
        R1_EC --> R2_EC["EffectCraft: Mô phỏng Easing / Expressions / Parent-Child"]
    end

    subgraph Role3["3. Executor / Compiler (Biên dịch ASS)"]
        R2_VC --> R3_Bridge1["craft_bridge.py svg-to-ass: Nâng bậc Q->C ra \\p1 / \\clip"]
        R2_EC --> R3_Bridge2["craft_bridge.py extract & keyframes-to-ass: Xuất multi-segment \\t hoặc FBF"]
        R3_Bridge1 --> R3_ASS["Candidate .ass File"]
        R3_Bridge2 --> R3_ASS
    end

    subgraph Role4["4. Perceptual Critic (Giám khảo Đối kháng Kép)"]
        R3_ASS --> R4_Libass["libass_render.py"]
        R2_EC --> R4_ECRender["effectcraft.cli render-frame (700ms)"]
        R4_Libass --> R4_Diff["visual_evidence.py (Diff kép: Raw vs EC & EC vs ASS)"]
        R4_ECRender --> R4_Diff
        R4_Diff -->|Phát hiện lệch mép| R2_VC
        R4_Diff -->|Phát hiện trượt nhịp| R2_EC
    end
```

---

## 3. Thao tác Chi tiết Từng Bước

### Bước 1: Decomposer & Precision Masking (VectorCraft)
1. Lấy frame đại diện chứa vật cản đè lên sign qua `video_frames.py`.
2. Mở VectorCraft (hoặc chạy qua MCP tool):
   - Đặt frame làm background reference.
   - Dùng `vectorcraft.draw_path` phác thảo đường bao che vùng nhân vật đè lên sign.
   - Kiểm tra trực tiếp canvas bằng `vectorcraft.render_preview` hoặc `vectorcraft.ui_screenshot`.
3. Xuất mask sang ASS:
   ```bash
   python3 scripts/craft_bridge.py svg-to-ass ~/snap/vectorcraft/current/ass_studio_work/mask.svg --format clip
   ```
   Kết quả trả về thẻ tag:
   `{\clip(m 450 320 b 480 310 520 340 540 380 l 450 380 c)}`

### Bước 2: Motion Modeling & Keyframe Sampling (EffectCraft)
1. Dựng comp chuyển động trong EffectCraft (thay thế hoàn toàn việc phải mở After Effects thương mại):
   - Chạy ExtendScript trực tiếp:
     ```bash
     /snap/bin/effectcraft.cli script --eval '
     var comp = app.project.activeItem;
     var layer = comp.layer("SignText");
     // Áp dụng biểu thức nảy đàn hồi (spring overshoot)
     layer.property("Position").expression = "var freq=3; var decay=5; var n=0; if (numKeys>0){...};";
     '
     ```
2. Trích xuất dữ liệu vị trí/góc xoay chính xác tại từng frame PTS của video:
   ```bash
   python3 scripts/craft_bridge.py extract-keyframes \
       --project ~/snap/effectcraft/current/ass_studio_work/sign.ecproj \
       --layer "SignText" \
       --start-s 1.250 --end-s 3.500 --fps 23.976 \
       --output ~/snap/effectcraft/current/ass_studio_work/track_data.json
   ```

### Bước 3: Biên dịch Thông minh sang ASS (`craft_bridge.py`)
1. **Trường hợp quỹ đạo mượt (Piecewise Polynomial)**:
   Biên dịch thành chuỗi `\t(t1, t2, \pos(x,y)\frz...)` liên tục, triệt tiêu việc tạo hàng trăm dòng event thừa, bảo tồn cache bitmap của `libass`:
   ```bash
   python3 scripts/craft_bridge.py keyframes-to-ass \
       ~/snap/effectcraft/current/ass_studio_work/track_data.json \
       --mode t --style Sign_Kanji --text "日本語看板"
   ```
2. **Trường hợp camera rung lắc mạnh (High-frequency Shake / 3D Homography)**:
   Biên dịch thành chuỗi Frame-by-Frame (FBF) bám đúng cadence hoạt họa (1s/2s/3s), khóa cứng PTS tuyệt đối để không bao giờ bị restart tag:
   ```bash
   python3 scripts/craft_bridge.py keyframes-to-ass \
       ~/snap/effectcraft/current/ass_studio_work/track_data.json \
       --mode fbf --fps 23.976 --style Sign_Kanji --text "日本語看板"
   ```

### Bước 4: Vòng lặp Đối chứng Kép (Perceptual Critic Dual-Diff)
Không đợi encode toàn bộ tập phim mới phát hiện sai. Thực hiện nghiệm thu 2 tầng ngay tại bàn làm việc:
1. **Tầng 1 (Kiểm định Mô hình Motion)**:
   Render frame tại giây $t = 2.0$ trong EffectCraft:
   ```bash
   /snap/bin/effectcraft.cli render-frame --time 2.0 --out ~/snap/effectcraft/current/ass_studio_work/ec_ref.png
   ```
   So sánh `ec_ref.png` với frame raw gốc qua `visual_evidence.py compare`. Nếu khác biệt $> 5\%$, hiệu chỉnh lại tracking/expression trong EffectCraft.
2. **Tầng 2 (Kiểm định Bản dịch ASS)**:
   Render frame ASS tương ứng qua `libass_render.py` $\to$ `ass_cand.png`.
   So sánh `ass_cand.png` với `ec_ref.png`. Phép so sánh này cô lập 100% lỗi cú pháp tag hoặc sai lệch nội suy của renderer `libass`.

---

## 3. Ràng buộc Hệ thống Bare-Metal (Bắt buộc Tuân thủ)

1. **Ranh giới Snap Sandbox (AppArmor Strict Confinement)**:
   * **CẤM**: Truyền đường dẫn `/tmp/...` hoặc đường dẫn chứa thư mục ẩn (như `~/.gemini/...`) vào `vectorcraft.cli` hay `effectcraft.cli`. Snap sẽ báo lỗi `Permission denied (os error 13)` hoặc `No such file (os error 2)`.
   * **ĐÚNG**: Mọi file trung gian (SVG, PNG render, JSON keyframes) phải được lưu trữ trong:
     * `~/snap/vectorcraft/current/ass_studio_work/`
     * `~/snap/effectcraft/current/ass_studio_work/`
     * Hoặc thư mục làm việc tiêu chuẩn dưới `$HOME/` không chứa dấu chấm ẩn.
2. **Thuật toán Nâng bậc Bézier $Q \to C$**:
   * Font chữ TrueType và nhiều file SVG thiết kế dùng đường cong Quadratic ($P_0, P_1, P_2$).
   * Tag vẽ `\p1` của ASS **chỉ chấp nhận** Cubic Bézier (`b x1 y1 x2 y2 x3 y3`).
   * `craft_bridge.py` tự động áp dụng công thức giải tích nâng bậc:
     $$C_1 = P_0 + \frac{2}{3}(P_1 - P_0), \quad C_2 = P_2 + \frac{2}{3}(P_1 - P_2)$$
     Đảm bảo đường cong vector trong ASS trùng khít 100% hình dạng thiết kế ban đầu.
3. **Hiệu năng Render**:
   * `effectcraft.cli render-frame` đạt tốc độ render GPU ~700 ms cho khung hình $1920 \times 1080$, đủ nhanh để chạy trong vòng lặp reflection lặp đi lặp lại nhiều lần mà không gây nghẽn phiên làm việc của Agent.
