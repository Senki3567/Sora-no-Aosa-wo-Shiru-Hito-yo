# aegisub-cli: chạy Automation macro để agent thao tác ASS

Đọc khi muốn tận dụng script Lua/MoonScript của cộng đồng cho typesetting, sửa tag, karaoke, timing hoặc thao tác hàng loạt. Tài liệu này dựa trên mã nguồn và trạng thái repo đối chiếu ngày **2026-10-16**; kiểm lại commit/binary khi dùng về sau. CLI không làm thay phần quyết định nội dung hay QC hình. Nó thực thi đúng macro được đăng ký, lưu ASS mới, rồi agent so thay đổi và render theo hợp đồng dự án.

## Chọn mã nguồn có bằng chứng

| Repo | Commit cuối quan sát | Thay đổi thực sự so với gốc | Kết luận cho agent |
|---|---|---|---|
| [Myaamori/aegisub-cli](https://github.com/Myaamori/aegisub-cli) | 2020-11-14 | Lõi CLI, ví dụ, Windows binary; `pushed_at` 2020 dù `updated_at` GitHub mới hơn. | Nguồn semantics; không mặc định build được với Meson/Boost hiện đại. |
| [HengXin666/aegisub-cli](https://github.com/HengXin666/aegisub-cli) | 2025-08-20 | Chuyển include Boost Phoenix, C++20, chuyển `luabins` khỏi `subprojects`; `src/main.cpp` chỉ thêm include. | Ứng viên Linux để tự build; logic Automation vẫn như gốc. |
| [boydaihungst/aegisub-cli](https://github.com/boydaihungst/aegisub-cli) | 2025-08-22 | Kế thừa fork HengXin; thêm workflow build Linux/release. Windows job bị comment; lúc đối chiếu GitHub không có workflow run và release không có asset. | CI file chưa là bằng chứng binary chạy; kiểm build/runtime riêng. |
| [kalterBebapKacke/aegisub-cli](https://github.com/kalterBebapKacke/aegisub-cli) | 2025-12-29 | Dockerfile và patch `fs.cpp`/logger khi dựng image; `src/main.cpp` cùng hash với gốc. | Có hướng đóng gói, không là engine CLI mới. Xem Dockerfile trước khi dùng: tải DependencyControl và gọi macro install với `|| true`. |
| [marcelocastrobarbosa](https://github.com/marcelocastrobarbosa/aegisub-cli), [scrpr](https://github.com/scrpr/aegisub-cli) | 2023/2024 | Workaround build/macOS và Docker; không phát triển giao diện CLI. | Chỉ xem nếu gặp đúng vấn đề nền tảng đó. |

Hai fork tạo năm 2026 là [dylei](https://github.com/dylei/aegisub-cli) và [LightArrowsEXE](https://github.com/LightArrowsEXE/aegisub-cli) vẫn trỏ tới commit gốc 2020; ngày tạo fork không chứng minh có bảo trì. **Không thấy một fork đang duy trì lõi CLI thường xuyên** trong tập fork công khai đã kiểm. Chọn bản theo thay đổi mã thực và kết quả build trên máy target, không theo `updated_at`, release title hay số sao. [Upstream issue về Meson](https://github.com/Myaamori/aegisub-cli/issues/4), [issue Apple arm64](https://github.com/Myaamori/aegisub-cli/issues/5).

## Cơ chế và phạm vi hỗ trợ từ mã nguồn

`src/main.cpp` nạp ASS → video/timecodes/keyframes nếu truyền → tạo selection → nạp từng file `--automation` → gọi command trùng **tên macro đã đăng ký** → lưu output. Nguồn: [main.cpp](https://github.com/Myaamori/aegisub-cli/blob/master/src/main.cpp), [command.cpp](https://github.com/Myaamori/aegisub-cli/blob/master/src/command/command.cpp), [auto4_lua.cpp](https://github.com/Myaamori/aegisub-cli/blob/master/src/auto4_lua.cpp).

- Chỉ những script được nêu trong `--automation` mới được nạp cho lần gọi đó; path có thể tuyệt đối, tương đối hoặc basename trong thư mục Automation autoload cấu hình. Phải cung cấp đúng tên macro đã đăng ký bằng `aegisub.register_macro`/DependencyControl, gồm cả dấu `/` nếu tác giả đặt trong tên. `script_name`, filename và tên filter không tự là tên macro.
- CLI gọi `cmd::call` cho macro/command, **không chạy export filter**. Chẳng hạn bản Karaoke Templater cài ở đây đăng ký macro `Apply karaoke template` và filter `Karaoke template`; không gọi filter bằng cách truyền tên đó cho CLI. [Ví dụ lỗi từ issue upstream](https://github.com/Myaamori/aegisub-cli/issues/1). Khi cần Templater, kiểm registration trong đúng bản `.lua` rồi gọi macro phù hợp.
- `--selected-lines` nhận các **chỉ số event 0-based** (`0-5,10`), không phải số dòng vật lý trong file và không phải chỉ số `subs[i]` 1-based mà Lua nhận. Không truyền selection hoặc chuỗi rỗng sẽ chọn **mọi event**; nếu chỉ số ngoài phạm vi, code có thể fallback active line. Tính lại index sau mọi macro chèn/xóa/sắp xếp event. `--active-line` cũng là event index 0-based trong CLI.
- `--dialog` có thể lặp để xếp các câu trả lời theo thứ tự dialog; JSON chứa `button` là chỉ số 0-based và `values` là tên control/giá trị. Đọc script để biết button/field, hoặc log `--loglevel 4`; không đoán button 0 luôn là OK. Thiếu một câu trả lời, code trả cancel cho dialog đó; macro có thể kết thúc không sửa mà process vẫn lưu output. [auto4_lua_progresssink.cpp](https://github.com/Myaamori/aegisub-cli/blob/master/src/auto4_lua_progresssink.cpp).
- `--file` có thể lặp cho open/save dialog; nhiều file một dialog ngăn bằng `|`. CLI trả path được cấp hoặc `nil` nếu thiếu; `must_exist` và `prompt_overwrite` trong code không được dùng để kiểm path. Tự kiểm trước file input và output; macro có thể ghi file ngoài `<output.ass>` nếu nó làm I/O riêng.
- `--video`, `--timecodes`, `--keyframes` cấp context cho macro cần frame/video; không tự sửa timing hay tracking. Script có phụ thuộc GUI widget, thư viện ngoài, DependencyControl, binary ngoài hoặc API của Aegisub mới hơn có thể không chạy. Đọc header/dependencies và thử riêng, không tuyên bố tương thích toàn bộ cộng đồng.
- Bản CLI biên dịch được vẫn cần `moonscript` trong đường dẫn Automation include **kể cả khi nạp `.lua`**: `libaegisub/lua/script_reader.cpp::Install` yêu cầu module này trước khi đọc script. Nếu báo `module 'moonscript' not found`, kiểm `Path/Automation/Include`, thư mục `?data/automation/include` và `?user/automation/include`; không chẩn đoán nhầm là lỗi riêng của macro. [script_reader.cpp](https://github.com/Myaamori/aegisub-cli/blob/master/libaegisub/lua/script_reader.cpp).

### Phép thử Linux đã chạy ngày 2026-10-16

Tự build commit `e15691676` của HengXin666 trên Ubuntu 24.04/GCC 13/Meson 1.3.2. Cần Boost program_options/readline bổ sung trong thư mục thử và đặt prefix tới thư mục Automation include có `moonscript.lua` (`/usr/local/share/aegisub` trên máy thử). Bản build đầu với prefix mặc định `/usr/share/aegisub` **không nạp được bất kỳ Lua script nào** vì không tìm thấy MoonScript; sau khi chỉnh prefix và build lại, macro chạy. Đây là kết quả trên môi trường này, không là chứng nhận binary có thể phân phối cho mọi máy.

Thử với hai event trên bản ASS tạm và macro cộng đồng đi kèm Aegisub:

```bash
aegisub-cli --automation /usr/local/share/aegisub/automation/autoload/strip-tags.lua \
  --selected-lines 0 input-tags.ass output-tags.ass 'Strip tags'
```

Kết quả: tag `\\bord2` ở event 0 bị bỏ; tag `\\bord3` ở event 1 giữ nguyên; exit code 0. Macro Lua thử riêng cũng chỉ đổi `Effect` của event 0. Với macro mở dialog thử riêng, `--dialog '{"button":0,"values":{"marker":"DIALOG-OK"}}'` sửa event 0; **bỏ `--dialog` vẫn exit 0 nhưng cả hai event không đổi**. Trên host không có DISPLAY, quá trình phát cảnh báo wxGTK khi kết thúc dù output đúng; phán định bằng file và field diff, không chỉ dựa log/exit code.

Thử riêng macro Aegisub gốc `Apply karaoke template` trên fixture 1 cue/2 `\k` đã chạy qua các bước progress, nhưng abort ở GtkStyleContext vì host thử không có display; **không tạo output**. Vì vậy CLI đã xác minh cho macro thuần ASS ở trên, chưa xác minh headless cho stock Templater trên host này. Khi macro chạm text metrics hoặc GUI, cần môi trường hiển thị/font phù hợp rồi chạy lại candidate và so output; không lấy progress hay registration làm bằng chứng macro hoàn tất.

## Quy trình dùng trên một bản sao

1. Kiểm `aegisub-cli --help`, đường dẫn binary, commit/fork, platform và thư viện; xem script đăng ký macro hay filter, tên macro chính xác, `require`/DependencyControl, dialog/file calls, video API và mọi thao tác file/network. Nạp đủ module trong thư mục Automation include của môi trường thử. Không tự động cài dependency từ script lạ vào cấu hình Aegisub đang dùng.
2. Khoá SHA-256 input; giữ output ở file khác và chạy một vùng nhỏ đại diện. Ví dụ cú pháp với macro đã xác minh:

   ```bash
   aegisub-cli --automation /path/to/script.lua --selected-lines 0-5 \
     --dialog '{"button":0,"values":{"control_name":"value"}}' \
     input.ass candidate.ass 'Exact registered macro name'
   ```

   Bỏ `--dialog` nếu macro không mở dialog; truyền `--file` khi script thực sự gọi open/save. Không dùng ví dụ placeholder này như lệnh sẵn chạy trên file chính.
3. Kiểm exit code, output tồn tại và macro thật sự đã đổi gì. Exit 0 một mình không chứng minh sửa thành công; so input/output theo field/structure, xem số event và notes, xác nhận các mục không được phép không đổi. Khi effect có hình, render still trên footage và kiểm trajectory/renderer target. Nếu script không idempotent, không chạy lại trên chính output.
4. Khi thay file đang mở trong Aegisub, đọc lại hash trước ghi. Với macro có thể gọi chương trình ngoài hoặc tải module, dùng bản sao và môi trường cấu hình riêng nếu cần; `<output.ass>` không giới hạn mọi side effect của script Lua.

## Chọn loại automation từ code script

| Mẫu script | Có thể dùng CLI? | Việc agent cần kiểm |
|---|---|
| Macro thuần biến đổi `subs, sel, act` | Thường có | Đúng selection và field; source/output riêng. |
| Macro có `aegisub.dialog.display` | Có nếu response được xếp đúng | Tên control, button, số dialog, nhánh Cancel. |
| Macro gọi open/save dialog | Có nếu truyền `--file` | Path thật và side effect ngoài output. |
| Macro cần footage/timecodes/keyframes | Có thể | Truyền đúng bản video, PTS/context và kiểm hình. |
| Export filter không kèm macro | Không trực tiếp qua giao diện CLI này | Tìm macro tương đương hoặc dùng export trong Aegisub; không đoán tên filter. |
| Macro phụ thuộc GUI, DependencyControl hoặc binary ngoài | Chưa biết trước | Kiểm mã/dependency và chạy thử môi trường cô lập; không coi mọi script Automation là CLI-compatible. |

Repo [Akatsumekusa Aegisub Scripts](https://github.com/Akatmks/Akatsumekusa-Aegisub-Scripts) là ví dụ thực tế: `aka.99PercentTags.lua` có nhiều macro và dialog, `aka.dupe-and-not-comment.lua` phụ thuộc DependencyControl dù logic sửa event ngắn, và nhiều macro gọi open/save file. Đọc registration và required modules của từng script; tên gói không đủ để gọi CLI đúng.
