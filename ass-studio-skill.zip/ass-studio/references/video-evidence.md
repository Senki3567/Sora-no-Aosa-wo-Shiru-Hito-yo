# Video gốc, frame, màu và âm thanh

## Khảo sát có mục tiêu

Bắt đầu đúng đường dẫn được chỉ định. Probe video/audio stream, width/height, frame-rate rational, stream/format start_time, duration, SAR, rotation và colorspace. Không giả định mọi MKV cùng tập đều có audio, OP giống nhau hoặc thời gian bắt đầu bằng 0. Phân biệt nguyên liệu raw với preview đã gắn sub; một ô màu/nhiễu có thể đã nằm trong footage.

Tạo contact sheet thưa để hiểu cảnh; sau đó lấy các frame kề ở cut, chỗ đổi màu/blur, intro, đỉnh motion và cuối cue. Đọc hình trước khi đo, đo phần quyết định thiết kế. Đừng lấy vài ảnh đầu OP rồi tạo curve màu tuần hoàn cho cả bài.

## Native frame và PTS

Frame index dùng gốc 0 trong helper. Với CFR đã xác minh, n * fps_den / fps_num là thời gian tương đối lý tưởng; không thay nó cho actual PTS khi stream bắt đầu khác 0, container làm tròn hoặc video là VFR. Lưu cả frame index và actual PTS. Keyframe phục vụ seek; shot cut là thay đổi cảnh, có thể không trùng keyframe.

`-ss` giải mã ở hoặc sau thời gian seek, tùy vị trí tham số/cách xử lý timestamps. PTS MKV làm tròn millisecond còn MP4 có timebase khác; seek tới số làm tròn lên có thể lấy frame kế. Muốn kiểm chứng một frame cụ thể, dùng select theo chỉ số frame, hoặc đối chiếu PTS từ showinfo/ffprobe thay vì gán số frame bằng suy đoán.

ASS End là biên không còn hiện; chọn centisecond chứa đúng frame mục tiêu và không lấn qua cut. Kiểm tra frame ngay trước, ngay tại và ngay sau biên. Với mỗi đợt đổi timing ghi quy tắc làm tròn; dịch đều các event giữ duration nhưng sai số lượng tử nhỏ vẫn có thể đổi một frame biên.

## Helper lấy frame

```bash
python3 scripts/video_frames.py raw.mkv --frames 100 101 150 --output work/native
python3 scripts/video_frames.py raw.mkv --range 100 160 --step 5 --output work/survey
```

Range bao gồm cả hai đầu. Helper giải mã native từ đầu đến frame cao nhất được yêu cầu; rất chắc về chỉ số nhưng có thể chậm nếu chọn cuối một tập dài. Với khảo sát dài, seek gần vùng quan tâm rồi xác minh PTS bằng showinfo; đừng gọi lặp từng frame khiến giải mã lại toàn đoạn. Helper xuất PNG, metadata actual PTS và contact sheet nếu có Pillow. Native ở đây là chỉ số và không gian frame; PNG vẫn qua chuyển màu từ YUV. Khi đo màu định lượng, ghi rõ matrix/range/bit depth của phép giải mã, không coi thumbnail RGB là số đo native YUV. Không bật frame interpolation hoặc fps filter trước bước select.

## Ghép bằng chứng và composite

Sau extraction, có thể dùng `python3 scripts/visual_evidence.py sheet work/native/frames.json --roi 100 80 900 600 --output work/evidence`. Trước khi render overlay, chạy `python3 scripts/visual_evidence.py times work/native/frames.json` để lấy `unique_ass_times_ms`, rồi truyền các mốc ấy cho `libass_render.py`. Thêm `--render-report work/render.json` khi tạo sheet để ghép raw và candidate.

Helper ưu tiên PTS thực từ `pts_time_text`/`pts_time_s`, cộng `--ass-offset-ms`, rồi lấy **floor millisecond** cho libass; làm tròn lên có thể qua biên cue centisecond. Chỉ fallback `pts_ms_rounded` khi thiếu PTS thực và ghi phương pháp trong report. Phải xác định offset từ timeline dự án, không mặc định mọi stream bắt đầu tại 0. Khi sample/overlay không khớp timestamp hoặc kích thước, helper dừng thay vì tự sửa/resize. Trên target renderer/timebase khác, kiểm lại biên frame và color pipeline.

Mở `sheet.png` bằng công cụ ảnh của harness; `evidence.json` lưu crop/scale từng panel để quy tọa độ thumbnail về pixel native. `compare before.png after.png --roi ... --output work/diff` xuất RGBA diff premultiplied và blend; pixel trong suốt không tạo khác biệt chỉ vì RGB vô hình. Diff dùng để khoanh lỗi, không tự xác định nguyên nhân. Xem [visual-reasoning.md](visual-reasoning.md) để chọn frame/ROI và dùng phép đo phù hợp.

## Đo grade và blur

Chọn ROI ổn định có chất liệu/bề mặt tương ứng. So cặp frame kề tại đổi grade; tách thay đổi scene, camera, ánh sáng và lớp màu. Một vùng trời/cây xanh không chứng minh filter xanh. Có thể ước lượng mức grade giữa hai trạng thái rõ của cùng cảnh, lưu residual/confidence, rồi giản lược curve có bảo toàn bước nhảy tại cut. Xem lại toàn phần sau để biết grade thực sự kết thúc ở đâu.

Một ước lượng thực dụng trên ROI cùng cảnh là chiếu vector màu current lên hướng neutral → cold: `g = clamp(dot(current-neutral, cold-neutral) / ||cold-neutral||², 0, 1)`. Chỉ dùng khi hai trạng thái/ROI thực sự tương ứng; đăng ký chuyển động trước, kiểm tra residual và bỏ vùng đổi vật thể. Lưu màu/curve dưới dạng dữ liệu đo, không coi công thức là bộ phát hiện grade phổ quát.

Phối palette sub theo trạng thái đường hình, không bắt buộc lấy màu y hệt raw. Luminance/contrast và readability vẫn cần xét trên composite. Blur hình do chuyển động có hướng khác blur Gaussian; đo vệt, vùng cạnh rõ và footprint mờ riêng nếu chúng dẫn tới thiết kế khác nhau. Đừng nhận template mờ nhầm thành scale hoặc translation.

## Audio và nguồn lời

Kiểm tra stream rồi nghe một đoạn có cả câu trước/sau khi speaker/lời Nhật còn mơ hồ. Phụ đề JP, transcript labels và Actor hiện tại là nguồn đối chiếu, không tự chứng minh người đang nói. Nếu không có audio truy cập được, giữ phần chưa chắc và ghi rõ giới hạn. Không tạo kết luận nghe giọng từ video câm.

Căn hai phiên bản video bằng nhiều mốc hình/nghĩa ở đầu, giữa, cuối; với karaoke có audio, đối chiếu thêm onset và drift. Một mốc đầu khớp không đảm bảo không có frame thêm/bớt ở montage. Tách offset cố định khỏi drift và chỗ cắt khác bản.
