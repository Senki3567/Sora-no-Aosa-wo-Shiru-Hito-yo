# Bài thực hành để kiểm skill qua harness/model

Đọc khi xác minh tính tương thích hoặc sau thay đổi pipeline FX/tracking. Đây là tập con hình ảnh của bộ đánh giá toàn workflow ở [workflow-evals.md](workflow-evals.md). Không dùng số lượng tài liệu, frontmatter validator hoặc một lệnh exit 0 làm điểm chất lượng. Cần tách: discovery/paths; helper runtime; chất lượng hoàn thành prompt; hình/timing trên footage thật. Không tự gọi model bên ngoài, đổi cấu hình hoặc tạo agent mới nếu chưa có quyền trong phiên.

## Kiểm helper có thể tái chạy

Từ thư mục skill:

```bash
python3 scripts/studio_check.py
python3 -m unittest discover -s tests -p 'test_visual_tools.py' -v
```

Tests sinh landmark và ảnh tổng hợp tạm để kiểm recovery matrix, điểm check, outlier, suy biến, PTS/gap, RGBA alpha, timestamp mapping, ROI và bảo toàn input. Chạy bằng Python/path chứa dấu cách từ cwd khác để kiểm tính portable. Đây là kiểm thuật toán/IO với ground truth tổng hợp; không chứng minh tự track được anime thật hoặc mọi model tuân thủ skill.

## Các prompt thử trên tài liệu/footage dự án được cấp

| Prompt/tình huống | Kết quả cần kiểm từ file và hình |
|---|---|
| “Dịch sign sang VI, giữ dáng chữ và dấu; chỉ thay sign này” | Chọn đúng object; glyph không fallback; vị trí/width đọc được; field/event ngoài phạm vi không đổi |
| “Cho chữ bám mặt bảng qua đoạn này” | Frame neo được ghi; native coords/PTS; mô hình vừa đủ; residual/held-out checks; render đầu/giữa/cuối và các cực trị |
| “Tâm luôn khớp nhưng hai mép trượt khi camera quay” | Không chốt theo centroid; đối chiếu width/height/shear/corner và điểm kiểm phân bố; chỉ nâng model khi dữ liệu ủng hộ |
| “Đầu mờ, về cuối rõ dần nhưng chữ thay thế vẫn nổi” | So độ rõ với chi tiết cùng điều kiện quang học; geometry không đổi để bù blur; kiểm contrast/nền che và các mốc gần ổn định, không áp ramp mặc định |
| “Dịch thiết kế xuống trên mặt nghiêng, giữ mọi motion” | Đổi placement reference rồi project; frame khác góc/scale vẫn bám mặt; không cộng cùng screen offset vào mọi frame |
| “Một phần mặt bị uốn/parallax, homography không còn khớp” | Nhận ra residual theo vùng; không ép một H hoặc đổi correspondence để che lỗi; chọn segment/biểu diễn phù hợp và giữ uncertainty |
| “Bảng bị che giữa đoạn, khôi phục motion khi thấy lại” | Không đo điểm trên occluder như thuộc bảng; đoạn thiếu có nhãn; anchor sau occlusion không drift; mask/text không lộ sai frame |
| “Mask khớp nhưng chữ perspective còn trôi” | Giữ mask đã đúng; test glyph/pivot/model riêng; không chốt chỉ bằng bốn góc shape |
| “Làm glow nhẹ hơn, giữ tất cả timing và chuyển động” | Thay đúng component/param; onsets và track giữ nguyên; sinh lại không mất chỉnh tay đã duyệt |
| “Giữ nhịp karaoke, làm intro thong thả hơn” | Hai clock tách rõ; mọi onset tuyệt đối giữ; chữ settle theo deadline từng âm; không restart fade trong FBF |
| “Tối ưu sign nhiều lớp” | Baseline/candidate cùng renderer/font/PTS; RGBA khác biệt được xem; CPU/bitmap đo ở peak; không chỉ báo file nhỏ hơn |
| “Tiếp tục bản vừa duyệt từ harness khác” | Mở đúng source/hash/scene state; tiếp tục candidate hiện hành; giữ mapping nguồn→output, font và phần khóa |

Chọn case phù hợp tác vụ, không bắt chạy toàn bộ cho sửa nhỏ. Cung cấp người đánh giá **prompt, nguồn và skill**, chưa đưa đáp án mong đợi; sau đó so output theo hợp đồng. Khi không có footage hoặc model run được phép, giữ các case là `not_run`, không ghi pass theo tài liệu.

## Ghi kết quả

Ghi harness/surface/version khi lấy được, model khi runtime cung cấp, Python/dependencies, nguồn/hash, tool calls cần thiết, candidate và ảnh check. Với mỗi case: `pass`, `fail`, `partial`, `not_run`, kèm lỗi và bằng chứng cụ thể. Một helper chạy trong terminal của Codex không được báo là Claude/OpenCode/Antigravity đã hoàn thành bài prompt. Khi lỗi lặp lại, sửa instruction/tool theo lỗi quan sát rồi thử lại đúng case; không thêm quy tắc chung thiếu bằng chứng.
