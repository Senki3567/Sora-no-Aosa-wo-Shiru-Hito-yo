# Nguồn bộ tích hợp

Scripts căn lấy từ bản softsub-align đang cài; worker OCR lấy từ hardsub-ocr và đổi duy nhất loader credential sang file/env. Workflow JP được đưa trực tiếp vào references. Các skill gốc được giữ nguyên.

| Nguồn | SHA256 tại lúc tích hợp |
|---|---|
| softsub-align/SKILL.md | ce8af1add19fd16978640c9e7262dc85b68d5c80d196341e74e8ba89d54e5659 |
| softsub-align/references/alignment_rubric.md | 90ef3ffc884ca971d554035c960b0f49c2d1b3c9880f9c146da51561c9b26f9e |
| softsub-align/references/map_schema.md | 18e68332061ebb45008a024b11ffd365ecfd387594fbecf005f24135580a4bf2 |
| softsub-align/references/vietnamese_grammar_rules.md | 44a27ea81cfd05124d34f18a96a3a08aef5178bd81159f8ce09157c36094d226 |
| softsub-align/scripts/ass_parser.py | 02b4ee9710861fd78164e9213e99fb61ff27436a4fbbb400eab138d7a8a5ed67 |
| softsub-align/scripts/mapping.py | 7df368f8d5e27ac24d282cf465d428cff4adcf6ac99a28a2f1c37d8b0e617be4 |
| softsub-align/scripts/sub_align.py | 7df442deb779eb89191f7cc66d5075719a87dca91843d539181338b59948f725 |
| softsub-align/scripts/test_sub_align.py | 6edb1edcf021f0b5bb0db9cdd5922013cfcc3dcc936459a3c01ce10e9afe4473 |
| softsub-align/scripts/text_utils.py | 8e3771cc4708a68b08410a14993e6eaf19ae70c49d18e5766a0ec824dce918ea |
| hardsub-ocr/SKILL.md | 91e06e4b0d6de85c98e53ca95bacd37ff7e3ed3493401513890c0d2c171e2835 |
| hardsub-ocr/scripts/extract_tiles.py | 058c7e49b9a9258dbf1d2ad1c73deb41a8364481c80bf48bfe4f1f481df1e896 |
| ja-vi-from-jp/SKILL.md | 8ee4b2b3884c020cfbf6d5d1b7cc3d0d97d4857260470d5556799ed2e6f46828 |
| ja-vi-from-jp/references/direct-japanese-workflow.md | 537976c9b41a8be7b90d66517bb000682754585e94c22f8f3442453e56d16a20 |

## Điều chỉnh khi tích hợp

- Loader OCR đọc key riêng/env, không đọc credential từ SKILL.md. Không thay logic extraction/rescue/provenance.
- Suite căn gốc import một heuristic is_compound_break đã bị xóa khỏi text_utils; bỏ import và đúng một test obsolete ấy. 18 test còn lại chạy đạt, không thêm lại heuristic ngôn ngữ.
- Giải quyết mâu thuẫn prose về cleanup: bản Full auditable giữ EN ẩn và nhãn exporter; cleanup chỉ theo yêu cầu riêng.
- Các workflow dùng đường dẫn tương đối trong bộ skill. Script căn giữ nguyên; integration được kiểm tra CLI end-to-end và OCR capture/PR/export offline, không gọi API.
