# Tracking phối cảnh: từ bằng chứng đến bản render

Đọc khi chữ phải bám một bề mặt qua camera motion, khi tâm đã đúng nhưng kích cỡ/phối cảnh sai, khi nhiều lớp bị trượt nhau, hoặc khi cần đổi vị trí trên một track đã chốt. Áp dụng cho mặt bảng, giấy, màn hình, tường và các mặt phẳng khác; không phụ thuộc vật thể hay bộ thông số của một cảnh mẫu.

Tài liệu này bổ sung cách quyết định cho [visual-reasoning.md](visual-reasoning.md), không thay pipeline đo ở [motion-measurement.md](motion-measurement.md). Chỉ đọc phần phù hợp lỗi hiện tại; không buộc sign chỉ tịnh tiến phải qua toàn bộ quy trình projective.

## 1. Xác định thứ gì phải đứng yên tương đối với thứ gì

Phân biệt chữ gắn vào vật thể, đồ họa gắn màn hình, và chữ có animation riêng trên vật thể. Một offset cố định trên màn hình phù hợp loại thứ hai; nó thường làm loại thứ nhất trượt khi camera đổi góc hoặc zoom.

Chọn bề mặt trước khi chọn tracker. Một homography mô tả chuyển đổi giữa hai ảnh của một mặt phẳng cứng trong mô hình camera phối cảnh lý tưởng. Parallax giữa các độ sâu, mặt cong, giấy uốn, rolling shutter hoặc méo lens đáng kể có thể làm một homography không đủ. Nếu residual thay đổi có hệ thống theo vùng, kiểm giả thiết bề mặt và chia vùng/segment hoặc dùng mô hình biến dạng/3D khi có dữ liệu; đừng chỉ tăng số tham số để che sai giả thiết.

Ghi ngắn: nguồn/hash; khoảng frame và PTS; vật thể/bề mặt; native resolution và phép đổi sang ASS; thiết kế ở frame tham chiếu; phần được khóa; phần đang chưa biết. Frame tham chiếu rõ là hệ tọa độ để dựng, không bắt buộc là đầu hoặc cuối. Nếu người dùng đã chốt một frame, giữ hình tại đó cho đến khi có yêu cầu thay đổi.

## 2. Chọn quan sát có khả năng phân xử lỗi

| Quan sát | Ràng buộc được | Chưa đủ để kết luận |
|---|---|---|
| Một tâm hoặc một điểm | Vị trí điểm đó | Width, height, roll, shear và foreshortening |
| Hai mép dài ở nhiều cao độ | Envelope ngang, độ hội tụ và nghiêng của mép | Vị trí dọc bề mặt nếu không có landmark dọc |
| Góc và texture phân bố trên mặt | Biến đổi hình học có redundancy | Chất lượng chữ/font hoặc độ hòa màu |
| Nét/chữ/chi tiết bên trong có identity rõ | Correspondence, dịch dọc/ngang, scale cục bộ | Tất cả vùng nếu chi tiết tập trung trong một góc |
| Cạnh vật thể khác ở phía trước | Occlusion và thứ tự lớp | Chuyển động của mặt bị che |

Tránh correspondence mơ hồ giữa hoa văn lặp hoặc vật thể lân cận. Các điểm đo sát nhau có thể khớp rất tốt nhưng ngoại suy sai ở phần còn lại. Phân bố điểm trên vùng cần đặt chữ, giữ điểm kiểm độc lập không tham gia fit; nếu góc không rõ thì dùng các đặc trưng nhìn được thay vì tự bịa tọa độ góc chính xác.

Chọn mẫu để bắt thay đổi: đầu/giữa/cuối, cực trị scale/góc, đổi hướng, lúc nét bắt đầu rõ, hai phía occlusion và đoạn nối. Sau khảo sát thưa, bổ sung ở khoảng mô hình còn mơ hồ. Việc chỉ xem vài frame đẹp không đủ chốt cả quỹ đạo.

## 3. Chọn mô hình từ residual, không từ tên hiệu ứng

Thử translation → similarity → affine → projective khi dữ liệu đòi hỏi. Cần tối thiểu lần lượt 1/2/3/4 correspondence ở cấu hình không suy biến; số tối thiểu chỉ xác định phép fit, chưa kiểm được nó đúng. Xem thêm phân bố điểm và held-out error trong [motion-measurement.md](motion-measurement.md).

| Dấu hiệu sau render | Giả thuyết cần thử | Phép kiểm phân xử |
|---|---|---|
| Cả nhóm lệch cùng một vector | Offset, timestamp hoặc quy đổi crop sai | So landmark native tại đúng PTS trước khi sửa font |
| Tâm đúng, mép mở ra/co vào đối xứng | Scale hoặc width/height sai | So các cạnh và khoảng cách landmark, không chỉ centroid |
| Một bên khớp, bên kia sai; sai số đổi theo cao độ | Shear, perspective hoặc sai mặt phẳng | Check các điểm ở nhiều vùng và nhiều cao độ |
| Shape/mask đúng nhưng glyph trôi | Local→screen, pivot, shaping hoặc tag model sai | Render glyph thật với cùng nguồn, tách khỏi mask |
| Sai tăng dần rồi nhảy sau che khuất | Tích lũy drift hoặc đổi identity | Đăng ký lại với reference và landmark trước/sau che |
| Fit ảnh đổi kích thước khi chỉ grade/blur đổi | Geometry đang hấp thụ appearance | Khóa geometry, chuẩn hóa contrast hoặc dùng cạnh ổn định |

Chiều ngang và chiều dọc trên màn hình có thể đổi khác nhau; không ép scale 1:1 nếu dữ liệu bác bỏ. Ngược lại, ít dữ liệu không phải lý do để tự do biến dạng từng trục. Đánh giá mô hình phức tạp hơn bằng điểm chưa fit và frame xen kẽ, không chỉ training residual nhỏ hơn.

Ưu tiên ràng buộc về reference tuyệt đối; tracking frame kề giúp nối dữ liệu nhưng có thể drift. Sau cut, đổi mặt hoặc mất bám, xác lập lại segment/correspondence. Đánh dấu measured/interpolated/extrapolated và khoảng không đáng tin. Nội suy chỉ trong pha chuyển động phù hợp; smoothing cần phân biệt noise với rung thật, không làm phẳng mọi đường tham số.

## 4. Một phép biến đổi chung cho các thành phần cùng mặt

Chọn và ghi quy ước. Ví dụ dùng column vector: `q_f ∼ H_f x_ref`, với H reference→frame và phép chia homogeneous sau nhân. Không đảo chiều matrix theo cảm giác. Quy đổi crop/resize/SAR/PlayRes một lần có kiểm chứng; `motion_fit.py` nhận điểm native, không nhận tọa độ thumbnail.

Chữ, nền che, viền, bóng và clip có thể bắt đầu từ các hệ tọa độ khác nhau. Đưa các thành phần **cùng gắn mặt** về hệ reference chung rồi áp H tương ứng. Chỉ tách motion khi có chuyển động riêng thật; occlusion mask gắn một vật thể khác cần track riêng. Kiểm cả bốn phía và chi tiết nội bộ, không chỉ cho các tâm trùng nhau.

Hai cách biểu diễn cần thử theo cảnh:

- **Native ASS:** giữ font/layout, dùng pos/scale/rotation/shear/3D tags nếu renderer biểu diễn được hình cần thiết. Kiểm `an`, `org`, drawing scale và thứ tự các phép đổi bằng render của chính glyph. Không copy matrix thành các tag độc lập hoặc thêm một góc 3D lên scale đã bù perspective mà chưa kiểm tác dụng kép.
- **Bake hình học:** khi native không giữ các lớp cùng hình, lấy silhouette tại reference từ renderer/font/tags đã duyệt, đưa contour về tọa độ screen reference rồi project chung. Giữ nguồn editable và mapping component→source event. Tọa độ local của drawing chưa qua anchor/pivot không được đưa thẳng vào H screen-space. Giữ holes/winding; quy đổi đúng đơn vị `\p` khi xuất.

Không cấm `frx/fry` cho mọi sign, cũng không coi chúng là một bộ xuất homography tùy ý. Bake contour có thể khác raster/hinting của font ở scale khác; render neo và các scale mục tiêu trước khi thay baseline. Nếu đường cong được lấy mẫu thành polygon, chọn mật độ theo sai số screen ở toàn quỹ đạo, không chỉ tại reference.

Trước khi sinh cả đoạn, thử các điểm/corner đã biết và một nhóm glyph thật trên vài frame khác nhau rõ rệt. Kiểm identity tại reference theo quy ước đã chọn, chiều matrix, scale và pivot. Một phép chiếu có mẫu số gần 0, đảo mặt bất thường hoặc quad tự cắt cần điều tra; đừng xuất hàng loạt rồi sửa từng frame.

## 5. Tách geometry khỏi màu và độ nét

Trước hết tìm đối chứng **cùng mặt hoặc cùng điều kiện quang học**, có nét/texture quan sát được qua thời gian. Màu và độ nét của một vật thể khác độ sâu hoặc khác chất liệu không tự là chuẩn cho sign. Dùng reference để so mức thay đổi; nét vẽ nguồn và font thay thế có thể có độ dày/độ mềm nội tại khác nhau.

Khóa geometry đủ tin cậy rồi thử appearance, sau đó kiểm lại geometry. Chỉ fit đồng thời nếu dữ liệu đủ phân biệt các biến. Nếu đổi blur làm fitter đẩy scale/offset để giảm loss, đó là dấu hiệu bài toán chưa được ràng buộc tốt. Nghiệm đụng bounds, contrast quá thấp hoặc nhiều nghiệm gần tương đương phải giữ nhãn chưa chắc chắn.

**Độ nét:** phân biệt defocus, motion blur có hướng, độ mềm của artwork và AA/raster. So profile cạnh, bề rộng nét, contrast và khả năng đọc ở native crop lẫn kích thước xem thực; chữ nét mảnh không cần cùng giá trị blur với nét dày để hòa cảnh. `\blur` là tham số renderer, không tự là sigma pixel đo từ raw. Khi cần ánh xạ, hiệu chuẩn bằng render trên chính pipeline. Ramp blur theo thời gian/zoom chỉ là mô hình ứng viên, phải qua các mốc quan sát, nhất là lúc camera gần ổn định. Không dùng blur để giấu sai vị trí/kích cỡ.

**Tông màu:** so các vùng cùng vật liệu, tránh highlight/occluder/texture đổi theo frame. Một pixel hay một dải tối không xác định được phép grade cho toàn dải sáng; ngoại suy từ chữ tối sang nền sáng có thể làm nền bật khỏi cảnh. Giữ endpoint đã duyệt và fit mức thay đổi có dữ liệu hỗ trợ; kiểm nhiều mức sáng nếu áp cùng phép đổi lên nhiều vật liệu. Màu raw đã composite không luôn xác định duy nhất màu foreground và alpha.

Kiểm từng giai đoạn độ rõ thay đổi, không chỉ đầu và cuối. Geometry đúng nhưng chữ vẫn nổi có thể do nền che, contrast, saturation, opacity, footprint blur hoặc bóng; tắt từng component để phân xử, không chỉnh mọi thứ cùng lúc. Khi core và vệt mờ có hành vi khác nhau, thử tách lớp nếu dữ liệu ủng hộ; kiểm tránh làm chữ dày/đậm hơn nguồn.

## 6. Đổi neo trên track đã chốt

Phân biệt đổi vị trí thiết kế **trên mặt reference** và dịch đồ họa **trên màn hình**. Nếu người dùng yêu cầu đổi neo, tạo phiên bản nguồn mới rồi thay đúng placement; khóa font, kích thước và appearance trừ khi yêu cầu cũng thay chúng. Neo đã duyệt trước đó không cấm yêu cầu mới.

Với H reference→frame, A là correction screen-space đã có, TΔ là dịch mong muốn trong reference:

```text
Trước:       q ∼ A H x
Đặt lại:     q_new ∼ A H TΔ x
Đã bake q:   q_new ∼ (A H TΔ H⁻¹ A⁻¹) q
```

Nhân ma trận từ phải sang trái, chia homogeneous ở kết quả. Công thức bake yêu cầu A/H khả nghịch; nếu correction thực là biến dạng phi tuyến thì cần dùng ánh xạ tương ứng hoặc sinh lại từ nguồn. Cách ít nhầm hơn là sửa reference placement và regenerate bằng cùng track. Dịch cùng một số pixel ở mọi frame chỉ đúng khi yêu cầu là screen-space hoặc transform cụ thể cho phép tương đương.

Nếu mục tiêu là tâm ảnh tại một frame, xác định tâm nào: panel, bbox glyph nhìn thấy hay một anchor thiết kế; dùng hình đã project tại frame ấy để giải displacement reference. Đừng lấy `\pos`/font metric làm tâm nhìn thấy một cách mặc định. Với native tag, việc dịch `pos` có thể còn cần dịch `org` và clip tương ứng; kiểm renderer thay vì sửa mỗi `pos`.

## 7. Timing và nghiệm thu quỹ đạo

Dùng native frame index có ghi base và PTS thực; chuyển qua đồng hồ ASS bằng offset đã xác minh. Event FBF cần phủ timestamp hiển thị theo quy ước `[start,end)` của pipeline. ASS lưu thời gian centisecond: sau lượng tử hóa, kiểm event active tại từng PTS cần phủ và ở frame ngay trước/sau đoạn; không suy chính xác từ công thức frame/fps hoặc số event. FPS cao có thể vượt độ phân giải timing này.

Các lớp phải dùng cùng nguồn clock cho camera/phase; fade/animation đang chạy không được restart mỗi event FBF. Kiểm chuyển tiếp native↔drawing, mask/text và phần giữ hình. Xem [geometry-animation.md](geometry-animation.md) cho clock riêng của animation.

Tách các bằng chứng khi kết luận:

| Kiểm tra | Chứng minh được | Không chứng minh được |
|---|---|---|
| Fit residual + điểm held-out | Mô hình khớp quan sát đã đo ở vùng/mốc kiểm | Glyph/render và những frame chưa quan sát |
| Composite chữ thật trên raw | Bám hình, phối cảnh, appearance ở frame đã xem | Mọi frame nếu chỉ xem mẫu |
| Diff RGBA trước/sau tối ưu | Bảo toàn hình của baseline trên tập render | Baseline vốn đã khớp footage |
| Field diff khi tích hợp | Đúng phạm vi sửa cấu trúc/event | Font/style kế thừa vẫn cho hình đúng |
| Benchmark paired | Chi phí trên cấu hình và mốc đã đo | Mọi player/máy hoặc playback cả video |

Kiểm đầu/giữa/cuối, cực trị và frame hai bên đoạn nối; nếu yêu cầu toàn bộ quỹ đạo thì phủ toàn interval, ghi rõ frame nào mới có kiểm số và frame nào đã xem composite. Xem native crop để bắt nét/offset và context rộng để đánh giá cân đối/hòa cảnh. Thumbnail phóng lớn không thay được hai phép xem đó.

## 8. Tối ưu và đưa vào file thật

Chốt hình trước khi tối ưu biểu diễn. Giảm precision, đổi local origin, simplify contour, reuse hình/font hay thay FBF bằng native đều là ứng viên có điều kiện. Giữ extrema/bbox/layout và holes; tolerance nhỏ hoặc số điểm ít hơn không bảo đảm raster giống. Xem [render-performance.md](render-performance.md) cho phép đo và chọn candidate.

Tích hợp bằng identity/vai trò/source mapping, không chọn tất cả dòng active trong một khoảng thời gian rồi thay. Nếu người dùng muốn comment bản cũ và đặt bản mới trong fold ngay dưới, giữ payload cũ, dùng cơ chế fold/extradata thật của file và ID không trùng. Không mang style name, số fold hoặc khoảng frame của dự án mẫu sang dự án khác.

Đổi sang style chuẩn của file có thể đổi thuộc tính chưa override như font, size, margins, border hoặc màu. Render lại **file đã tích hợp**, kiểm vùng overlap và so ngoài phạm vi được phép sửa; standalone đúng chưa đủ. Backup/hash guard và đọc lại output sau ghi theo [delivery-projects.md](delivery-projects.md).

## Khi bị kẹt hoặc chuyển model

Ghi checkpoint bằng kết quả có thể đọc lại: câu hỏi đang xét; input/hash; frame/PTS; nguồn đo và confidence; mô hình đã thử cùng residual; source/generator hiện hành; ảnh render đã mở; phần khóa; lỗi còn lại và phép thử tiếp theo. Tham số cần có tên/đơn vị/hệ tọa độ và nguồn gốc `measured`, `fitted` hoặc `authoring`, không chỉ một mảng số vô danh.

Đưa model tiếp theo bài toán và artifact cần thiết, yêu cầu nó nêu bằng chứng trước khi đổi mô hình. Khi các lần sửa cùng triệu chứng không cải thiện trên ảnh kiểm, quay lại kiểm correspondence/timing/coordinate/model; không tiếp tục chỉnh số ngẫu nhiên hoặc bù bằng blur. Quy trình này hỗ trợ reasoning bằng dữ liệu, không là lời hứa mọi model tự nhìn/đo được chính xác.
