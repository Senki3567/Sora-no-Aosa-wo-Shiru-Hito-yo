# Chọn cách giải theo bản chất công việc phụ đề

Đọc khi yêu cầu có nhiều bước, chưa rõ nguyên nhân lỗi, hoặc chuyển qua harness/model khác. Motion chỉ là một họ bài toán. Font, hình học, animation, câu chữ, audio, đồng bộ và phát hành cần các loại bằng chứng và phép kiểm khác nhau. Chọn các mục liên quan dưới đây; một sửa nhỏ không cần chạy toàn bộ quy trình sản xuất.

## Xác lập bài toán có thể hoàn thành

Từ prompt và file hiện hành, xác định: đối tượng cần tác động; kết quả người dùng muốn; nguồn quyết định nội dung/cấu trúc/hình/nhịp; phần được sửa và phần đã duyệt; artifact cần giao. Một lời chỉnh như “tự nhiên hơn”, “mềm hơn”, “sạch hơn” cần đọc trong ngữ cảnh bản hiện tại để chọn thử nghiệm hợp lý, không ánh xạ cố định vào một tham số. Hỏi khi còn lựa chọn có ảnh hưởng lớn chưa thể suy ra; tiến hành các phần độc lập đã rõ.

Phân loại **câu hỏi chưa biết**, không chỉ phân loại extension file hoặc tên công cụ. Với cùng một ASS, câu hỏi có thể là “ai nói?”, “font nào đang thật sự được nạp?”, “layer nào làm nét đậm?”, “cue nào lấy đúng mẩu VI?” hay “bản sync có xóa chỉnh sửa mới không?”. Mỗi câu hỏi phải có nguồn và cách phân xử tương ứng.

## Bản đồ phương pháp

| Họ bài toán | Cách tìm lời giải và phép thử quyết định | Đọc sâu |
|---|---|---|
| Kiến trúc vận hành Motion & Reverse Engineering | Tách 4 vai trò (Decomposer $\rightarrow$ Architect $\rightarrow$ Executor $\rightarrow$ Critic); dịch ngược pha/cadence/quỹ đạo/easing từ raw; biên dịch qua Declarative Motion IR và chấm 5 trục | [agent-motion-architecture.md](agent-motion-architecture.md), [scene-contract.md](scene-contract.md) |
| Font và bố cục | Lọc theo đặc tính nét, tạo bảng ứng viên với toàn câu thật; khóa geometry rồi thử font, khóa font rồi thử width/spacing. Kiểm fontselect, dấu Việt, baseline và khoảng từ | [font-selection.md](font-selection.md), [font-reconstruction.md](font-reconstruction.md) |
| Shape, mask, che khuất | Đưa contour/clip cùng hệ tọa độ; kiểm Boolean, lỗ và thứ tự lớp. Thử mask-only/text-only trên nền thật, nhất là giữa fade | [sign-fx-recipes.md](sign-fx-recipes.md), [geometry-animation.md](geometry-animation.md) |
| FX và animation | Phân tích các phase và thuộc tính; giữ clock tuyệt đối rồi quy về từng event qua `motion_studio.py compile`. Tắt từng lớp/phase để tìm xung đột; kiểm frame tại chuyển pha và nguồn editable | [geometry-animation.md](geometry-animation.md), [karaoke-design.md](karaoke-design.md) |
| Màu, alpha, blur và chất liệu | Tách foreground, background, alpha, softness và pipeline. Thử từng thành phần trên cùng frame/renderer; không suy màu gốc duy nhất từ một pixel đã blend | [color-palette-validation.md](color-palette-validation.md), [render-performance.md](render-performance.md) |
| KFX và Automation | Chọn implementation, tạo input nhỏ, đếm expansion và truy một output về source/template. Phân biệt lỗi module/selection, generator, tag và renderer | [kfx-templater-compatibility.md](kfx-templater-compatibility.md), [aegisub-cli.md](aegisub-cli.md) |
| Motion và perspective | Đo đúng landmark/frame/PTS, khử trôi nền, fit mô hình vừa đủ (`motion_fit.py` & `motion_studio.py`), kiểm điểm ngoài fit và glyph thật. Ghi frame thiếu/ngoại suy | [visual-reasoning.md](visual-reasoning.md), [motion-measurement.md](motion-measurement.md), [perspective-motion.md](perspective-motion.md) |
| Timing và sync | Nghe vùng có câu trước/sau, kiểm cut thật và cue split/merge. So nhiều anchor để phân biệt offset cố định, drift hoặc khác cut | [timing-practice.md](timing-practice.md), [playback-diagnostics.md](playback-diagnostics.md) |
| OCR và rescue | Đọc đủ vùng chữ/sequence, giữ ảnh và transcript nguyên văn; phân biệt không có chữ, không đọc chắc, lỗi dịch vụ và chưa probe đủ | [ocr-source-preservation.md](ocr-source-preservation.md), [ocr-workflow.md](ocr-workflow.md) |
| Dịch và biên tập | Giải nghĩa trọn lượt thoại, đối chiếu chủ thể/phủ định/quan hệ, thử cách viết Việt rồi kiểm ngược nghĩa và nhịp đọc; kiểm tràn lề bằng `scan_layout_overflow.py` | [dialogue-localization.md](dialogue-localization.md), [direct-japanese-workflow.md](direct-japanese-workflow.md) |
| Căn nguồn và split/merge | Tìm mẩu VI theo câu hỏi ngữ nghĩa của cue EN, mở rộng ngữ cảnh khi cần; kiểm thiếu/lặp/rò ý qua cue kề và provenance | [alignment-workflow.md](alignment-workflow.md), [alignment/alignment_rubric.md](alignment/alignment_rubric.md) |
| Chỉnh sửa, sync và roundtrip | Guard hash/identity, so ba phía khi có chỉnh sửa đồng thời; dùng mapping nguồn rõ. No-edit export và sửa thử có giới hạn kiểm được việc giữ dữ liệu | [field-edits-qc.md](field-edits-qc.md), [version-sync-organization.md](version-sync-organization.md) |
| Hiệu suất | Cô lập vùng peak/lớp gây tốn, đổi một cơ chế có giả thuyết, so hình và profile trên cùng môi trường; kiểm cả seek/cache và playback khi cần | [render-performance.md](render-performance.md) |
| Asset, nhiều tập và bàn giao | Kiểm dependency thật, biến thể theo tập, nguồn hiện hành và target. Mở lại package/mux/encode đã giao, so hashes/track/font và kiểm đoạn ngoại lệ | [delivery-projects.md](delivery-projects.md), [production-workflow.md](production-workflow.md) |

## Chọn phép thử nhỏ nhưng phân xử được

Lập một vài giả thuyết có thể kiểm khi nguyên nhân chưa rõ. Chọn phép thử làm hai giả thuyết cho kết quả khác nhau: đổi font nhưng giữ scale để kiểm dáng chữ; render không glow để kiểm nét đậm; nghe cả span để kiểm false cutoff; so base/current/proposed để phát hiện xung đột sync. Giữ những gì đã được xác minh và mở rộng đúng nơi còn bất định. Không mặc định mọi vấn đề đều cần tối ưu số hoặc render; không dùng điểm tương đồng văn bản để quyết định nghĩa.

Sau phép thử, ghi quan sát và quyết định ngắn kèm artifact/cue/frame vào `iteration_history` (và `falsified_hypotheses` nếu giả thuyết bị bác bỏ), không cần tường thuật suy luận nội bộ. Nếu bằng chứng không phân xử được, đổi nguồn hoặc phương pháp, thay vì lặp sửa tham số. Công cụ giúp thực hiện và lưu phép kiểm; model vẫn phải chọn câu hỏi đúng và đọc kết quả thật.

## Tiếp nhận phản hồi và kết thúc vòng sửa

Khi bắt đầu một lượt review, xác định tiêu chí bằng kết quả quan sát được: nghĩa/quan hệ nào phải giữ, thành phần hình nào đã chốt, lỗi nào đang sửa và phép kiểm nào phân xử. Phân biệt lỗi có chứng cứ với một phương án diễn đạt/thiết kế khác cũng hợp lệ. “Audit thêm” không bắt buộc phải tìm ra hoặc tạo thêm thay đổi; kết quả không phát hiện lỗi mới là hợp lệ trong phạm vi đã kiểm. Không đặt một từ vựng, số vòng hay mức severity của riêng dự án thành quy tắc phổ quát.

Với bản bị bác, ghi ngắn **phản hồi → nguyên nhân cần kiểm → phần được đổi → phần giữ → bằng chứng sau sửa**. Một ví dụ khoanh đỏ có thể chỉ ra lỗi chung của generator: rà cả họ output tương ứng, đặc biệt các trường hợp dài/ngắn hoặc biên pha khác nhau. Nếu đã sửa vài lượt mà cùng lỗi vẫn quay lại, quay về baseline gần nhất được duyệt, ghi cơ chế lỗi vào `falsified_hypotheses` và thử cơ chế khác có đối chứng; không tiếp tục xếp các bản vá tham số làm mất những phần đang tốt. “Bản cũ tốt hơn, chỉ có hai lỗi” là yêu cầu sửa hai lỗi trên bản cũ; “đập đi xây lại” là một phạm vi khác.

Một lượt dịch tổng thể cần tiêu chí ổn định về nghĩa, ngữ cảnh/giọng, tính nhất quán và nhịp đọc; xem [dialogue-localization.md](dialogue-localization.md). Một lượt FX cần trạng thái duyệt theo thành phần/phase và 5 trục Perceptual Critic trong [scene-contract.md](scene-contract.md) và [agent-motion-architecture.md](agent-motion-architecture.md). Khi mọi tiêu chí được giao đã đạt trong phạm vi kiểm được và không còn lỗi đã xác nhận, bàn giao; liệt kê bất định cụ thể thay vì hứa “hoàn hảo” hoặc mở vòng sửa vì sở thích mới.

## Tận dụng harness mà vẫn giữ phương pháp

Đọc [harness-compatibility.md](harness-compatibility.md) để chọn file/shell/image/audio/API tools được cấp. Shell phù hợp phép biến đổi/count/guard; vision phù hợp hình/glyph/occlusion; audio phù hợp onset/speaker; text reasoning phù hợp nghĩa và nguồn. Script chỉ làm I/O của workflow ngôn ngữ không tự được quyền suy nghĩa bằng heuristic. Chỉ gọi dịch vụ/model ngoài khi có quyền và cần cho tác vụ.

Chuyển harness phải mang **nguồn, quyết định đã kiểm, giả thuyết đã bác bỏ, phần chưa biết và bước tiếp theo**, không chỉ mang một danh sách tool names hoặc kết quả `PASS`. Khi tác vụ nhiều bước, có thể giữ một task state ngắn gồm `sources+roles+hash`, `scope`, `questions`, `decisions+evidence`, `falsified_hypotheses`, `candidate`, `checks` và `next_action`. Sign/FX nhiều lớp dùng thêm [scene-contract.md](scene-contract.md); tác vụ Text-only không cần frame/track manifest.

## Nghiệm thu theo yêu cầu

Chọn phép kiểm đủ cho kết quả: field diff cho scope; kiểm nghĩa cho dịch; ảnh nguồn cho OCR; nghe cho timing/speaker; render cho hình; đo renderer cho hiệu suất; mở lại artifact cuối cho bàn giao. Báo riêng phần đã đọc, đã thực thi, đã kiểm và chưa kiểm. Khi sửa một lỗi nhỏ, dừng kiểm ở rủi ro liên quan đã được giải quyết; khi người dùng yêu cầu toàn bộ phạm vi, không lấy một đoạn mẫu đại diện để báo hoàn tất toàn bộ.

[workflow-evals.md](workflow-evals.md) chứa các bài thực hành theo nhiều họ bài toán, để việc cải tiến tiếp theo bám lỗi thực tế và độ phủ thay vì xoay quanh một ví dụ nổi bật.
