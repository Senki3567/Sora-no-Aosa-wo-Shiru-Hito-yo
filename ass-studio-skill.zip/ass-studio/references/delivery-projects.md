# Triển khai, fold, bản render và Git

## Kiểm dependency và chính artifact sẽ giao

Trước khi gom file, đi từ event/source thực tới dependency: style đang dùng, `\rNamedStyle`, `\fn`, attachment `[Fonts]`, template/generator, script/mixin và font file thật. Style có count 0 vẫn có thể được reset hoặc generator gọi; font nằm cạnh project chưa có nghĩa player nhận được. Với nhiều tập, xác minh cut, title, logo, phase nhạc và asset riêng từng tập trước khi tái dùng một block.

Giữ source editable/generator và output phân phối có mapping rõ. Sau khi build, mở lại **đúng ZIP/MKV/ASS/video cuối** thay vì chỉ kiểm working folder: liệt kê tên file, giải nén/đọc thử, so hash manifest, probe track/language/default flags, kiểm font attachment và xem mốc đầu–giữa–cuối cùng đoạn ngoại lệ. Nếu tên file có Unicode, khoảng trắng hoặc ngoặc, kiểm từ archive thực. Không báo hoàn tất từ việc lệnh đóng gói trả exit 0.

Với mux, xác nhận video/audio/sub track thực và sync trên output; với hardsub, decode frame từ output; với softsub, render track đã mux bằng target player/renderer khi có thể. Một mẫu đầu đoạn không bắt được truncation cuối, asset thiếu chỉ xuất hiện ở tập khác hoặc timing lệch sau một điểm nối.

## Triển khai qua các tập

Dùng effect đã duyệt/frozen snapshot làm nguồn; không trích lại từ tập đã render/deploy rồi hiệu ứng hóa lần nữa. Kiểm tra từng tập thực sự có OP/ED/title cần chèn, nguồn FPS/start_time và phiên bản hình. Lấy anchor được người dùng cho hoặc tìm bằng actual frame; đừng mặc định một offset cho mọi tập.

Đối chiếu nhiều mốc hình và nhạc để xác minh toàn đoạn cùng phase. Ghi frame anchor/PTS và ASS offset; dịch comment nguồn cùng effect và mọi thời gian liên quan được phép, giữ duration và tags relative. Nếu absolute palette/motion clock nằm trong config, tái tính offset đúng chứ không chỉ dịch Start/End ở nơi chưa compile.

Thay khối cũ qua selector rõ (style/actor/fold/manifest + nội dung), không xóa mọi event rơi trong time span: dialogue hoặc sign khác có thể chồng đúng đoạn OP. Gom đủ hình của title theo khối/fold; các layer không có Name vẫn có thể thuộc title.

Style destination theo brief/dự án. Trước migration, so kế thừa/override như ass-model; không chỉ rename source style rồi đổi ngoại hình source comments. Giữ styles ngoài phạm vi, [Fonts], tags, metadata và event order. Tập ngoại lệ giữ nguyên nếu không được giao.

Stage từng output, verify clock và actual composite ở các anchor, then reread baseline hash trước khi install. Ghi manifest per-file và backup. Re-run nếu file đã đổi, không ghi đè bản mới bằng staged cũ.

## Vị trí event và fold

Danh sách ASS không bắt buộc sort theo thời gian. Nếu brief đặt OP dưới thoại, tìm đúng event thoại cuối theo vai trò của dự án và chèn cả block ngay sau đó; không mang source comments lên đầu toàn bộ Events nếu brief muốn trong block.

Đọc fold extension đang dùng, bảo toàn metadata cũ và cấp IDs/group mới không trùng. Có thể dùng Comment header làm nhãn, source comments rồi effect, marker tail tại cuối khối. Không tự đổi Comment thành Dialogue. Fold metadata không được lấn sang một section khác; kiểm tra nội dung khi mở trong Aegisub và render stacking sau reorder.

## Bộ ảnh/video sign để đối chiếu

Nếu dự án đã có fold/Extradata xác định từng sign, dùng nhóm đó làm inventory trước khi gom theo khoảng thời gian. Hai sign sát nhau không tự thành một clip; một sign nhiều lớp/FBF không thành nhiều asset. Liệt kê membership và khoảng hiện thật, rồi đối soát số nhóm nguồn → output theo từng tập. Khi người dùng bật lại Comment hoặc sửa master, cập nhật inventory từ bản mới; “render lại toàn bộ” khác chỉ bổ sung các nhóm thiếu.

Để chỉ hiện sign, tạo ASS tạm chọn đúng vai trò/lớp; không đổi Layer/Style/Actor hay trạng thái master để thuận tiện render. Bản raw và rendered dùng cùng nguồn, cut/PTS, crop, size và duration để so trực tiếp. Tạo đúng media/bố cục được yêu cầu, không tự thêm GIF, HTML hoặc sửa nguồn. Dọn bộ output qua manifest các file sinh ra; xem [version-sync-organization.md](version-sync-organization.md) cho rollback bảo toàn chỉnh sửa chưa commit.

## Bản render NC và các variant

NCOP không nhất thiết bắt đầu ngay câu đầu bài hát. Probe và xem mở đầu/đuôi; xác định title/cut/hình đầu OP bằng native frame và đối chiếu tập tham chiếu. Tạo standalone synced ASS với chỉ các style/event cần, không burn-in thoại/ED/credit ngoài yêu cầu. Đúng audio track và no overwrite raw.

Chuyển nguồn video từ MKV sang MP4 có thể đổi độ chính xác timebase; kiểm tra output frame biên. Giữ standalone ASS để sau này chỉnh được, xuất tên rõ và chất lượng vừa đủ theo brief. Không tạo video preview nếu người dùng chỉ cho phép ảnh tĩnh; cũng không giữ hạn chế đó khi họ đã yêu cầu một bản render video cụ thể.

“Video chỉ có sub và nhạc” cần canvas độc lập, không mặc định burn vào phim. Chốt nền trong yêu cầu hiện hành; lấy audio stream đúng, đổi clock toàn cue/phase nhất quán, tính crop từ toàn bộ blur/motion qua đoạn và giữ head/tail padding khi được yêu cầu. Nếu chỉ cần tăng khoảng trắng dưới để cân bố cục, pad canvas thay vì dời geometry của ASS đã chốt. Với trần dung lượng, encode từ ASS/raw nguồn và probe file cuối; không lấy bản encode nhỏ mờ làm nguồn cho lần encode kế tiếp.

## Commit và push khi được yêu cầu

Kiểm tra HEAD, branch/upstream, staged diff và path thực của file sau khi người dùng có thể di chuyển nó. Chỉ stage tài sản được giao, không add cả thư mục raw/untracked hoặc gom các deleted preview không liên quan. Nếu video/sub đã nằm trong commit gần nhất thì báo hash, không tạo commit trùng.

Push cần chỉ thị hiện hành/đã được cấp. Không xuất credential URL/token/log nhạy cảm. Khi remote từ chối kích thước, dùng chính giới hạn remote báo; Git LFS exact filenames tránh glob brackets/spaces. `git lfs track --filename` hỗ trợ literal path; không giả định untrack có cùng options.

Nếu blob lớn nằm trong commit chưa được remote nhận, thêm một commit pointer ở sau có thể vẫn để blob cũ trong lịch sử push. Chuyển các file cần thiết sang LFS và amend/migrate phần lịch sử chưa publish khi phạm vi cho phép; giữ user changes/staging ngoài phạm vi. Không force push published history hoặc sửa credentials dựa trên một permission suy diễn.

Kiểm tra pointer trong index/commit và object có nội dung thực; không nói đã LFS chỉ vì đã sửa .gitattributes. Push thành công gồm upload object và cập nhật ref; báo commit mới nếu amend đổi hash. LFS là cách lưu file, không phải thay Text ASS thành ba dòng pointer trong working output.

## Đồng bộ, chapter và bản giao

Với revised set/ZIP/report, dùng [version-sync-organization.md](version-sync-organization.md); so direct ASS fields đúng nguồn→đích, không lấy số diff từ Excel hay báo cáo của baseline khác. Copy đúng trường đã giao, giữ source comments/effects ngoài scope.

Chapter boundary có thể ở giữa GOP. Khi no-reencode được yêu cầu, probe seek/keyframe và báo phần preroll thực sự có trong clip; không tự hứa cắt chính xác mọi frame hoặc âm thầm encode GOP đầu. FFmpeg phân biệt seek/transcode với stream-copy; xem [tài liệu seek](https://ffmpeg.org/ffmpeg.html#Main-options). Căn ASS theo **đầu clip thực** sau khi probe output, không chỉ chapter Start. Tránh hỏi lặp lựa chọn đã có; tiến hành phần đã được phép và xác định xung đột cụ thể nếu exact cut/no-reencode cùng không đạt.
