# Chứng cứ từ các chat làm sub ngoài một repo

Chỉ mục này mở rộng [history-evidence.md](history-evidence.md). Nó ghi bài học tác nghiệp, không sao chép transcript/credential và không biến cách làm của Houseki hay một OP thành quy định mọi dự án.

## Phạm vi và độ chắc

Lần mở rộng đọc 18 phiên chat có liên quan, gồm snapshot gần nhất của 10 chat Codex và 8 chat ChatGPT. Với 9 chat Codex trong nhóm này, đã trích user messages/kết quả từ rollout local, loại trùng và bỏ nội dung hệ thống/approval khỏi cơ sở workflow. Việc “đọc chat” không có nghĩa mở lại toàn bộ raw video/ảnh/audio/artifact của mỗi phiên hoặc nghiệm thu lại output lịch sử. Chat cloud có phần đính kèm không còn nội dung trong snapshot; ghi giới hạn đó khi tái dùng.

| Nguồn / thread ID | Bài học bổ sung hoặc giới hạn | Đọc |
|---|---|---|
| OP/ED editable — `01a0da12-2672-7e83-9f31-9a0aae430a02` | 4.038 rendered events; source/generator roundtrip; spacing cả câu, border dưới fill, right alignment và particle retarget | lyrics-layout-retargeting |
| Houseki OCR/gom nhóm — `01a0d86c-36b7-7520-9bf9-70d34d6aae7c` | Nhầm style inventory; xáo thứ tự karaoke; OCR bị dịch lại; ED reuse 11 câu; provenance/rescue; source scope | ocr-source-preservation, version-sync-organization |
| Houseki nghiệm thu và lyric ngoại lệ — `01a0d957-ad44-79a1-ac9d-9bf60f7d2084` | Coverage khác accuracy; ED tập 8 khác 9 cue; ngắt \N tối đa một mới; OP chapter có keyframe preroll; việc QC JP chưa hoàn tất | ocr-source-preservation, dialogue-localization, delivery-projects |
| Chuẩn bị review Houseki — `01a0ddc7-a45d-76c1-a1d6-2de4600e6f08` | Handoff yêu cầu toàn thoại JP khác pass ngôi xưng; snapshot không chứng minh review đã xong | field-edits-qc |
| Houseki sync revised — `01a0de4d-d818-7201-b63a-f1f41e749e3f` | Sai folder/mốc diff; 350 Text và 745 Effect diff; yêu cầu giữ note đích khi sync thoại | version-sync-organization |
| Gradient — `01a101a2-376e-77a2-9341-7511cbc17bef` | Đủ 6 anchor và phase xuyên 25 dòng; 12–13 giữ border gradient; “8 màu” đã được user đổi lại | color-palette-validation |
| Shapery — `01a0f688-c0b3-7b31-9781-6c5d5720aca9` | Fit Curves/Flatten có thể tăng path; chỉ thử thông số trên bản sao; shape khác vector clip; plugin/version phải xác minh | geometry-animation, render-performance |
| Image tracking — `01a0f6c1-c29c-77a1-9343-edc34f8a69c3` | 76 frame đủ không chứng minh không jitter; org đã đi theo track, kết luận org đứng yên bị sửa; actual text/font/perspective còn chưa chốt | typesetting-tracking |
| Chapter OP — `01a0da1d-5605-7c72-ba2e-650ac41eec1a` | Stream-copy theo chapter, giữ hình/tiếng; không dùng một timestamp case làm mốc phim khác | delivery-projects |
| EN-first skill — `01a0d2a4-533c-7e22-8b00-d9232a87db91` | Champion/chồng thoại cần mẩu VI đúng ý; không coi cue VI là vật thể nguyên khối; Cliff Boris không lặp nguồn sang cue khác ý | dialogue-localization, ocr-source-preservation |
| Cloud review đại từ Houseki — `6ab7c943-cea4-83ec-af5f-0a69ffa97404` | Tôi–cậu máy móc làm mất giọng; ZIP cũ link gần giống; 495/496/4 thay đổi thuộc những cặp baseline khác nhau | dialogue-localization, version-sync-organization |
| Cloud diff/LFS — `6abbd6d3-63a4-83ec-a479-c0db7fc86384` | “ASS text luôn nhẹ” là giả định sai; inspect nơi chứa bytes trước khi đề nghị đổi storage; không copy mẫu attributes lịch sử mù quáng | delivery-projects |
| Matrix — `6aba92f8-6eac-83ec-a8fe-d8569e431522` | Lời khuyên header-only chưa chứng minh appearance; kiểm chứng lại với hướng dẫn primary và pipeline target | color-palette-validation |
| Hardsub Houseki dung lượng giới hạn — `6ab7a730-6a10-83ec-8ae1-107af02c5f17` | User muốn dưới 20 MB vẫn 1080p; giữ nguồn gốc để encode lại, font fallback không mặc nhiên tương đương | render-performance |
| Video/audio/ASS/font riêng — `6ac10000-d830-83ec-bcb8-d18ccedae4e8` | Cắt đồng hồ hình/âm/sub nhất quán; audio dài hơn hình cần scope rõ; encode thành công khác lưu artifact cloud thành công | render-performance |
| Lời nhạc ASS 25 event — `6ab6d4b3-a9bc-83ec-a2f8-0854fe4a6ffc` | Giữ đúng format/count/source tags/romaji k khi chỉ thay lời Việt | lyrics-layout-retargeting |
| Review CSV cue JP/VI — `6aba786c-2f1c-83ec-82e5-626cde017223` | Đọc câu nối trước khi coi mất sắc thái; ít nhất khác khoảng, suy diễn thêm làm sai nghĩa | dialogue-localization |
| So hai bản dịch — `6ac26d25-2018-83ec-b3a6-93c551b2fbe3` | Similarity bị ảnh hưởng duplicate/typeset/split; cùng wording không chứng minh độc lập nguồn hay copy, số phần trăm cần metric/baseline rõ | dialogue-localization, version-sync-organization |

## Đối chiếu thêm từ lịch sử local tháng 10/2026

Lần rà 2026-10-20 kiểm kê log Codex kể cả `.jsonl.zst` và lịch sử Antigravity trong SQLite. Trích lời user và câu trả lời công khai, tách phiên con/approval khỏi số chat độc lập; với Antigravity, một số user text thiếu trong search index được đối chiếu lại từ step gốc. Các hàng sau là **chứng cứ lịch sử**, không phải kết quả benchmark mới hoặc đánh giá xếp hạng model. Ảnh/audio lịch sử chưa được xem/nghe lại toàn bộ; “agent báo đã kiểm” khác “user chốt” và “đã kiểm lại artifact”.

| Nguồn và locator | Phản hồi → sửa cần thiết → trạng thái cuối quan sát được | Áp dụng |
|---|---|---|
| AG `27d4338d-de74-4a5c-a329-478e52eff9e8`, user 1187–1560 | Nhiều round dịch vẫn tiếp tục đổi; user chỉ ra chưa có barem. Chốt tiêu chí, tách lỗi nghĩa/giọng/callback khỏi gu từ; không coi thêm round là tăng chất lượng | problem-solving; dialogue-localization |
| Codex `01a12517-ac4b-7c72-bc8e-230c713671bd`; AG `ed660187-2553-4dcf-a535-521373d938a5`, user 286 | Có upload audio/transcript thật nhưng chưa đủ chứng minh mọi Actor; default MATCH, tên speaker xuyên batch và note đại trà cần sửa. Kết thúc có candidate/report, không là xác minh giọng độc lập toàn phim | field-edits-qc |
| Codex `01a12ee8-86fc-77e0-a737-85d9f71e8564`, user 763–781 | Đổi Dialogue thành Comment bị báo nhầm xóa. Bảng gọn cần giữ kind/membership, chỉ bung Text được sửa; Actor review đứng ngoài export | version-sync-organization |
| AG `9146b445-45a8-46cd-966f-991c26e2f8c1`, user 0/165/207 | Tạo bảng gọn, thêm cột từ thuật toán nhóm cũ, rồi đổi theme khi user đang sửa. Cần ID/header và fresh read; báo dry-run không chứng minh đã import bản sửa cuối | version-sync-organization |
| AG `6ea790e8-0cda-4594-ad08-3b24c9f07999`, user 291–841; Codex `01a1449b-7a78-7b63-a4a4-2bbe6dc30a70` | Frame cuối được user chốt; motion/handoff ban đầu thất bại. Codex sửa perspective rồi tông/độ nét theo bề mặt thật, đổi neo và tích hợp sau user chốt. Cấm dùng một kinh nghiệm “không dùng fry” làm luật mọi sign | perspective-motion; scene-contract |
| AG `27d4338d-de74-4a5c-a329-478e52eff9e8`, user 2762–4033 | Mây đổi màu theo thời gian thay vì mảng màu, đối xứng/coverage sai, lead-in hạt che khối fade. User bác và yêu cầu handoff; bản này chưa đạt hình | sign-fx-recipes |
| Codex `01a14dfa-0bd7-7753-855e-11bdbafe59a2`, user 582–1188 | Từ một chấm nở sang nhiều vùng hợp khối, giảm detail/margin/duration, liên kết mask–fade chữ; bỏ trượt continuous do user bác. Sau đó user giao tối ưu và cài master | scene-contract; sign-fx-recipes |
| Codex `01a14f0d-84bc-7dc2-a306-66bf144505d6`, user 1170–1950; artifact `ed-audit-20261018/REPORT.vi.md` | Tối ưu làm nhảy layout, mất spacing và attachment sai dù báo nhiều mốc render. Kiểm lại chữ native, font decode/hash, attachment-only và installed-only; report giữ sai số/giới hạn target rõ | render-performance |
| AG `75ca1624-c6c2-4bf5-b4dd-ebdf2411c5e4`, user 263/1103/1162/1266 | Tiếp tục nhầm tác vụ; revert nhầm mốc rồi user phải chỉ lại. Handoff phải gắn yêu cầu cuối và snapshot chính xác; “chỉ kiểm tra” không cho phép chạy sửa | scene-contract; version-sync-organization |
| Codex `01a15038-844d-7a00-9fa8-226034bfd2cc`, user 529–1641 | Rebuild làm xấu bản an2; user chỉ yêu cầu sửa bước hụt/đỉnh cao. Cần rà cả họ shape, giữ margin khi hạ đỉnh; sau các vòng sửa user chốt cài master | problem-solving; sign-fx-recipes |
| Codex `01a15038-844d-7a00-9fa8-226034bfd2cc`, user 2073/2127; AG `75ca1624-c6c2-4bf5-b4dd-ebdf2411c5e4`, user 1335–1480 | Render sub+nhạc trên canvas độc lập, thêm padding; biến thể sau đổi nền trắng và pad đáy thay vì dịch ASS. File render báo hoàn tất không tự có nghĩa đã được user nghiệm thu chất lượng | delivery-projects |
| AG `412ec1a4-86af-41c8-bf7f-8ba0b7eeeb93`, user 1111–1796 | Fold sign bị bỏ qua, render thiếu/gộp và cleanup làm mất sửa tay. Không có xác nhận cuối phục hồi chính xác; không nâng thành case thành công | delivery-projects; version-sync-organization |

## Thực hành cần mang sang task mới

- **Đúng nguồn:** raw hình/Việt OCR, bản revised và EN master có vai trò riêng. Ngoại hình/style/name/Actor không quyết định role hoặc nghĩa.
- **Đúng phiên bản:** hash/link/archive và đích sync phải cùng baseline đã so. Report cũ “final” không xác nhận trạng thái hiện tại.
- **Đúng phạm vi:** OCR-only không dịch lại; pronoun pass không thành full JP review; ngắt dòng không thay lời; nhóm stable không sort lại karaoke; dọn output không xóa raw.
- **Đúng kiểm chứng:** đủ cue/frames/coverage không thay accuracy, actual glyph render, playback và artifact đã giao. Ghi rõ phần chưa đo/chưa nghe/còn mâu thuẫn.

## Trường hợp không được nâng thành quy tắc

Font/margin/CPS/size/clip/alignment và bộ đại từ của một case không áp cho dự án khác. Một hướng dẫn Shapery đúng bản cài cũ không chứng minh bản mới giữ cùng UI/behavior. Byte-identical original roundtrip không chứng minh effect với lời mới. Keyframe khác scene cut; reencode, stream-copy hoặc HEVC là lựa chọn theo yêu cầu và target, không phải mặc định.

Các chat chứa đề xuất kỹ thuật tự mâu thuẫn, báo cáo chưa được nghiệm thu hoặc file đã dọn: dùng chúng để chọn phép kiểm tra, không sao chép kết luận. Nếu task cần con số/phép fix cụ thể, đọc lại nguồn hiện hành và primary docs tương ứng trước khi làm.
