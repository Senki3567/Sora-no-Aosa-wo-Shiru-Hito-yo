# Workflow trực dịch Nhật → Việt trên khung EN

## Đầu vào và vai trò

- **EN ASS** giữ thứ tự cue, timing, style, actor, tag và ranh giới đầu ra.
- **Full.vi.ass từ workflow căn tích hợp** là khung đã căn và là điểm xuất phát cho file thứ hai. Dùng nó để giữ cue, nhận diện nội dung đã được biên tập và so sánh sau dịch; không lấy câu Việt của nó làm câu nguồn hay khuôn diễn đạt.
- **JP ASS** là nguồn quyết định nội dung, cách hiểu và sắc thái. Timing và ranh giới cue Nhật có thể khác EN.
- **Các tập Việt đã duyệt** giúp xác định giọng nhân vật, thuật ngữ và cách viết; không được lấn át nghĩa JP.

## Tạo file thứ hai

1. Đọc EN, Full và JP theo nghĩa, actor, đối thoại kề nhau; không ghép chỉ bằng timing hoặc số cue.
2. Sao chép Full sang file mới. Giữ nguyên cue, thứ tự, timing, style, actor, tag và các trường event; chỉ thay Text hiển thị bằng bản dịch trực tiếp từ Nhật và thay Effect bằng trans note. Nếu Text có EN ẩn trong ngoặc nhọn theo quy ước dự án, giữ nguyên và xác nhận phần đó không hiện khi render. Không sửa file Full. Mặc định đặt file mới cạnh Full với hậu tố .vi.from-jp.ass; theo tên hoặc thư mục người dùng chỉ định nếu có.
3. Ghép lời Nhật tới cue EN tương ứng theo ý. Cho phép cue Nhật gộp/tách hoặc lệch giờ; không ép tương ứng 1:1. Dùng EN như trợ giúp phát hiện cách hiểu, rồi kiểm lại với JP. Dịch từ JP, giữ chủ thể bị lược, cách gọi/kính ngữ, phủ định, điều kiện, mức chắc chắn, câu đệm, lặp và bỏ lửng. Câu Việt có thể dài hơn nếu cần giữ nghĩa; ưu tiên rõ và sát lời gốc.
4. Rà tên và biệt danh theo mạch truyện, nhất là chữ Nhật cũng có thể là danh từ thường. Phân biệt điều văn bản file thực sự có với điều suy ra từ ngữ cảnh. Nếu EN và JP khác nhau, dịch theo JP và giải thích ảnh hưởng đó trong note khi cần biên tập.
5. Chỉ đánh dấu missing khi không tìm thấy lời JP tương ứng sau khi xét cue kề và các đoạn gộp. Theo dõi thiếu hụt JP riêng với thiếu hụt VI nguồn ở bản Full. Nội dung JP không có cue EN thì ghép vào cue hợp lý nếu tự nhiên; nếu không, báo vị trí và lý do, không tự thêm event.

## Trans note trong Effect

Viết một trans note riêng bằng tiếng Việt cho **mọi cue thoại**. Note phải giúp người dịch/biên tập chọn câu Việt: nêu nghĩa thực tế trong cảnh; giải thích từ/cấu trúc Nhật quan trọng và cách chúng đổi sắc thái hoặc hàm ý; chỉ rõ chủ thể bị lược, cách gọi, quan hệ, mức lịch sự, và liên hệ cue kế cận khi câu bị chia. Nêu cách đọc tên/biệt danh hoặc khác biệt JP–EN nếu có tác động đến lựa chọn dịch.

Viết đủ cụ thể để dùng được, không chỉ ghi “thân mật”, “buồn” hay “ngạc nhiên”; nhưng đừng kéo dài cảm thán đơn giản cho đủ khuôn. Không mở đầu bằng mẫu JP quote followed by colon, và không chép nguyên câu Nhật nếu việc đó không giúp giải thích. Khi bản chép có vẻ sai nhưng ngữ cảnh chỉ ra chắc cách hiểu, ghi cách hiểu và căn cứ; chỉ yêu cầu nghe lại nếu còn ít nhất hai cách nghe hợp lý làm đổi nghĩa/dịch.

Theo quy ước hiện tại của dự án Waiting in the Summer, đặt bốn dấu cách đầu mỗi note trong Effect. Với dự án khác, giữ định dạng đang dùng hoặc làm theo yêu cầu cụ thể. Tránh dấu phẩy ASCII trong Effect vì dấu phẩy phân cách trường ASS.

## Token và kiểm tra đầu ra

Tạo ghi chú tra cứu ngắn cho thuật ngữ, quan hệ và câu lặp; không nạp nguyên nhiều tập vào mọi lô. Xử lý theo cụm hội thoại đủ ngữ cảnh và mở rộng khi có tên đa nghĩa, lời lặp, nguồn thiếu hoặc JP–EN mâu thuẫn. Không bỏ qua cue thoại nào.

Trước khi giao:
- Kiểm tra mọi cue thoại EN đều có bản dịch hoặc missing có căn cứ, và có trans note tương ứng.
- Xác nhận file mới giữ đúng cue, timing, style, actor và tag của Full/EN.
- Xác nhận Full không bị sửa; bản dịch trực tiếp được quyết định từ JP, không bị kéo theo câu chữ Full.
- Kiểm tra cách thụt lề Effect theo quy ước dự án và rằng dấu câu không làm hỏng cấu trúc ASS.

## Công cụ trong ASS Studio

Dùng parser đã nêu trong [ass-model.md](ass-model.md) và helper `scripts/ass_tools.py` để inspect/patch/compare bản riêng sau khi có map JP và quyết định dịch. Khung Full chỉ cung cấp structural fields/EN ẩn, không là lời nguồn để viết lại. Plan có scope Text + Effect và expected identity của cue; không chỉnh file Full gốc. Không cần gọi/cài một skill ngoài bộ này.
