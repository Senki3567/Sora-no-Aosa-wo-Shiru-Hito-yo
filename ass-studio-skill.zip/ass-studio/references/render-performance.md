# Render và hiệu suất softsub

## Mô hình chi phí cần dùng

libass xuất các bitmap alpha và màu để player blend lên video. Tổng diện tích bitmap là chỉ số quan trọng; số event/byte ASS không đủ kết luận. Cache, blur, transform và clip ảnh hưởng đường raster; clip nhỏ không bảo đảm phần trước clip rẻ. Drawing giản lược riêng từng bản có thể làm mất chia sẻ cache. Đo bản thật trước/sau thay vì gán “native luôn nhanh” hay “FBF luôn chậm”. Nguồn giải thích: [arch1t3cht — renderer internals](https://gist.github.com/arch1t3cht/8cb1793beb72d30e334c7c46ff8c1080).

## Render đúng môi trường

Probe resolution/video SAR/colorspace; đọc PlayRes/LayoutRes/ScaledBorderAndShadow và font. Nạp font project, kiểm tra log fontselect/fallback và dấu Việt. Xem ASS standalone alpha lẫn composite trên raw, ở kích thước hiển thị mục tiêu. Target VSFilter/player khác có thể khác libass; đừng hứa tương thích từ một engine.

Helper `libass_render.py` dùng thư viện libass hệ thống, font dirs chỉ định và timestamps rõ. Không tự lấy font từ repo cũ. Nó trả số bitmap/diện tích và thời gian CPU ass_render_frame; thời gian tạo PNG/composite không nằm trong con số CPU đó.

```bash
python3 scripts/libass_render.py effect.ass --font-dir Fonts --size 1920x1080 --storage-size 1920x1080 --times-ms 116783 117250 118000 --png-dir work/rgba --report work/render.json
python3 scripts/libass_render.py effect.ass --font-dir Fonts --size 1280x720 --storage-size 1920x1080 --times-ms 116783 117250 118000 --cache-mb 16 --fresh --report work/profile.json
```

Storage size là kích thước mã hóa gốc, không de-squeeze. Với PAR khác, dùng `--pixel-aspect` theo video/target; mặc định 0 để libass suy ra. LayoutRes hợp lệ có thể ưu tiên hơn cấu hình API, nên đối chiếu header và [API libass](https://github.com/libass/libass/blob/master/libass/ass.h). PNG RGBA là overlay, chưa phải ảnh kiểm chứng với footage. Composite tại đúng PTS và màu/render setup, hoặc dùng ffmpeg `ass`/player để burn-in một số frame. Không alpha-composite bitmap premultiplied như straight alpha hai lần. Helper PNG không tái hiện toàn bộ color-management/HDR/player blend; khi kiểm chứng màu cuối cùng, dùng pipeline/video/player mục tiêu và metadata colorspace thực.

## Thiết kế phép đo

Chọn mốc có intro phức tạp, karaoke, nốt dài/ngắn, nhiều event đồng thời, outro và overlap. Đo cùng timestamps, fonts, resolution, cache và machine load cho baseline/candidate. Dùng profile tuần tự giữ cache và renderer mới mỗi mẫu để xét seek/cold path; renderer mới vẫn không là toàn bộ cold start của process/font/track.

Báo median/P95/max, mẫu vượt frame budget, số event đồng thời, diện tích bitmap, file bytes và event count; gắn hash output. `1000/fps` là toàn bộ frame budget, decoder/blend/display còn dùng một phần nên CPU libass dưới ngưỡng chưa đủ hứa playback máy yếu. Một máy phát nhanh không chứng minh máy yếu cũng nhanh; nếu có mục tiêu máy/player thực thì thử trên nó. Giữ giới hạn đo rõ.

Với thay đổi nhỏ dễ lẫn nhiễu đo, chạy baseline/candidate xen kẽ theo cặp cùng mốc, lặp đủ để thấy phân bố; không đo hết bản A rồi hết bản B trong hai trạng thái tải khác nhau. Phân biệt wall time và CPU time của đúng vùng render: wall time có thể gồm chờ lịch chạy, process CPU có thể gồm luồng khác. Ghi loại đồng hồ và chi phí được tính; mức cải thiện nhỏ hơn dao động chưa đủ kết luận tăng tốc.

Đọc ảnh để biết còn chữ và đúng phase; một benchmark nhanh nhưng mất lớp chữ là thất bại. Không rerun các kiểm tra to khi chưa có thay đổi mới hoặc lo ngại cụ thể.

## Chọn nơi cần tối ưu từ triệu chứng

| Triệu chứng | Phép cô lập | Quyết định sau phép thử |
|---|---|---|
| File nhỏ hơn nhưng render không nhanh hơn | Cùng timeline/font/cache, so CPU và bitmap với baseline | Giữ kết luận giảm bytes riêng; tìm raster/blur/cache thay vì tiếp tục xóa văn bản |
| Chỉ một đoạn peak tốn CPU | Render sign/lớp riêng và full ASS tại cùng timestamp | Tìm layer/footprint gây tốn rồi đổi cơ chế có mục tiêu; kiểm overlap toàn cảnh sau đó |
| Sequential nhanh, seek chậm | So cache warm và fresh renderer/process với giới hạn phép đo rõ | Đánh giá cache miss/font/setup; không hứa playback chỉ từ median warm |
| Benchmark nhanh nhưng mất hình | So event active, alpha, font, RGBA/crop và composite | Loại candidate sai appearance trước khi đánh giá hiệu năng |
| Overlay đúng nhưng player drop | Video không sub, baseline, candidate trên cùng đoạn | Khoanh decode/raster/blend/display; dùng [playback-diagnostics.md](playback-diagnostics.md) |

Giả thuyết tối ưu cần ghi thay đổi cụ thể và kết quả mong đợi: giảm bitmap rỗng bằng chia shape; giữ outline dùng chung để thử cache; thay nhiều event bằng native tag khi hình/clock cho phép. Mỗi thay đổi phải qua cả gate hình và phép đo liên quan. Không tích lũy các mẹo chưa đo rồi báo một tổng tốc độ không thể quy nguyên nhân.

## Tối ưu có điều kiện

Ưu tiên giảm lớp thừa và footprint lớn; không tự làm mỏng chữ/blur hoặc phá masking để giảm chi phí. Thử native move/t/alpha, chia highlight thay vì cả dòng, một shape ghép thay nhiều shape khi cache/appearance cho phép, dùng cadence rung vừa đủ, tránh tạo noise/fullscreen overlay nhiều lớp. Tách giảm dung lượng khỏi giảm render cost.

Giữ shape/source có thể reuse; kiểm chứng renderer ở vài scale. Drawing Fit Curves/Flatten/Simplify có thể tăng số tọa độ và bytes; đo output, silhouette và cache. Thử một thay đổi rồi xem cả visual và profile, không tích nhiều “tối ưu” chưa đo.

Với contour nhiều component, có thể chọn candidate theo từng component bằng render trước/sau, rồi bắt buộc kiểm lại bản kết hợp. So premultiplied RGBA hoặc composite trên nền phù hợp để không coi RGB rác ở alpha 0 là thay đổi nhìn thấy. Kiểm nhiều kích thước target, extrema/bbox, counter và dấu; sai số hình học nhỏ không bảo đảm AA/raster giống. Exact ở một scale không chứng minh exact ở scale khác. Đọc [perspective-motion.md](perspective-motion.md) để phân biệt bảo toàn baseline với bám đúng footage.

## Bảo toàn khi bake chữ, gọt shape và đóng gói glyph

Đối chiếu end-to-end với **bản hình được duyệt trước tối ưu**, kèm checkpoint từng phép chuyển. So hai intermediate sau cùng có thể bỏ sót một lỗi đã lọt vào cả hai. Đặc biệt kiểm frame ngay trước/tại/sau ranh shape → chữ native hoặc FBF → transform, các trạng thái fade/mask và các scale mục tiêu; số mốc lớn không cứu được baseline hoặc đường nạp font sai.

Text → outline → glyph cần giữ shaping/layout thật: giãn chữ kể cả `\fsp` âm, kerning, advance/sidebearing, baseline, `\pbo`, alignment/pivot, drawing scale và transform. Dùng ink render của chữ native làm đối chứng; một contour giống hình nhưng metrics khác vẫn gây nhảy khi chuyển về chữ thường. Nếu converter chưa hỗ trợ tag/phase mới, dừng ở phần đó hoặc giữ native, không lặng lẽ bỏ tag để xuất được hình.

Với font sinh, gắn hash/names rõ để biết bản nào được dùng. Sau khi ghép `[Fonts]`, **giải mã lại attachment từ ASS cuối và so bytes/hash** với font chuẩn. Dữ liệu uuencode có thể có dòng bắt đầu `[`; không tách section bằng điều kiện mọi dòng bắt đầu `[` rồi cắt mất payload. Dùng header section hợp lệ trong ngữ cảnh, giữ newline và toàn block; mở lại chính ASS đã ghép để kiểm. Lỗi này từng không lộ vì font đúng cài trên máy đã che attachment hỏng.

Khi tuyên bố font portable và Aegisub preview đúng, kiểm riêng đường nạp attachment/project với đường nạp font đã cài; ghi fontselect/file/hash thật và loại trừ fallback che lỗi. Cài font hoặc gỡ bản cũ chỉ khi được giao, giới hạn theo family/file có usage đã kiểm và giữ bản khôi phục; không xóa font khác chỉ vì tên gần giống. Font mới/đổi family có thể cần ứng dụng nạp lại cache; không tự đóng Aegisub đang có sửa chưa lưu. Giữ source chữ/comment cùng mapping/generator để lời mới còn tái sinh được, không chỉ giao PUA glyph đã bake.

## Khi có yêu cầu render encode

Giữ input gốc, audio và FPS; map stream rõ, chỉ burn-in các cue được chọn. User yêu cầu không reencode thì dùng stream-copy và nêu giới hạn keyframe; user yêu cầu encode thì chọn codec/quality phù hợp kích thước và player. Một cấu hình moderate đã dùng là 1080p H.264 CRF 21/AAC 192k, đây là điểm bắt đầu theo yêu cầu cụ thể, không chuẩn bắt buộc.

Kiểm tra output thực: duration, count/FPS, audio, frame trước/tại cut, title, kara/grade/outro và đuôi video. Encode log không có lỗi và output tồn tại chưa chứng minh sync hoặc font đúng.

Các trường hợp shape lặp có thể thử reuse outline qua glyph/font nhúng rồi đo lại; đọc [playback-diagnostics.md](playback-diagnostics.md) để phân biệt giảm MB, giảm CPU và playback đúng. Không chuyển giải pháp chẩn đoán player thành lời hứa đã tối ưu chính ASS.

## Encode với giới hạn dung lượng hoặc nguồn tách rời

Khi user giữ 1080p nhưng đặt trần bytes, chọn codec/preset theo target decode và đo chất lượng chữ/sign trên nền chuyển động. CRF là quality control, không bảo đảm trần file; có thể ước tính video bitrate `8 * target_bytes / duration_seconds - audio_bitrate - overhead`, chừa margin rồi dùng bitrate control/two-pass khi cần. Không dùng giới hạn ghi file để cắt đứt output và gọi đó là encode đạt duration. Encode lại từ raw để tránh generation loss; giữ resolution nếu đã được yêu cầu.

Video, audio và ASS riêng có thể dùng cùng absolute timeline hoặc clip-relative clocks khác nhau. Probe cả hai nguồn, xác minh sync/cut rồi áp một phép đổi đồng hồ thống nhất. Burn ASS trước trim ở timeline gốc hoặc shift cue khi burn sau trim: chọn một cách, không trừ offset hai lần. Audio dài hơn hình cần cắt theo deliverable đã yêu cầu, không suy sync từ duration bằng nhau. Kiểm tra đầu/đuôi và nhiều anchor giữa clip.

Font mapping thay bằng font gần giống không là font đúng; nếu phải fallback cần nói rõ và xem glyph/layout thật. Zip font chỉ là nguồn attachment, giải nén vào folder task rồi nạp renderer, không tự cài hệ thống. Kiểm tra decoded output, audio sync, bytes/resolution, actual subtitle frames và metadata; upload/library failure không phủ định local file nhưng phải báo đúng phần nào đã giao thành công.

Với matrix/palette đọc [color-palette-validation.md](color-palette-validation.md). Giữ file cũ và variant đã yêu cầu riêng, không ghi đè một bản render tốt chỉ để thử codec khác.
