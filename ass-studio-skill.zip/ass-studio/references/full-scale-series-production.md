# Quản trị Dự án Phụ đề Full-Scale (Nhiều Tập) & Cổng Kiểm Toán Tự Động

Đọc khi triển khai phụ đề cho một bộ phim truyền hình/anime dài tập (12–26 tập), một series phim chiếu rạp nhiều phần hoặc khi nhận bàn giao một dự án phụ đề lớn có nhiều người cùng tham gia.

Tài liệu này chuẩn hóa **cấu trúc 5 tầng của file ASS**, hồ sơ dự án (`series_bible.json`) và **4 cổng kiểm toán tự động** bằng `scripts/ass_tools.py` để đảm bảo chất lượng kỹ thuật đồng đều và ngăn ngừa lỗi lan truyền qua các tập.

---

## 1. Năm Tầng Kỹ Thuật của một File ASS Chuẩn

Mỗi file `.ass` trong một dự án series chuyên nghiệp không phải là một văn bản tự do, mà phải tuân thủ nghiêm ngặt cấu trúc 5 tầng:

| Tầng (Layer) | Section trong ASS | Vai trò & Quy định bất biến | Lỗi thường gặp cần tránh |
|---|---|---|---|
| **Tầng 1 — Canvas & Không gian** | `[Script Info]` | Xác lập độ phân giải `PlayResX`, `PlayResY`, ma trận màu `YCbCr Matrix` (thường là `TV.709`), `WrapStyle: 2` (ngắt dòng thông minh có chủ đích) và tỷ lệ co giãn `ScaledBorderAndShadow: yes`. | Đổi PlayRes giữa các tập làm lệch toàn bộ kích thước chữ/viền; sai Matrix làm biến đổi sắc thái màu. |
| **Tầng 2 — Bảng Kiểu Thống Nhất** | `[V4+ Styles]` | Tập hợp các style tiêu chuẩn: `Default`, `Alt`, `Narrator`, `OS`, `Signs`, `Flashback`, `OP`, `ED`. Tên style, font, size, màu và margin của các style chính phải khớp 100% giữa các tập. | Nhân bản các style rác (`Default_1`, `Style1`, `Copy of Signs`); tự ý đổi cỡ font thoại giữa các tập. |
| **Tầng 3 — Dòng Thời Gian & Sự Kiện** | `[Events]` | Bao gồm các dòng `Dialogue` (thoại nhân vật) và `Comment` (ghi chú ngữ cảnh, trans note, template KFX). Phân quyền trường rõ ràng: Text (lời dịch), Name/Actor (nhân vật), Effect (chỉ thị kỹ thuật). | Trộn lẫn lời thoại vào dòng sign; chèn ghi chú phân tích dịch vào dòng sub chính; làm mất EN provenance khi căn. |
| **Tầng 4 — Đóng Gói Font Đính Kèm** | `[Fonts]` | Chứa các file font nhúng đã mã hóa định dạng uuencode đặc thù của ASS (bắt đầu bằng `fontname: <FamilyName>_0.ttf`). | Lỗi giải mã làm hỏng file font; tách header làm mất payload; đặt font attachment xen giữa Styles và Events. |
| **Tầng 5 — Siêu Dữ Liệu Dự Án** | `[Aegisub Project Garbage]` / `[Aegisub Extradata]` | Lưu cấu hình video, audio, timecode, điểm neo lưới và metadata macro của Aegisub. Cần bảo toàn ở cuối file. | Chèn các dòng event mới xuống sau Extradata làm Aegisub không thể nhận diện được các dòng này. |

---

## 2. Hồ sơ Bộ Phim (`series_bible.json`)

Để duy trì tính nhất quán xuyên suốt nhiều tập phim, thư mục gốc của dự án bắt buộc phải lưu trữ file `series_bible.json`:

```json
{
  "schema": "ass-studio.series-bible.v1",
  "series_title": "Ano Natsu de Matteru",
  "technical_contract": {
    "play_res_x": 1920,
    "play_res_y": 1080,
    "ycbcr_matrix": "TV.709",
    "wrap_style": 2,
    "scaled_border_and_shadow": "yes"
  },
  "character_glossary": [
    {
      "actor_id": "ichika",
      "canonical_name": "Takatsuki Ichika",
      "japanese": "貴月 イチカ",
      "style": "Default",
      "relationships": [
        {
          "with": "kaito",
          "stage_episodes": [1, 9],
          "self_pronoun": "tôi",
          "other_pronoun": "cậu",
          "note": "Giai đoạn đầu quen biết"
        },
        {
          "with": "kaito",
          "stage_episodes": [10, 12],
          "self_pronoun": "em",
          "other_pronoun": "anh",
          "note": "Sau cảnh tỏ tình ở tập 10"
        }
      ]
    }
  ],
  "terminology_map": {
    "Rinon": "Rinon",
    "Men in Black": "Đặc vụ áo đen",
    "Federation": "Liên bang Ngân hà"
  },
  "shared_assets": {
    "op_style": "OP - Japanese",
    "op_translation_style": "OP - Vietnamese",
    "ed_style": "ED - Japanese",
    "ed_translation_style": "ED - Vietnamese"
  }
}
```

---

## 3. Bốn Cổng Kiểm Toán Tự Động (`scripts/ass_tools.py`)

Trước khi đóng gói bàn giao bất kỳ tập phim nào, Agent phải chạy qua 4 cổng kiểm toán tự động:

```mermaid
flowchart LR
    FileASS["File .ass Tập Phim"] --> Gate1["Cổng 1: lint-tags (Cú pháp thẻ)"]
    Gate1 --> Gate2["Cổng 2: timing-qc (Nhịp đọc & Scene Cut)"]
    Gate2 --> Gate3["Cổng 3: font-audit (Font & Dấu Việt)"]
    Gate3 --> Gate4["Cổng 4: series-audit (Nhất quán qua nhiều tập)"]
    Gate4 --> ReleaseReady["Release Candidate Sạch"]
```

### Cổng 1: Kiểm toán Cú pháp Thẻ (`lint-tags`)
```bash
python3 scripts/ass_tools.py lint-tags episode_01.ass --strict
```
- Quét các lỗi thẻ override: ngoặc nhọn chưa đóng (`{` thiếu `}`), dấu ngoặc thừa (`\}`), tag không có dấu gạch chéo (`bord2` thay vì `\bord2`).
- Phát hiện **trùng lặp thẻ khối đơn nhất (duplicate singleton block tags)** trong cùng một cặp ngoặc: ví dụ `{\pos(100,200)\an5\pos(300,400)}` làm renderer hành xử không xác định.
- Bắt các thẻ ảo thường bị LLM hallucinate: `\opacity`, `\scale`, `\rotate`, `\glow`.

### Cổng 2: Kiểm toán Nhịp Đọc & Cắt Cảnh (`timing-qc`)
```bash
python3 scripts/ass_tools.py timing-qc episode_01.ass --cps-warn 25.0 --flash-ms 100 --bleed-scene-cuts scene_cuts.json
```
- **Tốc độ đọc (CPS - Characters Per Second)**: Cảnh báo khi CPS $> 25.0$ (quá nhanh người xem không kịp đọc).
- **Flash Cues**: Phát hiện các dòng xuất hiện chớp nhoáng dưới 100ms.
- **Micro-gaps**: Phát hiện các khoảng trống 1–2 frame giữa hai câu thoại liên tiếp (cần nối sát hoặc tách rộng ít nhất 120ms).
- **Scene-Cut Bleeds**: Kiểm tra thoại đè qua vệt cắt cảnh $\pm 2$ frame. Tự động áp dụng **miễn trừ cho cụm thoại 1:N** khi nhiều nhân vật nói đè lên nhau.

### Cổng 3: Kiểm toán Font & Dấu Tiếng Việt (`font-audit`)
```bash
python3 scripts/ass_tools.py font-audit episode_01.ass --font-dir Fonts/ --check-vietnamese
```
- Đối chiếu toàn bộ font trong `[V4+ Styles]` với các font cài đặt trên hệ thống hoặc font nhúng trong `[Fonts]`.
- Giải mã trực tiếp phần uuencode trong section `[Fonts]` thành chuỗi byte gốc và kiểm tra mã băm SHA-256 để chống lỗi hỏng font nhúng.
- Quét toàn bộ bảng ký tự (cmap) của font để đảm bảo hiển thị đúng 100% các ký tự tiếng Việt có dấu (`Đ`, `đ`, `ơ`, `ư`, `ạ`, `ễ`, `ở`, `ỹ`...) mà không bị lỗi ô vuông (tofu) hoặc fallback font.

### Cổng 4: Kiểm toán Nhất Quán Giữa Các Tập (`series-audit`)
```bash
python3 scripts/ass_tools.py series-audit ep01.ass ep02.ass ep03.ass --strict-styles
```
- So sánh ma trận kỹ thuật: `PlayResX`, `PlayResY`, `YCbCr Matrix`. Báo lỗi nếu tập 1 dùng `TV.709` còn tập 2 dùng `TV.601`.
- So sánh bảng Style: Phát hiện style bị đổi màu, đổi font, đổi cỡ chữ, hoặc style xuất hiện ở tập này nhưng biến mất ở tập kia.
- So sánh danh sách Actor: Phát hiện lỗi chính tả tên nhân vật (ví dụ tập 1 ghi `Ichika`, tập 2 ghi `Ichika-senpai`, tập 3 ghi `Itchika`).

---

## 4. Quy tắc Bàn Giao & Quản Trị Phiên Bản (Delivery Governance)

1. **Khóa Checksum Baseline**: Mọi chỉnh sửa bắt buộc phải ghi nhận hash của file trước khi sửa (`scripts/ass_tools.py compare`).
2. **Không Overwrite Mù Quáng**: Mọi macro, generator hoặc script tự động đều phải ghi ra file candidate trước, chạy qua 4 cổng audit và render kiểm chứng rồi mới được thay thế bản master.
3. **Quản lý Font qua Git LFS**: File font binary (`.ttf`, `.otf`, `.ttc`) phải được quản lý qua Git LFS; không commit file font rỗng hoặc con trỏ pointer bị hỏng vào repository phát hành.
