# Palette liên tục và bảo toàn màu khi đổi matrix

Đọc khi chỉnh gradient từng char/line, palette quay vòng, hoặc mask đổi màu sau resample/migration. Phần grade theo footage đã ở [video-evidence.md](video-evidence.md); tài liệu này xử lý invariants của màu và pipeline.

## Gradient có đủ palette và cùng phase

Lấy palette thực và các màu bị yêu cầu loại bỏ từ source, tách màu anchor khỏi màu nội suy. “Cả 6 màu quay vòng đều” cần đủ mọi màu tham gia cả chu kỳ, không chỉ màu mint xuất hiện ở đầu rồi chạy 5 màu còn lại. Số anchor khác số mã RGB duy nhất sau nội suy. Không tự tăng palette lên 8 khi brief cuối đã quay lại 6.

Định nghĩa tiến trình toàn sequence theo grapheme/độ dài nhìn thấy hoặc thời gian tùy effect. Mang phase qua ranh giới dòng, đừng reset ở mỗi dòng nếu yêu cầu nối màu. Chọn mật độ chu kỳ và nội suy riêng: tăng tốc vòng không thay việc làm mượt giữa char. Không tính override, dấu cách vô hình hoặc source reference như ký tự có màu trừ khi thiết kế cần.

Kiểm tra boundary màu cuối dòng → đầu dòng sau, độ nhảy RGB trong phần visible, đủ anchor xuất hiện và tỷ trọng phân bổ phù hợp. Punctuation/space có thể làm hue liên tục dù không thấy pixel; đối chiếu render mới chốt. Nếu style một dòng dùng gradient outline thì giữ kênh 3c riêng; không đổi thành gradient fill để đồng nhất script.

Với palette-only, chỉ sửa RGB các kênh được yêu cầu. Giữ alpha, outline/blur, timing, char positions, layer, tags và text; không blanket replace mọi `&H...&` vì alpha và nhiều data cũng có biểu diễn hex. Case 25 dòng từng cần xử lý riêng 12–13 và loại hai màu đơn trong khi bảo toàn border gradient.

## YCbCr Matrix không chỉ là nhãn

Theo [hướng dẫn libass](https://github.com/libass/libass/wiki/ASS-File-Format-Guide#ycbcr-matrix), header và range/matrix video liên quan cách host diễn giải màu; một số host xử lý khác nhau. [Aegisub Resampler](https://aegisub.org/docs/latest/resolution_resampler/) hỗ trợ resample, nhưng thay aspect ratio không bảo toàn chính xác blur/rotation 3D. Không lấy thay header hay công thức convert làm bằng chứng đã giữ ngoại hình.

Một chat cũ đưa lời khuyên “chỉ đổi header sang TV.709 và giữ tags”. Không dùng nó thành fix chung: header đổi có thể đổi pixel hiển thị, còn converter cũng thay style/tag. Trước tiên xác định mục tiêu: giữ appearance của bản đã QC, hay author lại theo metadata raw mới. Tạo copy và giữ bản render trước làm tham chiếu.

## Phép so có kiểm soát

Ghi raw hash, matrix/range/transfer/primaries/SAR, ASS header, colors trong style/override/t, renderer/player/video provider và display pipeline. So raw **không sub** trước/sau để biết video provider có đổi diễn giải hình hay không. Nếu nền thay mà sub không, đo màu mask trong screenshot mới có thể làm người sửa đuổi theo sai pipeline.

Chụp cùng native PTS ở cấu hình cố định. So vùng mask opaque, mép antialias/blur, màu fill/outline và alpha trên nền thật; translucent màu phụ thuộc nền. Thử header-only riêng với full conversion để biết thay đổi nào gây sai, đừng đổi cả matrix, range và palette trong một phép thử. Giữ fonts và render resolution giống nhau.

Nếu cần appearance match sau migration, tìm màu/alpha theo target render với scene sample; đối chiếu toàn palette và các frame grade. Rounding/clipping, color-management và HDR có thể cản equality tuyệt đối. Overlay RGBA từ helper libass không mô phỏng mọi host color mangling/blend, nên nó không đủ nghiệm thu matrix. Báo metric/diff và target đã thử thay vì hứa “601→709 giữ nguyên 100%”.

## Tìm nguyên nhân sai màu, alpha và softness

Giữ cùng frame, renderer, font và background, rồi thử từng thành phần. Màu composite có thể đổi do foreground, alpha, border/glow hoặc video pipeline. Mô hình blend đơn giản `C = alpha*F + (1-alpha)*B` giúp nhận ra rằng một pixel C không xác định duy nhất cả F và alpha; color management/gamma/host còn có thể làm phép so phức tạp hơn. Lấy vùng opaque để đo màu fill, mép/halo để xét blur và nhiều nền tương ứng để xét alpha nếu có dữ liệu. Đừng đổi palette cả bài để chữa một mask bán trong chỉ sai trên một nền.

Khi chữ nhìn quá mờ/đậm, render fill-only rồi thêm outline, blur và glow từng bước. So core nét, độ rộng halo, opacity và chiều vệt riêng. Tăng blur và tăng alpha có thể cho footprint khác nhau dù bbox gần giống; motion trail có hướng cần bằng chứng riêng, không tự thêm bản sao chữ ở frame kế. Giữ các lớp có vai trò rõ để sửa tiếp đúng tham số.

Khi màu đổi theo cảnh, dùng cùng ROI đã đăng ký hình và so raw không sub trước. Tách grade thật của footage, thay bề mặt/ánh sáng và cách player diễn giải video. Chỉ tạo curve màu/alpha của sub sau khi xác định sự thay đổi cần theo; giữ bước nhảy ở cut nếu raw thực sự có nó.

## Sửa chữ mà giữ thiết kế gradient

Trước khi thay text, xác định gradient đang phụ thuộc vào index glyph, vị trí x, grapheme, syllable, thời gian hay phase toàn sequence; kênh fill/outline và alpha nào được phép đổi. Giữ những anchor/phase/clock đã duyệt rồi tính lại mapping cho chuỗi mới bằng đúng cơ chế đó. Một gradient theo vị trí hình học không thể bảo toàn chỉ bằng phân bố đều theo số ký tự.

Nội suy RGB theo `i/(M-1)` là một lựa chọn khi nguồn thực sự dùng các màu neo và khoảng đều theo glyph; xử lý riêng M=0/1. Với palette vòng, giữ đủ anchor và phase nối qua dòng; với curve/không gian màu khác, giữ cơ chế nguồn. Ghi ASS theo BGR và giữ alpha; không blanket replace mọi số hex hoặc tách dấu kết hợp thành ký tự độc lập.

Kiểm cả câu sau sửa bằng font đã shape: điểm nối màu, khoảng trắng/dấu câu, dấu Việt, outline và highlight/outro. Thử chuỗi dài/ngắn hoặc xóa một cụm lặp trên candidate để xác minh mapping vẫn hợp lý; no-edit roundtrip chỉ chứng minh trường hợp nguyên bản.

