# QC và sửa đúng trường

## Phạm vi trước, phép sửa sau

Đọc file hiện tại, xác nhận target theo kind, thời gian, style, Name/Actor và Text; ghi hash trước khi sửa. Xem nguồn bằng chứng và phần liên quan. Báo lỗi không tạo quyền sửa. Một người dùng vừa sửa trong Aegisub có thể tạo baseline mới ngay khi agent đang phân tích: đọc lại/hash trước khi ghi.

Với Effect-only, chỉ đổi Effect ở những cue được chỉ định; giữ Text, Actor, timing, Style, margins, Layer, line type, thứ tự, section, newline và BOM. Effect không chứa ASCII comma; dùng dấu chấm phẩy, không quote theo CSV. Với Text-only, preserve tag chức năng và mọi field còn lại; kiểm chứng riêng phần tags khi người dùng yêu cầu chúng giữ nguyên.

Không lấy Cue/Actor làm sự thật âm thanh. Tách “sai chắc”, “cần nghe” và “lựa chọn dịch”; note phải nêu vấn đề cụ thể và lý do, không chỉ dán cờ mơ hồ. Đừng biến một nghi vấn thành lời dịch hoặc tên người mới.

## Kiểm chứng Actor trên toàn bộ thoại

Lập corpus theo vai trò thực của event: tên style có chữ JPN vẫn có thể chứa thoại Việt; `Dialogue:` cũng có thể là sign/shape/ED. Gộp các layer của cùng lời nói để nghe một lần nhưng lưu đủ thành viên, kind và ordinal. Timing dùng để tìm đoạn audio; tác vụ Actor-only không tạo quyền sửa timing hoặc đưa retime vào kế hoạch patch.

Giữ ledger cho từng cue/cụm: đoạn audio đã xử lý và offset, nhận định người nói, nguồn nhận diện, trạng thái `khớp / có vấn đề / còn bất định / chưa kiểm`. Trạng thái mặc định là chưa kiểm; nhãn cũ, confidence cao, transcript hoặc audio file tồn tại không biến thành đã nghe. Tổng trạng thái phải phủ đúng corpus, không đếm mỗi lớp styling thành một câu. Các cue không có cờ cũ vẫn phải được kiểm khi yêu cầu là toàn bộ.

Speaker ID từ diarization chỉ là nhãn của lần phân đoạn, có thể va chạm giữa batch hoặc cảnh; không map một `spk:4` thành một tên cho cả phim. Dùng mốc giọng đã xác định và ngữ cảnh kề để kiểm lại từng scene; với câu ngắn/chồng tiếng, mở rộng audio và ghi phần lời thuộc từng người nếu phân biệt được. Transcript có tên nhân vật hoặc hình ảnh là chứng cứ hỗ trợ, không thay kiểm chứng giọng khi yêu cầu lấy audio làm nguồn chính.

Bảng bàn giao chứa lỗi đã xác nhận và phần còn bất định sau kiểm, kèm bằng chứng đủ để người dùng rà đúng đoạn. Không gọi toàn bộ cue chưa nghe là danh sách Actor sai hoặc đẩy hàng trăm cờ chung chung sang người dùng để gọi audit hoàn tất. Nếu runtime không nghe được, báo đúng phần chưa kiểm và giao corpus/lookup cho công cụ có khả năng nghe; không tự xác nhận danh tính từ text. Xem [harness-compatibility.md](harness-compatibility.md).

## Kế hoạch sửa có guard

Helper `ass_tools.py patch` cần baseline hash và một plan. Nó ghi candidate khác nguồn, không tự cài vào file đang mở. Mỗi edit có physical line 1-based, kind, giá trị kỳ vọng và các trường đặt mới. Dùng tên trường theo Format; alias Actor được hiểu như Name.

```json
{
  "baseline_sha256": "SHA256-cua-file-hien-hanh",
  "allowed_fields": ["Effect"],
  "edits": [{
    "line": 42,
    "kind": "Dialogue",
    "expect": {
      "Start": "0:00:12.34",
      "End": "0:00:15.00",
      "Style": "Default",
      "Name": "Ichika",
      "Text": "Câu hiện tại."
    },
    "set": {"Effect": "CẦN NGHE — lời gốc có hai cách hiểu; giữ bản hiện tại"}
  }]
}
```

```bash
python3 scripts/ass_tools.py inspect current.ass
python3 scripts/ass_tools.py patch current.ass plan.json --output candidate.ass
python3 scripts/ass_tools.py compare current.ass candidate.ass --allowed-fields Effect
```

Điền hash và expected text từ file thật, không từ ví dụ. Nếu hash/giá trị lệch, helper dừng: phân tích diff, nối thay đổi của người dùng rồi cập nhật plan; không bỏ guard để chạy cho qua. Candidate đã tồn tại chỉ ghi đè khi dùng `--force` có chủ đích.

## So những gì đã thay

Với sửa field, compare phải chứng minh chỉ các field cho phép đổi; toàn bộ dòng không phải event cũng cần nguyên byte. Với yêu cầu phức tạp hơn, chọn invariant tương ứng: palette-only giữ geometry/alpha/non-RGB tags; migration style giữ appearance; tracking giữ mask; reorder giữ toàn bộ event payload ngoài marker/layout; triển khai giữ unrelated events/styles/fonts.

Helper compare không chứng minh reorder hoặc insertion tương đương; nó cố tình báo structural change khi số dòng/format/kind đổi. Dùng matching/multiset có identity rõ trong script chuyên biệt, và render để kiểm chứng stacking.

Parse/count/hash là bằng chứng cấu trúc. Những thay đổi ảnh hưởng ngoại hình cần actual render của target event trên video. Thoại cần bằng chứng nguồn/nghĩa; pixel equality không chứng minh dịch đúng.

## Ghi bản đã duyệt

Khi phạm vi đã cho phép sửa và candidate đã kiểm chứng, đọc lại baseline rồi ghi vào đúng file người dùng chọn; giữ backup có thể truy hồi khi thay đổi lớn. Báo số cue/field đổi và bất kỳ điểm chưa chắc còn lại. Không chỉ tạo candidate rồi dừng nếu người dùng đã yêu cầu sửa file chính.

## Ghi chú QC trong file không phá huỷ (In-file QC Annotations)

Khi người dùng yêu cầu chỉ ra lỗi trực tiếp trong file để mở trong Aegisub nhưng cấm sửa câu thoại:
- Theo đúng nơi user chọn: Actor/Name, Effect hoặc Comment. “Không sửa thoại” không tự cấp quyền chèn event hoặc đổi style/metadata.
- Nếu được phép thêm Comment, ghi timing/identity cue liên quan và manifest những dòng mới; dùng convention dự án nếu có. Comment thông thường không hiện trong playback, nên tag căn góc không bảo đảm có overlay trong video preview.
- Nếu cần note xuất hiện trên video, xác định yêu cầu hiển thị đó và tạo candidate phù hợp; không tự biến QC note thành Dialogue trong bản phát hành.
- So các field, kind, thứ tự, section và bytes ngoài phạm vi. Chỉ báo thêm dòng nếu thực sự được phép; khi hoàn nguyên, nhận diện đúng note đã chèn bằng manifest thay vì xóa mọi comment có tag giống nhau. Xem [multi-agent-qc.md](multi-agent-qc.md).

