# OCR hardsub và giữ đúng bản lời đã có

Đọc khi lấy lời Việt từ hardsub, nghiệm thu output của agent khác, hoặc tái dùng lyric qua tập. OCR là đọc chữ đã có; nó không mặc nhiên cho phép dịch lại. Bộ OCR và contract đầy đủ có ở [ocr-workflow.md](ocr-workflow.md), worker là `scripts/ocr_worker.py` trong skill này; không cần một skill OCR ngoài bộ. Tài liệu này bổ sung cách quyết định nội dung và nghiệm thu.

## Phân biệt OCR, căn cue và dịch

Giữ ba lớp: ảnh/PTS chứng cứ; OCR nguyên văn; bản phân phối vào cue ASS. EN có thể quyết định cue cần lấy ý nào, không trở thành nguồn câu Việt thay thế hardsub. Có thể tách/gộp mẩu lời Việt để khớp cue nếu được phép, nhưng không diễn đạt lại, thêm ý hoặc “cải thiện văn phong” chỉ vì EN khác. Nếu việc sau đó là biên dịch/QC ngữ nghĩa thì cần phân biệt scope và nguồn đầu ra rõ.

Case Houseki ED: OCR đã đọc “Thật là vui nhỉ” nhưng agent đổi thành lời dịch dài theo EN rồi áp sang 9 tập. Output có đủ cue và cấu trúc đúng vẫn sai nhiệm vụ. Gate nội dung cần so bản cuối với **lời Việt trong ảnh**, không chỉ EN và report coverage.

## Chọn đúng nguồn và frame

Xác minh video hardsub và ASS bằng số tập/scene/offset, không fuzzy-match basename khác nhóm phát hành. Có thể staging symlink video và bản ASS tạm theo naming worker yêu cầu sau khi xác minh; không copy video lớn chỉ để đổi tên. Tránh dựa vào đường portal `/run/user/.../doc/...` hết hạn: tìm đúng nguồn được cung cấp, không tự đổi sang bản phim khác khi path chết.

Lấy frame ở phần chữ đã rõ, tránh intro/outro/cut và vùng sub trên cùng bị crop mất. Nếu cùng cue có nhiều lời nối nhau hoặc thoại đồng thời, lưu sequence probe thay vì một frame giữa cue. OCR cấp crop phải còn đủ dấu, outline và toàn dòng; kiểm tra tile output thực tế trước khi gửi hàng loạt.

## Raw evidence, rescue và trạng thái

Lưu cue ID, native PTS/frame, crop/hash, OCR raw, trạng thái và quyết định chia lời. Phân biệt không có chữ trong hình, không đọc chắc, chưa probe đủ sequence, và có chữ nhưng căn nghĩa chưa chắc. `[EMPTY]`, `[UNCERTAIN]`, `MISSING`, `NEED_SEQ_PROBE`, `NEED_SEMANTIC_REVIEW` là ví dụ nhãn của một workflow, không tự đổi schema của worker khác.

Một OCR rỗng rồi ASS có câu Việt phải có nguồn rescue/đọc frame bổ sung đã lưu; không coi đó là recovery thành công nếu không có chứng cứ. Chỉ rescue nơi còn nghi, dùng batch/cache/checkpoint của worker khi có. Không gọi lại toàn tập đã hoàn tất để xử lý vài cue, không để service outage dẫn tới tự bịa câu. Giới hạn retry/model fallback theo contract, lưu trạng thái để resume nếu cần.

Không đưa key/token/credential từ chat lịch sử vào skill, ví dụ hoặc log. Khi workflow cần dịch vụ ngoài, dùng cách cấu hình sẵn có và phạm vi đã được cho phép; khảo sát lịch sử không tạo quyền chạy API mới.

## Khoanh nguyên nhân trước khi rescue

Khi OCR trống/sai, kiểm theo đường dữ liệu: đúng video/scene và offset chưa; frame có chữ đã rõ chưa; crop/tile còn đủ hai dòng/dấu chưa; request có thành công và response có được parse đúng chưa; cuối cùng mới xét khả năng nhận chữ. Mỗi tầng cần artifact thật, không coi lỗi service/parse như nguồn không có lời.

Với chữ thay đổi trong cùng cue, probe sequence ở các trạng thái đọc được và ghép theo thứ tự xuất hiện; đừng lấy consensus làm mất phần chỉ hiện ngắn. Với một glyph/dấu mơ hồ, so nhiều frame cùng chữ và crop native có margin; chú ý blur/outline/occlusion tạo hình giống chữ khác. Giữ raw OCR và sửa có nguồn, không “điền” câu bằng EN/audio rồi gọi là OCR đã đọc được.

Chỉ retry/rescue vùng lỗi sau khi đã xác định dữ liệu đầu vào và lưu trạng thái. Nếu nguồn khác giúp đoán chữ, dùng nó để chọn frame/câu cần kiểm, rồi xác nhận lại bằng ảnh hardsub; nếu chưa thấy đủ thì ghi uncertainty. Đây là phép kiểm nhận dạng nguồn, khác với chấm câu dịch đúng nghĩa.

## Nghiệm thu nội dung và cấu trúc

Coverage `cue có text / tổng cue` không là accuracy OCR hoặc độ đúng bản dịch. Báo riêng blank, uncertain, rescue và semantic-review. Với full audit theo yêu cầu, đọc đủ phạm vi; với smoke test chỉ mẫu, ghi rõ số mẫu. Report không thay raw evidence.

Kiểm tra phủ định, tên riêng, các từ gần dạng, dấu Việt, câu bị cụt, hai cue lặp một câu nguồn và lời của hai người bị đảo. Nếu hardsub VI khác EN, giữ VI trong OCR-only và note nghi vấn; không chữa bằng dịch EN. Bảo toàn các event ngoài scope và metadata provenance cần thiết, không chỉ tổng event count.

## OCR một lần để tái dùng

Lyric lặp có thể OCR trên một tập đại diện khi văn bản/phiên bản giống; xác minh các tập thực có cùng lyric trước khi tái dùng. Timing/offset/đường hình vẫn xét riêng. Case ED thường 11 câu nhưng tập 8 có ED khác 9 câu ở style khác: không áp bộ 11 câu lên ngoại lệ. Lưu mapping lyric ID + bản lời và provenance nguồn; không coi cùng tên style là đủ chứng minh cùng nội dung.
