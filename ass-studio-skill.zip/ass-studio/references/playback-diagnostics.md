# Khảo sát playback, drop frame, performance và FBF Sync

## Bắt đầu từ hiện tượng

Khảo sát với target renderer, PlayRes thực tế, font đã nạp, và video có cùng timeline/profile. Phân biệt **drop frame do quá tải render** (CPU cao, draw call lớn, clip phức tạp, blur bán kính rộng) với **rụng frame do lệch pha timestamp / dead-zone** (libass không nhận diện được event tại PTS của frame). Không phán đoán qua mắt thường; dùng log `mpv -v` kiểm tra drop frame và trích xuất PTS thực từ container.

Benchmark trước/sau với renderer độc lập/cùng font/cùng timeline, render full trajectory và xem playback trên target. Một case EP06 từng giảm 71,8 → 3,65 MB và 26,4 → 14,0 ms/frame theo báo cáo lịch sử, nhưng mpv fullscreen vẫn drop ngay cả không sub. Không dùng số này làm ngưỡng đảm bảo máy yếu hoặc sao chép script/nguồn đã bị dọn.

---

## Quy tắc sống còn khi đồng bộ (Sync) hiệu ứng FBF giữa các bản phát hành (WEB vs BD)

### 1. Bản chất toán học của bẫy Dead-Zone ở phụ đề FBF
Trong các file ASS có hiệu ứng Frame-by-Frame (glitch, vector morphing, particle, karaoke fbf), mỗi frame video thường được biểu diễn bằng 1 dòng subtitle riêng biệt:
- Video $23.976\text{ fps}$ ($24000/1001$) có chu kỳ frame là $T_{\text{frame}} \approx 41.71\text{ ms}$.
- Trong nhiều sub gốc (ví dụ CrappySubs), nhóm làm sub hardcode thời lượng mỗi dòng FBF cực ngắn: $\text{Duration} = 10\text{ ms} = 0.01\text{s}$ (1 centisecond).
- Giữa 2 frame liên tiếp luôn tồn tại một **khoảng chết (dead gap)** dài:
  $$\Delta t_{\text{dead}} \approx 41.71\text{ ms} - 10\text{ ms} = 31.71\text{ ms}$$
- Khi player (`mpv`, `libass`) render video frame thứ $N$ tại thời điểm $\text{PTS}_N$ (tính theo millisecond nguyên $\text{pts\_ms}$):
  $$\text{start\_ms} \le \text{pts\_ms} < \text{end\_ms}$$
- **Nguyên nhân chớp tắt / mất frame khi sync**:
  - Ở bản nguồn (WEB), các timestamp được sinh vừa khít ôm lấy $\text{pts\_ms}$ của video WEB.
  - Khi tịnh tiến sang bản mới (BD) bằng phép cộng thời gian thông thường `round(Start + offset_sec)`:
    Do sai số lượng tử hóa centisecond ($0.01\text{s}$) cộng dồn với timebase container, mốc $\text{Start}$ có thể bị làm tròn tiến lên ($\text{start\_ms} > \text{pts\_ms}$).
    Hậu quả: Điểm lấy mẫu $\text{pts\_ms}$ rơi vào đúng khoảng chết $31.7\text{ ms}$ $\rightarrow$ **libass không vẽ phụ đề cho frame đó $\rightarrow$ sub bị chớp nháy, rụng frame**.

### 2. Hai sai lầm chết người cần cấm tuyệt đối
1. **Cấm tính thời lượng qua frame số nguyên**:
   $$\text{dur\_frames} = \text{round}(t_{\text{end}} \times \text{fps}) - \text{round}(t_{\text{start}} \times \text{fps})$$
   Với các dòng $10\text{ ms}$, công thức này cho ra $0\text{ frame}$, biến $\text{Start} == \text{End}$ ($0.00\text{s}$). Thư viện `libass` lập tức bỏ qua toàn bộ các dòng này, xóa sổ hàng trăm nghìn dòng effect.
2. **Cấm tự ý kéo dài thời lượng (duration expansion)**:
   Không được tự tiện nới $\text{End}$ thành $0.04\text{s}$ để lấp khoảng chết nếu chưa được phép, vì sẽ làm đè/loạn các layer animation chồng nhau của effect.

### 3. Định lý chuẩn bao phủ Frame trong miền Millisecond (Integer Millisecond Floor Division)
Để bảo toàn tuyệt đối 100% thời lượng gốc mà vẫn đảm bảo 100% frame không bị drop khi sync sang bản video mới:
1. Xác định frame mục tiêu trên video đích:
   $$N_{\text{target}} = \text{round}(t_{\text{start\_orig}} \times \text{fps}) + \text{offset\_frames}$$
2. Tính $\text{PTS}$ chính xác của frame mục tiêu theo integer milliseconds:
   $$\text{pts\_ms} = \text{round}\left(\frac{N_{\text{target}} \times 1001 \times 1000}{24000}\right)\text{ ms}$$
3. Dùng phép chia lấy phần nguyên trong miền millisecond để lấy mốc centisecond:
   $$\text{Start}_{\text{cs}} = \lfloor \text{pts\_ms} / 10 \rfloor = \text{pts\_ms} // 10$$
   $$\text{Start}_{\text{ms}} = \text{Start}_{\text{cs}} \times 10$$
   $$\text{End}_{\text{ms}} = \text{Start}_{\text{ms}} + \text{Duration}_{\text{orig\_ms}}$$
   Theo định lý chia có dư: $\text{pts\_ms} = 10 \times \text{Start}_{\text{cs}} + r$ với $0 \le r < 10$.
   Do đó:
   $$\text{Start}_{\text{ms}} \le \text{pts\_ms} < \text{Start}_{\text{ms}} + 10 \le \text{End}_{\text{ms}}$$
$\rightarrow$ **Chứng minh toán học: Điều kiện libass `start_ms <= pts_ms < end_ms` luôn thỏa mãn 100.0000% trên toàn bộ các dòng FBF, triệt tiêu hoàn toàn hiện tượng drop/chớp tắt**.

---

## Trim/apply: đếm endpoint trước khi sửa script

Ghi rõ start/end là event time, native frame index hay clip-relative index. Hai index inclusive a..b có b-a+1 frame; một khoảng half-open [a,b) có b-a. ASS End là lúc ngừng active, nhưng phép time→frame của editor/macro có thể dùng semantics riêng; kiểm tra implementation và mẫu thực trước khi xóa/cộng `+1`.

Đặc biệt lưu ý mốc kết thúc của cue âm tiết/karaoke: Nếu cue kết thúc tại `1:48:47.40` ($6527.40\text{s} = 6527400\text{ ms}$) nhưng frame cuối có $\text{pts\_ms} = 6527401\text{ ms}$, do $\text{End}$ trong ASS là biên loại trừ (exclusive) nên libass sẽ không vẽ frame cuối. Cần kiểm tra cận biên và mở rộng $1\text{ cs}$ (kéo lên `1:48:47.41`) để bao trọn frame biên.
