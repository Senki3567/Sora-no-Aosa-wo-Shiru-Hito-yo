# Dựng font từ sign và thiết kế dấu Việt

Đọc khi người dùng cần bộ chữ riêng từ footage, chữ editable bằng font, hoặc glyph/dấu chưa đồng bộ. Dựng giống hình gốc và tìm font tương tự là hai nhiệm vụ khác nhau; yêu cầu dựng từ hình không được thay bằng chọn font gần giống.

## Chọn mẫu đủ hình trước khi trace

Xem nhiều native frame rõ, cùng kích thước và không có sub thử nghiệm. Chữ trong wipe/split/occlusion có thể chỉ hiện một nửa: không lấy phần nhìn thấy làm silhouette đầy đủ. Case JAPAN BRANCH từng làm thân trái B quá mỏng vì B đang bị hai nửa chuyển động che nhau; cần frame mở đủ trước khi quyết định tỷ lệ.

Rectify phối cảnh/scale của ROI về frame tham chiếu nếu cần. Lưu ảnh mẫu và đường bao đã dựng riêng; đừng trace blur, grain hay antialias thành nhiều điểm vụn. Lấy các chữ có thật làm bộ quy tắc: thân nét, đường vát, góc nối, counter, cap height, baseline, độ mở và tỷ lệ ngang. Chữ chưa có mẫu được suy ra từ quy tắc ấy, ghi rõ phần tự thiết kế.

## Dựng font editable thật

Có thể dùng FontTools và pen phù hợp để tạo TTF/OTF từ contour, nhưng xem đúng API của phiên bản được cài trước khi viết generator. Giữ outlines, metrics, cmap và tên family/style trong nguồn; đừng chỉ giao một shape ráp chữ nếu yêu cầu font chỉnh sửa được. Dựng các chữ cần cho sign trước; không cần tự vẽ cả alphabet khi không có nhu cầu.

Dùng cùng hệ đơn vị cho mọi glyph. Tách chiều rộng đường bao, advance, left/right bearing và kerning; bbox giống nhau không chứng minh spacing đều. Tên family trong ASS phải là tên nội bộ của font, không phải tên file. Cập nhật phiên bản hoặc nạp lại renderer/font cache khi đổi font; kiểm tra log fontselect để tránh render font cũ hoặc fallback.

Chữ A và các A có dấu phải reuse cùng thân và metrics. Thiết kế dấu theo độ dày, góc, điểm kết thúc và khoảng trắng của bộ chữ; dấu giống một chữ nhỏ đặt lên trên chưa chắc hợp phong cách. Kiểm tra tổ hợp dấu mũ + dấu thanh, dấu nặng dưới baseline, Đ và các chữ có dấu ở cả kích thước sử dụng lẫn bảng glyph.

Bounds dọc phải chứa glyph cao/thấp nhất gồm dấu; kiểm tra ascender/descender và các metric dọc mà renderer sử dụng. Không nới khung rồi vô tình đổi vị trí/scale chữ: render cùng baseline trước/sau. Kiểm tra NFC và chuỗi dấu kết hợp theo nội dung thật; có glyph precomposed không tự bảo đảm mọi combining sequence đều được shaping đúng.

## Kiểm tra hình và spacing

Tạo bảng glyph ở **cùng font size và cùng tỷ lệ**, cùng baseline, có ô metric và mép nét nhìn thấy. Không resize từng glyph về cùng bbox để chứng minh “đều”. So thân nét, chiều cao, độ rộng chủ đích và trọng lượng quang học. Chữ I/B có thể hẹp hơn H/N mà vẫn đúng; A có cạnh vát có thể nhìn nhỏ dù cap height bằng nhau. Sửa theo hình gốc và cảm quan có đo đạc, không ép tất cả chữ bằng chiều rộng.

Render toàn câu, các cặp có dấu và chữ hai bên dấu cách bằng đúng shaping engine. Chỉnh bearing/kerning khi cần; đừng chữa mọi lỗi spacing bằng dịch từng char trong ASS vì làm nguồn khó sửa. Nếu có splitting, dựng layout **toàn câu một lần** quanh tâm/anchor đã chốt rồi mới tách; không căn giữa hai nửa riêng.

Cần xem silhouette/counter khi blur=0 trước, sau đó render blur thực tế. Nếu font thành shape, so dấu, counter, baseline, advance và điểm nối với bản font ở cùng scale. Giữ dòng font/source dưới dạng comment hoặc file editable theo yêu cầu, kèm generator; outline đã duyệt là nguồn để tạo shape, không trace lại video ở bước cuối.

## Đưa font vào target

Font bên cạnh ASS không đảm bảo player/editor tự nạp. Nạp trực tiếp khi render thử, attach font khi mux nếu phù hợp target, hoặc cài font khi được yêu cầu. Font nhúng trong ASS cần đúng mã hóa/section và phải thử trên target thật; không coi mọi player hỗ trợ như nhau. Xem [render-performance.md](render-performance.md) và [geometry-animation.md](geometry-animation.md).
