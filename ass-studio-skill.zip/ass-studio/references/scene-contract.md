# Nguồn editable và trạng thái điều hành để tiếp tục bằng prompt

Đọc khi tạo sign/FX nhiều lớp, dùng generator/compiler hoặc tiếp tục qua nhiều lượt (multi-turn) và trên harness khác. Một prompt như “dịch sang trái một chút, giữ nhịp và mask” cần chỉ đúng đối tượng nguồn, tham số vị trí, các phần đã chốt và mapping output. Không cần dựng một parser ngôn ngữ riêng; agent đọc yêu cầu, lập kế hoạch thao tác có phạm vi theo [agent-motion-architecture.md](agent-motion-architecture.md) và chạy công cụ kiểm được.

## Trạng thái điều hành chuẩn (`ass-studio.scene.v2`)

Trong thư mục công việc của dự án, giữ `scene.json` (tương thích ngược với `v1`, mở rộng thêm đồ thị chuyển động khai báo và bộ nhớ tiến hóa đa vòng). Chỉ tạo trường cần dùng, nhưng bảo toàn các thông tin sau khi có nhiều lớp/track/vòng tinh chỉnh:

```json
{
  "schema": "ass-studio.scene.v2",
  "object_id": "hallway-sign-01",
  "source": {
    "ass": "source.ass",
    "sha256": "<actual hash>",
    "video": "raw.mkv",
    "video_identity": "<actual hash or size+mtime pending hash>"
  },
  "frame_space": {
    "native_size": [1920, 1080],
    "play_res": [1920, 1080],
    "reference_frame_0based": 100,
    "ass_time_equals_pts_ms_plus": 0,
    "cadence": "2s-hold-or-1s-camera"
  },
  "timeline_phases": [
    {"id": "entry", "frames": [90, 100], "pts_ms": [3754, 4171], "status": "accepted"},
    {"id": "steady", "frames": [100, 148], "pts_ms": [4171, 6173], "status": "accepted"},
    {"id": "exit", "frames": [148, 160], "pts_ms": [6173, 6673], "status": "candidate"}
  ],
  "editable": {
    "file": "generator.py",
    "config": "design.json",
    "track": "track.json",
    "probe": "probe.json"
  },
  "components": [
    {"id": "mask", "role": "cover-original", "layer": 0, "source_key": "mask-01", "status": "accepted"},
    {"id": "glow", "role": "underlay", "layer": 1, "source_key": "glow-01", "status": "candidate"},
    {"id": "fill", "role": "translated-text", "layer": 2, "source_key": "text-01", "status": "accepted"}
  ],
  "motion_graph": {
    "clocks": {
      "timeline": "video_pts_ms",
      "content": "immutable_lyric_onsets"
    },
    "surface_track": "track.json",
    "curves": [
      {
        "component": "glow",
        "property": "alpha",
        "keyframes": [
          {"time_ms": 3754, "value": 255},
          {"time_ms": 4171, "value": 96, "easing": {"type": "power", "gamma": 0.65}}
        ]
      }
    ],
    "compilation_mode": "hybrid_multi_segment"
  },
  "locked": ["lyric-absolute-onsets", "mask-contour", "surface-track-v1"],
  "last_request": "Reduce glow opacity during steady hold without altering entry cadence",
  "candidate": "candidate.ass",
  "checks": {
    "field_scope": "accepted",
    "numerical_track": "accepted",
    "spatial_alignment": "accepted",
    "temporal_easing": "accepted",
    "mask_occlusion": "accepted",
    "photometric_blend": "candidate",
    "vietnamese_typography": "accepted"
  },
  "iteration_history": [
    {
      "round": 1,
      "hypothesis_tested": "Lower glow alpha from &H40& to &H60& on layer 1",
      "parameter_diff": {"glow.alpha_steady": "64 -> 96"},
      "evidence_inspected": ["work/evidence/sheet.png", "frames 95, 100, 124, 154"],
      "critic_verdict": "Core text is clearer; exit fade at frame 154 still slightly bright",
      "dominant_discrepancy": "Exit phase glow alpha needs faster decay"
    }
  ],
  "falsified_hypotheses": [
    {
      "hypothesis": "Single \\frx12\\fry-8 tag on full line without per-corner projection",
      "reason": "Right edge drifts 5.4px upward at frame 138; rejected in favor of planar track fit"
    }
  ]
}
```

Các placeholder ở ví dụ phải thay bằng giá trị thật hoặc giữ trạng thái chưa xác minh; đừng điền hash/measurement giả. Paths có thể tương đối **với scene file**, không với cwd ngẫu nhiên của harness. Mapping scene không nhất thiết phải ghi vào Actor/Effect của ASS nếu người dùng đã khóa các trường đó.

## Bộ nhớ Tiến hóa Đa vòng (Sliding Window Trajectory Memory) và Chống Lặp Lỗi

Khi làm việc qua nhiều lượt hoặc chuyển giao giữa các subagent:
- **Giới hạn cửa sổ lịch sử (`iteration_history`)**: Giữ tối đa 3–5 vòng thử nghiệm gần nhất theo nguyên lý Sliding Window Memory ($M_{t+1} = \text{Tail}_L(M_t \cup \{(p_t, c_t)\})$). Trạng thái thành công của các vòng trước đã kết tinh vào `motion_graph` và snapshot `accepted`, giúp ngữ cảnh luôn gọn mà không mất lịch sử thiết kế.
- **Sổ đen Giả thuyết Đã Bác bỏ (`falsified_hypotheses`)**: Mọi cơ chế hoặc tổ hợp tham số đã thử nhưng làm tăng residual, làm lộ mask, làm nhảy chữ hoặc bị người dùng bác bỏ phải được ghi ngắn gọn kèm nguyên nhân định lượng/hình ảnh. Trước khi đề xuất phép thử mới, Agent bắt buộc kiểm tra mảng này để không lặp lại đúng hướng sai cũ.
- **Bảo vệ tiến trình đơn điệu (Monotonic Progress Guard)**: Mỗi thành phần (`mask`, `fill`, `glow`, `intro`, `steady`, `outro`) và mỗi trục trong 5 trục của `checks` giữ trạng thái riêng (`accepted`, `candidate`, `rejected`, `pending`). Nếu một thay đổi ở `candidate` làm một trục đã `accepted` bị hỏng, phải hoàn nguyên về snapshot `accepted` ngay trước đó thay vì chồng thêm bản vá.

## Mapping và sửa tiếp

Ghi `object_id/component_id/source_key` trong nguồn/config và manifest output; khi cần, thêm source event index **kèm fingerprint** (line type + field values/hash) và generated event indices của chính bản output/hash hiện hành. Index thay đổi sau insert/sort/macro; không coi nó là ID lâu dài. Sau khi Aegisub được sửa tay, đọc lại baseline và reconcile mapping trước khi sinh lại.

Nếu generator/compiler (`scripts/motion_studio.py compile`) có roundtrip giữ được chỉnh sửa đã duyệt, sửa tham số nguồn trong `motion_graph`/config rồi tái sinh. Nếu master đã được sửa tay ngoài generator, xác định phần khác trước; có thể patch field/lớp liên quan trên master hiện hành hoặc nhập chỉnh sửa trở về source. Không rebuild từ config cũ rồi mất bản đã duyệt. Source lyric và generated `fx` cần quyền sở hữu rõ trước reapply Templater.

Khi nhận prompt mới, ghi ngắn: object/components đích, thuộc tính cần đổi theo phân cấp (Temporal $\rightarrow$ Geometry $\rightarrow$ Layout/Mask $\rightarrow$ Local Easing $\rightarrow$ Photometric), phần khóa, candidate và phép kiểm cần chạy. “Nhẹ hơn” có thể là opacity, blur footprint, density hoặc motion amplitude; dùng raw/brief và bản vừa duyệt để chọn thử hợp lý, hỏi chỉ khi kết quả phụ thuộc một lựa chọn chưa thể suy ra. Render vùng chịu tác động và các biên liên quan, so phần khóa rồi cập nhật scene state bằng kết quả thật.

## Chuyển harness hoặc tiếp tục sau mất ngữ cảnh

Giữ trạng thái duyệt riêng cho layout, hình dáng, màu/chất liệu, intro, continuous, outro, lời và mức tối ưu khi chúng đang được sửa độc lập. Mỗi phần có thể là `accepted`, `candidate`, `rejected` hoặc `not_checked`, gắn đúng hash/artifact và phản hồi gần nhất. Không suy cả effect đã đạt vì một thành phần được khen, cũng không dựng lại continuous đã chốt chỉ vì lead-in bị bác. Với shift/scale/đổi neo, đi theo mapping tới chữ, mask, shape, pivot và mọi event chuyển pha; giữ cả những chỉnh sửa tay mới của người dùng.

Khi được bảo “tiếp tục việc đang dở”, đối chiếu yêu cầu cuối và artifact hiện hành trước khi chạy. Tên chat, handoff cũ hoặc tiến trình encode còn tồn tại không đủ quyết định tác vụ gần nhất. Handoff ghi bản nào được chốt/bị bác, snapshot cần khôi phục, `falsified_hypotheses`, lỗi còn lại (`dominant_discrepancy`) và bước chưa hoàn tất. Một lời yêu cầu “chỉ kiểm tra, cấm làm” chỉ cho phép khảo sát; không khởi động lại pipeline dang dở.

Handoff giữ nguồn/hash, candidate mới nhất, file đo/track/probe, font/renderer, frame/timestamp đã kiểm và vấn đề còn lại. Harness nhận việc phải mở các artifact này; một lời tóm tắt hoặc nhãn `VERIFIED` không thay bằng chứng. Chỉ mang quyết định cần tiếp tục, không yêu cầu chuyển toàn bộ hội thoại hay suy luận nội bộ. Khi thiếu ảnh/audio tool, giữ check tương ứng là `pending/unavailable`, hoàn tất phần độc lập rồi báo giới hạn cụ thể.
