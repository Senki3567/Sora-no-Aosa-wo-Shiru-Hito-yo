# Đo transform theo frame từ landmark

Đọc sau [visual-reasoning.md](visual-reasoning.md) khi sign gốc cần track chính xác và có các điểm tương ứng đo được. `scripts/motion_fit.py` dùng NumPy để fit translation, similarity, affine hoặc homography. Nó nhận quan sát do người/agent/tracker cung cấp; không tự nhận diện sign hoặc biến phép nhìn ước lượng thành ground truth.

## Dữ liệu đầu vào

Chọn frame neo rõ trong mỗi segment và giữ tọa độ `reference_x/reference_y` của từng landmark cố định trong segment. `x/y` là landmark ấy ở frame hiện tại, đo trong **pixel video native**, x sang phải, y xuống. `pts_ms` là PTS thực, có thể khác `frame/fps`; không trộn PTS nguồn với timestamp ASS chưa áp offset. Crop từ công cụ ảnh phải quy về native trước khi ghi CSV.

```csv
segment,frame_index_0based,pts_ms,point_id,reference_x,reference_y,x,y,role,status
shot-a,100,4171,A,100,80,112,86,fit,measured
shot-a,100,4171,B,300,80,312,86,fit,measured
shot-a,100,4171,C,100,180,112,186,check,measured
shot-a,101,4213,A,100,80,114,87,fit,measured
shot-a,101,4213,B,300,80,314,87,fit,measured
shot-a,101,4213,C,100,180,114,187,check,measured
```

Trong ví dụ similarity này, hai điểm fit cho cùng scale 1/góc 0, translation lần lượt (12,6) và (14,7); điểm C kiểm độc lập. Đây là ví dụ kiểm công cụ, không phải các mốc đo của footage người dùng. Thêm điểm trên nhiều góc/mép để có redundancy. Không dùng các điểm cùng đường thẳng cho affine/projective; không lấy điểm trên vật thể đang che sign làm điểm thuộc sign. Với điểm bị che, để `status=occluded` và bỏ trống tọa độ current; script ghi nhận nó bị bỏ qua.

```bash
python3 scripts/motion_fit.py work/points.csv --model similarity --threshold-px 1.5 --output work/similarity.json
python3 scripts/motion_fit.py work/points.csv --model homography --ransac --seed 7 --threshold-px 2 --output work/projective.json
```

Ngưỡng tính bằng pixel native, phải chọn theo resolution và mức cần khớp. `--ransac` có tối đa 256 mẫu, seed cố định và fit lại theo consensus; script dùng forward reprojection error, không tự đo photometric error. Khi dữ liệu nhiều outlier hoặc gần suy biến, kiểm point placement và thử tracker/cách đo khác thay vì tin matrix chỉ vì công cụ xuất JSON. Cơ sở số: [NumPy least squares](https://numpy.org/doc/stable/reference/generated/numpy.linalg.lstsq.html), [OpenCV: homography và robust estimation](https://docs.opencv.org/4.x/d9/d0c/group__calib3d.html).

## Đọc kết quả và chuyển sang ASS

- Matrix là **reference→current**, dùng column vector `[x,y,1]`. Translation trong matrix là dịch gốc tọa độ, **khác** `\pos` của một pivot tùy chọn. Với similarity quanh C, đặt vị trí anchor hiện tại bằng `M*C`, còn scale/góc tác động vào vector glyph quanh C. `rotation_clockwise_deg_y_down` dương khi nhìn xoay theo chiều kim đồng hồ trong ảnh; không copy dấu vào `\frz` trước khi kiểm renderer.
- Kết quả từng frame gồm predicted/observed/error cho mọi điểm, điểm tham gia fit, held-out checks và review reasons. Tối thiểu 1/2/3/4 điểm tương ứng translation/similarity/affine/homography chỉ xác định mô hình; thêm redundancy/held-out points để kiểm. Khi chỉ đủ tối thiểu và không có check, trạng thái là `needs_review`.
- `fitted` chỉ nghĩa fit số qua các kiểm đã khai báo. Điểm bị loại, residual vượt ngưỡng hoặc frame fit lỗi phải được xem lại. Exit 0: các frame fit qua gate số; exit 3: report đã tạo nhưng có frame cần rà/failed; exit 2: input/runtime lỗi. Không đồng nhất exit 0 với sign khớp thị giác.
- Frame thiếu nằm trong `unmeasured_frame_intervals`; không được tự nội suy. Nếu cần phủ toàn interval, lấy thêm mẫu hoặc nội suy có nhãn trong cùng shot/phase rồi render frame xen kẽ. Tách segment khi cut, đổi bề mặt hoặc frame neo; cùng landmark trong một segment không được tự đổi tọa độ reference để che drift.
- Chuyển qua ASS cần biết PlayRes/LayoutRes, SAR, crop, font/layout, anchor và `\org`. Affine/homography cần fit/bake vào mô hình ASS phù hợp; script **không** sinh tags tự động. Track mask đúng chưa đủ chứng minh chữ 3D đúng. Đọc [typesetting-tracking.md](typesetting-tracking.md) và [blender-aae-motion.md](blender-aae-motion.md).

## Xem lại bằng chứng

```bash
python3 scripts/visual_evidence.py sheet work/frames/frames.json --points-csv work/points.csv --roi 80 50 380 240 --width 600 --output work/landmark-sheet
```

Mở `sheet.png`; check point name/identity và native crop mapping trong `evidence.json`. Bảng tọa độ là bằng chứng đo, sheet là bằng chứng đọc hình, matrix là mô hình. Sau khi sinh ASS candidate, thêm render/composite theo timestamp ở [visual-reasoning.md](visual-reasoning.md). Giữ tất cả cùng scene state để harness khác có thể tiếp tục từ mốc đã kiểm.

Khi cần quyết định điểm nào đủ ràng buộc phối cảnh, chẩn đoán residual có cấu trúc hoặc đưa matrix vào nhóm glyph/shape, xem [perspective-motion.md](perspective-motion.md). Fit số không tự quyết định bề mặt đúng, độ nét đúng hoặc representation ASS đúng.
