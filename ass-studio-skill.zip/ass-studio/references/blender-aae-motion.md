# Blender/AAE/Aegisub-Motion cho sign

Đọc cùng [typesetting-tracking.md](typesetting-tracking.md) khi dữ liệu chuyển động đến từ Blender. Phần thao tác dựa trên [AAE Export tutorial](https://github.com/Akatmks/Akatsumekusa-Aegisub-Scripts/blob/master/docs/aae-export-tutorial.md), [smoothing technical details](https://github.com/Akatmks/Akatsumekusa-Aegisub-Scripts/blob/master/docs/aae-export-smoothing-technical-details.md), [Phos: Blender tracking](https://phoscity.github.io/Phos-Fansubbing-Guide/Typesetting/Motion%20Tracking%20Using%20Blender/) và [Phos: Aegisub-Motion](https://phoscity.github.io/Phos-Fansubbing-Guide/Typesetting/Motion%20Tracking/). Menu và phụ thuộc phải so với phiên bản đang cài; đây là quy trình kiểm dữ liệu và output, không phải lệnh cài đặt cố định.

## Thu thập track

1. Khóa footage, fps/timecodes, kích thước native, crop và frame interval của sign. Trong Blender, clip bắt đầu tại **frame 1**; frame 0/âm lặp ảnh đầu, AAE Export xuất từ frame 1. Ghi ánh xạ frame Blender ↔ frame/PTS video ↔ ASS Start để tránh lệch một frame. Với VFR, map qua PTS thực thay vì một fps danh nghĩa.
2. Chọn marker trên vùng có texture ổn định và cùng mặt phẳng với sign. Pattern đủ chứa chi tiết độc đáo; search region đủ cho chuyển động nhưng không quá rộng dễ bám nhầm. Theo dõi qua frame kề có thể tích lũy drift; đặt keyframe sửa tại các anchor rõ. Thay search box được; đổi pattern size giữa track có thể thay suy luận scale khi xuất. Khi ánh sáng đổi, thử normalization/channel; khi marker bị che, track offset trên chi tiết có cùng motion rồi kiểm đường trở lại.
3. Điểm đơn phù hợp translation/scale/rotation khi hình cho phép. Plane/corner phù hợp bề mặt có phối cảnh; cần các góc bám mặt phẳng và kiểm lại sau cut hoặc vùng thiếu texture. `Power Pin Remap` có thể sửa thứ tự/hướng/flip của góc; test bằng ký hiệu bất đối xứng trước khi áp chữ thật.
4. Lưu `.blend`/track gốc và AAE output. Tùy chọn **Auto export** có thể tự ghi dữ liệu cạnh video; tắt nếu không muốn side effect. Chọn đúng track hoặc plane khi copy/export, kiểm first/last sample và range trước khi nhập.

## Smoothing và nhập vào ASS

- AAE Export fit position, scale, rotation và 4 Power Pin corners theo các stream riêng. Xem đồ thị raw, fitted và residual; residual cao hoặc outlier phải truy về frame hình, không tự tăng bậc đa thức. Tài liệu kỹ thuật đánh dấu outlier bằng modified Z-score >3, nhưng đó là gợi ý xem frame, không phải tiêu chí xóa điểm. Rotation được unwrap trước khi fit. Chia section ở cut/đổi mô hình; section blending làm khớp **giá trị** tại biên, không bảo đảm vận tốc liên tục, nên xem frame hai bên biên.
- AAE `position` dùng gốc góc trái trên và đơn vị chuẩn hóa theo chiều cao; ở 16:9, x trong khung thường 0–1.778, y 0–1. `power_pin` tương đối với position. Đừng lấy những số này làm pixel ASS hoặc hoán đổi x/y mà chưa kiểm hệ tọa độ của import.
- Trong Aegisub-Motion, kiểm số frame track trùng phạm vi selection. `Trim` có thể lấy phạm vi từ Start sớm nhất đến End muộn nhất của các dòng chọn; `Trim Each` xử lý riêng từng dòng. Comment không được tính giống Dialogue. `Relative` chọn frame neo của vị trí/tags; `Linear` chỉ phù hợp chuyển động thực gần tuyến tính. Kiểm option cho origin, scale, border/shadow/blur và clip trước khi apply vì chúng thay diện mạo chứ không chỉ vị trí. [Phos: Motion Tracking](https://phoscity.github.io/Phos-Fansubbing-Guide/Typesetting/Motion%20Tracking/).
- Với perspective, AAE Power Pin sang pers-mo có thể tạo nhiều event/shape. Một homography đúng của bốn góc không chứng minh glyph ASS 3D khớp từng điểm; render chữ thật tại đầu, giữa, cực trị, occlusion và biên section. Khi mặt phẳng gấp/biến dạng ngoài mô hình, chia đoạn hoặc FBF có kiểm soát.

## Hợp đồng Apply/Derive trong Aegisub

- Span từ Start sớm nhất tới End muộn nhất của các Dialogue được chọn phải khớp frame range của tracking data; mỗi line riêng không buộc dài bằng track. Comment có thể không được tính như Dialogue. Sau split/reorder, đếm lại frame range thay vì tái dùng selection cũ.
- `Relative` chỉ frame nơi tags hiện tại đã được typeset đúng. Nếu frame neo là 120 tính từ đầu track, lưu đúng convention 1-based/0-based của script đang dùng và kiểm output tại chính frame đó. `Absolute` hay frame 1 không phải lựa chọn an toàn mặc định.
- Chọn từng kênh cần áp: x/y, origin, scale/rotation, clip, border/shadow/blur. Nếu `\org` tồn tại và cần quay quanh cùng vật thể, position đi mà origin đứng yên có thể tạo quỹ đạo sai lớn. Scale `\bord`/`\shad` là quyết định hình, không chỉ quyết định track.
- Với perspective motion, quyết định perspective đã được đặt thủ công hay để script suy từ Power Pin; không làm cả hai. Lưu quad/extradata khi pipeline tiếp theo cần nó và kiểm clip riêng nếu clip phải bám bề mặt.
- Derive Track thường đòi các event liên tiếp, cùng text/layer/comment-state và đủ nhiều frame; macro blur/split/layer có thể phá cấu trúc cần để derive. Giữ AAE/track gốc hoặc InlineStorage thay vì coi derive từ output là backup chắc chắn.

Phos mô tả `Match=Keyframe` giữ reference cố định, còn kiểu previous/keyframe gần nhất thích nghi deformation nhưng có thể tích lũy sai. Pattern region cần giữ kích thước ổn định khi scale của export dựa vào nó. Correlation/normalize/channel là controls để thử theo footage; không dùng một threshold phổ quát rồi tự chấp nhận track.

## Bài kiểm tra bắt buộc trước khi nhân rộng

Đặt dấu bất đối xứng và một baseline trên candidate, render frame đầu, frame kế, frame cuối, hai bên cut và điểm track nghi drift. Kiểm hướng chuyển động, offset một frame, scale, pivot, clip/occlusion. Sau đó thay bằng glyph thật cùng font/tags và so với raw. Lưu manifest ánh xạ frame, bản AAE, option import, frame tham chiếu và ngoại lệ. Không sửa cả video chỉ vì một preview ở frame đầu đẹp.
