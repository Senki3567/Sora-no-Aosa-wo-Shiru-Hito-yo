# Dùng ASS Studio qua nhiều harness và model

Đối chiếu tài liệu chính thức ngày 2026-10-16. Giữ một bộ `SKILL.md` + references + scripts dùng chung. Điều chỉnh cách nạp skill, gọi shell, đọc ảnh/audio và trình bày artifact theo **công cụ thực sự được cấp ở phiên hiện tại**. Tên harness không chứng minh model có vision/audio hoặc công cụ cài sẵn.

## Nạp đúng bản và giải đường dẫn

| Harness | Vị trí được tài liệu mô tả | Cách dùng trong phiên |
|---|---|---|
| Codex | Project/user `.agents/skills/ass-studio/`; bản Codex desktop ở máy này đang có `~/.codex/skills/ass-studio/` | Đọc path skill được runtime cung cấp; `$ass-studio` hoặc chọn skill trong UI. Giữ `agents/openai.yaml` là metadata tùy chọn. [OpenAI docs](https://learn.chatgpt.com/docs/build-skills) |
| Claude Code | `.claude/skills/ass-studio/` của project hoặc `~/.claude/skills/ass-studio/` | `/ass-studio` hoặc auto selection. Claude có hỗ trợ biến thư mục skill trong body, nhưng core vẫn dùng đường dẫn giải từ file đang nạp để portable. [Claude skills](https://code.claude.com/docs/en/skills) |
| OpenCode | `.opencode/skills/`, `~/.config/opencode/skills/`; cũng đọc `.claude/skills/` và `.agents/skills/` ở scope được tài liệu hỗ trợ | Nạp qua native `skill` tool. Có thể dùng chung copy Claude-compatible; tránh nhiều bản cùng tên khác nội dung. Frontmatter không cần key của Claude/Codex. [OpenCode skills](https://docs.opencode.ai/docs/skills/) |
| Antigravity app/IDE | Project `.agents/skills/ass-studio/`, global `~/.gemini/config/skills/ass-studio/` | Auto discovery hoặc slash skill; IDE kiểm skill đang active qua Customizations. [Antigravity skills](https://antigravity.google/docs/skills) |
| Antigravity CLI | Project `.agents/skills/ass-studio/`, global `~/.gemini/antigravity-cli/skills/ass-studio/` | Kiểm surface/version trước khi copy; path global khác app/IDE. [Antigravity skills by surface](https://antigravity.google/docs/skills#skills-by-surface) |

Các đường dẫn trên mô tả discovery, không cấp quyền ghi/cài thêm vào máy. Khi phân phối, copy **cả thư mục** cùng scripts/references; chỉ copy SKILL.md làm hỏng các tài nguyên tương đối. Giải `skill_root` từ SKILL.md thực đang được nạp; dùng script tuyệt đối và Python được kiểm ở runtime. Cwd làm việc vẫn là project, output đặt trong project work folder. Khi dùng Windows có thể là `py -3` thay vì `python3`; không giả định Bash/ffmpeg/libass đã có.

**OpenCode v1/v2:** kiểm phiên bản CLI thực trước khi viết custom-agent adapter; cú pháp v1 và v2 khác nhau. Trên v2, Markdown agent dùng `permissions` là danh sách `{action, resource, effect}`, body là system prompt; tránh thêm các trường legacy `permission`, `tools`, `temperature`. Agent nên nạp skill dùng chung thay vì giữ một bản workflow rút gọn dễ lệch. V2 có `opencode debug agents` để kiểm discovery không gọi model; đọc help của bản cài trước khi dùng. Skill nạp bằng ID theo path, và bản native global được ưu tiên hơn bản `.claude` global cùng ID. Nguồn đối chiếu 2026-10-20: [V2 agents](https://opencode.ai/v2/docs/agents), [V2 skills](https://opencode.ai/v2/docs/skills). Đừng suy file đặt đúng thư mục là runtime đã nhận; cũng đừng quy lỗi plugin cũ thành lỗi nội dung skill khi chưa tách nguyên nhân.

Không nhúng bắt buộc `allowed-tools`, `context: fork`, shell injection hoặc hook riêng của một hãng vào core. Chỉ cấu hình chúng nếu người dùng yêu cầu và môi trường hỗ trợ. Không sửa permission để vượt một công cụ đang bị chặn. Model khác có thể chọn kỹ thuật khác, nhưng phải tạo được cùng loại bằng chứng cần thiết.

## Khảo sát khả năng theo tác vụ

Chạy `scripts/studio_check.py` bằng Python của phiên để biết đường dẫn helper, command và module hiện có. `--probe` chỉ thêm version check có giới hạn của ffmpeg/ffprobe/Blender. Script không đọc credential/config của harness, không cài dependency và không tự xác định model đang nhìn/nghe được gì.

| Cần làm | Ưu tiên công cụ phù hợp | Nếu thiếu |
|---|---|---|
| Đọc/sửa ASS | File tool có encoding đúng hoặc helper `ass_tools.py` | Dùng shell/Python đã cấp, giữ BOM/newline và so field; không sửa file qua text preview bị truncate |
| Xem raw/candidate/landmark sheet | Công cụ ảnh của runtime; Codex có thể cấp `view_image`, Claude Code `Read` hỗ trợ ảnh theo docs | Thử một PNG nhỏ thật, xác nhận tool đưa **pixel vào model**, không chỉ link/path. Nếu chưa có, dùng image-capable tool/model đã được cấp; giữ visual check chưa kiểm |
| Chạy Python/ffmpeg/macro | Shell/process tool hiện có; truyền argv và path có dấu cách đúng | Đổi interpreter/path hoặc dùng target renderer đã có; ghi capability thiếu. Sự có mặt của CLI không chứng minh macro chạy |
| Theo dõi process dài | Session handle/background process/wait của harness | Poll theo job handle hoặc chạy đoạn có giới hạn; giữ log/output và tránh khởi động cùng job lần nữa |
| Nghe lời/kiểm speaker | Audio/video input có nội dung nghe được cho model | Trích audio đoạn đúng để tool hỗ trợ; waveform/spectrogram/Actor không đủ kết luận giọng. Phần chưa nghe giữ uncertainty |
| Trình bày kết quả | Artifact/file preview/ảnh inline của harness | Giữ PNG/report trong workspace và link file; hiển thị được cho người dùng không tự nghĩa model đã xem |

Nguồn công cụ: [Claude Code tools](https://code.claude.com/docs/en/tools-reference), [OpenCode tools](https://docs.opencode.ai/docs/tools/), [Antigravity hooks/tool reference](https://antigravity.google/docs/hooks). Đây là gợi ý để tìm capability, không phải tên API dùng được trên mọi bản. OpenCode phụ thuộc provider/model và tools/permission được bật; đừng suy vision chỉ từ tên `read` hoặc tên model.

## Tận dụng công cụ riêng trong từng harness

- **Codex:** dùng process/file tools được cấp để chạy helper, trả JSON ngắn và giữ report đầy đủ trên đĩa. Dùng image tool với PNG/crop thật, không suy hình từ terminal output. Nếu có file/media panel, mở candidate/evidence ngay trong chat. Session handle giúp tiếp tục process dài; kiểm completion trước khi đọc output. Không chép các wrapper `functions.*` của một phiên vào script portable.
- **Claude Code:** dùng Bash chạy helper và Read để đọc source/ảnh theo tool schema của phiên. Giữ đường dẫn script gắn với skill đang nạp; biến thư mục riêng của Claude chỉ dùng trong adapter của Claude khi cần. Nếu chạy nền, theo job/output handle mà phiên trả về. File dùng legacy encoding nên đi qua helper bảo toàn encoding thay vì ghi toàn bộ bằng Write. Các tính năng fork/hook có thể hỗ trợ quy trình riêng, không là điều kiện để skill chạy.
- **OpenCode:** nạp nội dung bằng `skill`, chạy helper bằng shell tool, dùng `read`/search để đọc đúng phần source và report. Kiểm ảnh có được đưa vào model bằng một PNG thử; provider/model hoặc tool plugins có thể khác nhau. Tận dụng custom/MCP tool đã có cho image/video nếu nó thực sự cung cấp pixel. Khi kiểm discovery, đọc help của bản cài trước; không mặc định có một lệnh `debug skill`, và không khởi chạy model chỉ để liệt kê skill.
- **Antigravity:** dùng file/process/image tools của surface đang chạy, giữ ảnh/report có đường dẫn project làm nguồn tái dùng. Dùng artifacts/review pane nếu được cấp để trình bày phép so sánh và nhận sửa tiếp; artifact hoàn tất phải trỏ tới file thật. Khi agent browser nhìn được media, kiểm nguồn/timestamp/kích thước trước khi đo; screenshot UI cần quy đổi thêm sang native. Phân biệt SDK, CLI và IDE tool schemas; không đem tên enum SDK gọi trực tiếp như tool IDE.

Các thao tác đọc/probe độc lập có thể chạy đồng thời khi harness hỗ trợ. Các bước đo→fit→render phải theo phụ thuộc; mutation vào một master hoặc một macro selection chạy tuần tự. Khi đổi model, giữ scene data/checks và cho model đọc bằng chứng cần thiết thay vì yêu cầu nó lặp cùng một chuỗi suy nghĩ.

## Chọn capability từ câu hỏi, không từ ví dụ mẫu

| Câu hỏi cần trả lời | Capability và bằng chứng tối thiểu |
|---|---|
| Câu dịch/câu biên tập có đúng nghĩa không? | Text reasoning trên lời nguồn, ngữ cảnh và quy ước dự án; timing hoặc độ giống chuỗi chỉ hỗ trợ tìm kiếm |
| Hardsub ghi gì? | Pixel/crop/sequence thật và provenance OCR; EN/audio không được dùng để bịa lại chữ trong ảnh |
| Ai đang nói, onset/off ở đâu? | Audio đoạn đủ câu trước/sau; waveform, Actor cũ hoặc hình miệng không tự là kết luận |
| Bản sửa có vượt phạm vi không? | Parser giữ dữ liệu, baseline hash, identity guard và field diff; vision không thay được kiểm byte/field |
| Sign/KFX có đúng hình không? | Renderer/font/PTS đúng và composite trên footage; script exit 0 chỉ xác nhận thực thi |
| Tối ưu có thật sự tốt hơn không? | Cùng renderer, cache state, scene peak và chỉ số CPU/bitmap kèm kiểm hình |
| Package giao có dùng được không? | Mở lại archive/mux/encode cuối, kiểm contents/hash/track/font và sample endpoint |

Với việc nhiều bước, giữ task state chung trong [problem-solving.md](problem-solving.md). Chỉ dùng `scene.json` của [scene-contract.md](scene-contract.md) khi bài toán thật sự có object/layer/frame/track; không buộc tác vụ dịch, timing hoặc sửa một field phải giả làm scene hình ảnh.

## Chọn mức tự động hóa và giữ chất lượng

- Có shell + vision + video/frame tools: dùng [visual-reasoning.md](visual-reasoning.md), fit dữ liệu đo khi cần, render/composite rồi kiểm qua quỹ đạo. Tận dụng công cụ native để đọc ảnh/process; giữ thuật toán và scene data trong file portable.
- Có shell nhưng chưa có vision: có thể parse/patch, kiểm field, fit landmark từ dữ liệu đã đo và xuất ảnh. Chỉ báo những phần ấy đã qua; không tự tuyên bố sign/FX khớp raw.
- Có vision nhưng không có shell: dùng file/ảnh/tool được cấp để khảo sát và lập tham số; chỉ tạo output cuối nếu công cụ thực sự hỗ trợ ghi/render. Không tạo số đo chính xác giả từ một thumbnail.
- Có macro Aegisub/Blender: chạy trên candidate với version/dependencies/context đã kiểm. Nếu lỗi hiển thị, font, module hoặc API, giữ lỗi cụ thể và chuyển cách thực thi phù hợp. Không cần đổi model khi lỗi nằm ở môi trường.
- Không có delegation hoặc không được phép: làm tuần tự các lượt đo, dựng và phản biện. Có delegation được phép thì chia read-only evidence hoặc file owner rõ ràng, không để nhiều agent ghi một master. Số agent không tự tăng độ đúng.

Với tác vụ hình phức tạp, giữ `scene.json` và artifact paths theo [scene-contract.md](scene-contract.md) để chuyển harness/sau compaction. Bằng chứng có thể xem lại giúp model tiếp tục từ trạng thái đã kiểm; không phụ thuộc vào việc nó có nhớ thủ pháp từ cuộc trò chuyện trước. Đánh giá từng harness/model bằng bộ tình huống rộng ở [workflow-evals.md](workflow-evals.md) và tập hình chuyên sâu ở [visual-evals.md](visual-evals.md); ghi rõ phần nào mới được kiểm định dạng, phần nào đã chạy tools, phần nào đã qua đánh giá nội dung/hình/audio thật.

Với motion phức tạp, dùng checkpoint theo [perspective-motion.md](perspective-motion.md): giữ dữ liệu đo, câu hỏi chưa giải, mô hình đã bác bỏ, ảnh đã xem và phép thử tiếp theo. Model thiếu context nên thực hiện từng quyết định có đầu vào/đầu ra kiểm được; không chỉ nhận một lời nhắc dài yêu cầu “track chính xác”. Không coi skill là huấn luyện trọng số hoặc tuyên bố một model khác đã qua bài thực hành khi chưa chạy nó.
