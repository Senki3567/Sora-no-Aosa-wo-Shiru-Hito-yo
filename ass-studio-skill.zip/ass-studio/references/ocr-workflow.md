
# Hardsub OCR ASS-native

## 1. Invariants

- Workflow này **chỉ xử lý ASS**. Parser/export SRT legacy có thể còn trong script để tương thích cũ nhưng **không thuộc SOP này** và không được mở rộng.
- ASS source là bất biến. Output luôn là file mới có hậu tố `_vi.ass`; không ghi đè source.
- Timing, style, trường ASS ngoài scope và leading override tags của cue được giữ nguyên. EN source được giữ dưới dạng inline comment `{en_ref}`; không để EN hiển thị trên video.
- Script chỉ làm I/O cơ học: parse ASS, ffprobe/ffmpeg, crop/scale, contact sheet, manifest, schema validation, checkpoint, provenance và export.
- **Cấm script suy luận ngôn ngữ**: không regex sửa dấu câu/chính tả, không similarity, không tự merge/copy/missing, không keyword heuristic, không tự quyết định line break.
- Gemini worker chỉ OCR ảnh. Gemini không dịch, không giải thích, không thêm `\N`.
- **Cấm dịch lại ở mọi bước**: chữ Việt nhìn thấy trong hardsub (qua OCR/rescue) là nguồn câu chữ duy nhất. EN chỉ là mốc tham chiếu để ghép đúng nội dung Việt vào cue EN; không dùng EN để tự viết câu Việt.
- Agent được biên lại ranh giới câu khi tách/gộp: chuyển các cụm Việt đã OCR sang cue EN tương ứng, thêm dấu câu hoặc `\N` khi cần, giữ nguyên từ ngữ, xưng hô, ý và thứ tự của fansub. Chỉ sửa lỗi OCR/chính tả có căn cứ; cấm diễn đạt lại, thay từ đồng nghĩa, lược ý hoặc thêm ý từ EN. Nếu thiếu chữ Việt, dùng rescue/trạng thái thiếu thay vì suy ra lời dịch từ EN.
- `DIRECT` không được chọn chỉ vì cùng số cue hoặc timestamp gần nhau. Agent phải đối chiếu ý chính của từng cue EN–VI trong ngữ cảnh các cue liền kề; EN và VI có thể là hai bản dịch khác nhau từ tiếng Nhật, nên chấp nhận cách nói tự nhiên/phi nguyên văn nếu ý và chức năng câu tương hợp.
- Phân biệt khác biệt diễn đạt với lệch nghĩa: chỉ đánh dấu nghi vấn khi có mâu thuẫn rõ, đảo phủ định/hành động/đối tượng, thiếu một mệnh đề trọng yếu, hoặc câu VI không liên quan. Khi nghi vấn, tìm cụm VI OCR ở cue lân cận trước; chỉ chuyển phần văn bản đã có bằng chứng OCR/rescue. Không dùng EN để viết lại VI.
- Nếu sau khi soát ngữ cảnh vẫn không thể phân biệt chắc chắn giữa bản dịch tự do và lệch nghĩa/lệch cue, gán method `NEED_SEMANTIC_REVIEW`. Giữ nguyên VI đã có để hiển thị và ghi đúng nhãn trong `Effect`; không biến thành `MISSING`, không tự sửa câu theo EN. Đây là nhãn chờ người rà soát, không phải nhãn OCR rescue.
- Người xử lý bước semantic PR chỉ cần text cho PR thông thường. Agent chỉ xem ảnh khi `review_report.json` tồn tại sau Gemini rescue và cue vẫn `[UNCERTAIN]`.

## 2. Cấu hình OCR trong bộ tích hợp

Worker tích hợp đọc key từ `~/.config/hardsub-ocr/api_keys` (quyền 600), `HARDSUB_GEMINI_API_KEYS_FILE`, `HARDSUB_GEMINI_API_KEYS` hoặc `GEMINI_API_KEY`. Bản skill/ZIP không chứa credential; khi cài trên máy đang dùng, có thể giữ cấu hình OCR riêng hiện có. Không in key trong log hoặc kết quả.

Khai báo `HARDSUB_GEMINI_OCR_MODELS` và `HARDSUB_GEMINI_RESCUE_MODELS` theo các model project đang cho phép. Doctor kiểm tra cả hai allowlist trước đợt chạy; primary chỉ dùng rescue khi có cue cần rescue. Tên/quota cũ trong lịch sử không là mặc định ổn định. Checkpoint và key/model pool giữ cơ chế resume; không coi nhiều key cùng project là quota riêng hoặc dùng rotation để vượt giới hạn.

Tài liệu tham chiếu:
- Models API: https://ai.google.dev/api/models
- GenerateContent: https://ai.google.dev/api/generate-content
- Structured output: https://ai.google.dev/gemini-api/docs/structured-output
- Rate limits: https://ai.google.dev/gemini-api/docs/rate-limits

## 3. Exit codes

| Code | Trạng thái |
|---:|---|
| `0` | Thành công |
| `64` | Input/config/technical precondition lỗi |
| `65` | Capture/JPEG/I/O lỗi |
| `66` | JSON/schema/coverage lỗi |
| `75` | Toàn bộ cặp key/model khả dụng đã trả 429 cho batch đang chạy; có thể resume |
| `76` | Source/artifact stale hoặc provenance không khớp |
| `77` | Gemini rescue vẫn còn `[UNCERTAIN]`; cần agent review theo `review_report.json` |

Không biến lỗi kỹ thuật thành `MISSING`.

## 4. Preflight và doctor

### 4.1 Exact pairing

```bash
python3 scripts/ocr_worker.py \
  preflight --video-dir "/path/videos" --sub-dir "/path/subs"
```

Pairing chỉ dựa trên **basename trùng chính xác** giữa video và `.ass`. Không fuzzy glob để đoán tập.

Preflight liệt kê exact pairs và style/count để xác minh scope; dùng style đã được người dùng chỉ định hoặc xác định qua event role, chỉ hỏi khi còn mơ hồ ảnh hưởng output. Nếu có video thiếu ASS, ASS thiếu video hoặc episode không tồn tại, dừng trước extraction.

Nếu tên video và ASS khác nhau, chỉ ghép khi đã xác định rõ đường dẫn từng file theo tập. Tạo symlink video trong thư mục staging video ở `/tmp` và copy ASS vào thư mục staging ASS riêng, đặt cùng một basename tập đã chọn, rồi chạy lại preflight trên staging. Không copy video nhiều GB, không fuzzy match, không đổi tên/di chuyển file nguồn. Ghi lại ánh xạ staging → hai file gốc và giữ staging đến khi export/rescue xong: manifest dùng đường dẫn staging để kiểm tra source identity.

### 4.2 Technical/Gemini doctor

```bash
python3 scripts/ocr_worker.py \
  ocr-doctor --video "/exact/episode.mkv" --sub "/exact/episode.ass" --styles "Default"
```

Doctor kiểm tra:
- `ffmpeg`, `ffprobe`, Pillow;
- video stream/duration/dimensions;
- ASS và style được chọn;
- timestamp lỗi/cue rỗng;
- cấu hình key riêng hoặc biến môi trường;
- model listing và `generateContent` support của hai allowlist.

## 5. Primary extraction

Sau khi style/tập/output đã xác định từ yêu cầu và preflight (không hỏi lại nếu đã được chỉ rõ):

```bash
python3 scripts/ocr_worker.py \
  batch-extract \
  --video-dir "/path/videos" \
  --sub-dir "/path/subs" \
  --styles "Default" \
  --out-base /tmp/sub_ocr
```

Mặc định:
- crop đáy 24%; scale tile rộng 560 px bằng Lanczos;
- safe interval clamp theo cue trước/sau và duration video;
- lấy frame 50% của safe interval;
- contact sheet lưới 3 cột, tối đa 20 cue/ảnh;
- JPEG capture atomic, verify bằng Pillow, retry decoder một lần;
- chỉ prefill `[EMPTY]` khi crop gần như đồng nhất; **không** coi ảnh tối là empty.

Mỗi `ep.../batch_manifest.json` chứa `run_id`, source identity, video metadata, config crop/style, cue timestamps, batch label map, capture status và prefilled labels.

Nếu run cùng source/config đã tồn tại, giữ lại để resume. Muốn tạo run mới:

```bash
... batch-extract ... --replace-run
```

Không xóa artifact âm thầm.

## 6. Gemini OCR worker

```bash
python3 scripts/ocr_worker.py \
  ocr-vlm /tmp/sub_ocr/epXX/batches /tmp/sub_ocr/epXX/ocr_raw.json
```

Gemini nhận JPEG inline và structured JSON. Response schema chỉ gửi `type`/`properties`/`required` mà API hỗ trợ; worker kiểm tra chính xác tập key trả về theo manifest ở phía local. Không gửi `additionalProperties` trong schema. Mỗi batch chỉ được trả đúng các key trong manifest. Giá trị hợp lệ:

- text phẳng;
- `[EMPTY]`;
- `[UNCERTAIN]`.

Không trả chuỗi rỗng: tile không có chữ dùng `[EMPTY]`; tile không đọc chắc được dùng `[UNCERTAIN]`. Không `\N`, không translation, không prose.

Worker:
- retry lỗi response/schema/timeout theo đúng batch;
- checkpoint từng batch;
- primary chỉ kiểm tra allowlist rescue và gọi rescue khi kết quả thực sự có `[UNCERTAIN]`; doctor đầu đợt vẫn kiểm tra cả hai allowlist;
- 429 tạm loại cặp key/model, thử key tiếp theo rồi model kế tiếp; 503 chuyển model kế tiếp nếu còn model dự phòng; lỗi tạm thời khác được retry theo batch rồi mới thử cặp tiếp;
- chỉ trả exit `75` khi mọi cặp key/model khả dụng cho batch đó đều kết thúc bằng 429; 503 hết model dự phòng là lỗi tạm thời (`64`), không phải hết quota;
- resume không OCR lại checkpoint đã hoàn tất.

### 6.1 Automatic uncertain rescue

Nếu primary OCR trả `[UNCERTAIN]`, script tự lấy ba frame thô 35% / 50% / 65% của safe interval và gửi `HARDSUB_GEMINI_RESCUE_MODELS`.

Không threshold, sharpen, contrast hay sửa ảnh để quyết định chữ.

Nếu rescue vẫn `[UNCERTAIN]`:
- ghi `review_report.json` với đúng image paths;
- ghi OCR artifact/provenance;
- exit `77`;
- lúc này agent mới được phép xem các ảnh được liệt kê trong review report.

## 7. Text-only semantic PR

```bash
python3 scripts/ocr_worker.py \
  prepare-pr episode.ass ocr_raw.json pr_tasks.json --styles "Default"
```

`pr_tasks.json` có một contract chung và cue payload compact:

```json
{
  "id": "42",
  "en": "English reference",
  "ocr": "Văn bản OCR",
  "source_state": "OCR"
}
```

Để agent đọc đủ mọi cue mà không lặp JSON/contract trong context, dùng view chỉ đọc:

```bash
python3 scripts/ocr_worker.py \
  pr-view pr_tasks.json
```

View in một dòng `id<TAB>EN<TAB>VI OCR` cho mỗi cue; chỉ in `source_state` khi khác `OCR`. Có thể đọc lại đoạn khó bằng `--start ID --count N`. Agent phải soát ngữ nghĩa **toàn bộ** view theo thứ tự, kể cả các dòng trông khớp; không tự chấp nhận hàng loạt hay bỏ cue vì format gọn. Với mỗi cue, kiểm tra ý chính/câu thoại có tương hợp không và nhìn cue trước/sau khi có dấu hiệu lệch; ghi chú riêng chỉ các cue nghi vấn cùng lý do ngắn. `DIRECT` chỉ xác nhận nội dung hiện có phù hợp cue sau bước này; không có nghĩa là câu VI đã được dịch lại hay đạt tương đương từng chữ. `pr_tasks.json` và provenance vẫn là nguồn chính để ghi `pr_done.json`.

Bước semantic PR không cần contact sheet thường; diagnostics kỹ thuật do worker cung cấp. Agent điều phối có thể đọc diagnostics và sửa lỗi kỹ thuật trong phạm vi đã giao; không dò/in key. Agent quyết định:
- `DIRECT`
- `MERGE_N1`
- `COPY_M`
- `MISSING_ROLLOVER`
- `DUP_CASCADE`
- `MISSING`
- `NEED_SEQ_PROBE`
- `NEED_SEMANTIC_REVIEW`
- copyedit tối thiểu và line break `\N`.

Agent phải dùng chính chữ Việt OCR/rescue làm nguồn. EN chỉ giúp xác định ranh giới và vị trí của các phần Việt khi một câu bị tách, gộp hoặc lệch cue. Được chuyển phần Việt đã OCR giữa các cue, chỉnh dấu câu và `\N`, và sửa lỗi OCR/chính tả có căn cứ; không được dịch lại, viết lại cho mượt, đổi xưng hô/từ đồng nghĩa, bổ sung ý từ EN hay tự lấp phần thiếu. Giữ thứ tự các phần Việt; dùng method phù hợp để ghi nhận tách/gộp/thiếu.

Trước khi đánh dấu `MISSING`, soát cue EN liền kề và các phần VI OCR liền kề để phát hiện rollover, lệch một hay nhiều cue, hoặc một câu VI phủ nhiều cue EN. Nếu ánh xạ vẫn chưa chắc, chọn rescue phù hợp (`NEED_SEQ_PROBE` hoặc `MISSING` để chạy probe) thay vì suy ra rằng video không có chữ. Chỉ giữ `MISSING` sau khi rescue không tìm thấy chữ Việt.

Trước `merge-pr`, đối chiếu từng `vi` với chữ Việt trong `ocr`/rescue và các cue Việt lân cận: mọi cụm Việt có nghĩa trong `vi` phải truy được về OCR/rescue (trừ sửa lỗi OCR rõ ràng). Nếu không truy được, sửa quyết định PR hoặc đưa cue vào rescue, không xuất ASS. Kiểm tra thêm các cue `DIRECT` để chắc rằng không còn mâu thuẫn/lệch cue rõ; không đòi VI khớp nguyên văn EN vì cả hai có thể dịch từ tiếng Nhật. `report.json` `matched`/`coverage_pct` chỉ đo độ phủ cue, không phải xác nhận chất lượng ngữ nghĩa. Không dùng rule ngôn ngữ từ case cũ.

`pr_done.json` phải mang đúng provenance run:

```json
{
  "run_id": "<run_id trong pr_tasks.json>",
  "decisions": {
    "1": {"vi": "...", "method": "DIRECT"},
    "2": {"vi": "", "method": "MISSING"}
  }
}
```

Hợp nhất:

```bash
python3 scripts/ocr_worker.py \
  merge-pr pr_tasks_locked.json pr_done.json pr_merged.json
```

`run_id`, source identity và coverage phải khớp; stale PR bị từ chối.

## 8. Export ASS

```bash
python3 scripts/ocr_worker.py \
  export episode.ass pr_merged.json episode_vi.ass \
  --styles "Default" \
  --report /tmp/sub_ocr/epXX/report.json
```

Output bắt buộc kết thúc `_vi.ass`; source không được overwrite.

`Effect` phản ánh method agent đã chọn. `{en_ref}` được đặt trước VI dưới dạng ASS inline comment. Dòng ngoài target style giữ nguyên từ source.

## 9. Targeted rescue sau PR

`batch-rescue` chỉ chạy sau PR/report, dựa trên exact source identities trong primary manifest và report provenance. Nó **không** tìm video/ASS gần đúng bằng glob.

```bash
python3 scripts/ocr_worker.py \
  batch-rescue --out-base /tmp/sub_ocr
```

Mặc định report method:
- `MISSING` → Top 50% probe;
- `MISSING_ROLLOVER` và `DUP_CASCADE` không tự rescue; chỉ chạy lại nếu agent/harness chỉ định `--top-ids` hoặc `--full-ids`;
- `NEED_SEQ_PROBE` → Bottom 25% + 75% probes.

Có thể yêu cầu explicit rescue IDs do agent/harness quyết định:

```bash
... batch-rescue --out-base /tmp/sub_ocr --top-ids 12,18 --full-ids 44 --seq-ids 51 --replace-rescue
```

Rescue tạo manifest v2 riêng, 3-column contact sheets và giữ artifact. Không tự sửa ASS/output.

OCR rescue vẫn dùng Gemini:

```bash
python3 scripts/ocr_worker.py \
  ocr-vlm /tmp/sub_ocr/rescue/batches /tmp/sub_ocr/rescue/rescue_raw.json
```

Sau đó tạo task text-only cho agent:

```bash
python3 scripts/ocr_worker.py \
  prepare-rescue-pr /tmp/sub_ocr/rescue/rescue_raw.json /tmp/sub_ocr/rescue/rescue_tasks.json
```

Agent quyết định text cuối/line break cho rescue, đặc biệt `SEQ_SPLIT`; script không tự ghép hai vế theo nghĩa.

`rescue_done.json`:

```json
{
  "run_id": "<rescue run_id>",
  "decisions": {
    "01:51": {"vi": "vế đầu\\Nvế sau", "method": "SEQ_SPLIT"}
  }
}
```

Apply explicit:

```bash
python3 scripts/ocr_worker.py \
  batch-rescue-apply /tmp/sub_ocr/rescue/rescue_done.json --out-base /tmp/sub_ocr
```

Apply chỉ cập nhật artifact PR và `_vi.ass` đã định danh bởi report provenance; không ghi source ASS.

Sau `batch-rescue-apply`, `pr_merged.json` đã chứa các kết quả rescue. Không chạy lại `merge-pr` sau bước này vì lệnh đó dựng lại file từ `pr_tasks_locked.json` và `pr_done.json`, làm mất mọi cập nhật sau merge. Nếu cần hợp nhất lại PR, áp dụng lại các quyết định rescue đã lưu rồi mới export.

## 10. Method contract

| Method | Effect | VI hiển thị |
|---|---|---|
| `DIRECT` | rỗng | VI |
| `MERGE_N1` | `MERGE_N1` | VI đã agent ghép |
| `MERGED_INTO` | `MERGED_INTO` | rỗng |
| `COPY_M` | `COPY_M` | cùng VI do agent quyết định |
| `DUP_CASCADE` | `DUP_CASCADE` | rỗng |
| `MISSING_ROLLOVER` | `MISSING_ROLLOVER` | rỗng |
| `RESCUE_CAND` | `RESCUE_CAND` | VI |
| `TOP_RESCUE` | `TOP_RESCUE` | VI |
| `RESCUE` | `RESCUE` | VI |
| `SEQ_SPLIT` | `SEQ_SPLIT` | VI, có thể chứa một `\N` do agent đặt |
| `NEED_SEQ_PROBE` | `NEED_SEQ_PROBE` | trạng thái trung gian trước rescue |
| `NEED_SEMANTIC_REVIEW` | `NEED_SEMANTIC_REVIEW` | VI hiện có vẫn hiển thị; cần rà soát nghĩa/căn cue |
| `MISSING` | `MISSING` | rỗng |

## 11. Agent handoff rules

- Một episode/run OCR đầy đủ là mặc định; không chia nhỏ theo quota token cứng.
- Chỉ chia PR text thành cửa sổ khi harness thực tế báo context limit.
- Agent không được mở batch OCR thường.
- Không dò/in API key. Worker xử lý retry/checkpoint; agent điều phối có thể kiểm tra schema/ffmpeg diagnostics và sửa integration khi có căn cứ, không biến lỗi kỹ thuật thành thiếu lời.
- Agent chỉ xem ảnh từ `review_report.json` khi Gemini rescue vẫn unresolved.
- Không biến cue thiếu OCR hoặc technical failure thành `MISSING`.
