# Shape, clip, split và đồng hồ hiệu ứng

Đọc khi cắt outline theo clip, chuyển font thành drawing, tracking nhiều phần hoặc ghép FBF/native animation. Nguồn bổ trợ: [agent-motion-architecture.md](agent-motion-architecture.md), [typesetting-tracking.md](typesetting-tracking.md), [font-reconstruction.md](font-reconstruction.md).

## Gọt shape theo clip

“Shape clipper” có thể nghĩa là thêm tag clip, hoặc cắt trực tiếp đường bao để bỏ tag. Xác định từ yêu cầu; nếu muốn gọt shape thì thêm `\clip` chưa hoàn tất nhiệm vụ.

Đưa outline và clip vào cùng hệ tọa độ trước khi làm Boolean intersection: font units → layout advances → drawing scale → anchor/position/transform → screen. Clip rectangle, vector clip và inverse clip cần xử lý đúng phép giao/hiệu; không lấy tọa độ màn hình cắt outline local chưa biến đổi. Khi có frx/fry/phối cảnh không thể giả định chỉ dịch pos là đủ.

Có thể dùng thư viện hình học đường cong/Boolean sẵn có. Nếu phải flatten Bézier thành polygon, chọn tolerance theo sai số screen ở scale target, giữ holes/fill rule, loại đoạn suy biến và kiểm tra hướng contour. Số điểm có thể tăng mạnh; đo bytes và silhouette trước/sau. Giữ shape path chính xác cho bản chốt, không tối ưu bằng ngưỡng chưa kiểm chứng.

Trong split hai bên, clipping vùng chữ gốc/màn hình chuyển động có thể khác clip local của từng nửa. Dựng toàn câu quanh một tâm, gọt hai phần theo đường cắt đúng và áp track riêng cho mỗi phần. Không dùng dấu cách/font advance để đoán motion. Theo dõi mép wipe/landmark raw và vùng còn nhìn thấy, kể cả chữ nằm trên đường cắt.

Màn hình tự cắt nội dung ngoài frame: chỉ giữ clip bổ sung khi phục vụ wipe/occlusion thực. Một clip bị inset vào trong khung có thể làm mất nét thay vì chỉ “tối ưu”. Blur sau gọt silhouette có thể lan qua mép khác với clip sau blur; xem composite ở đường cắt, không hứa pixel-identical từ phép Boolean.

So bản font, bản shape còn clip và bản đã gọt ở cùng frame/renderer. Kiểm tra counter, dấu, đường cắt, góc màn hình, blur và vị trí qua toàn quỹ đạo. Chỉ bỏ tag đã được bake; giữ timing/màu/blur/phases từ baseline người dùng vừa chốt.

## Dựng animation từ ý tưởng hoặc mẫu (Declarative Motion IR)

Viết các phase có nghĩa của effect: chuẩn bị/hiện, settle, nhấn, giữ, chuyển trạng thái và biến mất; không buộc mọi effect có đủ các phase ấy. Với mỗi thành phần, chọn thuộc tính thật sự cần đổi (hình/vị trí/scale/alpha/màu/blur/clip), mốc tuyệt đối và trạng thái ở hai đầu. Một từ mô tả như “nảy”, “tan”, “quét” chưa đủ quyết định trajectory, số lớp hay easing.

Nếu có mẫu video gốc, chạy `python3 scripts/motion_studio.py probe` để đọc thứ tự sự kiện, cadence (1s/2s/3s) và silhouette/nhịp trước, sau đó dùng `python3 scripts/motion_studio.py fit-curve` để khôi phục đường cong tham số (`linear`, `power`/`accel`, `cubic-bezier`, `spring`, `step`). Nếu thiết kế mới, dựng một cơ chế nhỏ phù hợp brief rồi kiểm readability. Có thể thử native tags, shape pieces, clip bands hoặc FBF theo loại thay đổi; giữ cơ chế đơn giản khi nó đủ mô tả. Kiểm renderer hỗ trợ tag/property cần animate; không coi mọi override đều biến đổi được bằng `\t`. [Aegisub tags](https://aegisub.org/docs/latest/ass_tags/).

Khi hiệu ứng sai, khóa các phase đã đúng rồi tắt từng lớp/transform trên candidate. Kiểm thứ tự tag, trạng thái đầu, thời gian chồng và clock của event gây lỗi. Với nhiều `\t` cùng sửa một thuộc tính, xác minh hình tại chỗ giao; xếp hai transform cạnh nhau không tự tạo một đường animation liên tục. Chỉ đổi easing sau khi endpoint, deadline và đơn vị đã đúng.

Để generator/compiler chỉnh được bằng prompt, tách tham số thiết kế (biên độ, thời gian, mật độ, seed, palette) khỏi dữ liệu nguồn (lyric, onset, glyph/layout đã duyệt) trong `scene.json` (`motion_graph`). Thử thay một tham số và thử đổi text dài/ngắn/dấu để kiểm việc tái sinh không lệ thuộc duy nhất vào ví dụ ban đầu. Điều kiện qua bước là đúng cơ chế, đủ đọc, đúng mốc và giữ phần khóa; xem [scene-contract.md](scene-contract.md).

### Layer graph và curve trước khi viết hàng trăm event

Ghi mỗi output layer thành một node trong `layer_dag` có: nguồn glyph/shape, blend bằng alpha/blur/border, z-order, phase sống và dependency motion/mask. Ghi cạnh “che”, “kế thừa transform”, “dùng chung clock” hoặc “sinh từ” giữa các node. Cách này bắt được các lỗi như glow sống lâu hơn fill, particle lấy pivot khác chữ, mask che nhầm cả foreground hoặc generated layer không còn source.

Với thuộc tính biến đổi, lưu endpoint và hàm tiến triển riêng. Native `\t` có acceleration (`accel` = $\gamma$ với tiến trình $u^\gamma$) nhưng không biểu diễn trực tiếp mọi curve chữ S (`cubic-bezier`) hay `spring` overshoot; dùng `scripts/motion_studio.py fit-curve` hoặc `compile` để xấp xỉ tự động bằng nhiều đoạn transform (`multi-segment \t`) hoặc FBF theo sai số hình và cadence nhìn thấy, rồi kiểm frame ở đoạn nối. Không lấy tên easing như “bounce/back/elastic” làm quyết định thiết kế nếu reference chỉ thể hiện settle không overshoot.

Khi tái dựng từ video mẫu, tách camera/object motion ($\mathcal{T}_{\text{surface}}$) khỏi animation của chữ ($\mathcal{T}_{\text{local}}$) bằng landmark nền (`motion_studio.py probe --track track.json`) hoặc phase chữ đã settle. Nếu không tách được duy nhất, lưu vài giả thuyết và chọn phép thử cho kết quả khác nhau, chẳng hạn track nền giữ chữ cố định so với chữ có motion riêng. Đừng bake cả hai vào một quỹ đạo rồi gọi đó là motion của sign.

## Hai nửa chữ và nhiều layer

Một sign có thể có motion toàn cảnh và motion riêng của mảnh: compose các biến đổi theo thứ tự đã đo. Theo dõi left/right hoặc chữ/box riêng nếu chúng có chuyển động khác, đừng track một bbox chung rồi suy ra cả sign.

Nếu người dùng đã đặt anchor ở frame cuối, preserve hình tại frame đó và tính track ngược từ reference; nếu anchor ở đầu thì giữ đầu. Khi có yêu cầu mới đổi neo, cập nhật placement trên mặt reference rồi truyền qua track; xem phép compose/reanchor ở [perspective-motion.md](perspective-motion.md). Không tự chuyển anchor sang frame giữa cho tiện rồi làm lệch vị trí đã duyệt. Các mảnh/mask phải dùng cùng native PTS và model khi thuộc cùng vật thể.

## FBF không được khởi động lại fade hoặc transform

Tag thời gian trong ASS là tương đối với Start của **event chứa nó**. Khi tách một event thành nhiều event từng frame, copy `\fad`/`\t` nguyên xi có thể làm animation chạy lại mỗi frame. Lưu curve ở clock chung (absolute video PTS) và biên dịch qua `python3 scripts/motion_studio.py compile`: tại event thứ $i$ có khoảng `[Start_i, End_i)`, compiler tự động evaluate giá trị chính xác từ đường cong toàn cục tại PTS thực của frame đó hoặc quy đổi mốc tuyệt đối về offset `T_boundary - Start_i`. Nếu cần time âm/ngoài duration, kiểm chứng engine hoặc bake giá trị thay vì dựa vào giả định clamp.

Ví dụ event gốc fade 850 ms không có nghĩa mỗi event 42 ms cũng fade 850 ms từ đầu. Một cách an toàn là lấy alpha từ curve toàn sign ở PTS thực (do `motion_studio.py compile` tính sẵn), rồi dùng constant/native segment đã kiểm chứng. `\fade` với mốc đã quy đổi có thể phù hợp; không có một chuỗi tag chung đúng cho mọi frame segment. Những tương tác native karaoke theo Start cũng phải kiểm tra như [karaoke-design.md](karaoke-design.md).

Giữ bảng phase độc lập: shake settle, stroke complete, box fill, inversion, blur pulse, exit. Các mốc có thể khác nhau; nét tiếp tục hình thành không tự cho phép rung tiếp sau khi toàn chữ đã đứng yên. Khi sửa “bỏ overshoot của nét”, giữ curve reveal và quãng trượt đã duyệt, chỉ bỏ pha kéo dài/rút lại. Không rebuild toàn effect từ một lời sửa nhỏ.

## Ngoại suy vùng mờ

Đo track trên frame có landmark rõ rồi fit mô hình để ngoại suy frame blur/fade. Phần chưa đo được phải có nhãn và khoảng tin cậy. Nếu khung phim/cạnh cố định vẫn thấy, đo chuyển động nền và quan hệ sign–khung ở đoạn rõ để ràng ngoại suy, thay vì giữ chữ đứng yên ở đoạn fade.

Blur in có thể đồng thời translation theo góc, scale và rotation; một `\t(\blur...)` không tái tạo tất cả. Phân biệt base softness, directional blur (đo qua `edge_spread_x` vs `edge_spread_y` trong `motion_studio.py probe`), core nét và underlay chỉ có lúc blur động. Xem từng frame trước/sau pulse và box fill để tránh underlay dư làm chữ quá mờ/đậm. Ghi model đo được và phần thiết kế, không bịa thêm bounce/ngẫu nhiên khi raw chỉ có trượt ngang/dọc.
