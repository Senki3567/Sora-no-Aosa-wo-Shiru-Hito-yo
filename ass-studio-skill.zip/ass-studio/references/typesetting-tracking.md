# Typeset sign và tracking theo hình thật

Khi agent cần tái dựng phương pháp đo từ đầu hoặc đang lặp sửa số theo cảm giác, đọc [visual-reasoning.md](visual-reasoning.md). Nếu đã có landmark qua frame, [motion-measurement.md](motion-measurement.md) hướng dẫn fit/check transform; [scene-contract.md](scene-contract.md) giữ mapping nguồn để sửa tiếp.

## Từ footage thành thiết kế

Hiểu chức năng sign: bảng trong cảnh, credit, điện thoại, title hay trang trí. Chốt nội dung đọc được và hierarchy; chọn font theo nét/độ rộng/độ nặng/spacing của hình, không chọn chỉ vì cùng phân loại serif/sans. Đặt baseline, neo, chiều rộng và khoảng dòng bằng render của glyph thật. Hộp metric không luôn trùng mép nhìn thấy, nhất là chữ hoa Đ và dấu tiếng Việt.

Đo vị trí sign và camera, vùng che chữ gốc, nền phía sau, occlusion, màu/opacity, outline và blur. Làm mock composite ở frame rõ trước khi thiết kế động. Hiệu ứng xuất hiện nên theo ngôn ngữ đường hình: nét ráp, film cells, zoom, invert hay strip box phải có cơ chế cụ thể; đừng thêm glow/particle/bounce vì thiếu ý tưởng.

## Chọn mô hình tracking vừa đủ

- Translation: landmark chạy đều mà kích thước/góc không đổi; thử pos/move native.
- Similarity: translation + rotation + scale quanh một pivot phù hợp.
- Affine: thêm scale không đều/shear khi có bằng chứng.
- Projective: bảng phẳng có biến dạng phối cảnh; track góc/homography rồi chuyển sang mô hình ASS khả thi hoặc shape FBF có kiểm soát.

Bắt đầu mô hình đơn giản, nâng độ phức tạp khi residual có cấu trúc. ASS 3D rotation không phải bộ homography tùy ý; homography khớp shape không đảm bảo chữ font có cùng hình. Render đúng `fn/fs/an/org/frx/fry/frz/fax/fay/fscx/fscy` trước khi áp cả track.

Chọn landmark ổn định, tránh nét đang mọc, màu đang invert, box đổi dày và vùng occluded. Theo dõi tuyệt đối về frame tham chiếu rõ để tránh tích lũy drift; có thể dùng liên kết frame kề hỗ trợ nhưng ràng lại bằng anchor tuyệt đối. Ghi điểm đo rõ, nội suy, ngoại suy và confidence riêng. Không làm mượt nhịp rung thật chỉ vì muốn curve đẹp; cũng không giữ noise của tracker làm rung phim.

Nếu lấy track từ Blender, đọc [blender-aae-motion.md](blender-aae-motion.md) để kiểm ánh xạ frame 1, Power Pin, đơn vị chuẩn hóa, smoothing và `Trim`/`Relative` khi nhập. Nếu effect có nhiều lớp/mask/fade, xem [sign-fx-recipes.md](sign-fx-recipes.md).

## Một phép đo có thể tái lập

Chọn frame rõ làm template và ROI chứa landmark; lưu tọa độ trong video native, không dùng crop contact sheet làm tọa độ gốc. Với similarity quanh tâm C, mô hình là `x_current = C + s R(theta) (x_reference - C) + d`. Warp template về ROI current, fit s/theta/dx/dy bằng residual cạnh hoặc luminance phù hợp; robust loss như soft_l1 giúp bớt nhiễu. Có thể khởi tạo bằng feature matching/RANSAC rồi refine. Giới hạn tìm kiếm dựa trên chuyển động đã thấy, không dùng bounds tùy ý để ép kết quả.

Fit blur ở phần riêng hoặc cùng mô hình khi có đủ dữ liệu; chuẩn hóa mức sáng/contrast khi grade thay đổi để tránh fitter coi tối màu là glyph dày hơn. Ghi mỗi native frame: PTS, model parameters, residual, landmark/ROI và measured/interpolated/extrapolated. Xem overlay landmark để phát hiện tracker bám nhầm chữ/cạnh nền; loại nhịp không đáng tin trước khi nội suy.

Khi đo glyph, render một dòng bằng đúng style/font/tags ở frame reference. Dùng bbox alpha nhìn thấy ở một ngưỡng nhất quán để fit mép, kiểm tra thêm baseline/dấu và outline. Bbox một glyph rời không đủ đo advance/kerning: dùng cả prefix/string với cùng shaping context. Từ phép đổi đã fit, sinh pos/scale/rotation quanh đúng anchor hoặc chuyển điểm shape; render lại chính glyph để kiểm chứng phép ánh xạ trước khi nhân ra toàn quỹ đạo.

## Render, đo, sửa

Đưa native raw và ASS overlay về đúng hệ tọa độ. So visible glyph, góc, scale, baseline, centroid, góc box và sai số mép qua toàn quỹ đạo. Test ít nhất ở đầu/giữa/cuối, các cực trị và frame hai bên đoạn nối; với một track ngắn phức tạp có thể render mọi frame. MSE thấp có thể chỉ do nhiều pixel nền/alpha trong suốt.

Nếu masking đã khớp mà chữ méo/trôi, giữ masking và fit lại chữ: tìm mô hình/pivot gây khuếch đại, thử bỏ org xa hoặc chuyển 3D sang 2D nếu cảnh cho phép, rồi kiểm chứng cả glyph lẫn trajectory. Không tự xóa perspective của mọi sign.

## Masking và shape

Giữ contour và thứ tự lỗ; kiểm tra winding/render chỗ khoét chữ. Không mặc định hai miếng alpha bán trong cộng lại che kín nền. Adjacent shapes với blur/antialias có thể hở đường nối: xem composite ở độ phóng đại và playback bình thường.

Làm shape từ font khi cần hình khoét/piece effect và glyph đã chốt; retain nguồn glyph/layout. Drawing scale p1/p4, clip scale, anchor, bbox và transform phải thống nhất. Giản lược sau khi so silhouette và render, không dùng “Simplify” như lời hứa giảm dung lượng.

Native transform/move hợp với motion đơn giản; FBF hợp khi hình/occlusion/phối cảnh thay đổi khó mô tả native. Không ép một phương án cho mọi sign. Nếu FBF, dùng PTS thực, resampling có kiểm soát, nhóm hình dùng chung, và benchmark.

## Motion blur, chuyển pha và generator

Fit motion blur theo chiều vệt từ raw, không lấy frame sau làm ghost tùy tiện. Với footage có core rõ và phần mờ thay đổi, có thể dùng core cố định + underlay chỉ khi cần. Đo footprint/offset/opacity của underlay; tránh chồng lớp mờ làm chữ đặc hơn raw.

Mọi thành phần một title dùng chung phase và tracking clock. Khi font đổi sang shape/box rồi quay lại, khớp silhouette/alpha/màu ngay frame nối. Giữ generator đọc một nguồn cố định hoặc biết rõ source đã sinh; không lấy output deployed làm input rồi nhân hiệu ứng thêm lần nữa.

Bàn giao nguồn, generator/config, tracking measurements và bản ASS target; thông số đo phải gắn đúng video/hash. Một bản tốt nhất ở frame đầu chưa phải sign hoàn tất.

Với chữ phải dựng từ raw hoặc dấu Việt chưa hợp bộ chữ, đọc [font-reconstruction.md](font-reconstruction.md). Với split/wipe và chuyển clip thành hình học, đọc [geometry-animation.md](geometry-animation.md). Khi từng frame khớp nhưng phát vẫn lệch, đọc [playback-diagnostics.md](playback-diagnostics.md) trước khi đổi tracking theo phỏng đoán.

Với camera đổi góc/scale, nhiều component cùng mặt, hoặc sign vẫn nổi dù tâm đúng, đọc [perspective-motion.md](perspective-motion.md): chọn landmark theo khả năng ràng buộc, chuyển hệ tọa độ chung, tách geometry/appearance và nghiệm thu quỹ đạo.
