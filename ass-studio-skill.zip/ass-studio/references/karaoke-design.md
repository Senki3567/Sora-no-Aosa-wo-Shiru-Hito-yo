# Karaoke có thiết kế, nhịp và nguồn chỉnh được

## Đọc nguồn và chốt ngôn ngữ hình

Tìm editable source, source comments, generator, config và output hiện hành. Nếu chỉ có rendered ASS, dựng lại nguồn từ các lớp chữ/nhịp bằng đối chiếu; không dùng mọi Dialogue effect như một cue lời riêng. Xác nhận câu, syllable, ngôn ngữ, chính tả, font/layout và timing. Giữ rendered master để so sánh khi thay dịch/font.

Nếu source dùng KFX Templater, đọc [kfx-templater-compatibility.md](kfx-templater-compatibility.md) trước khi sửa marker Effect hoặc chạy macro. Bản gốc, karaOK và The0x539 khác cú pháp; `fx` được sinh có thể bị dọn khi apply. Không chạy trên master nếu còn effect `fx` ngoài phần đang rebuild.

Xem OP thật: motifs, màu, camera, texture, cut và chỗ trống chữ. Đề xuất cơ chế có liên hệ với hình và đủ rõ để triển khai. Một motif filmstrip có thể vừa là cửa sổ hình vừa đưa chữ ra; nó không buộc có lỗ sprocket phức tạp, noise, particle hay glow. Làm đoạn đại diện cả intro và highlight; sửa theo phản hồi trên chính bản mới nhất.

## Hai đồng hồ và deadline từng chữ

Lưu nguồn timing thành các khoảng tuyệt đối `[sung_start_i, sung_end_i)`, text/syllable index và mapping glyph. Nếu người dùng đã time nhạc chuẩn, giữ toàn bộ các mốc này; không dời highlight để cứu intro, không bỏ syllable ngắn hay nhấn cuối câu. Duration `\k` thường tính bằng centisecond; `\kt` cần xét hỗ trợ của target.

Intro/outro là visibility clock riêng. Với glyph hoặc syllable i, cần `settled_i <= sung_start_i` nếu thiết kế yêu cầu chữ ổn định khi hát. Không mặc định `settled_last <= sung_start_first`: các chữ đầu ổn định có thể hát trong lúc chữ sau còn vào. Deadline cục bộ thường tạo chuyển động thong thả hơn một trigger chung cho cả dòng.

Nếu cue không đủ thời gian: xét gap, cut và yêu cầu người dùng trước khi mở rộng visibility window. Có thể rút intro vừa đủ, bắt đầu intro trước cue, cho out câu trước chồng in câu sau, hoặc bỏ intro cho dòng đầu ở cut; lựa chọn tùy brief. Không tự dịch đồng hồ hát. Chỉ hỏi khi lựa chọn thực sự còn xung đột chưa được người dùng giải quyết.

Một event karaoke native kéo Start sớm sẽ dịch cả nhịp tích lũy nếu không bù. Tách intro/base khỏi event nhấn dùng clock nguồn, hoặc tính bù rõ trong generator và chứng minh lại mọi khoảng. Đừng chỉ so tổng duration rồi bỏ lỡ mốc bên trong.

## Layout glyph và các lớp

Giữ grapheme cluster, dấu Việt, khoảng trắng và punctuation; chia codepoint đơn giản có thể tách dấu khỏi chữ. Dùng shaping/render của font thật, cả prefix và context kerning, để lấy vị trí glyph/syllable. Không cộng bounding box từng chữ rời rồi cho rằng bằng layout cả dòng. Giữ source Text nguyên bản; việc chuẩn hóa Unicode để đo không được âm thầm đổi câu đã duyệt.

Mỗi thành phần nên có vai trò rõ: base chưa hát, active highlight, film cửa sổ/shape, outro. Nếu chữ khởi đầu trong một ô film, xác định transform từ vị trí ô/cửa sổ đến vị trí chuẩn và tiến trình từng chữ; xem frame nơi nó rời ô, scale/position settle và giao với lớp đang hát. Một clip ngang cả dòng không tự tái hiện cơ chế này.

## Outro và continuous lines

Outro phải áp nhất quán lên base, active highlight và các bản sao của cùng glyph. Không để base tan hết mà layer đang hát vẫn hiện. Tính hạn biến mất theo `sung_end_i`, visibility window và alpha của mọi lớp; giữ nhấn đầy đủ tới mốc được yêu cầu. Không sinh highlight mới sau khi toàn glyph đã invisible.

Nếu brief yêu cầu đơn giản, fade alpha native từng grapheme thường đủ; ví dụ `\t(1200,1600,\alpha&HFF&)` dùng thời gian tương đối của đúng event. Giữ alpha ban đầu/từng kênh của thiết kế, không chèn global alpha làm mất khác biệt lớp.

Với câu nối sát, dùng một timeline phase/chuyển động chung để lead-in sau và lead-out trước chạy đều. Kiểm tra thật các đoạn giao, stack và readability; không xử lý mỗi câu độc lập rồi ráp mà chưa xem điểm nối.

## Palette, rung và deterministic generation

Palette theo grade đã đo có thể gồm trạng thái tự nhiên/lạnh, cut đổi tức thời và curve hồi màu; chuyển absolute video time sang relative `\t` riêng cho mỗi event. Giữ thứ tự ưu tiên màu palette và accent karaoke. Cảnh mới hoặc grade đã kết thúc không tự lặp nhịp màu cũ.

Nếu dùng rung phim, chọn cadence/biên độ theo footage và kích thước hiển thị, áp ở lớp cần nhấn. Pivot gần glyph hạn chế roll biến thành lệch vị trí lớn. Dùng seed và clock nhất quán; về vị trí chuẩn khi chuyển sang lớp đứng yên nếu cần. Không chia mọi base/shape thành FBF chỉ để rung một âm tiết.

## Kiểm chứng

Đối chiếu toàn bộ clock manifest, đầy đủ syllable và glyph, không gap/overlap nhấn sai. Render đầu/giữa/cuối mỗi khoảng nhấn quan trọng, nốt ngắn/dài, first cut, outro và giao hai câu. So source comments/font/layout và phần effect ngoài phạm vi. Đánh giá ở playback bình thường; crop phóng lớn chỉ hỗ trợ.

Giữ source ASS + generator + config, và output render tách rõ. Generator phải tái tạo được từ frozen input, không tự ghi đè các tập. Đo hiệu suất theo [render-performance.md](render-performance.md), rồi mới triển khai hàng loạt.

Đổi lời/font/alignment trên rendered master cần thêm kiểm chứng layout và source roundtrip; xem [lyrics-layout-retargeting.md](lyrics-layout-retargeting.md). Border/blur của mỗi char phải ở dưới fill các char liên quan khi thiết kế cần, không để viền char kế che ruột char trước. Palette quay vòng/phase xuyên dòng xem [color-palette-validation.md](color-palette-validation.md).
