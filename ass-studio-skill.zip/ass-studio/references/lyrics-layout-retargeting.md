# Lời nhạc, layout và retarget karaoke editable

Đọc khi đổi lời dịch/font/alignment trên effect đã có, khôi phục template, hoặc biên dịch lời nhạc trong format ASS cố định. Các clock/phases xem [karaoke-design.md](karaoke-design.md).

## Dịch lời và hợp đồng định dạng

Lời nhạc có hình ảnh/ý kéo qua nhiều cue. Đọc trọn mạch và nguồn đúng ngôn ngữ; giữ hình tượng, chủ thể, phủ định, quan hệ mệnh đề và ambiguity có chủ đích. Bản Việt tự nhiên không có nghĩa được tự thêm diễn giải cho tròn ý. Cách ngắt EN không quyết định cú pháp JP. Nếu chỉ biên dịch lời Việt, giữ timing romaji và `\k`, style, Actor/Effect và tham chiếu ẩn theo yêu cầu.

Nếu người dùng đưa 25 event và yêu cầu trả đúng 25 event, output phải giữ thứ tự/kind/fields và chỉ thay run Việt được giao. Không chuyển thành bài thơ/Markdown hay gộp hai dòng lyric chỉ vì câu Việt nhìn đẹp hơn. Cue cùng time hai bản dịch hoặc upper/lower cluster có thể có chủ đích; bỏ một cụm chỉ khi yêu cầu.

## Khôi phục source từ rendered master

Inventory base/highlight/border/particle/clip events theo cue, syllable và cùng glyph; không dùng mọi fx Dialogue như nguồn text riêng. Ghi source text, durations, style/alignment, offsets và mapping các lớp. Nếu không có template, giữ master nguyên vẹn làm ground truth và generator có nhánh unchanged-source roundtrip; byte-identical roundtrip hữu ích cho tái tạo, nhưng chưa chứng minh đổi text/font sẽ đúng.

Khi đổi số glyph, không map theo index ratio rồi bỏ dấu/cụm âm tiết. Ánh xạ timing, layout và particle attachment riêng; phân biệt geometry đo được với chuyển vị motif từ master. Đổi font ảnh hưởng ascender/descender, kerning/space, word width, baseline và clip; phải render lại cả câu và effect, không chỉ `fc-match` thành công.

## Spacing và viền là hai lỗi độc lập

Đo chữ liền bằng đúng font/style/render engine, gồm **mọi dấu cách**, rồi lấy advance/glyph position trong context. Bbox glyph rời không là advance; cộng width riêng hoặc crop bỏ space làm kara sát nhau. Prefix measurement cũng cần bảo đảm context shaping tương thích, nhất là ligature; chỉ đo chữ rời để đặt char không đủ.

Ưu tiên giữ một chuỗi shaped liên tục nếu effect chỉ cần đổi màu theo âm tiết. Khi cần event char/syllable riêng, giữ layout tham chiếu và chứng minh mép glyph/word gap bằng overlay của cả câu. Clip nên phục vụ reveal/wipe thực; không dùng clip để che sai spacing.

Outline/blur gắn với mỗi char có thể đè lên ruột chữ kề nếu layer/stacking sai. Tách border/blur xuống lớp dưới và fill lên trên khi thiết kế cần; base/highlight/fade của hai lớp vẫn cùng clock. Không xếp fill của char A rồi border của char B lên trên chỉ vì thứ tự event tăng. Xem giao nét/word space trong highlight và fade, không chỉ bbox toàn dòng.

## Layout variants và source đổi sau khi duyệt

Căn phải toàn bộ không chỉ đổi Alignment style. Tính origin toàn câu/line và margin target; dịch glyph, clips và particle anchors theo cùng phép. Event MarginL/R khác 0 có thể ghi đè style; kiểm tra cả hai. Giữ bản trái/giữa khi yêu cầu một output phải riêng.

Case OP 24 dòng: bản căn phải margin 45 từng được render glyph và particle; bản OP08 bỏ upper cluster và particle riêng. Những con số/font này là lựa chọn case, không chuẩn chung. Với yêu cầu một dòng, giữ đúng một dòng thay vì split để cứu width; điều chỉnh font/scale hoặc wording chỉ trong phạm vi cho phép.

Test generator bằng một bản source tạm có đổi font/câu dài/ngắn/dấu/khoảng trắng, ngoài roundtrip source nguyên. Xem bản render thực trên video ở font target; nền đen/alpha chart chỉ là diagnostic. Helper/source/path cũ còn hay không phải kiểm tra lại, không dựa tên “final”.
