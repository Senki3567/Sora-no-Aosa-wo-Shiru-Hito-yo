# Kiến trúc Vận hành Agent Motion & Dịch ngược Video (Agent Operating Architecture)

Đọc khi thực hiện typesetting sign phức tạp, dựng hiệu ứng KFX/karaoke từ mẫu, hoặc tái tạo chuyển động/biến dạng chữ trực tiếp từ raw video. Tài liệu này quy định **cách tổ chức luồng suy nghĩ, phân vai nội tâm, dịch ngược tham số (Reverse Engineering), biểu diễn chuyển động khai báo (Declarative Motion IR), quản lý trạng thái nhiều vòng (Multi-Turn State) và vòng lặp tự kiểm định (Perception-Reflection Loop)**.

Công cụ và công thức ở [visual-reasoning.md](visual-reasoning.md), [perspective-motion.md](perspective-motion.md), [geometry-animation.md](geometry-animation.md) và [scene-contract.md](scene-contract.md) được điều phối thống nhất bởi kiến trúc này.

## 1. Phân vai Nội tâm Đa nhân cách (4-Role Cognitive Loop)

Một VLM/LLM không thể nhìn một ảnh raw 1920×1080 rồi viết chính xác hàng trăm dòng tag ASS trong một lượt (one-shot). Để tránh vừa nhìn hình vừa đoán mò tham số, Agent phải tách chu kỳ làm việc thành **4 vai trò độc lập** nối tiếp nhau trong vòng lặp phân tích – tổng hợp (`probe → model → compile → render → critique → revise`):

| Vai trò (Role) | Trách nhiệm cốt lõi | Đầu vào | Đầu ra bắt buộc | Điều cấm tuyệt đối |
|---|---|---|---|---|
| **1. Decomposer / Reverse-Engineer** (Kỹ sư Dịch ngược) | Quan sát raw video, tách pha thời gian, tách lớp không gian, đo tín hiệu định lượng (quỹ đạo, cadence, đường cong vận tốc, màu/alpha/blur) | Raw video, `frames.json`, crop ROI, `motion_studio.py probe` | **Reverse-Engineered Motion Spec** (các mốc pha, cadence, bảng đo, mô hình đường cong đã fit) | Cấm viết thẳng chuỗi tag ASS hoặc đoán tên easing ("bounce", "elastic") khi chưa đo dữ liệu |
| **2. Motion Architect** (Kiến trúc sư Biểu diễn — Tư duy Remotion) | Chuyển Motion Spec thành đồ thị chuyển động khai báo (Declarative Motion IR) và chọn cơ chế biên dịch sang ASS | Motion Spec, `scene.json`, dữ liệu lời/font tiếng Việt | Cập nhật `motion_graph` trong `scene.json` hoặc cấu hình cho `motion_studio.py compile` / generator | Cấm sửa trực tiếp trên hàng trăm dòng FBF đã xuất hoặc trộn đồng hồ hát với đồng hồ intro |
| **3. Executor / Compiler** (Bộ thực thi & Render) | Biên dịch IR ra ASS candidate, chạy libass render tại đúng các frame chốt và ghép bảng đối chiếu | `scene.json` / generator, `libass_render.py`, `visual_evidence.py` | `candidate.ass`, ảnh composite sheet, crop native 1:1 và diff RGBA | Cấm kết luận "đã khớp" chỉ vì script trả `exit 0` hoặc file ASS hợp lệ cú pháp |
| **4. Perceptual Critic / Verifier** (Giám khảo Thị giác Đối kháng) | Đọc ảnh composite + crop native, chấm 5 trục độc lập, chỉ ra **Dominant Discrepancy** (lỗi lớn nhất) và quyết định tiến/lùi | Ảnh `sheet.png`, crop native, `scene.json`, lịch sử vòng trước | `critic_verdict` trên 5 trục, cập nhật `iteration_history` và `falsified_hypotheses` | Cấm duyệt qua loa từ thumbnail nhỏ hoặc cho phép sửa nhiều trục cùng lúc làm mất dấu nguyên nhân |

## 2. Quy trình 4 Bước Dịch ngược Chuyển động từ Raw Video (Video Reverse Engineering)

Khi người dùng giao một đoạn video có chữ gốc chuyển động/biến dạng (hoặc một mẫu hiệu ứng) và yêu cầu thay bằng chữ dịch khớp hoàn toàn:

### Bước RE-1 — Khảo sát Thời gian, Cadence & Tách Pha (Temporal & Cadence Discovery)
1. **Lấy mẫu thưa rồi tìm biên bằng chia đôi (Coarse-to-Fine Phase Seeking)**:
   - Dùng `video_frames.py --range <start> <end> --step <k>` tạo contact sheet thưa để nhận diện toàn bộ vòng đời của đối tượng.
   - Tại mỗi điểm nghi ngờ có sự kiện (bắt đầu hiện, đổi hướng, dừng lại, chớp sáng, bắt đầu mờ, biến mất, hoặc scene cut), lấy các frame liền kề để khóa chính xác `frame_index_0based` và `pts_ms` thực.
2. **Đo Cadence hoạt họa thực tế**:
   - Chạy `python3 scripts/motion_studio.py probe <frames.json> --roi x0 y0 x1 y1 --output work/probe.json` để đo độ biến thiên giữa các frame liên tiếp (`frame_l1_diff`).
   - Phân biệt: camera pan mượt ở **1s (24fps)**, hoạt họa giữ frame **2s (12fps)** / **3s (8fps)**, hay nền đi 1s còn chữ vẽ tay nhảy 2s. Nếu gốc giữ frame 2s/3s mà ASS nội suy 1s thì chữ sẽ trượt khỏi nét vẽ gốc ở các frame giữ.
3. **Lập bảng Pha (Phase Table)**:
   - Chia timeline thành các pha rời rạc không chồng lấn: ví dụ `entry_slide` $\rightarrow$ `overshoot_settle` $\rightarrow$ `steady_hold` $\rightarrow$ `highlight_pulse` $\rightarrow$ `exit_fade`. Mỗi pha có `[start_frame, end_frame]`, `[start_pts_ms, end_pts_ms)` và danh sách thuộc tính biến đổi.

### Bước RE-2 — Tách Quỹ đạo Bề mặt khỏi Animation Nội tại (Motion Decoupling)
Một chữ trên màn hình có vị trí biến đổi do **hai nguồn độc lập**: chuyển động của mặt phẳng chứa chữ trong cảnh ($\mathcal{T}_{\text{surface}}$) và hiệu ứng động của bản thân chữ trên mặt phẳng đó ($\mathcal{T}_{\text{local}}$):
$$\mathbf{q}_{\text{screen}}(t) = \mathcal{T}_{\text{surface}}(t) \circ \mathcal{T}_{\text{local}}(t) \circ \mathbf{x}_{\text{ref}}$$

1. **Khóa $\mathcal{T}_{\text{surface}}(t)$ trước**:
   - Đo các landmark thuộc về **vật thể/bề mặt nền** (4 góc bảng, khung cửa, mép giấy, hoa văn tường — tuyệt đối không lấy nét chữ đang mọc hoặc đang trượt) và fit bằng `scripts/motion_fit.py` (`translation`, `similarity`, `affine`, hoặc `homography`).
2. **Khử trôi nền để lộ $\mathcal{T}_{\text{local}}(t)$**:
   - Truyền `--track work/track.json` vào `scripts/motion_studio.py probe` để đưa mọi frame về hệ quy chiếu phẳng của `reference_frame`.
   - Quan sát trên hệ quy chiếu đã khử trôi nền: nếu chữ đứng yên thì $\mathcal{T}_{\text{local}} = I$ (chỉ cần tracking bề mặt); nếu chữ vẫn phóng to, trượt vào, rung hoặc mọc nét thì đo riêng $\mathcal{T}_{\text{local}}(t)$ trong không gian reference này.

### Bước RE-3 — Khôi phục Đường cong Tham số, Easing & Quang học (Inverse Parameter & Curve Fitting)
Trên từng pha $[t_0, t_1]$, chuẩn hóa thời gian $u = \frac{t - t_0}{t_1 - t_0} \in [0, 1]$ và chuẩn hóa giá trị thuộc tính $v(u) = \frac{\theta(t) - \theta(t_0)}{\theta(t_1) - \theta(t_0)}$:

1. **Nhận diện Họ Đường cong (Curve Family Identification)** bằng `python3 scripts/motion_studio.py fit-curve`:
   - **Tuyến tính (`linear`)**: $v(u) = u$, vận tốc không đổi $\rightarrow$ ánh xạ sang `\move(x0,y0,x1,y1,t0,t1)` hoặc `\t(t0,t1,\tag)`.
   - **Lũy thừa đơn điệu (`power` / ASS `accel`)**: $v(u) = u^\gamma$ ($\gamma > 1$: vào chậm ra nhanh / ease-in; $0 < \gamma < 1$: vào nhanh ra chậm / ease-out) $\rightarrow$ ánh xạ trực tiếp sang tham số `accel` = $\gamma$ của `\t(t0, t1, accel, \tag)`.
   - **Đường cong chữ S (`cubic-bezier` ease-in-out)**: Vận tốc bằng 0 ở cả hai đầu, cực đại ở giữa. Một tag `\t` đơn lẻ của ASS chỉ có `accel` đơn điệu nên **không thể** biểu diễn chính xác S-curve $\rightarrow$ tách tại điểm uốn $u^*$ thành 2–4 đoạn `\t` nối tiếp (piecewise power approximation) hoặc bake FBF nếu kết hợp với `\pos` phi tuyến.
   - **Vượt đích / Đàn hồi tắt dần (`spring` / `overshoot`)**: $v(u)$ vượt quá $1.0$ tại đỉnh $u_{\text{peak}}$ rồi hồi về $1.0$ $\rightarrow$ tách pha tại các cực trị đạo hàm ($v'(u) = 0$) thành các đoạn `\t` riêng biệt (ví dụ: đoạn 1 từ $0 \to 1.12$ với `accel` $< 1$, đoạn 2 từ $1.12 \to 1.0$ với `accel` $> 1$), hoặc xuất FBF theo cadence.
   - **Bậc thang giữ nhịp (`step` / `hold`)**: Giá trị giữ nguyên trong $k$ frame rồi nhảy bậc $\rightarrow$ xuất chuỗi event rời rạc theo đúng biên frame giữ.
2. **Dịch ngược Thuộc tính Quang học (Inverse Photometrics)**:
   - **Màu & Độ đục (`c`, `alpha`)**: Lấy mẫu vùng lõi đặc (opaque core) để xác định màu foreground $F$; lấy mẫu nền $B$ ngay sát cạnh; giải phương trình blend $C(t) = \alpha(t) F + (1 - \alpha(t)) B$ trên dải frame fade để tìm đường cong $\alpha(t)$ thực tế (phân biệt fade tuyến tính của `\fad` với fade phi tuyến hoặc đổi màu theo grade).
   - **Độ mờ & Vệt chuyển động (`blur`, `fscx/fscy`, `underlay`)**: Đo độ rộng vùng chuyển tiếp cạnh (`edge_spread_px` trong `probe`). Nếu độ rộng cạnh tăng đều mọi hướng khi camera out-of-focus $\rightarrow$ tăng `\blur`. Nếu cạnh chỉ nhòe dọc theo vector vận tốc $(\Delta x, \Delta y)$ trong khi cạnh vuông góc vẫn sắc $\rightarrow$ đó là **directional motion blur**, cần biểu diễn bằng lớp underlay dịch theo vector vận tốc hoặc scale bất đối xứng theo trục chuyển động, không tăng `\blur` đẳng hướng làm bệt chữ.

### Bước RE-4 — Chuyển vị sang Chữ Dịch & Biên dịch ASS (Retargeting & Compilation)
1. **Bảo toàn Neo Ngữ nghĩa trên Mặt phẳng Tham chiếu (Reference-Plane Semantic Anchoring)**:
   - Chữ tiếng Việt thường khác độ dài và tỷ lệ ascender/descender (nhờ dấu thanh + dấu mũ) so với chữ Nhật/Anh gốc.
   - Đặt chữ Việt trên mặt phẳng `reference_frame`, đo **hộp mực thực tế (rendered ink bounding box)** qua `libass_render.py` (không dùng font metric lí thuyết).
   - Căn tâm mực (ink center) hoặc mép neo thiết kế (alignment edge) trùng với tâm/mép của chữ gốc trên mặt phẳng tham chiếu, sau đó mới áp phép chiếu $\mathcal{T}_{\text{surface}}(t) \circ \mathcal{T}_{\text{local}}(t)$.
2. **Biên dịch bằng Declarative Motion Compiler (`motion_studio.py compile`)**:
   - Không tính nhẩm từng dòng FBF hoặc copy-paste `\t`/`\fad` thủ công. Đưa đặc tả vào compiler để tự động quy đổi từ **Global Video PTS Clock** sang **Event-Relative Clock** ($t_{\text{rel}} = t_{\text{abs}} - \text{Start}_i$).
   - Khi xuất FBF, mọi đường cong `alpha`, `blur`, `color`, `scale`, `rotation` đều được **evaluate tại đúng PTS của frame thứ $i$**, tuyệt đối ngăn chặn lỗi kinh điển "mỗi event FBF 42ms lại khởi động lại `\fad(850,0)` hoặc `\t` từ đầu".

## 3. Ngôn ngữ Biểu diễn Chuyển động Khai báo (Declarative Motion IR — Tư duy Remotion cho ASS)

Lấy cảm hứng từ kiến trúc hàm theo frame của Remotion (`useCurrentFrame()`, `interpolate()`, `spring()`) và đồ thị cảnh của After Effects, mọi hiệu ứng phức tạp trong `ass-studio` đều được mô hình hóa thành 4 khối khai báo trước khi sinh dòng ASS:

1. **`clocks` (Hệ đồng hồ kép)**:
   - `timeline_clock`: Gắn với `pts_ms` của video và các mốc chuyển pha của camera/vật thể.
   - `content_clock`: Gắn với các mốc âm tiết/lyric tuyệt đối `[sung_start_i, sung_end_i)` hoặc mốc thoại đã duyệt.
   - Ràng buộc bất biến: Thay đổi `intro`/`outro` trên `timeline_clock` chỉ điều chỉnh đường cong tiến vào/ra, không bao giờ được phép dịch chuyển `content_clock`. Với mỗi âm tiết $i$, thời điểm kết thúc pha vào phải thỏa mãn $t_{\text{settled}, i} \le \text{sung\_start}_i$.
2. **`layer_dag` (Đồ thị Phân lớp Có hướng)**:
   - Mỗi lớp là một node tường minh: `mask_bg` (Layer $L_0$) $\rightarrow$ `ambient_glow` ($L_1$) $\rightarrow$ `border_stroke` ($L_2$, tách riêng để viền ký tự sau không đè lên ruột ký tự trước) $\rightarrow$ `base_fill` ($L_3$) $\rightarrow$ `active_highlight` ($L_4$) $\rightarrow$ `foreground_occluder_clip` (cạnh phụ thuộc cắt qua các lớp dưới).
3. **`tracks` & `curves` (Các bộ điều biến tham số)**:
   - Mọi thuộc tính động được định nghĩa bằng:
     ```json
     {
       "property": "fscx",
       "clock": "timeline",
       "keyframes": [
         {"time_ms": 1000, "value": 140.0},
         {"time_ms": 1250, "value": 96.0, "easing": {"type": "power", "gamma": 0.45}},
         {"time_ms": 1380, "value": 100.0, "easing": {"type": "power", "gamma": 1.8}}
       ]
     }
     ```
4. **`compilation_policy` (Chiến lược Xuất ASS)**:
   - `native_tags`: Ưu tiên khi mặt phẳng biến đổi nhẹ (translation/similarity) và các đường cong thuộc tính đều hỗ trợ trong `\t` (scale, rotation, alpha, blur, color, clip chữ nhật) với số đoạn chia nhỏ vừa phải.
   - `hybrid_multi_segment`: Tách một event dài thành $K$ đoạn thời gian tại các điểm uốn hoặc dùng chuỗi `\t(t1,t2,accel,...)` nối tiếp trên cùng một event.
   - `baked_fbf`: Tự động kích hoạt khi có homography phối cảnh mạnh, `\pos` đi theo đường cong phi tuyến (vì ASS `\move` chỉ đi đường thẳng và `\pos` không animate được trong `\t`), hoặc vector `\clip`/`\p1` biến hình theo frame.

## 4. Giao thức Hội tụ Phân cấp & Giám khảo Thị giác 5 Trục (Convergence & Critic Protocol)

Để chống hiện tượng Agent sửa vòng quanh (vòng sau làm hỏng vòng trước, hoặc dùng blur/viền to để che lỗi lệch vị trí), vòng lặp tinh chỉnh phải tuân thủ hai quy tắc sắt:

### Quy tắc 1: Hạ bậc Tọa độ Phân cấp (Hierarchical Coordinate Descent)
Chỉ được phép mở khóa và tinh chỉnh tầng $k+1$ sau khi tầng $k$ đã đạt trạng thái `accepted`:
- **Tầng 1 — Temporal & Phase Boundaries**: Frame bắt đầu, kết thúc, cut, cadence và các mốc chuyển pha.
- **Tầng 2 — Surface Geometry & Reference Anchor**: Vị trí neo, tỷ lệ, góc xoay, phối cảnh của mặt phẳng chứa chữ (`track.json` + reference placement).
- **Tầng 3 — Glyph Layout, Typography & Masking**: Font chữ Việt, dấu thanh/mũ, khoảng cách chữ/dòng, vùng mask che chữ gốc và clip vật cản.
- **Tầng 4 — Local Animation & Easing Curves**: Biên độ trượt, độ nảy/settle, nhịp highlight karaoke, hiệu ứng mọc nét.
- **Tầng 5 — Photometric Blend & Render Budget**: Màu sắc theo grade, độ đục `\alpha`, độ mờ `\blur`/glow, và tối ưu hóa diện tích bitmap/cache.

**Luật cấm bù chéo tầng**: Không bao giờ sửa tham số ở Tầng 5 (`\blur`, `\bord`, `\alpha`) để che giấu sai số còn tồn tại ở Tầng 2 (trượt track) hoặc Tầng 3 (lộ chữ gốc do mask hẹp).

### Quy tắc 2: Bảng chấm 5 Trục của Perceptual Critic & Chống Lặp Lỗi
Sau mỗi lần render candidate, Agent chuyển sang vai **Perceptual Critic**, mở ảnh `sheet.png` và crop native 1:1 để điền đánh giá vào `scene.json`:
1. `spatial_alignment`: Độ khớp tâm, 4 góc, baseline và độ hội tụ phối cảnh qua đầu/giữa/cuối/cực trị.
2. `temporal_easing`: Độ khớp frame biên, cadence và cảm giác gia tốc/settle ở các điểm chuyển pha.
3. `mask_occlusion`: Không lộ chữ gốc trong suốt quá trình fade; không hở khe antialias giữa các mảnh shape; không đè lên vật thể tiền cảnh.
4. `photometric_blend`: Độ hòa màu, contrast, độ mềm cạnh so với chi tiết cùng mặt phẳng/điều kiện quang học trên raw.
5. `vietnamese_typography`: Dấu tiếng Việt rõ nét, không fallback font, không dính nét hoặc bị viền ký tự kế bên lấn vào ruột.

Nếu một giả thuyết sửa đổi không làm giảm lỗi mục tiêu hoặc gây suy thoái (regression) ở trục đã `accepted`:
- **Rollback ngay lập tức** về snapshot `accepted` gần nhất.
- Ghi giả thuyết vừa thử kèm lý do thất bại vào mảng `falsified_hypotheses` trong `scene.json` để các lượt tiếp theo (hoặc subagent tiếp quản) tuyệt đối không lặp lại.
