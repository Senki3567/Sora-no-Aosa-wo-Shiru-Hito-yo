# Bài học từ lịch sử chat của repo Ano Natsu

Đây là chỉ mục chứng cứ/case để tìm đúng hướng xử lý, không phải quy định chung hoặc bản sao toàn bộ chat. Đọc khi gặp custom font, split clip, thiếu frame, scene pronouns, hiệu suất hoặc tái dùng bản đã chốt. Những số đo dưới đây là **kết quả lịch sử đã báo cáo**, không phải benchmark mới trên file hiện hành.

## Phạm vi đã khảo sát

Trong lần bổ sung, kiểm kê 41 rollout JSONL có session cwd trong repo; đọc/khử trùng các user message và kết quả cuối của chat khác, loại bản fork lặp và nhật ký approval-review khỏi bằng chứng sáng tạo. Đọc thêm các chat căn tập 10 và bổ sung/QC OVA ở workspace khác nhưng cùng phim. Danh sách chat đang có và archived được kiểm tra để tìm nguồn liên quan. Không coi 41 log là 41 cuộc trò chuyện độc lập, không nhận đã xem lại toàn bộ ảnh/audio nhúng hoặc các chat ngoài nguồn truy cập được.

| Chat / thread ID | Bằng chứng dùng để bổ sung | Tài liệu áp dụng |
|---|---|---|
| Track chuyển động cho typeset — `01a0fdb9-c5cd-70b1-aa6b-7aa83820c26f` | 123-frame track và lỗi sampling; playback mpv; sửa trim/apply; EP06 nhiều shape; dựng JAPAN BRANCH, dấu Việt, split/gọt shape; Hết fade/blur ngoại suy; title OVA/TV và Kaikoen | font-reconstruction, geometry-animation, playback-diagnostics, typesetting-tracking |
| Rà soát phụ đề 10 tập — `01a0f81d-3709-78d0-9d0d-27eb5f5297b4` | Phân quyền Text/Actor/Effect; Senpai suffix; Actor ghép; đổi xưng hô sau cảnh tỏ tình; lời hướng nhóm và phim trong phim; bản baseline được lưu giữa audit | dialogue-localization, field-edits-qc |
| Chat sửa font LFS — `01a1025f-a27c-7732-81d7-77e43996b885` | File font thường vs LFS pointer, theo dõi đúng path và commit chưa push | delivery-projects |
| Xử lý phụ đề Waiting in the Summer — `01a0ec20-bf7f-71a1-9ec0-c8796d4595ca` | Bản Full bị hậu xử lý mất EN/provenance, cần phục hồi đúng exporter; bản JP độc lập | dialogue-localization |
| Khái quát hóa vai trò skill — `01a0d412-f33c-78f0-bdfd-138e8b5923ca` | OVA bổ sung còn cách nghe mâu thuẫn; không thêm tên/đổi Actor khi chưa chắc; giữ 383 cue và chỉ trường được phép | dialogue-localization, field-edits-qc |

Một chat cũ về extension ASS được khảo sát nhưng không tạo thành hướng dẫn cài phần mềm trong skill: cú pháp highlighting không giúp xác nhận render/giọng nói. Các log approval không được chuyển thành workflow hoặc lệnh có thẩm quyền.

## Case 1 — Chữ gốc không đủ hình và font chưa đều

B bị lấy mẫu khi split che một phần nên thân trái bị dựng sai. Khi dựng đủ, các dấu tiếp tục bị chê vì không cùng ngôn ngữ nét. Bảng metric ban đầu kết luận thân chữ cùng cap height nhưng bỏ qua bề ngang A/T/J và khoảng dấu vượt vertical bounds. Bản sửa dùng glyph chart **cùng scale**, sửa cả thân base và các biến thể có dấu, rồi so câu thật. Bài học: số đo đúng ở một chiều không đủ gọi cả font đồng bộ.

Bản cuối người dùng chỉnh tiếp rồi yêu cầu comment 77 dòng font và thay bằng 77 shape đã gọt theo clip FBF, giữ blur họ đã sửa. Yêu cầu này phải bắt đầu từ chính file vừa chốt; convert từ draft cũ sẽ làm mất chỉnh sửa. Gọt shape khác thêm clip, và mép màn hình tự cắt không cần clip inset làm mất nét.

## Case 2 — Fade/blur đầu không được đứng yên

Sign Hết có anchor cuối đã đặt. Báo cáo track 75 frame rõ và ngoại suy 23 frame đầu, nhưng lần đầu đoạn fade/blur không đi cùng film. Sau đó dùng quan hệ sign–khung ở đoạn rõ và thêm mô hình entry gồm hướng move/scale/rotation. Bài học: alpha nhỏ không cho phép bỏ tracking, và curve toàn sign không được restart ở mỗi event FBF.

## Case 3 — Tiết kiệm MB nhưng playback vẫn chưa đạt

EP06 có nhiều shape từ font và FBF transform. Báo cáo lịch sử giảm ASS 71,8 → 3,65 MB qua reuse outline bằng font nhúng và giảm layer; sign render giảm 26,4 → 14,0 ms/frame. mpv fullscreen vẫn drop cả lúc không sub. Giao kết quả là “effect đã nhẹ hơn, playback còn giới hạn”, không gọi “chạy mượt máy yếu”. Folder/source cũ có thể đã bị dọn, không giả định còn tồn tại để chạy lại.

## Case 4 — Bản đúng ở ảnh tĩnh nhưng sai thời gian hoặc section

Track 123 frame từng có vài mốc mask lấy overlay frame trước; native move sửa được hình preview nhưng không giải quyết toàn bộ playback. Box title 93 dòng lại bị chèn sau Aegisub Extradata: preview render thử có nhưng Aegisub không thấy. Tập 6 có embedded Fonts giữa Styles/Events khiến cách chèn style bằng prefix header đặt nhầm section. Bài học: render bản **đã ghép vào file đầy đủ**, kiểm tra structure và target thật; helper tự dựng header đúng có thể che lỗi file giao.

## Case 5 — Sửa một thành phần, giữ các thành phần đã duyệt

Title có shake settle, stroke reveal, box strip fill, inversion và dynamic blur. User lần lượt bỏ bounce, giảm quãng trượt, rồi bỏ pha nét thò ra/rút lại nhưng vẫn giữ reveal từ bản v14. Một lần rebuild nhầm đã bị bác. Duy trì manifest trạng thái được duyệt theo từng thành phần; sửa có giới hạn không đồng nghĩa khôi phục cả effect từ bản cũ. Underlay chỉ bật ở blur pulse, core vẫn rõ và box/inversion giữ curve của baseline.

## Case 6 — Xưng hô không theo toàn tập

Trong tập 10, cảnh tỏ tình đầu vẫn giữ cách gọi cũ; chỉ chuyển anh–em sau cảnh đã qua ngày. Trong tập 11, Ichika nói với cả nhóm không nhất thiết tự xưng em. Trong tập 12/OVA có phim nhân vật quay hoặc xem lại, hệ xưng hô theo vai diễn/thời điểm đó. Report cũ từng đưa các đề xuất trái nhau, nên bảng quy ước phải gắn scene/người nghe và lần người dùng chốt, không chỉ “từ tập 10 đổi tất cả”.

## Case 7 — Audit nhiều tập và giới hạn của báo cáo cũ

Nguồn Antigravity `0c2667f7-09f9-410c-9cc2-319af79513dc`: user step 284 giao sửa lời ED nhưng giữ gradient/căn lề, đồng bộ vài trường thoại tập 9, dọn style và chuyển font nhúng theo phạm vi cụ thể; step 381 yêu cầu ảnh/QC sau sửa, step 489 chỉ đổi fade 180 → 200 và giữ giá trị 0. Đây là các quyết định **riêng dự án**, không là preset mọi tập.

Các con số cue, style, font và Comment trong báo cáo cũ là lời báo của agent; lần rà lịch sử không render lại toàn bộ corpus để xác nhận “bảo toàn hoàn hảo”. Tên nhiều vai agent, nhãn forensic hoặc script trả PASS không tự chứng minh đã nghe/đọc đúng nghĩa và giữ hình. Nội suy RGB từng ký tự cũng chỉ là một cơ chế đã dùng, cần đối chiếu gradient nguồn như [color-palette-validation.md](color-palette-validation.md).

Nguồn nối tiếp `412ec1a4-86af-41c8-bf7f-8ba0b7eeeb93` cho thấy một thất bại khác: gallery bỏ sót/gộp sign mặc dù dự án có fold; các lần dọn/khôi phục sau đó bị user phản hồi mất chỉnh sửa chưa commit. Câu trả lời cuối của agent báo phục hồi từ các bản còn lại, nhưng không có xác nhận user rằng mọi sửa tay đã trở lại chính xác. Không dùng kết thúc này như bằng chứng quy trình rollback đã đạt. Đọc [delivery-projects.md](delivery-projects.md) và [version-sync-organization.md](version-sync-organization.md).

## Cách tái dùng chứng cứ

Tìm file hiện hành và yêu cầu hiện tại trước. Dùng case để chọn phép đo/điểm dễ lỗi, không copy các frame/scale/style/giọng vào dự án khác. Nếu tái kiểm tra, phân biệt: người dùng yêu cầu; agent đã báo; artifact/log có thể đối chiếu; kết quả đo mới. Các tài liệu `TECHNICAL_QC.md` của title và log kiểm chứng đang còn trong repo đã được đọc, nhưng có cả style tạm cũ không còn là quy định cuối. Giá trị hiện hành chỉ xác nhận bằng ASS/raw/font đang dùng.

