# Chọn font, kiểm glyph và quản lý bộ font

Đọc khi cần tìm font cho sign/thoại/karaoke, sửa fallback hoặc chuẩn bị attachment. Nếu người dùng yêu cầu dựng chính glyph từ hình, chuyển sang [font-reconstruction.md](font-reconstruction.md); một font gần giống không thay thế bản dựng.

## Từ hình đến danh sách ứng viên

Trích frame rõ ở đúng kích thước và màu; xét vai trò sign, kích cỡ xem, mật độ chữ, ngữ cảnh thiết kế. Đo nét chính, serif/đầu nét, tỷ lệ cao:rộng, x-height/cap height, dáng chữ đặc trưng, độ nặng, spacing, độ nghiêng, counter và độ tròn. Phân loại thư viện theo nhóm hữu ích khi tìm (serif, sans, brush, handwritten, pixel, digital, chalk, display...) rồi lọc ứng viên bằng những nét thực thấy. Cách tổ chức theo loại và độ nặng là gợi ý quản lý, không là yêu cầu tải một bộ font thật lớn. [Phos: font collection and categories](https://phoscity.github.io/Phos-Fansubbing-Guide/Typesetting/Font/).

PANOSE là vector phân loại thiết kế chữ Latin, có family kind và các đặc tính như serif, weight, proportion, contrast, stroke variation; dùng để thu hẹp tìm kiếm **khi metadata của font có ý nghĩa**, rồi so glyph trực quan. Nó không khẳng định hai font có cùng hình, không chứng minh kerning/coverage, và tài liệu gốc nêu các hệ chữ ngoài Latin chưa được định nghĩa trong phiên bản đó. Vì vậy không lấy khoảng cách PANOSE làm phán quyết cho Kanji hoặc dấu tiếng Việt. [Monotype: PANOSE Metrics Guide](https://monotype.github.io/panose/pan2.htm).

## Cách phân xử lỗi font, layout và weight

Khi “chưa giống”, thử phân biệt các nguyên nhân thay vì thay đồng thời font, scale, spacing và border:

1. Chọn vài ứng viên có dáng nét/counter phù hợp, render **cùng toàn câu**, cùng baseline, kích cỡ và renderer; giữ mẫu chữ Việt thực dùng. Một bảng ứng viên cần cho thấy dáng nét và khoảng từ, không resize từng glyph cho vừa cùng hộp. Nếu font không có dấu, kiểm chính glyph được fallback trước khi loại/sửa layout.
2. Khóa font và thử fit chiều cao/chiều rộng tổng thể; sau đó xét advance, spacing, line break và anchor. Scale ngang có thể khớp width mà làm nét/counter sai, nên kiểm các chữ đặc trưng thay vì chỉ bbox toàn câu. Với JP gốc và VI dịch, cần giữ phong cách và hierarchy, không ép hai chuỗi khác nội dung phải trùng silhouette.
3. Khi chữ quá đậm/mờ, render fill-only, rồi thêm border và blur lần lượt. Nếu fill đã đúng, sửa layer/outline thay vì đổi font weight; nếu chỉ vài cặp chữ sát nhau, kiểm shaping/bearing/kerning trước khi tăng spacing cả dòng.
4. Khi ảnh thử và player khác nhau, kiểm file font/face nội bộ, log fontselect, attachment và cache của **đúng** môi trường. Đổi renderer hoặc reload có thể là phép chẩn đoán; không tự thay nội dung/font để chữa một lỗi nạp asset.

Giữ bảng ứng viên và lý do chọn/loại khi tìm font là phần chính. Điều này giúp harness khác tiếp tục thử đúng giả thuyết, không bắt đầu lại bằng chọn font theo cảm giác.

## Thử bằng chữ thật

Đọc family/style nội bộ thay vì tên file; phân biệt TTF/OTF/TTC và face trong collection. Tạo mẫu toàn câu bằng renderer target, cùng font size, scale, outline, shadow, blur, matrix và background của cảnh. Thử chữ đặc trưng và chuỗi tiếng Việt thực dùng: Đ/đ, ă/â/ê/ô/ơ/ư, dấu thanh trên nguyên âm và tổ hợp dài. Kiểm tra glyph missing, font fallback cục bộ, bold/italic giả, dấu bị lệch, advance/kerning và ngắt dòng. Nếu target softsub nhiều renderer, so trên các renderer/phân giải thật cần hỗ trợ; font đúng trên máy agent chưa chứng minh máy xem sẽ nạp đúng.

Một font được chọn vì phù hợp hình và đọc được trong cảnh, không vì metadata đứng đầu. Ghi top ứng viên cùng lý do loại/chọn và still so sánh nếu việc tìm font là phần chính của nhiệm vụ. Tránh ép mọi sign của một tập vào cùng font; đồng nhất thiết kế chỉ trong hệ thống thị giác có cùng chức năng.

## Đóng gói

Giữ thư viện tìm kiếm riêng với font **thực dùng** của bản giao. Đối chiếu `\fn`, Style và file/face nội bộ; gom attachment đúng các font cần, bảo đảm giấy phép/cách phân phối nếu phát hành. MKV attachment, ASS `[Fonts]`, thư mục font nạp trực tiếp và font cài trên hệ thống là các cơ chế khác nhau; kiểm target bằng log chọn font và still thực. Không tự cài hàng loạt font hệ thống để che lỗi thiếu attachment. Font mới hoặc cache cũ có thể khiến một lần thử hiển thị sai; reload renderer và so lại.
