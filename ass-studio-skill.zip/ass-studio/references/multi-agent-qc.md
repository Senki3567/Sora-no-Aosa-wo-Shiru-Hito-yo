# Audit phụ đề theo các lượt độc lập

Đọc khi audit nhiều tập hoặc cần phản biện các kết luận ngữ nghĩa/timing/asset. Tổ chức thành các lượt: điều phối nguồn/phạm vi, đọc thoại, kiểm timing/audio, kiểm asset/style, phản biện và xác minh bằng file. Một agent có thể làm tuần tự. Chỉ dùng nhiều agent khi harness hỗ trợ và quyền hiện tại cho phép; quy mô dự án không tự cấp quyền delegation hay sửa file.

## Nguồn, phạm vi và bằng chứng

Khóa input/hash hiện hành, chia phạm vi theo tập/cảnh hoặc nhóm event và ghi người sở hữu file khi có delegation. Worker đọc-only trả cue/file/hash, bằng chứng và vấn đề chưa chắc; một người thực hiện merge/ghi theo yêu cầu. Agent chạy sau phải xác minh file/bằng chứng, không coi số worker đồng ý là độ đúng.

| Lượt | Kết quả cần có |
|---|---|
| Ngữ nghĩa | Câu nguồn, câu Việt, ngữ cảnh, phủ định/chủ thể/quan hệ, mức chắc chắn; không suy speaker chỉ từ Actor |
| Timing/audio | Vùng nghe được, frame/cut liên quan, split/merge và đoạn drift; chưa nghe thì giữ cờ cần nghe |
| Asset/style | Usage font/style/shape và ảnh lỗi; báo phần có thể dọn, chỉ sửa khi được giao |
| Phản biện | Loại false positive do ngữ cảnh, lựa chọn dự án, thoại đồng thời hoặc cue chia khác |
| Xác minh | Citation khớp file/hash/timestamp; đối chiếu thực tế các trường giữ nguyên và candidate |

Không lấy regex hoặc timestamp overlap làm bằng chứng dịch đúng/nghe được/cắt âm. Script có thể kiểm citation tồn tại, hash và field diff; kết luận về nghĩa/âm thanh cần nguồn tương ứng. Một danh sách lỗi gõ tay vẫn có thể là nhận xét hợp lệ nếu gắn bằng chứng thật; vấn đề là báo giả đã chạy một phép kiểm chưa thực hiện.

Ví dụ lưu checksum trên môi trường có công cụ này:

```bash
sha256sum *.ass > baseline_checksums.sha256
```

Đó là định dạng checksum text, không phải JSON. Khi chỉ audit, cuối lượt so hash và không sửa phụ đề. Khi user yêu cầu Actor-only hoặc Effect-only, dùng compare giới hạn trường; không chèn Comment thay hợp đồng đó.

## Ghi chú trong file

Chọn nơi ghi theo yêu cầu cụ thể: báo cáo ngoài file, `Name`/Actor, `Effect` hoặc event `Comment`. Giữ style/line type/timing/câu chữ ngoài quyền sửa. Nếu được phép chèn Comment, lưu manifest gồm vị trí, nội dung/hash và ID ghi chú để hoàn nguyên đúng những dòng mới; không xóa bằng regex tag chung có thể trùng comment cũ.

Comment không hiện trong playback ASS thông thường; tags căn góc không tự biến nó thành ghi chú overlay. Nếu user cần ghi chú **hiện lên video**, phải xác định rõ yêu cầu đó và tạo candidate overlay riêng hoặc event hiển thị được cho phép. Font/size/style dự án không áp sang dự án khác; Arial cũng không được bảo đảm có trên mọi máy.

Kiểm sau ghi: nội dung/các trường được khóa vẫn giữ; số event tăng đúng số ghi chú được phép; mapping/citation còn đúng sau insert/sort; output mở được. Nếu cần UI Aegisub thấy issue ngay, ưu tiên field mà user đã chọn thay vì tự dựng kiểu note mới.
