# Mô hình ASS và thao tác không làm hỏng file

## Đọc theo section và Format

ASS không phải CSV thông thường. Phân biệt [Script Info], [V4+ Styles], [Events], [Fonts], [Graphics] và [Aegisub Extradata]. `Dialogue:` đặt sau section Extradata có thể bị Aegisub bỏ qua dù một bộ parser tự viết vẫn tìm thấy nó. Chèn event trước section tiếp theo, không nối tùy tiện cuối file.

Đọc `Format:` riêng cho Styles và Events, kể cả khi file đổi Format giữa chừng. `Name` trong định dạng chuẩn là trường Actor của giao diện. Khi Text ở cuối, split tối đa số-trường-trừ-một lần: dấu phẩy còn lại thuộc Text. Các trường trước Text không có cơ chế quote CSV để chứa dấu phẩy; ghi note Effect bằng dấu chấm phẩy hoặc câu khác. Với layout không thể phân tách không mơ hồ, dừng phép sửa tự động và đọc lại format, đừng đoán.

Giữ BOM, encoding và từng newline; không dùng một exporter chuẩn hóa toàn file cho yêu cầu sửa một trường. Giữ Comment/Dialogue, thứ tự layer/event, margin, Actor, Effect, font nhúng, project garbage và extradata ngoài phạm vi. LFS pointer không phải ASS: lấy object thực trước khi parse hoặc render.

## Styles và override

Phân biệt thuộc tính kế thừa từ style với override đang có hiệu lực. Khi đổi event sang một style dùng chung, so đủ font/family, size, primary/secondary/outline/shadow color+alpha, bold/italic/underline/strikeout, scale, spacing, angle, border style, outline, shadow, alignment, margin và encoding. Margin event bằng 0 thường kế thừa style. BorderStyle 3 hoặc Encoding không có một phép thay bằng tag thông thường tương đương cho mọi renderer: nếu không chứng minh được, giữ style phù hợp hoặc nêu giới hạn.

Đọc các reset `\r` và `\rTênStyle`, tag sau reset, transform và alpha từng kênh; thêm override chỉ ở đầu Text có thể bị reset về sau. Không đổi định nghĩa style dùng chung để sửa một sign. Nếu dự án yêu cầu gom style, tái hiện phần kế thừa cần thiết bằng override/event margins và render trước/sau bằng đúng font. Comment nguồn cũng cần giữ ngoại hình khi người dùng bật lại.

Xác định file font thực và tên family nội bộ, không dựa vào tên `.ttf`. Chú ý font fallback cho dấu Việt, italic/bold và synthetic bold. Giữ shape/glyph được duyệt; outline chữ dùng để khoét box phải đúng font, shaping và scale của chữ render.

## Các hệ tọa độ và thời gian

PlayRes là hệ tọa độ script; resolution video, resolution hiển thị, pixel aspect và LayoutRes có thể khác. Theo dõi cả bốn trước khi fit tọa độ. `\pN` scale drawing theo hệ số 2^(N-1); p4 coordinates không phải pixels p1. Vector clip cũng có scale riêng. `\an` chọn neo cho pos/move; `\org` đặt pivot quay, không phải vị trí chữ.

Thời gian Start/End ASS dùng centisecond. Move/transform/fade có các tham số millisecond tương đối với event; karaoke duration thông thường dùng centisecond. Màu ASS BGR, alpha 00 là hiện và FF là trong suốt. `\N`, `\n`, `\h`, reset và tag chức năng không phải câu chữ để xóa khi biên tập. Không strip tất cả brace để thay Text rồi quên tái dựng tag.

## Extradata, fold và nguồn

Giữ `[Aegisub Extradata]` cùng các marker `{=id}` hoặc marker nhiều ID. Fold là metadata của extension đang dùng, không phải chuẩn ASS render phổ quát. Đọc ví dụ fold hiện có trong dự án. Cấp ID mới lớn hơn cả IDs định nghĩa lẫn tham chiếu; group ID cũng cần riêng. Di chuyển khối giữ nguyên thứ tự nội bộ. Kiểm tra fold bao trọn khối và section vẫn hợp lệ; reorder có thể đổi stacking khi layer/time cùng nhau nên cần render.

## Helper

`ass_tools.py inspect` báo section, layout, style/font, loại event, time span, mức đồng thời, các dòng event lạc section và ID chưa định nghĩa. `patch` dành cho sửa trường trên event đã có; không tự migrate style, fold, chèn event hay sửa tag bằng regex tổng quát. Các thao tác cấu trúc phức tạp dùng generator riêng và so invariant tương ứng.

Tra semantics tag khi cần: [Aegisub ASS Override Tags](https://aegisub.org/docs/latest/ass_tags/). Đối với tính năng khác biệt renderer, đọc tài liệu hoặc code của đúng phiên bản mục tiêu.
