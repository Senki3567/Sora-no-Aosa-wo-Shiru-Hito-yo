# Chọn tự động hoá cho ASS, karaoke và tracking

Đọc khi cần sinh lặp nhiều event, áp macro Aegisub, hoặc nhập tracking từ Blender. Công cụ là phương tiện cho một nguồn chỉnh được và bản phát chạy đúng; chọn theo dữ liệu đầu vào, mức kiểm soát, renderer target và khả năng tái tạo, không theo tên công cụ đang phổ biến.

## Karaoke Templater và generator

Karaoke Templater hợp khi nguồn là các dòng karaoke `\k`/`\kf`/`\ko`, effect có quy tắc lặp theo line/syllable/char và template comment được giữ trong ASS. **Chọn đúng implementation trước khi viết Effect**: Aegisub gốc nhận source `karaoke` hoặc Effect rỗng, The0x539 chỉ nhận `kara`/`karaoke`; `template line` ở bản gốc và The0x539 có ngữ nghĩa output khác. Các dòng `fx` cũ có thể bị xóa khi apply, gồm cả effect của việc khác, nên chỉ chạy trên candidate đã kiểm quyền sở hữu `fx`. Xem ma trận, clock, profile `nyaa.kara-templater.lua` và preflight ở [kfx-templater-compatibility.md](kfx-templater-compatibility.md). [Tài liệu Aegisub gốc](https://aegisub.org/docs/latest/automation/karaoke_templater/declaring_template_and_code_lines/) xác nhận hành vi source/output; [Muteki karaoke docs](https://mutekifansub.hu/public/karaoke-docs/en/) mô tả extension `shape`, `recalculate`, `fbf` của local build, không phải chức năng chung.

Generator riêng hợp khi timing/phase theo nhiều clock, trajectory đo trên video, màu theo grade, shape hoặc provenance phức tạp. Nguồn phải ghi lyric, syllable absolute times, style/font, vị trí, các keyframe, seed nếu có random và version config. Sinh idempotent từ source, không dùng output sinh làm input. Với generator hay Templater, kiểm mapping từ source đến output, số lớp, clock, render quỹ đạo và CPU/bitmap; đừng suy tốc độ từ số dòng ASS.

## Aegisub CLI

`aegisub-cli` là cầu nối để agent chạy nhiều Automation macro của cộng đồng trên bản ASS riêng rồi đo và so output. Nhưng repo gốc cũ và các fork giải quyết các vấn đề khác nhau; CLI gọi macro, không gọi export filter. Trước khi đưa một script vào pipeline, đọc [aegisub-cli.md](aegisub-cli.md) để chọn bản, kiểm phụ thuộc, tên macro, selection/dialog và phạm vi thay đổi.

## Blender → AAE → Aegisub-Motion

Với sign chuyển động, chọn track điểm cho translation/similarity; plane/corner track khi mặt phẳng có perspective. Add-on AAE Export của Akatsumekusa xuất Blender tracking/plane tracking sang dữ liệu AAE tương thích Aegisub-Motion/Perspective-Motion. [Tutorial gốc](https://github.com/Akatmks/Akatsumekusa-Aegisub-Scripts/blob/master/docs/aae-export-tutorial.md) và [blender-aae-motion.md](blender-aae-motion.md) nêu frame 1 của Blender, side effect Auto export, Power Pin, residual smoothing và tùy chọn nhập. Render sign trên vài frame đầu/giữa/cuối, cực trị, cut và occlusion. Data tracker cần được lưu cùng footage/hash để tái áp, thay vì chỉ giữ ASS FBF. Smoothing chỉ xử lý noise có bằng chứng; không san phẳng camera shake thật. Plane track có thể giúp mask/shape bám mặt phẳng nhưng ASS font 3D chưa chắc mô phỏng được homography ấy; chuyển sang FBF/shape hoặc fit mô hình chữ riêng nếu residual còn cấu trúc. [typesetting-tracking.md](typesetting-tracking.md).

## Ranh giới renderer và chất lượng

libass, VSFilter và các extension khác có thể khác nhau về shaping, scaling, clip và performance. Với softsub, tránh phụ thuộc tag chỉ có ở extension không được player target hỗ trợ; với hardsub được chỉ định có thể tận dụng renderer riêng sau khi đo output. Hiệu năng chủ yếu phải đo trên bitmap được tạo, blur/cache và khung hình nhiều lớp; file nhỏ hoặc ít event không bảo đảm nhanh. Đặc biệt shape dài/chéo tạo bitmap rỗng lớn; thay đổi shape hoặc tham số vị trí có thể phá cache. Đo baseline và candidate ở cùng resolution/font/timestamp, kiểm cả cold và sequential frames. [arch1t3cht: renderer internals](https://gist.github.com/arch1t3cht/8cb1793beb72d30e334c7c46ff8c1080), [render-performance.md](render-performance.md).

PlayRes là hệ toạ độ của phần lớn vị trí/kích cỡ; LayoutRes còn ảnh hưởng blur, phối cảnh `\frx`/`\fry` và độ rộng chữ. Do đó đổi PlayRes hoặc LayoutRes của bản đã có có thể thay hình dù cue/tags giữ nguyên. Kiểm video storage/display aspect và matrix YCbCr; chỉnh matrix trên bằng chứng color pipeline, không chỉ nhìn một thumbnail RGB. [Aegisub: Resolution and Matrix](https://github.com/TypesettingTools/aegisite/blob/ca712c69385e7be508e25dd21d165e42d8c50ad8/content/en/docs/latest/Resolution_and_Matrix.md).

## Thuật toán Automation Cộng đồng tích hợp sẵn trong `motion_studio.py`

Khi không có GUI Aegisub hoặc `aegisub-cli` bị chặn bởi phụ thuộc GUI/MoonScript/DependencyControl, Agent có thể gọi trực tiếp các thuật toán tương đương chính xác về mặt toán học trong `scripts/motion_studio.py` (chi tiết công thức và cơ chế pipeline `libass` tại [community-automation-algorithms.md](community-automation-algorithms.md)):

- **Giải ngược Phối cảnh 3D (`quad-to-ass3d` — tương đương `arch.Perspective` / `PerspectiveMotion`)**: Giải hệ phương trình chiếu phẳng – tứ giác lồi với khoảng cách camera cố định $d = 312.5$ và thứ tự quay 3D nội bộ $R_y(-\text{fry})\cdot R_x(-\text{frx})\cdot R_z(-\text{frz})$ sau khi áp shear `\fax` rồi nhân `\fscx/\fscy`.
- **Chuyển Văn bản & Font sang Vector Shape (`text-to-shape` — tương đương `Yutils` / `ILL.Font` / `Shapery`)**: Trích xuất trực tiếp đường bao glyph từ file `.ttf`/`.otf`/`.ttc` qua `fontTools`, tự động nâng bậc đường cong Bézier bậc 2 (TrueType) lên bậc 3 (`b` trong ASS), lật trục $Y$ và cộng `advanceWidth`.
- **Cắt Dải Gradient Hình chữ nhật (`clip-gradient` — tương đương `Gradient Everything` / `Colorize`)**: Tạo dải `\clip(x0,y0,x1,y1)` (chi phí cắt con trỏ bitmap trong `libass` gần như bằng 0) có tùy chọn `--separate-border-layer` tách lớp viền `\1a&HFF&` xuống dưới để triệt tiêu hoàn toàn lỗi sọc viền (border striping).
