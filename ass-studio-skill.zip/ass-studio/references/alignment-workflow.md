
# Căn và biên tập bản Việt theo EN

Skill này chỉ tạo **bản Việt chuẩn hóa theo EN** từ phụ đề Việt có sẵn. EN ASS xác định cue, thứ tự và khuôn đầu ra; VI là nguồn câu chữ cần tìm và biên tập; JP giúp xác minh nghĩa gốc. Đầu ra là Full.vi.ass. Dùng [workflow trực dịch JP](direct-japanese-workflow.md) sau đó nếu người dùng muốn thêm bản dịch trực tiếp từ Nhật có trans note.

## Cách làm

1. Xác định đúng EN, VI và JP trong thư mục người dùng chỉ định. Đồng bộ VI với EN trước khi ghép: kiểm tra nhiều mốc khớp theo nghĩa ở đầu, giữa, cuối; chỉ dùng timing để khoanh ứng viên. Không để một offset tự động chưa kiểm chứng quyết định việc câu nào khớp.
2. Với mỗi cue EN, tìm phần VI diễn đạt đúng lời đó trong cả chuỗi hội thoại. Xét actor, câu trước/sau và JP khi cần. Cho phép ghép một-nhiều hoặc nhiều-một theo nội dung; cue VI dịch sai là ứng viên cần sửa, không phải missing. Chỉ ghi nguồn VI đã chọn sau khi đã chốt nghĩa.
3. Dùng các tập Việt đã duyệt làm chuẩn cho toàn bộ phong cách: giọng theo nhân vật và quan hệ, xưng hô, thuật ngữ, cách gọi, mức khẩu ngữ, nhịp câu và cách viết. Tạo ghi chú tra cứu ngắn; khi có cảnh/lời thoại lặp, so bản đã duyệt nếu JP lần này cùng nghĩa. Không sao chép câu cũ khi ngữ cảnh hoặc lời gốc đã khác.
4. Biên tập bản Việt đã chọn để sửa sai nghĩa, thiếu/thừa ý, tên, xưng hô, câu gượng và lỗi gõ. Giữ nghĩa JP khi EN diễn đạt lệch; không dịch trực tiếp từ EN để giả làm nguồn VI. Giữ phủ định, điều kiện, mức chắc chắn, hàm ý và phân biệt tên/biệt danh với danh từ thường.
5. Chỉ ghi missing sau khi đã tìm rộng trong VI và kiểm tra cue EN kề/đồng thời, đoạn gộp và lệch timing. Nếu người dùng xác nhận một câu thực sự thiếu rồi yêu cầu điền, dùng JP và ngữ cảnh đáng tin cậy; nếu chưa xác nhận/ủy quyền, để trạng thái thiếu rõ ràng.
6. Rà lại toàn bộ cue thoại về nghĩa và phong cách. Exporter giữ EN ẩn và provenance split/merge/missing theo schema. Note review ghi riêng trong map/report; không tự xóa provenance trong output Full. Nếu người dùng yêu cầu bản biên tập cuối chỉ giữ note chưa giải quyết, tạo hoặc sửa bản đó trong phạm vi riêng, chứng minh Text/format không đổi ngoài yêu cầu. Đọc lại file hiện hành trước khi tiếp tục để giữ nguyên sửa đổi mới nhất của người dùng.

## Công cụ và tham chiếu

Dùng scripts/alignment/sub_align.py để kiểm tra cặp nguồn, đồng bộ, tạo lô đối chiếu, biên dịch quyết định và xuất theo EN. Đọc:
- [alignment_rubric.md](alignment/alignment_rubric.md) khi ghép khác cue, gặp nguồn thiếu hoặc cần rà phong cách.
- [map_schema.md](alignment/map_schema.md) khi ghi map hoặc xử lý lỗi xuất.
- [vietnamese_grammar_rules.md](alignment/vietnamese_grammar_rules.md) khi biên tập câu Việt/ngắt dòng.

Giữ các lô nhỏ đủ ngữ cảnh hội thoại. Không nạp nguyên nhiều tập tham chiếu; tạo bảng giọng/thuật ngữ/lời lặp ngắn và chỉ mở rộng vùng khó. Rà đủ mọi cue thoại dù đã có vẻ khớp. Bảo toàn timing, thứ tự, style, actor và tag chức năng theo EN master.


## Chạy bộ căn trong ASS Studio

Chạy từ thư mục skill, dùng file/path thật của task. `--styles` phải xác định rõ khi file có sign/song dùng chung style; danh sách mặc định chỉ là heuristic của parser. ID căn bắt đầu **0**, khác ID OCR thường bắt đầu **1**.

```bash
python3 scripts/alignment/sub_align.py preflight --en-dir /path/en --vi-dir /path/vi --inspect-styles
python3 scripts/alignment/sub_align.py sanitize-sync --en-file /path/en.ass --vi-file /path/vi.ass --styles Default,Alt --offset none --out-data /path/work/data.json
python3 scripts/alignment/sub_align.py cluster --in-data /path/work/data.json --out-candidates /path/work/candidates.json
python3 scripts/alignment/sub_align.py review --in-data /path/work/data.json --start-en 0 --count 16
python3 scripts/alignment/sub_align.py compile-map --in-data /path/work/data.json --in-decisions /path/work/decisions.jsonl --out-map /path/work/map.json
python3 scripts/alignment/sub_align.py export --en-file /path/en.ass --in-data /path/work/data.json --map-pr-file /path/work/map.json --styles Default,Alt --out-file /path/output.Full.vi.ass
```

`--offset none` trong ví dụ không thay khảo sát lệch giờ; chọn auto/giây đã kiểm chứng nếu cần. Cluster/review chỉ giúp tìm ứng viên, không tự xác nhận match. Agent điền quyết định từng cue với source_parts và reviewed sau khi đọc nghĩa. Script compile/export xác nhận schema/source identity/coverage và giữ structural fields của EN; các cờ true không là phép tự nghiệm thu ngôn ngữ.

Bản tích hợp giữ nguyên code căn hiện có. Trước export, kiểm tra format hỗ trợ bằng parser ở input thật và so structural fields sau export; không dùng nó thay helper field-edit để chỉnh tùy ý một ASS typeset phức tạp. Khi gặp custom Format hoặc inline tag có chức năng chưa bảo toàn, giữ nguồn và xử lý theo ass-model/field-edits-qc thay vì ép parser cho qua. Source VI có thể ASS/SRT; nguồn SRT không làm output mất khung ASS master.
