import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from PIL import Image, ImageDraw

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / 'scripts'))
import motion_studio


class MotionStudioTests(unittest.TestCase):
    def test_probe_detects_2s_cadence_and_rectifies_surface_motion(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            frames_meta = []
            track_frames = []
            for idx in range(6):
                step_2s = idx // 2
                dx_surf = 10 * idx
                dy_surf = 5 * idx
                local_shift = 4 * step_2s

                im = Image.new('RGB', (160, 120), (20, 20, 20))
                draw = ImageDraw.Draw(im)
                x0 = 40 + dx_surf + local_shift
                y0 = 30 + dy_surf
                draw.rectangle([x0, y0, x0 + 20, y0 + 16], fill=(240, 220, 180))
                fname = f'f_{idx:03d}.png'
                im.save(root / fname)

                pts = idx * 41.708
                frames_meta.append({
                    'frame_index_0based': idx,
                    'pts_time_text': f'{pts / 1000.0:.6f}',
                    'file': fname
                })
                track_frames.append({
                    'frame_index_0based': idx,
                    'pts_ms': pts,
                    'matrix_reference_to_current': [
                        [1.0, 0.0, float(dx_surf)],
                        [0.0, 1.0, float(dy_surf)],
                        [0.0, 0.0, 1.0]
                    ]
                })

            manifest_path = root / 'frames.json'
            manifest_path.write_text(json.dumps({'frames': frames_meta}), encoding='utf-8')
            track_path = root / 'track.json'
            track_path.write_text(json.dumps({'segments': [{'frames': track_frames}]}), encoding='utf-8')

            report = motion_studio.probe_frames(
                manifest_path, roi=[20, 15, 100, 75], track_path=track_path
            )
            self.assertEqual(report['estimated_cadence'], '2s')
            c0 = report['frames'][0]['centroid_native']
            c1 = report['frames'][1]['centroid_native']
            c2 = report['frames'][2]['centroid_native']
            self.assertAlmostEqual(c0[0], c1[0], places=2)
            self.assertAlmostEqual(c0[1], c1[1], places=2)
            self.assertGreater(c2[0], c1[0] + 3.0)

    def test_fit_curve_identifies_power_and_spring_overshoot(self):
        times = [0, 100, 200, 300, 400, 500]
        values_pow = [100.0 + 50.0 * ((t / 500.0) ** 0.45) for t in times]
        res_pow = motion_studio.fit_curve_series(times, values_pow)
        self.assertEqual(res_pow['selected_model'], 'power')
        self.assertAlmostEqual(res_pow['selected_easing']['gamma'], 0.45, delta=0.06)
        self.assertEqual(len(res_pow['ass_transform_segments']), 1)

        u_vals = [t / 600.0 for t in [0, 100, 200, 300, 400, 500, 600]]
        spring_norm = motion_studio.evaluate_easing(u_vals, {'type': 'spring', 'damping_ratio': 0.35, 'angular_freq': 10.0})
        values_sp = [200.0 + 100.0 * float(v) for v in spring_norm]
        res_sp = motion_studio.fit_curve_series([0, 100, 200, 300, 400, 500, 600], values_sp)
        self.assertTrue(res_sp['has_overshoot'])
        self.assertEqual(res_sp['selected_model'], 'spring')
        self.assertGreaterEqual(len(res_sp['ass_transform_segments']), 2)

    def test_compile_enforces_dual_clock_and_prevents_fbf_fade_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            bad_spec = {
                'content_clock_onsets': [
                    {'id': 'syl-1', 'sung_start_ms': 1200, 'settled_by_ms': 1350}
                ],
                'components': []
            }
            bad_path = root / 'bad_spec.json'
            bad_path.write_text(json.dumps(bad_spec), encoding='utf-8')
            with self.assertRaises(ValueError):
                motion_studio.compile_declarative_spec(bad_path)

            good_spec = {
                'fbf_interval_ms': [1000, 1200, 50],
                'content_clock_onsets': [
                    {'id': 'syl-1', 'sung_start_ms': 1200, 'settled_by_ms': 1150}
                ],
                'components': [
                    {
                        'id': 'sign-fill',
                        'layer': 2,
                        'style': 'Sign',
                        'text': 'Chữ Việt',
                        'alignment': 5,
                        'reference_pos': [960, 540],
                        'compilation_mode': 'baked_fbf',
                        'start_ms': 1000,
                        'end_ms': 1200,
                        'curves': {
                            'alpha': [
                                {'time_ms': 1000, 'value': 255},
                                {'time_ms': 1200, 'value': 0, 'easing': {'type': 'linear'}}
                            ],
                            'fscx': [
                                {'time_ms': 1000, 'value': 120.0},
                                {'time_ms': 1200, 'value': 100.0, 'easing': {'type': 'power', 'gamma': 0.5}}
                            ]
                        }
                    }
                ]
            }
            spec_path = root / 'good_spec.json'
            spec_path.write_text(json.dumps(good_spec), encoding='utf-8')
            compiled = motion_studio.compile_declarative_spec(spec_path)
            self.assertEqual(compiled['event_count'], 4)
            lines = [e['ass_line'] for e in compiled['events']]
            self.assertIn('\\alpha&HFF&', lines[0])
            self.assertIn('\\alpha&HBF&', lines[1])
            self.assertIn('\\alpha&H80&', lines[2])
            self.assertIn('\\alpha&H40&', lines[3])
            for line in lines:
                self.assertNotIn('\\fad', line)
                self.assertNotIn('\\t(', line)

            out_rep = root / 'compiled_report.json'
            out_ass = root / 'compiled.ass'
            proc = subprocess.run(
                [sys.executable, str(SKILL_ROOT / 'scripts' / 'motion_studio.py'),
                 'compile', str(spec_path), '--output-report', str(out_rep), '--output-ass', str(out_ass)],
                capture_output=True, text=True, check=False
            )
            self.assertEqual(proc.returncode, 0, msg=proc.stderr)
            self.assertTrue(out_ass.exists())



    def test_transform_shape_projects_drawing_with_p_scale(self):
        # Translate by (+10, +20) in screen pixels; in \p2 (scale=2), coordinates should shift by (+20, +40)
        mat = [[1.0, 0.0, 10.0], [0.0, 1.0, 20.0], [0.0, 0.0, 1.0]]
        res = motion_studio.transform_ass_drawing("m 0 0 l 20 0 20 10 0 10 c", mat, p_scale=2, precision=1)
        self.assertEqual(res, "m 20 40 l 40 40 40 50 20 50 c")



    def test_quad_to_ass3d_recovers_exact_perspective_parameters(self):
        import math, numpy as np
        def rot_x(a):
            c, s = math.cos(a), math.sin(a)
            return np.array([[1,0,0],[0,c,-s],[0,s,c]])
        def rot_y(a):
            c, s = math.cos(a), math.sin(a)
            return np.array([[c,0,s],[0,1,0],[-s,0,c]])
        def rot_z(a):
            c, s = math.cos(a), math.sin(a)
            return np.array([[c,-s,0],[s,c,0],[0,0,1]])
        R = rot_y(-math.radians(-20.0)) @ rot_x(-math.radians(25.0)) @ rot_z(-math.radians(12.0))
        d = 312.5
        quad = []
        for (u, v) in [(0,0), (200,0), (200,100), (0,100)]:
            ux, vy = (u + 0.3 * v) * 1.2, v * 0.8
            p3 = np.array([(520 - 480) + ux, (410 - 390) + vy, 0.0])
            vr = R @ p3
            w = d + vr[2]
            quad.append([480 + vr[0]*d/w, 390 + vr[1]*d/w])
        res = motion_studio.solve_ass_perspective_quad(quad, ref_w=200.0, ref_h=100.0, org_xy=[480.0, 390.0])
        self.assertAlmostEqual(res["pos"][0], 520.0, places=2)
        self.assertAlmostEqual(res["pos"][1], 410.0, places=2)
        self.assertAlmostEqual(res["fscx"], 120.0, places=2)
        self.assertAlmostEqual(res["fscy"], 80.0, places=2)
        self.assertAlmostEqual(res["fax"], 0.3, places=4)
        self.assertAlmostEqual(res["frx"], 25.0, places=2)
        self.assertAlmostEqual(res["fry"], -20.0, places=2)
        self.assertAlmostEqual(res["frz"], 12.0, places=2)

    def test_text_to_shape_converts_vietnamese_glyphs_to_ass_drawing(self):
        font_path = "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"
        if Path(font_path).exists():
            res = motion_studio.text_to_ass_shape("Đêm", font_path, fontsize=64.0)
            self.assertEqual(res["missing_glyphs"], [])
            res_missing = motion_studio.text_to_ass_shape("Đêm\u65e5\u672c\u8a9e", font_path, fontsize=64.0)
            self.assertEqual(res_missing["missing_glyphs"], ["\u65e5", "\u672c", "\u8a9e"])
            self.assertTrue(res["drawing"].startswith("m "))
            self.assertIn(" b ", res["drawing"])
            self.assertGreater(res["advance_width_px"], 50.0)

    def test_motion_fit_output_schema_integrates_with_motion_studio_probe_and_compile(self):
        import motion_fit
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            csv_path = root / "points.csv"
            csv_lines = [
                "frame_index_0based,pts_ms,point_id,reference_x,reference_y,x,y,role,status",
                "0,0.0,p1,100,100,100,100,fit,measured",
                "0,0.0,p2,200,100,200,100,fit,measured",
                "0,0.0,p3,150,200,150,200,check,measured",
                "1,50.0,p1,100,100,115,108,fit,measured",
                "1,50.0,p2,200,100,215,108,fit,measured",
                "1,50.0,p3,150,200,165,208,check,measured",
            ]
            csv_path.write_text("\n".join(csv_lines) + "\n", encoding="utf-8")
            fit_report = motion_fit.run_fit(csv_path, model="similarity", threshold=1.0)
            track_path = root / "track.json"
            track_path.write_text(json.dumps(fit_report), encoding="utf-8")

            # Verify _load_surface_track_map reads motion_fit.py schema directly
            track_map = motion_studio._load_surface_track_map(track_path)
            self.assertIn(0, track_map)
            self.assertIn(1, track_map)
            self.assertIn("matrix_reference_to_current", track_map[1])
            self.assertAlmostEqual(track_map[1]["similarity_parameters"]["scale"], 1.0, places=3)

            # Verify compile_declarative_spec applies surface_track in both baked_fbf and native_tags modes
            spec = {
                "fbf_interval_ms": [0, 100, 50],
                "surface_track": str(track_path),
                "components": [
                    {
                        "id": "fbf-comp",
                        "style": "Sign",
                        "text": "FBF",
                        "reference_pos": [100.0, 100.0],
                        "compilation_mode": "baked_fbf",
                        "start_ms": 0,
                        "end_ms": 100
                    },
                    {
                        "id": "native-comp",
                        "style": "Sign",
                        "text": "NATIVE",
                        "reference_pos": [100.0, 100.0],
                        "compilation_mode": "native_tags",
                        "start_ms": 0,
                        "end_ms": 50
                    }
                ]
            }
            spec_path = root / "spec.json"
            spec_path.write_text(json.dumps(spec), encoding="utf-8")
            compiled = motion_studio.compile_declarative_spec(spec_path)
            self.assertEqual(compiled["event_count"], 3)
            self.assertIn(r"\pos(100.00,100.00)", compiled["events"][0]["ass_line"])
            self.assertIn(r"\pos(115.00,108.00)", compiled["events"][1]["ass_line"])
            self.assertIn(r"\move(100.00,100.00,115.00,108.00,0,50)", compiled["events"][2]["ass_line"])

    def test_clip_gradient_separates_border_and_slices_strips(self):
        spec = {
            "axis": "vertical",
            "bounds": [100, 200, 300, 210],
            "step_px": 5,
            "accel": 1.0,
            "colors_rgb": [[255, 0, 0], [0, 0, 255]],
            "layer": 3,
            "style": "Sign",
            "start_ms": 1000,
            "end_ms": 3000,
            "pos": [200, 205],
            "alignment": 5,
            "text": "GRADIENT",
            "separate_border_layer": True
        }
        res = motion_studio.generate_clip_gradient(spec)
        self.assertEqual(res["strip_count"], 2)
        self.assertEqual(res["total_events"], 3)  # 1 border underlay + 2 fill strips
        self.assertIn("\\1a&HFF&", res["lines"][0])
        self.assertIn("\\bord0\\shad0", res["lines"][1])
        self.assertIn("\\clip(100,200,300,205)", res["lines"][1])
        self.assertIn("\\clip(100,205,300,210)", res["lines"][2])



    def test_extrapolate_tracking_series_picks_optimal_degree(self):
        # Parabolic motion x(t) = 100 + 4*t + 0.1*t^2
        fr = [0, 1, 2, 3, 4, 5, 6, 7]
        vals = [100.0 + 4.0 * t + 0.1 * t**2 for t in fr]
        res = motion_studio.extrapolate_tracking_series(fr, vals, count_extra=3, direction="end")
        self.assertEqual(res["selected_polynomial_degree"], 2)
        self.assertEqual(res["target_frames"], [8.0, 9.0, 10.0])
        # t=8 => 100 + 32 + 6.4 = 138.4
        self.assertAlmostEqual(res["extrapolated_values"][0], 138.4, places=2)

    def test_wobble_and_wave_generation(self):
        w_spec = {
            "mode": "damped_harmonic",
            "frames": 10,
            "fps": 24.0,
            "pos": [500, 400],
            "amplitude_x": 10.0,
            "amplitude_y": 5.0,
            "amplitude_rot_deg": 4.0,
            "freq_hz": 3.0,
            "decay": 1.5
        }
        res_w = motion_studio.generate_wobble_animation(w_spec)
        self.assertEqual(len(res_w["frames"]), 10)
        self.assertIn("\\pos(", res_w["frames"][0]["ass_tag_snippet"])
        self.assertIn("\\frz", res_w["frames"][0]["ass_tag_snippet"])

        wave_spec = {
            "text": "SÓNG",
            "pos": [200, 300],
            "amplitude_y": 20.0,
            "wavelength_px": 200.0,
            "freq_hz": 2.0,
            "time_s": 0.25,
            "char_advance_px": 35.0
        }
        res_wave = motion_studio.generate_wave_characters(wave_spec)
        self.assertEqual(len(res_wave["characters"]), 4)
        for c in res_wave["characters"]:
            self.assertIn("\\frz", c["ass_tag_block"])
            self.assertIn("\\pos(", c["ass_tag_block"])

    def test_path_motion_and_envelope_warping(self):
        # Symmetrical arc: peak at middle with tangent 0 deg
        p_spec = {
            "path": "m 100 800 b 300 200 700 200 900 800",
            "keyframes": [{"time_ms": 0, "progress": 0.0}, {"time_ms": 1000, "progress": 1.0}],
            "sample_times_ms": [0, 500, 1000]
        }
        res_path = motion_studio.animate_along_path(p_spec)
        self.assertEqual(len(res_path["trajectory"]), 3)
        self.assertAlmostEqual(res_path["trajectory"][1]["frz"], 0.0, places=1)
        self.assertAlmostEqual(res_path["trajectory"][1]["pos"][0], 500.0, places=1)

        # 4x4 Grid for envelope warp
        grid = [[[i * 50.0, j * 25.0] for j in range(4)] for i in range(4)]
        # Bulge center row
        grid[1][1][1] -= 10.0
        grid[2][1][1] -= 10.0
        warped = motion_studio.deform_drawing_envelope("m 0 0 l 150 0 150 75 0 75 c", grid, p_scale=1)
        self.assertTrue(warped.startswith("m "))
        self.assertTrue(warped.endswith(" c"))


if __name__ == '__main__':
    unittest.main()
