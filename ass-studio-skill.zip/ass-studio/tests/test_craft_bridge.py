import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
from craft_bridge import parse_svg_path_advanced, quad_to_cubic


class TestCraftBridge(unittest.TestCase):
    def test_svg_path_parsing_and_clip_format_has_single_m(self):
        svg = 'M 10 20 L 30 40 Z'
        ass_str = parse_svg_path_advanced(svg)
        self.assertEqual(ass_str, 'm 10 20 l 30 40 c')

        proc = subprocess.run(
            [sys.executable, str(SCRIPTS / 'craft_bridge.py'), 'svg-to-ass', svg, '--format', 'clip'],
            capture_output=True, text=True, check=False
        )
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout.strip(), r'\clip(m 10 20 l 30 40 c)')
        self.assertNotIn('m m', proc.stdout)

    def test_quad_to_cubic(self):
        c1, c2, p2 = quad_to_cubic((0.0, 0.0), (15.0, 30.0), (30.0, 0.0))
        self.assertAlmostEqual(c1[0], 10.0, places=4)
        self.assertAlmostEqual(c1[1], 20.0, places=4)
        self.assertAlmostEqual(c2[0], 20.0, places=4)
        self.assertAlmostEqual(c2[1], 20.0, places=4)
        self.assertEqual(p2, (30.0, 0.0))

    def test_keyframes_to_ass_never_emits_pos_inside_t(self):
        with tempfile.TemporaryDirectory() as td:
            kf_path = Path(td) / 'kf.json'
            kf_data = [
                {"time": 0.0, "x": 100.0, "y": 200.0, "rot": 0.0, "scale_x": 100.0, "scale_y": 100.0, "opacity": 100.0},
                {"time": 0.5, "x": 150.0, "y": 250.0, "rot": 15.0, "scale_x": 120.0, "scale_y": 120.0, "opacity": 50.0},
                {"time": 1.0, "x": 200.0, "y": 300.0, "rot": 30.0, "scale_x": 100.0, "scale_y": 100.0, "opacity": 100.0},
            ]
            kf_path.write_text(json.dumps(kf_data), encoding='utf-8')
            proc = subprocess.run(
                [sys.executable, str(SCRIPTS / 'craft_bridge.py'), 'keyframes-to-ass', str(kf_path), '--mode', 't', '--text', 'SIGN'],
                capture_output=True, text=True, check=False
            )
            self.assertEqual(proc.returncode, 0)
            out = proc.stdout.strip()
            self.assertIn(r'\move(100.00,200.00,200.00,300.00,0,1000)', out)
            self.assertNotIn(r'\t(0,500,\pos', out)
            self.assertIn(r'\t(0,500,\frz15.00\fscx120.0\fscy120.0\alpha&H80&)', out)


if __name__ == '__main__':
    unittest.main()
