"""Synthetic numerical and image IO contracts; no model calls or real footage claims."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

import numpy as np
from PIL import Image

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
import motion_fit as motion
import visual_evidence as visual


class VisualTools(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ass studio visual test ')
        self.root = Path(self.temp.name)
        self.reference = np.array([[0,0],[200,0],[200,100],[0,100],[50,20],[160,80],[80,70],[120,40]],dtype=float)

    def tearDown(self):
        self.temp.cleanup()

    def points(self, matrix, frames=(10,11), check=True, outlier=False):
        target=motion.project(matrix,self.reference)
        path=self.root/'measured points.csv'
        fields=['segment','frame_index_0based','pts_ms','point_id','reference_x','reference_y','x','y','role','status']
        with path.open('w',newline='',encoding='utf-8') as handle:
            writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader()
            for frame in frames:
                for i,(ref,cur) in enumerate(zip(self.reference,target)):
                    cur=cur.copy()
                    if outlier and i==0: cur+=np.array([70,-40])
                    writer.writerow(dict(segment='one',frame_index_0based=frame,pts_ms=frame*41.7,
                        point_id=f'p{i}',reference_x=ref[0],reference_y=ref[1],x=cur[0],y=cur[1],
                        role='check' if check and i==len(target)-1 else 'fit',status='measured'))
        return path

    def frame_manifest(self, overlay=False):
        raw=self.root/'raw.png';Image.new('RGB',(200,100),(0,0,0)).save(raw)
        record={'frame_index_0based':10,'pts_ms_rounded':417,'file':'raw.png'}
        if overlay:
            path=self.root/'overlay.png';Image.new('RGBA',(200,100),(255,0,0,128)).save(path)
            record['overlay']='overlay.png'
        path=self.root/'frames.json';path.write_text(json.dumps({'frames':[record]}))
        return path

    def test_all_models_recover_known_mapping(self):
        angle=.18;scale=1.12
        matrices={
            'translation':np.array([[1.,0,12],[0,1.,-8],[0,0,1.]]),
            'similarity':np.array([[scale*np.cos(angle),-scale*np.sin(angle),12],
                                   [scale*np.sin(angle),scale*np.cos(angle),-8],[0,0,1.]]),
            'affine':np.array([[1.1,.12,12],[-.04,.9,-8],[0,0,1.]]),
            'homography':np.array([[1.1,.12,12],[-.04,.9,8],[.0008,-.0004,1.]])}
        for model,matrix in matrices.items():
            with self.subTest(model=model):
                path=self.points(matrix)
                before=hashlib.sha256(path.read_bytes()).hexdigest()
                report=motion.run_fit(path,model,.01)
                for frame in report['frames']:
                    self.assertEqual(frame['status'],'fitted')
                    np.testing.assert_allclose(frame['matrix_reference_to_frame'],matrix,atol=1e-8)
                    self.assertLess(frame['max_check_error_px'],1e-8)
                self.assertEqual(before,hashlib.sha256(path.read_bytes()).hexdigest())

    def test_ransac_excludes_bad_point_and_requires_review(self):
        matrix=np.array([[1.02,-.1,8],[.1,1.02,12],[0,0,1.]])
        report=motion.run_fit(self.points(matrix,outlier=True),'similarity',.2,True,7)
        for row in report['frames']:
            self.assertEqual(row['status'],'needs_review')
            self.assertFalse(row['points'][0]['used_in_fit'])
            self.assertGreater(row['points'][0]['error_px'],50)
            np.testing.assert_allclose(row['matrix_reference_to_frame'],matrix,atol=1e-8)

    def test_noisy_projective_fit_predicts_unseen_points(self):
        matrix=np.array([[1.1,.12,12],[-.04,.9,8],[.0008,-.0004,1.]])
        observed=motion.project(matrix,self.reference)+np.random.default_rng(19).normal(0,.08,self.reference.shape)
        fitted=motion.fit_matrix(self.reference,observed,'homography')
        checks=np.array([[25,25],[175,75],[100,50]],dtype=float)
        error=np.linalg.norm(motion.project(fitted,checks)-motion.project(matrix,checks),axis=1)
        self.assertLess(float(error.max()),.25)

    def test_minimum_fit_is_not_independent_validation(self):
        self.reference=self.reference[:2]
        report=motion.run_fit(self.points(np.eye(3),frames=(10,),check=False),'similarity',1.)
        self.assertEqual(report['frames'][0]['status'],'needs_review')

    def test_held_out_landmark_catches_wrong_model(self):
        matrix=np.array([[1.1,.2,12],[.1,.9,8],[.001,-.0004,1.]])
        report=motion.run_fit(self.points(matrix),'translation',.1)
        self.assertEqual(report['frames'][0]['status'],'needs_review')
        self.assertGreater(report['frames'][0]['max_check_error_px'],.1)

    def test_degenerate_plane_is_rejected(self):
        points=np.array([[0,0],[10,0],[20,0],[30,0],[40,0]],dtype=float)
        for model in ['affine','homography']:
            with self.subTest(model=model),self.assertRaises(ValueError):
                motion.fit_matrix(points,points+1,model)

    def test_frame_gaps_are_explicit_and_not_interpolated(self):
        report=motion.run_fit(self.points(np.eye(3),frames=(10,13)),'similarity',1.)
        self.assertEqual([row['frame_index_0based'] for row in report['frames']],[10,13])
        self.assertEqual(report['unmeasured_frame_intervals'],[{'segment':'one','first':11,'last':12}])

    def test_changed_reference_or_nonmonotonic_pts_rejected(self):
        for change in ['reference','pts']:
            path=self.points(np.eye(3))
            with path.open(newline='') as handle:
                reader=csv.DictReader(handle);rows=list(reader);fields=reader.fieldnames
            if change=='reference': rows[8]['reference_x']='22'
            else:
                for row in rows[8:]:row['pts_ms']='1'
            with path.open('w',newline='') as handle:
                writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader();writer.writerows(rows)
            with self.subTest(change=change),self.assertRaises(ValueError):motion.read_points(path)

    def test_rgba_composite_and_native_crop_mapping(self):
        manifest=self.frame_manifest(True)
        before=(self.root/'raw.png').read_bytes()
        report=visual.make_sheet(manifest,self.root/'sheet',roi=(50,20,150,80),width=200)
        panel=report['panels'][0]
        self.assertEqual(panel['native_crop_box'],[50,20,150,80])
        self.assertEqual(panel['scale_native_to_sheet'],[2.,2.])
        with Image.open(self.root/'sheet/composite_0000_000010.png') as composite:
            self.assertEqual(composite.getpixel((100,50)),(128,0,0,255))
        self.assertEqual(before,(self.root/'raw.png').read_bytes())

    def test_missing_render_timestamp_fails_then_explicit_offset_matches(self):
        manifest=self.frame_manifest()
        Image.new('RGBA',(200,100),(0,255,0,128)).save(self.root/'render.png')
        render=self.root/'render.json'
        render.write_text(json.dumps({'samples':[{'time_ms':517,'png':'render.png'}]}))
        with self.assertRaises(ValueError):visual.make_sheet(manifest,self.root/'bad',render_report=render)
        self.assertFalse((self.root/'bad').exists())
        report=visual.make_sheet(manifest,self.root/'good',render_report=render,ass_offset_ms=100)
        self.assertEqual(report['ass_offset_ms'],100)
        self.assertEqual(len(report['panels']),2)

    def test_mismatched_overlay_dimensions_do_not_resize_silently(self):
        manifest=self.frame_manifest(True)
        Image.new('RGBA',(100,50)).save(self.root/'overlay.png')
        with self.assertRaises(ValueError):visual.make_sheet(manifest,self.root/'bad')

    def test_actual_fractional_pts_does_not_round_across_ass_boundary(self):
        record={'pts_time_text':'1.0199','pts_ms_rounded':1020}
        pts,sample,method=visual.frame_time(record)
        self.assertEqual(str(pts),'1019.9000')
        self.assertEqual(sample,1019)
        self.assertEqual(method,'actual_pts_text_floor_ms')
        manifest=self.frame_manifest()
        data=json.loads(manifest.read_text());data['frames'][0].update(record)
        manifest.write_text(json.dumps(data))
        self.assertEqual(visual.render_times(manifest)['unique_ass_times_ms'],[1019])

    def test_comparison_ignores_invisible_rgb_but_detects_alpha(self):
        a,b=self.root/'a.png',self.root/'b.png'
        Image.new('RGBA',(12,8),(255,0,0,0)).save(a)
        Image.new('RGBA',(12,8),(0,255,0,0)).save(b)
        self.assertEqual(visual.compare_images(a,b,self.root/'same')['changed_pixels'],0)
        Image.new('RGBA',(12,8),(0,255,0,64)).save(b)
        result=visual.compare_images(a,b,self.root/'different',roi=(0,0,6,4))
        self.assertEqual(result['changed_pixels'],24)
        self.assertAlmostEqual(result['max_premultiplied_rgba_error_255'],64)

    def test_force_never_overwrites_source_image(self):
        manifest=self.frame_manifest()
        raw=self.root/'raw.png';raw.rename(self.root/'sheet.png')
        data=json.loads(manifest.read_text());data['frames'][0]['file']='sheet.png'
        manifest.write_text(json.dumps(data));before=(self.root/'sheet.png').read_bytes()
        with self.assertRaises(ValueError):visual.make_sheet(manifest,self.root,force=True)
        self.assertEqual(before,(self.root/'sheet.png').read_bytes())

    def test_cli_from_unrelated_cwd_and_paths_with_spaces(self):
        copy=self.root/'portable skill'/'scripts';copy.mkdir(parents=True)
        for name in ['motion_fit.py','visual_evidence.py','studio_check.py']:
            shutil.copyfile(SCRIPTS/name,copy/name)
        path=self.points(np.eye(3));output=self.root/'fit result.json'
        process=subprocess.run([sys.executable,str(copy/'motion_fit.py'),str(path),'--model','similarity',
                                '--output',str(output)],cwd=self.root,capture_output=True,text=True)
        self.assertEqual(process.returncode,0,process.stderr)
        self.assertTrue(output.exists())
        process=subprocess.run([sys.executable,str(copy/'studio_check.py')],cwd=self.root,capture_output=True,text=True)
        self.assertEqual(process.returncode,0,process.stderr)
        self.assertEqual(json.loads(process.stdout)['skill_root'],str(copy.parent))


if __name__=='__main__':
    unittest.main()
