"""Loss-preserving ASS field-edit contracts; no language or visual claims."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
import ass_tools


FIXTURE_TEXT = """[Script Info]\r
Title: Roundtrip fixture\r
[Unknown Section]\r
Keep: exactly,including,commas\r
[V4+ Styles]\r
Format: Name, Fontname, Fontsize\r
Style: Main,Arial,42\r
[Events]\r
Format: Layer, Start, End, Style, Actor, MarginL, MarginR, MarginV, Effect, Text\r
Comment: 0,0:00:01.00,0:00:02.00,Main,template,0000,0000,0000,kara,template line\r
Dialogue: 1,0:00:02.00,0:00:04.00,Main,A,0000,0000,0000,,Hello, with commas\r
Dialogue: 2,0:00:02.00,0:00:04.00,Main,A,0000,0000,0000,,Hello, with commas\r
"""
FIXTURE = b'\xef\xbb\xbf' + FIXTURE_TEXT.encode('utf-8')


class AssToolsContracts(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ass tools test ')
        self.root = Path(self.temp.name)
        self.source = self.root / 'source file.ass'
        self.source.write_bytes(FIXTURE)
        self.doc = ass_tools.Document.read(self.source)
        self.events = list(self.doc.events.values())

    def tearDown(self):
        self.temp.cleanup()

    def plan(self, event, allowed, updates, expect_updates=None, baseline=None):
        row = event.data()
        expect = {key: row[key] for key in ('Start', 'End', 'Style', 'Name', 'Text')}
        if expect_updates:
            expect.update(expect_updates)
        data = {
            'baseline_sha256': baseline or self.doc.sha256,
            'allowed_fields': allowed,
            'edits': [{'line': event.line, 'kind': event.kind, 'expect': expect, 'set': updates}],
        }
        path = self.root / 'plan.json'
        path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        return path

    def test_no_edit_roundtrip_is_byte_identical(self):
        self.assertEqual(self.doc.serialize(), FIXTURE)
        self.assertEqual(self.doc.bom, b'\xef\xbb\xbf')
        self.assertTrue(all(line.endswith('\r\n') for line in self.doc.lines))
        self.assertEqual(self.doc.events[self.events[0].line].data()['Name'], 'template')

    def test_name_only_patch_preserves_every_other_byte_and_event_kind(self):
        event = self.events[1]
        output = self.root / 'candidate.ass'
        result = ass_tools.patch(self.source, self.plan(event, ['Actor'], {'Actor': 'Speaker VI'}), output)
        self.assertTrue(result['scope_pass'])
        self.assertEqual(result['event_changes'], [{'line': event.line, 'kind': 'Dialogue', 'fields': ['Name']}])
        after = ass_tools.Document.read(output)
        self.assertEqual(after.events[self.events[0].line].kind, 'Comment')
        for index, (before_line, after_line) in enumerate(zip(self.doc.lines, after.lines), 1):
            if index != event.line:
                self.assertEqual(before_line, after_line)

    def test_text_may_contain_commas_and_duplicate_row_remains_distinct(self):
        event = self.events[1]
        output = self.root / 'text candidate.ass'
        value = 'Xin chào, vẫn giữ, nhiều dấu phẩy'
        ass_tools.patch(self.source, self.plan(event, ['Text'], {'Text': value}), output)
        after = ass_tools.Document.read(output)
        self.assertEqual(after.events[event.line].data()['Text'], value)
        self.assertEqual(after.events[self.events[2].line].data()['Text'], 'Hello, with commas')

    def test_unapproved_field_is_rejected(self):
        event = self.events[1]
        with self.assertRaisesRegex(ValueError, 'unapproved'):
            ass_tools.patch(self.source, self.plan(event, ['Name'], {'Text': 'No'}), self.root / 'bad.ass')

    def test_stale_baseline_hash_is_rejected(self):
        event = self.events[1]
        with self.assertRaisesRegex(ValueError, 'Baseline SHA256 differs'):
            ass_tools.patch(self.source, self.plan(event, ['Name'], {'Name': 'B'}, baseline='0' * 64), self.root / 'bad.ass')

    def test_wrong_expected_identity_is_rejected(self):
        event = self.events[1]
        with self.assertRaisesRegex(ValueError, 'Expected Text differs'):
            ass_tools.patch(self.source, self.plan(event, ['Name'], {'Name': 'B'}, {'Text': 'wrong row'}), self.root / 'bad.ass')

    def test_comma_in_non_text_field_is_rejected(self):
        event = self.events[1]
        with self.assertRaisesRegex(ValueError, 'Comma is invalid in Effect'):
            ass_tools.patch(self.source, self.plan(event, ['Effect'], {'Effect': 'one,two'}), self.root / 'bad.ass')

    def test_source_output_alias_is_rejected(self):
        event = self.events[1]
        before = hashlib.sha256(self.source.read_bytes()).hexdigest()
        with self.assertRaisesRegex(ValueError, 'distinct candidate'):
            ass_tools.patch(self.source, self.plan(event, ['Name'], {'Name': 'B'}), self.source)
        self.assertEqual(before, hashlib.sha256(self.source.read_bytes()).hexdigest())



    def test_lint_tags_detects_trailing_backslash_duplicate_pos_and_nested_t(self):
        bad_text = r"{\pos(100,200)\pos(300,400)\opacity50\t(0,200,\t(0,100,\blur2))\}Xin chào"
        res = ass_tools.lint_event_text(bad_text)
        issue_kinds = {item["issue"] for item in res["issues"]}
        self.assertIn("trailing_backslash_before_brace_close", issue_kinds)
        self.assertIn("duplicate_singleton_tag_in_block", issue_kinds)
        self.assertIn("hallucinated_override_tag", issue_kinds)
        self.assertIn("nested_transform_tag", issue_kinds)
        self.assertEqual(res["visible_text"], "Xin chào")

    def test_timing_qc_respects_1_to_n_cluster_immunity_and_flags_cut_bleed(self):
        sample_ass = """[Script Info]
PlayResX: 1920
PlayResY: 1080
[V4+ Styles]
Format: Name, Fontname, Fontsize
Style: Default,Arial,48
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:01.00,0:00:01.25,Default,Ichika,0,0,0,,Câu mở đầu nối tiếp...
Dialogue: 0,0:00:01.30,0:00:03.00,Default,Ichika,0,0,0,,phần hai của cùng lượt nói.
Dialogue: 0,0:00:05.00,0:00:05.20,Default,Kaito,0,0,0,,Chớp!
Dialogue: 0,0:00:05.26,0:00:07.05,Default,Remon,0,0,0,,Câu này kết thúc sát cảnh cắt.
"""
        doc = ass_tools.Document(sample_ass.encode("utf-8"))
        report = ass_tools.audit_timing(doc, styles="Default", cuts_ms=[7000])
        self.assertEqual(report["continuation_clusters_count"], 1)
        types_by_line = [(i["line"], i["type"]) for i in report["issues"]]
        # Line 9 (0:00:01.00 -> 0:00:01.25) is 250ms and has 50ms gap to line 10,
        # but because it is in a 1:N cluster for Ichika, neither flash_cue nor micro_gap is raised!
        self.assertNotIn((9, "flash_cue"), types_by_line)
        self.assertNotIn((9, "micro_gap"), types_by_line)
        # Line 11 (Kaito -> Remon) has both flash_cue (200ms) and micro_gap (60ms)
        self.assertIn((11, "flash_cue"), types_by_line)
        self.assertIn((11, "micro_gap"), types_by_line)
        # Line 12 ends at 7050ms, bleeding 50ms past the 7000ms cut
        self.assertIn((12, "cut_bleed_end"), types_by_line)

    def test_series_audit_detects_cross_episode_style_divergence(self):
        ep1 = self.root / "ep01.ass"
        ep2 = self.root / "ep02.ass"
        ep1.write_text(FIXTURE_TEXT, encoding="utf-8")
        ep2.write_text(FIXTURE_TEXT.replace("Style: Main,Arial,42", "Style: Main,Arial,54"), encoding="utf-8")
        report = ass_tools.audit_series([ep1, ep2])
        self.assertIn("Main", report["style_divergences_across_episodes"])
        self.assertEqual(report["episode_count"], 2)


if __name__ == '__main__':
    unittest.main()

class TestSyncFBF(unittest.TestCase):
    def test_sync_fbf_theorem_coverage(self):
        # Fixture with FBF line of duration 10ms (0.01s)
        text = """[Script Info]\r
Title: FBF Test\r
ScriptType: v4.00+\r
PlayResX: 1920\r
PlayResY: 1080\r
\r
[V4+ Styles]\r
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\r
Style: Default,Arial,20,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,2,2,10,10,10,1\r
\r
[Events]\r
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\r
Dialogue: 0,0:00:00.00,0:00:00.01,Default,,0,0,0,,Frame 0\r
Dialogue: 0,0:00:00.04,0:00:00.05,Default,,0,0,0,,Frame 1\r
"""
        with tempfile.TemporaryDirectory() as td:
            in_p = Path(td) / "in.ass"
            out_p = Path(td) / "out.ass"
            in_p.write_bytes(text.encode('utf-8'))
            
            doc = ass_tools.Document.read(str(in_p))
            res = ass_tools.sync_fbf_document(doc, offset_frames=3711, output_path=str(out_p))
            self.assertEqual(res['synced_events'], 2)
            
            out_doc = ass_tools.Document.read(str(out_p))
            # Verify frame 0: 3711 * 1001 / 24000 = 154.779625s -> pts_ms = 154780 ms -> st_cs = 15478 -> 2:34.78
            ev0 = out_doc.events[13]
            self.assertEqual(ev0.data()["Start"], "0:02:34.78")
            self.assertEqual(ev0.data()["End"], "0:02:34.79")
            ev1 = out_doc.events[14]
            self.assertEqual(ev1.data()['Start'], '0:02:34.82')
            self.assertEqual(ev1.data()['End'], '0:02:34.83')

            # Verify custom FPS (e.g. 25.0 fps: 100 frames = 4.00s)
            out_25 = Path(td) / "out25.ass"
            ass_tools.sync_fbf_document(doc, offset_frames=100, fps=25.0, output_path=str(out_25))
            doc_25 = ass_tools.Document.read(str(out_25))
            self.assertEqual(doc_25.events[13].data()['Start'], '0:00:04.00')
