import sys
from pathlib import Path
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
from typesetting_subs import TypesettingSubsClient, DEFAULT_PASSWORD

class TestTypesettingSubs(unittest.TestCase):
    def setUp(self):
        self.client = TypesettingSubsClient()

    def test_client_init_and_default_password(self):
        self.assertEqual(self.client.base_url, "https://subs.typesetting.cc")
        self.assertEqual(self.client.password, "SlothStationAlpha")
        self.assertIsNotNone(self.client.cj)

    def test_live_search_and_auth(self):
        # Live search test: should return results without prompting
        results = self.client.search("Kaguya")
        self.assertIsInstance(results, list)
        self.assertGreater(len(results), 0)
        found_titles = [r.get("title") for r in results]
        self.assertTrue(any("Kaguya" in t for t in found_titles))

    def test_live_anime_and_episode_lookup(self):
        # aid: 19701 is Chou Kaguya-hime
        data = self.client.get_anime_details(19701)
        self.assertEqual(data.get("aid"), 19701)
        eps = data.get("episodes", [])
        self.assertGreater(len(eps), 0)
        eid = eps[0]["eid"]
        
        # Test scripts listing
        scripts = self.client.get_episode_scripts(eid)
        self.assertIsInstance(scripts, list)
        self.assertGreater(len(scripts), 0)
        # Check script fields
        s0 = scripts[0]
        self.assertIn("fid", s0)
        self.assertIn("filename", s0)

if __name__ == '__main__':
    unittest.main()
