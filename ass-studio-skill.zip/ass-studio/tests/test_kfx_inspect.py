"""Behavioral contracts for the read-only KFX inventory."""
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
import kfx_inspect


HEADER = """[Script Info]\r
Title: KFX fixture\r
[V4+ Styles]\r
Format: Name, Fontname, Fontsize\r
Style: Romaji,Arial,42\r
[Events]\r
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\r
"""


class KfxInspectContracts(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='kfx inspect ')
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write(self, rows):
        path = self.root / 'source.ass'
        path.write_bytes(b'\xef\xbb\xbf' + (HEADER + ''.join(rows)).encode('utf-8'))
        return path

    def test_the0x_components_clock_and_hash_are_inventory_only(self):
        path = self.write([
            'Comment: 0,0:00:00.00,0:00:01.00,Romaji,,0,0,0,code once,remember = 1\r\n',
            'Comment: 0,0:00:00.00,0:00:01.00,Romaji,,0,0,0,template syl loop petals 3,petal\r\n',
            'Comment: 0,0:00:00.00,0:00:01.00,Romaji,,0,0,0,mixin syl,\\bord1\r\n',
            'Dialogue: 0,0:00:01.00,0:00:02.00,Romaji,,0,0,0,kara,{\\k40}ka{\\kf60}ra\r\n',
            'Dialogue: 0,0:00:01.00,0:00:02.00,Romaji,,0,0,0,fx,rendered\r\n',
        ])
        before = path.read_bytes()
        result = kfx_inspect.inspect_path(path)
        self.assertEqual(result['sha256'], hashlib.sha256(before).hexdigest())
        self.assertEqual(path.read_bytes(), before)
        self.assertEqual(result['counts']['component'], 3)
        self.assertEqual(result['component_classes'], {'code': 1, 'template': 1, 'mixin': 1})
        self.assertEqual(result['counts']['explicit_source'], 1)
        self.assertEqual(result['counts']['generated_fx'], 1)
        self.assertIn('the0x', result['dialect']['families_with_signals'])
        clock = result['karaoke_clocks'][0]
        self.assertEqual(clock['k_total_ms'], 1000)
        self.assertEqual(clock['k_minus_cue_ms'], 0)
        self.assertTrue(any(risk['code'] == 'generated_fx_present' for risk in result['risks']))

    def test_implicit_stock_source_and_nyaa_extensions_are_distinguished(self):
        path = self.write([
            'Comment: 0,0:00:00.00,0:00:01.00,Romaji,,0,0,0,template pre-line fxgroup demo,setup\r\n',
            'Comment: 0,0:00:00.00,0:00:01.00,Romaji,,0,0,0,template syl fbf recalculate shape allowempty,draw\r\n',
            'Dialogue: 0,0:00:02.00,0:00:03.50,Romaji,,0,0,0,,{\\kt20\\k30}one{\\ko40}two\r\n',
        ])
        result = kfx_inspect.inspect_path(path)
        self.assertEqual(result['counts']['implicit_source_candidate'], 1)
        self.assertEqual(result['karaoke_clocks'][0]['kt_offsets_ms'], [200])
        self.assertEqual(result['karaoke_clocks'][0]['k_total_ms'], 700)
        self.assertEqual(result['karaoke_clocks'][0]['k_minus_cue_ms'], -800)
        self.assertEqual(result['dialect']['families_with_signals'], ['nyaa', 'stock'])
        self.assertTrue(any(risk['code'] == 'mixed_dialect_signals' for risk in result['risks']))

    def test_overrun_and_mixin_without_template_are_visible(self):
        path = self.write([
            'Comment: 0,0:00:00.00,0:00:01.00,Romaji,,0,0,0,mixin syl,\\blur1\r\n',
            'Dialogue: 0,0:00:01.00,0:00:01.50,Romaji,,0,0,0,kara,{\\k80}long\r\n',
        ])
        result = kfx_inspect.inspect_path(path)
        codes = {risk['code'] for risk in result['risks']}
        self.assertIn('mixin_without_template', codes)
        self.assertIn('karaoke_clock_overrun', codes)
        self.assertEqual(result['karaoke_clocks'][0]['warning'], 'karaoke_duration_exceeds_cue')


if __name__ == '__main__':
    unittest.main()
