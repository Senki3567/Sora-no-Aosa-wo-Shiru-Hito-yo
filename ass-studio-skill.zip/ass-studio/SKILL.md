---
name: ass-studio
description: "Làm phụ đề ASS và dự án full-scale nhiều tập: typeset sign, tracking, karaoke, dịch ngược motion (reverse engineering), thuật toán Aegisub automation trên libass, OCR hardsub, căn EN–VI, dịch trực tiếp từ JP, kiểm toán tag/timing/font/series và triển khai toàn bộ series. Dùng khi công việc cần hiểu sâu cấu trúc ASS, override tags, font, đồ thị chuyển động khai báo hoặc kiểm chứng hình và timing; không dùng cho dịch một câu văn độc lập."
---

# ASS Studio

Làm ra phụ đề vừa đúng nội dung, đúng nhịp và đúng đường hình, vừa còn chỉnh sửa được — từ thao tác kỹ thuật sâu trên một file `.ass` đơn lẻ, tận dụng tối đa khả năng đồ họa softsub của `libass`, cho đến quản trị toàn bộ dự án phụ đề nhiều tập (Full-Scale Series Production). Đọc file hiện hành và footage thực tế trước khi quyết định; giữ nguồn, dữ liệu đo, đồ thị chuyển động (`scene.json`), hồ sơ bộ phim (`series_bible.json`) và generator/compiler đủ rõ để lần sau tiếp tục được.

## Làm việc qua harness và model khác nhau

Giải thư mục skill từ chính `SKILL.md` đang được runtime nạp, không hardcode đường dẫn Codex/Gemini hoặc giả định cwd là skill. Dùng công cụ file/shell/ảnh/audio thực được cấp; giữ nguồn và output trong workspace dự án. Khi đổi harness hoặc thiếu công cụ, đọc [harness-compatibility.md](references/harness-compatibility.md). `scripts/studio_check.py` khảo sát dependency tại chỗ; nó không chứng minh model đang nhìn/nghe được nội dung.

Trước khi chọn tool hay công thức, xác định câu hỏi chưa biết, nguồn nào có quyền trả lời câu hỏi đó, phần được sửa và phép thử nào phân xử được các nguyên nhân. Đọc [problem-solving.md](references/problem-solving.md) cho mọi việc nhiều bước hoặc chưa rõ nguyên nhân. Font/layout, KFX, timing, dịch, đồng bộ phiên bản và phát hành không dùng chung một phép đo; mỗi họ bài toán có nguồn và tiêu chí nghiệm thu riêng.

Riêng FX/typeset/motion vận hành theo kiến trúc **Agent Motion & Reverse Engineering** tại [agent-motion-architecture.md](references/agent-motion-architecture.md), [community-automation-algorithms.md](references/community-automation-algorithms.md) và [visual-reasoning.md](references/visual-reasoning.md):
- **Tách 4 vai trò nội tâm (4-Role Cognitive Loop)**: **Decomposer** (dịch ngược pha, cadence 1s/2s/3s, tách quỹ đạo bề mặt $\mathcal{T}_{\text{surface}}$ khỏi animation nội tại $\mathcal{T}_{\text{local}}$, khôi phục đường cong easing/quang học bằng `motion_studio.py probe` & `fit-curve`, trích xuất mask vật cản foreground qua VectorCraft và tracking bề mặt qua EffectCraft) $\rightarrow$ **Motion Architect** (xây dựng đồ thị chuyển động khai báo kiểu Remotion trong `scene.json` với đồng hồ kép, thiết kế vector/boolean trong VectorCraft và mô phỏng physics/rigs trong EffectCraft) $\rightarrow$ **Executor** (biên dịch bằng `motion_studio.py compile` hoặc `craft_bridge.py` sang multi-segment `\t` hoặc FBF không bao giờ bị restart `\t`/`\fad`, giải phối cảnh 3D `quad-to-ass3d`, chuyển vector `text-to-shape` / `svg-to-ass`, tạo dải `clip-gradient`, biến đổi hình học `transform-shape`, render `libass_render.py` và ghép `visual_evidence.py`) $\rightarrow$ **Perceptual Critic** (chấm 5 trục thị giác độc lập ở cả context rộng và crop native 1:1, kiểm chứng đối kháng kép so với frame render GPU 700ms từ EffectCraft).
- **Hội tụ đơn biến theo phân cấp (Hierarchical Coordinate Descent)**: Khóa *Temporal/Cadence* $\rightarrow$ *Surface Geometry* $\rightarrow$ *Glyph Layout & Mask* $\rightarrow$ *Local Easing* $\rightarrow$ *Photometric Blend & Performance*. Tuyệt đối không dùng lớp dưới (tăng `\blur`, làm to viền) để che lỗi lớp trên (trượt track, lộ chữ gốc), và lưu mọi giả thuyết đã bác bỏ vào `falsified_hypotheses` trong `scene.json` để chống lặp lỗi qua nhiều vòng.

## Bắt đầu từ yêu cầu và bản hiện hành

Xác định file người dùng chỉ định, video liên quan, bản nguồn editable, effect đã sinh, font và quy định dự án. Không mặc định một file backup hoặc báo cáo có chữ “final” là bản mới nhất. Ghi hash bản đang chỉnh; đọc lại trước khi ghi nếu người dùng có thể đang sửa trong Aegisub.

Chốt phạm vi từ yêu cầu: đọc và báo lỗi; chỉ ghi Effect; sửa Text; sửa timing; sửa style; tạo sign/effect; xuất hoặc triển khai. “Chỉ check” không cho phép sửa file. “Effect-only” nghĩa là giữ nguyên mọi trường khác, line type, thứ tự, BOM và newline. Quyết định sáng tạo thông thường nằm trong phạm vi đã giao; đừng tự dựng thêm vòng xin xác nhận.

Không suy đoán thoại/sign chỉ từ một tên style hay Actor. Đọc loại event, Text, override, vai trò trong cảnh và các dòng kề. Các event đang hát, shape và source comment có thể cùng dùng một style.

## Chọn tài liệu theo việc đang làm

| Công việc | Đọc |
|---|---|
| Giải phẫu thuật toán Automation cộng đồng (`arch.Perspective`, `ILL/Shapery`, `Gradient Everything`, `Vector Gradient`, `Inner Glow`, `libass` internals) | [community-automation-algorithms.md](references/community-automation-algorithms.md) |
| Quản trị dự án phụ đề full-scale (nhiều tập), 5 tầng kỹ thuật của 1 file `.ass`, `series_bible.json` và cổng kiểm toán tự động | [full-scale-series-production.md](references/full-scale-series-production.md) |
| Kiến trúc vận hành Agent Motion, 4 vai trò, dịch ngược video (Reverse Engineering), Declarative Motion IR và chấm 5 trục | [agent-motion-architecture.md](references/agent-motion-architecture.md) |
| Chọn phương pháp theo bản chất vấn đề, nguồn bằng chứng và phép thử quyết định | [problem-solving.md](references/problem-solving.md) |
| Chọn công cụ/discovery theo Codex, Claude Code, OpenCode, Antigravity hoặc harness khác | [harness-compatibility.md](references/harness-compatibility.md) |
| Suy FX/motion từ raw; chọn phép đo, thử giả thuyết, khoanh nguyên nhân lỗi hình | [visual-reasoning.md](references/visual-reasoning.md) |
| Camera đổi góc/scale, nhiều lớp bám một mặt, lỗi phối cảnh/độ hòa cảnh hoặc đổi neo trên track đã chốt | [perspective-motion.md](references/perspective-motion.md) |
| Fit transform theo frame từ landmark đã đo, residual, outlier và frame thiếu | [motion-measurement.md](references/motion-measurement.md) |
| Giữ `scene.json` v2 (`motion_graph`, `iteration_history`, `falsified_hypotheses`) để sửa tiếp bằng prompt hoặc chuyển harness | [scene-contract.md](references/scene-contract.md) |
| Đánh giá độ phủ và chất lượng prompt toàn workflow | [workflow-evals.md](references/workflow-evals.md); phần hình chuyên sâu ở [visual-evals.md](references/visual-evals.md) |
| Dựng một bản sub từ nguồn đến bản giao; chọn thứ tự việc và tiêu chí qua bước | [production-workflow.md](references/production-workflow.md) |
| Time thoại hoặc karaoke từ audio, scene cut và frame thực; kiểm toán CPS/flash/gap/cut-bleed | [timing-practice.md](references/timing-practice.md) |
| Tìm, phân loại, thử và kiểm toán độ phủ glyph dấu tiếng Việt / đính kèm `[Fonts]` | [font-selection.md](references/font-selection.md) |
| Chọn Karaoke Templater, Blender/AAE export hay generator/compiler riêng | [automation-tooling.md](references/automation-tooling.md) |
| Viết/chạy KFX bằng Templater gốc, karaOK hoặc The0x539; kiểm cú pháp, clock và `fx` | [kfx-templater-compatibility.md](references/kfx-templater-compatibility.md) |
| Chạy Automation macro cộng đồng bằng aegisub-cli; kiểm fork, tham số, giới hạn và output | [aegisub-cli.md](references/aegisub-cli.md) |
| Hiểu hoặc sửa cấu trúc, AST override tags, style, font, section | [ass-model.md](references/ass-model.md) |
| Xem raw, lấy frame, xác định PTS/cut/audio/grade | [video-evidence.md](references/video-evidence.md) |
| Làm sign, đo layout, tracking, masking, perspective, blur | [typesetting-tracking.md](references/typesetting-tracking.md) |
| Tích hợp VectorCraft (vẽ/convert vector sign/clip \p1) & EffectCraft (motion tracking/keyframe/render frame) | [craft-apps-integration.md](references/craft-apps-integration.md) |
| Track Blender → AAE → Aegisub-Motion; so frame, smoothing, Power Pin và option nhập | [blender-aae-motion.md](references/blender-aae-motion.md) |
| Làm FX sign nhiều lớp, mask/fade, glow, shape và FBF | [sign-fx-recipes.md](references/sign-fx-recipes.md) |
| Karaoke, thiết kế intro/highlight/outro, glyph, timing | [karaoke-design.md](references/karaoke-design.md) |
| Dịch, căn EN/VI/JP, xưng hô, lời lặp giữa các tập, ngắt dòng theo chiều rộng pixel libass | [dialogue-localization.md](references/dialogue-localization.md) |
| QC hoặc chỉnh một số trường với bằng chứng rõ | [field-edits-qc.md](references/field-edits-qc.md) |
| Render softsub, tối ưu, đo cache và bitmap | [render-performance.md](references/render-performance.md) |
| Triển khai qua tập, fold, render encode, Git/LFS | [delivery-projects.md](references/delivery-projects.md) |
| Dựng font từ footage, glyph và dấu tiếng Việt | [font-reconstruction.md](references/font-reconstruction.md) |
| Gọt shape, chiếu vector `\p1` qua ma trận (`transform-shape`), Declarative Motion IR, FBF và ngoại suy fade/blur | [geometry-animation.md](references/geometry-animation.md) |
| Playback lệch/drop hoặc trim/apply thừa frame | [playback-diagnostics.md](references/playback-diagnostics.md) |
| Chạy OCR hardsub từ extraction tới PR/rescue/export | [ocr-workflow.md](references/ocr-workflow.md), [ocr-source-preservation.md](references/ocr-source-preservation.md) |
| Chạy căn EN-VI và xuất Full.vi.ass | [alignment-workflow.md](references/alignment-workflow.md), [map schema](references/alignment/map_schema.md) |
| Dịch trực tiếp JP thành bản riêng có trans note | [direct-japanese-workflow.md](references/direct-japanese-workflow.md) |
| So phiên bản, sync Text/Effect, stable grouping, audit đồng bộ nhiều tập và dọn tag | [version-sync-organization.md](references/version-sync-organization.md) |
| Gradient/chu kỳ palette và migration matrix màu | [color-palette-validation.md](references/color-palette-validation.md) |
| Biên dịch lyric, khôi phục/đổi font và layout karaoke | [lyrics-layout-retargeting.md](references/lyrics-layout-retargeting.md) |
| Audit theo lượt, delegation khi được phép và ghi chú đúng phạm vi | [multi-agent-qc.md](references/multi-agent-qc.md) |
| Cần bài học từ Houseki, OCR, OP/ED và các chat khác | [cross-project-evidence.md](references/cross-project-evidence.md) |
| Tìm bài học và nguồn từ các chat của repo | [history-evidence.md](references/history-evidence.md) |
| Cần ví dụ thực tế và các lỗi từng gặp | [worked-cases.md](references/worked-cases.md) |

Đọc phần liên quan khi cần; không nạp tất cả tài liệu cho một chỉnh sửa nhỏ. Các workflow OCR/căn/dịch đã tích hợp đầy đủ bên trong skill. Không cần gọi skill bên ngoài; nếu người dùng chỉ định một phiên bản workflow khác, giữ đúng hợp đồng của phiên bản họ chọn.

## Cách tiến hành

- Với sign/effect mới hoặc dịch ngược từ raw: khảo sát footage đủ đầu-giữa-cuối và điểm chuyển pha; dùng `motion_studio.py probe` đo cadence (1s/2s/3s), tách motion bề mặt khỏi animation nội tại và dùng `motion_studio.py fit-curve` khôi phục hàm tiến triển (`linear`, `power`/`accel`, `cubic-bezier`, `spring`, `step`); biên dịch qua `motion_studio.py compile`, `quad-to-ass3d`, `text-to-shape`, `clip-gradient` hoặc `transform-shape` trên một đoạn đại diện; render chữ/font/tag thật trên video và chấm đủ 5 trục Perceptual Critic; rồi mới nhân rộng. Không thay thế thiết kế bằng các hiệu ứng trang trí mặc định.
- Với vẽ vector phức tạp, logo sign và motion tracking nâng cao: khai thác bộ đôi MCP/CLI VectorCraft & EffectCraft (đã tích hợp qua `mcp_config.json` và `scripts/craft_bridge.py`). Dùng VectorCraft vẽ đường bao Bézier, nắn shape hoặc convert SVG/AI sang chuỗi vẽ ASS `\p1`; dùng EffectCraft để dựng comp tracking, tính toán keyframe chuyển động (vị trí, xoay, scale, opacity) rồi xuất sang ASS FBF hoặc `\t` qua `craft_bridge.py keyframes-to-ass`, và gọi `render_frame` để lấy ảnh kiểm chứng thị giác tức thì. Đọc [craft-apps-integration.md](references/craft-apps-integration.md).
- Với tracking phối cảnh: xác định bề mặt và quan sát đủ ràng buộc vị trí, hai chiều kích thước và biến dạng; dùng `motion_studio.py quad-to-ass3d` để giải chính xác bộ tag 3D nội bộ của `libass` ($d = 312.5$, thứ tự quay $Y \leftarrow X \leftarrow Z$, shear trước scale) hoặc dùng `text-to-shape` + `transform-shape` khi mặt phẳng nghiêng gắt. Đọc [community-automation-algorithms.md](references/community-automation-algorithms.md) và [perspective-motion.md](references/perspective-motion.md).
- Với kiểm toán kỹ thuật sâu trên 1 file `.ass`: chạy `ass_tools.py lint-tags` để bắt lỗi cú pháp tag (`\}`, ngoặc lẻ, `\t` lồng nhau, tag tĩnh trùng lặp); chạy `ass_tools.py timing-qc` để kiểm CPS, flash, micro-gap và cut-bleed có miễn nhiễm cụm tách $1:N$; chạy `ass_tools.py font-audit` để xác minh tên family nội bộ, độ phủ glyph tiếng Việt và giải mã `[Fonts]`; chạy `scan_layout_overflow.py` để đo chiều rộng pixel thực tế qua libass.
- Với dự án full-scale nhiều tập: duy trì `series_bible.json` (ma trận xưng hô có hướng theo giai đoạn, glossary thuật ngữ, sổ đăng ký khối OP/ED/Sign dùng chung) và chạy `ass_tools.py series-audit` để phát hiện lệch Style, PlayRes, YCbCr Matrix hoặc Actor giữa các tập. Đọc [full-scale-series-production.md](references/full-scale-series-production.md).
- Với chỉnh sửa có giới hạn: chọn đúng event, ghi giá trị trước và sau, thay đúng trường, so phần không được phép thay. Cú pháp hợp lệ hoặc số cue đúng chỉ là kiểm tra cấu trúc.
- Với thoại và ngắt dòng: quyết định nghĩa từ lời và ngữ cảnh; timing chỉ khoanh ứng viên. Xem quan hệ nhân vật, câu trước/sau, các nguồn và audio nếu có; không dùng biểu cảm hình để giả làm bằng chứng âm thanh.
- Với bản đã duyệt: sửa theo yêu cầu mới trên chính baseline đó. Không rebuild từ nguồn cũ nếu nó có thể xóa chỉnh sửa đã duyệt. Nếu cần generator/compiler, sửa cấu hình nguồn và chứng minh bản sinh ra bảo toàn phần đã chốt.
- Với audit nhiều tập: khóa checksum baseline, rà ngữ nghĩa/timing/asset và phản biện kết luận; làm tuần tự hoặc dùng delegation khi harness hỗ trợ và được phép. Chọn ghi chú theo yêu cầu người dùng (báo cáo, Actor, Effect hoặc Comment); không tự chèn event hay style dự án khác. Xem [multi-agent-qc.md](references/multi-agent-qc.md).
- Với sửa chữ trên dải màu ký tự (ED/OP): giữ gradient/control points và mapping glyph của thiết kế hiện hành. Nếu cần nội suy lại, dùng phương pháp/không gian màu phù hợp bản đã duyệt, kiểm dấu Việt và render; không mặc định mọi gradient đều tuyến tính RGB.
- Với dọn dẹp asset/style/fade: kiểm usage và quyền sửa trước; đối chiếu `[Fonts]` với font thực dùng và thư mục repo. Các giá trị `0` hoặc layer/shape có chủ đích phải được xét theo hình và nguồn, không đồng bộ hàng loạt theo tên style.

Giữ hai đồng hồ riêng khi cần: nhịp nội dung đã time (đặc biệt karaoke) và thời gian hiện/di chuyển/biến mất. Chữ đã ổn định có thể bắt đầu hát trong khi các chữ sau còn đi vào; không ép cả dòng đợi một trigger chung nếu điều đó làm intro chạy quá nhanh.

## Ba workflow ngôn ngữ đã tích hợp

| Mode | Nguồn câu chữ | Khung/output | Invariant riêng |
|---|---|---|---|
| OCR hardsub | Chữ Việt có chứng cứ từ ảnh/OCR/rescue | ASS source → `_vi.ass` mới | Không dịch lại theo EN; technical failure không là missing |
| Căn EN-VI và biên tập | VI đã có, JP xác minh nghĩa và phần cần hiệu đính | Cue EN → `.Full.vi.ass` | Tìm mẩu VI theo nghĩa; giữ EN ẩn/provenance của exporter |
| Trực dịch JP | JP + ngữ cảnh | Khung Full → `.vi.from-jp.ass` riêng | Không dùng Text Full làm nguồn dịch; mọi cue thoại có trans note |

Đừng trộn quyền biên tập của mode căn/dịch vào OCR-only. Chọn mode từ yêu cầu và nguồn; việc user đã chỉ rõ style/tập/output không cần thêm vòng xác nhận. Với nhiều đầu ra, hoàn tất và kiểm chứng Full trước khi tạo bản JP riêng. Chạy command từ thư mục skill hoặc dùng đường dẫn script tương ứng nơi cài; các bản dùng trên Codex, Claude Code, OpenCode, Antigravity và bản giải nén đều dùng cùng tài nguyên tương đối; capability thực tế cần kiểm theo phiên.

## Công cụ đi kèm

Từ thư mục skill, chạy Python 3; không cần sửa repository để dùng các helper.

```bash
python3 scripts/ocr_worker.py --help
python3 scripts/alignment/sub_align.py --help
python3 scripts/ass_tools.py inspect /path/to/file.ass
python3 scripts/ass_tools.py lint-tags /path/to/file.ass
python3 scripts/ass_tools.py timing-qc /path/to/file.ass --styles Default,Alt --cuts-ms 12040 24100
python3 scripts/ass_tools.py font-audit /path/to/file.ass --font-dir /path/to/Fonts
python3 scripts/ass_tools.py series-audit /path/to/ep01.ass /path/to/ep02.ass
python3 scripts/ass_tools.py sync-fbf /path/to/source.ass --offset-frames 3711 --output /path/to/synced.ass
python3 scripts/typesetting_subs.py login --password <PASS>
python3 scripts/typesetting_subs.py search Kaguya
python3 scripts/typesetting_subs.py download /sub/123.ass --output-dir /path/to/subs
python3 scripts/ass_tools.py patch /path/to/file.ass /path/to/plan.json --output /path/to/candidate.ass
python3 scripts/ass_tools.py compare /path/to/before.ass /path/to/after.ass --allowed-fields Effect
python3 scripts/kfx_inspect.py /path/to/karaoke.ass
python3 scripts/scan_layout_overflow.py /path/to/file.ass --font-dir /path/to/Fonts --json /path/to/overflow.json
python3 scripts/video_frames.py /path/to/video.mkv --frames 2799 2800 2801 --output /path/to/frames
python3 scripts/motion_fit.py /path/to/points.csv --model similarity --threshold-px 1.5 --output /path/to/track.json
python3 scripts/motion_studio.py probe /path/to/frames/frames.json --roi 100 80 600 320 --track /path/to/track.json --output /path/to/probe.json
python3 scripts/motion_studio.py fit-curve /path/to/series.json --output /path/to/curve.json
python3 scripts/motion_studio.py compile /path/to/motion_spec.json --output-report /path/to/compiled.json --output-ass /path/to/events.ass
python3 scripts/motion_studio.py quad-to-ass3d --quad 520 410 841.52 343.37 995.14 439.56 580.18 484.71 --ref-size 200 100 --org 480 390
python3 scripts/motion_studio.py text-to-shape --text "Đêm Hè" --font /path/to/font.ttf --fontsize 64
python3 scripts/motion_studio.py clip-gradient /path/to/gradient_spec.json --output-ass /path/to/grad.ass
python3 scripts/motion_studio.py transform-shape --drawing "m 0 0 l 100 0 100 50 0 50 c" --matrix 1 0 10 0 1 20 0 0 1 --p-scale 1
python3 scripts/motion_studio.py extrapolate-track /path/to/series.json --count 10 --direction end
python3 scripts/motion_studio.py wobble /path/to/wobble_spec.json
python3 scripts/motion_studio.py wave /path/to/wave_spec.json
python3 scripts/motion_studio.py path-motion /path/to/path_spec.json
python3 scripts/motion_studio.py envelope-warp --drawing "m 0 0 l 150 0 150 75 0 75 c" --grid-json /path/to/grid.json
python3 scripts/libass_render.py /path/to/file.ass --font-dir /path/to/Fonts --size 1920x1080 --times-ms 116742 116783 116980 --png-dir /path/to/rgba --report /path/to/render.json
python3 scripts/craft_bridge.py check
python3 scripts/craft_bridge.py svg-to-ass /path/to/mask.svg --format clip
python3 scripts/craft_bridge.py extract-keyframes --project /path/to/sign.ecproj --layer "SignText" --start-s 0.0 --end-s 2.0 --fps 23.976 --output /path/to/track_data.json
python3 scripts/craft_bridge.py keyframes-to-ass /path/to/track_data.json --mode fbf --fps 23.976 --style Sign_Motion --text "TYPESET_SIGN"
python3 scripts/craft_bridge.py render-compare /path/to/candidate.ass --time-s 1.0 --ec-png /path/to/ec_ref.png --output /path/to/diff_out
python3 scripts/visual_evidence.py times /path/to/frames.json
python3 scripts/visual_evidence.py sheet /path/to/frames.json --render-report /path/to/render.json --output /path/to/evidence
python3 scripts/studio_check.py
```

`scripts/ocr_worker.py` chứa extraction/checkpoint/Gemini/rescue/PR/export; cần ffmpeg/ffprobe và Pillow, key/model allowlist ở cấu hình riêng. `scripts/alignment/sub_align.py` cùng parser/mapping đi kèm chạy bằng thư viện chuẩn; có regression suite `scripts/alignment/test_sub_align.py`. JP là workflow dịch/ngữ cảnh do agent thực hiện, không có script tự suy nghĩa.

`ass_tools.py` dùng thư viện chuẩn (và tự động tận dụng `fontTools` khi chạy `font-audit`), giữ nguyên những dòng không đổi, bảo vệ section `[Fonts]` khỏi bị cắt nhầm bởi dòng uuencode bắt đầu bằng `[`, kiểm tra baseline trước khi ghi candidate, kết nối trực tiếp kho phụ đề https://subs.typesetting.cc qua CLI  và MCP server  để tìm kiếm/tải ASS fansub tự động, đồng thời cung cấp các bộ kiểm toán chuyên sâu: `lint-tags` (cú pháp override tag), `timing-qc` (CPS, flash, micro-gap, scene-cut bleed với miễn nhiễm cụm 1:N), `font-audit` (đối chiếu tên family nội bộ, độ phủ glyph tiếng Việt và giải mã `[Fonts]`), và `series-audit` (đối chiếu nhất quán Style/PlayRes/Matrix/Actor qua nhiều tập). `scan_layout_overflow.py` dùng `libass` để đo chính xác chiều rộng pixel unwrapped (`WrapStyle: 2`) của từng dòng so với lề hiệu dụng (`PlayResX - MarginL - MarginR`) và gợi ý vị trí ngắt dòng. `video_frames.py` dùng ffmpeg/ffprobe để lấy đúng chỉ số frame bằng một lần giải mã từ đầu; đọc giới hạn chi phí trong tài liệu video. `libass_render.py` cần libass hệ thống; NumPy/Pillow chỉ cần khi xuất PNG. Render này là overlay và đo CPU, không thay cho kiểm tra composite trên footage hoặc playback thực tế.

`kfx_inspect.py` chỉ kiểm kê source/component/output, dấu hiệu dialect và clock `\k`; nó không chạy Lua, không quyết định template đúng hình và không tự nhận quyền xoá các dòng `fx`. Dùng report để chọn đúng implementation và fixture trước khi gọi Aegisub/Aegisub CLI.

`motion_fit.py` cần NumPy, nhận landmark native đã đo rồi fit từng frame; không tự track ảnh hoặc sinh tag perspective. `motion_studio.py` cần NumPy, Pillow và `fontTools`: `probe` trích xuất tín hiệu định lượng từ chuỗi frame trong ROI (phát hiện cadence 1s/2s/3s, khử trôi bề mặt theo `track.json`, đo bbox/centroid, tiến trình luminance/alpha và độ rộng biên ngang/dọc để phân biệt Gaussian blur với directional motion blur); `fit-curve` khôi phục hàm easing (`linear`, `power`/`accel`, `cubic-bezier`, `spring`, `step`) và xấp xỉ thành các đoạn `\t`; `compile` nhận đặc tả Declarative Motion IR, kiểm tra ràng buộc đồng hồ kép (`settled_by_ms <= sung_start_ms`) và biên dịch ra native multi-segment `\t` hoặc FBF được tính giá trị theo PTS tuyệt đối; `quad-to-ass3d` phân rã tứ giác 4 góc thành bộ tag phối cảnh 3D chuẩn của `libass` ($d=312.5$); `text-to-shape` chuyển văn bản và font sang đường vẽ `\p1`; `clip-gradient` sinh dải gradient cắt lát hình chữ nhật có tách lớp viền chống sọc; `transform-shape` chiếu trực tiếp chuỗi vector drawing `\p1..\p4` qua ma trận đồng nhất $3\times 3$; `extrapolate-track` ngoại suy quỹ đạo tracking bằng đa thức k-fold cross-validation khi sign ra khỏi khung/fade; `wobble` sinh rung lắc/dao động tắt dần/jiggle gelatin; `wave` tạo sóng chuyển động kèm góc nghiêng tiếp tuyến `\frz` theo từng ký tự; `path-motion` cho chữ/vật thể di chuyển dọc theo đường cong spline vector bất kỳ với góc tiếp tuyến tự động; `envelope-warp` uốn cong vector shape theo lưới Coons/Bézier bicubic 4x4 cho cờ bay/ống trụ. `visual_evidence.py` cần Pillow (thêm NumPy cho RGBA diff), ghép raw-overlay theo timestamp, tạo sheet và lưu mapping crop/resize; không tự chấm thiết kế. `studio_check.py` dùng thư viện chuẩn, chỉ khảo sát môi trường. Xem [agent-motion-architecture.md](references/agent-motion-architecture.md), [community-automation-algorithms.md](references/community-automation-algorithms.md), [full-scale-series-production.md](references/full-scale-series-production.md), [motion-measurement.md](references/motion-measurement.md) và [visual-reasoning.md](references/visual-reasoning.md) trước khi dùng các số đo để chốt sign.

## Kết quả và kiểm chứng

Bàn giao theo yêu cầu: ASS đã sửa; nguồn editable (`scene.json` + generator/compiler config) cho effect sinh; hoặc bản render. Với công việc phức tạp, giữ một manifest ngắn gồm input/hash, offset/đơn vị, font, phạm vi thay, bản đầu ra và bằng chứng render. Báo rõ phần đã kiểm chứng và giới hạn còn lại.

Xem chữ thật trên video ở mốc quan trọng và qua quỹ đạo; kiểm tra đủ 5 trục của Perceptual Critic (`spatial_alignment`, `temporal_easing`, `mask_occlusion`, `photometric_blend`, `vietnamese_typography`). Đừng kết luận khớp chỉ từ một centroid, shape tracking, alpha MSE hay một ảnh đầu dòng. Khi render target khác libass, kiểm tra thêm trên target đó trước khi hứa tương thích.

Tên style, vị trí OP trong danh sách event, một hay hai dòng dịch, số language và kiểu effect là lựa chọn của dự án/người dùng. Các ví dụ trong worked-cases không tự áp đặt `Sign-CưongwtBas`, `OP - Sign`, bỏ Kanji, filmstrip hay biên độ rung lên dự án mới.

Nguồn và các khác biệt tích hợp được ghi ở [integration-sources.md](references/integration-sources.md). Các số đo lịch sử không thay việc kiểm chứng input/output của lần chạy mới.

Các tài liệu cộng đồng mới được đối chiếu ở [research-sources.md](references/research-sources.md). Đọc nguồn đúng phiên bản khi một chức năng phụ thuộc công cụ/renderer; liên kết không truy cập được không được xem là bằng chứng cho quy tắc kỹ thuật.
